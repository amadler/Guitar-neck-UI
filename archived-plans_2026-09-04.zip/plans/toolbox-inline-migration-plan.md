# Migration Plan: Inline guitar-toolbox-lib into GNUI

## Rationale

The `guitar-toolbox-lib` external library has been reduced to **3 source files** (~450 lines total):

| File | Lines | Purpose |
|------|-------|---------|
| `toolbox.builder.component.ts` | ~107 | Main toolbox UI component |
| `toolbox.builder.component.html` | ~128 | Template (sentence-style UI) |
| `toolbox.builder.component.scss` | ~165 | Styles |
| `dropdown.component.ts` | ~145 | Reusable dropdown (inline template + styles) |
| `model.ts` | ~49 | Types: `FretboardCommand`, `MusicKey`, `Interval`, etc. |

The overhead of maintaining a separate Angular library project (separate `angular.json` project entry, `ng-packagr` build, `peerDependencies`, `package-lock.json`, build pipeline, path mapping in `tsconfig.json`, `preserveSymlinks` in `angular.json`) **outweighs the value** of 3 small files consumed by a single application.

**Decision:** Move the 3 source files directly into `src/app/toolbox/` inside GNUI.

---

## Step-by-step Plan

### Step 1 — Create `src/app/toolbox/` directory and copy source files

Copy these files from `../guitar-toolbox/projects/guitar-toolbox-lib/src/lib/toolbox-forms/`:

```
toolbox-forms/
  toolbox-forms/toolbox.builder/
    model.ts                          → src/app/toolbox/model.ts
    toolbox.builder.component.ts      → src/app/toolbox/toolbox-builder.component.ts
    toolbox.builder.component.html    → src/app/toolbox/toolbox-builder.component.html
    toolbox.builder.component.scss    → src/app/toolbox/toolbox-builder.component.scss
    toolbox.builder.component.spec.ts → src/app/toolbox/toolbox-builder.component.spec.ts
  dropdown/
    dropdown.component.ts             → src/app/toolbox/dropdown.component.ts
    dropdown.component.spec.ts        → src/app/toolbox/dropdown.component.spec.ts
```

**File renames** (Angular convention: kebab-case file names):
- `toolbox.builder.component.ts` → `toolbox-builder.component.ts`
- `toolbox.builder.component.html` → `toolbox-builder.component.html`
- `toolbox.builder.component.scss` → `toolbox-builder.component.scss`
- `toolbox.builder.component.spec.ts` → `toolbox-builder.component.spec.ts`

**Changes needed inside copied files:**

1. **`toolbox-builder.component.ts`** — update imports:
   - `import { FretboardCommand, MusicKey, ShowKind, ToolboxIntent, Interval } from './model';` (was `'./model'` — stays the same since model.ts is in same dir)
   - `import { DropdownComponent } from './dropdown.component';` (was `'../../dropdown/dropdown.component'`)

2. **`toolbox-builder.component.spec.ts`** — update imports:
   - `import { ToolboxBuilderComponent } from './toolbox-builder.component';` (kebab-case)
   - `import { ShowScaleCommand, CompareCommand, ShowIntervalCommand } from './model';`

3. **`dropdown.component.spec.ts`** — no import changes needed (self-contained)

4. **`model.ts`** — no changes needed (pure type definitions)

5. **`dropdown.component.ts`** — no import changes needed (self-contained, no external deps)

---

### Step 2 — Update `home-page.component.ts`

**File:** `src/app/home-page/home-page.component.ts`

Changes:
- Line 16: `import { FretboardCommand } from 'guitar-toolbox-lib';` → `import { FretboardCommand } from '../toolbox/model';`
- Line 17: `import { ToolboxBuilderComponent } from 'guitar-toolbox-lib';` → `import { ToolboxBuilderComponent } from '../toolbox/toolbox-builder.component';`

---

### Step 3 — Remove `tsconfig.json` path mapping

**File:** `tsconfig.json`

Remove lines 25-27:
```json
"paths": {
  "guitar-toolbox-lib": ["../guitar-toolbox/dist/guitar-toolbox-lib"]
}
```

---

### Step 4 — Remove `package.json` dependency

**File:** `package.json`

Remove line 26:
```json
"guitar-toolbox-lib": "file:../guitar-toolbox/dist/guitar-toolbox-lib",
```

Then run `npm install` to clean up `node_modules` and `package-lock.json`.

---

### Step 5 — Remove `preserveSymlinks` from `angular.json`

**File:** `angular.json`

Remove line 35:
```json
"preserveSymlinks": true
```

This was only needed for the path-mapped external library.

---

### Step 6 — Update tests

1. **`toolbox-builder.component.spec.ts`** — already adapted in Step 1 (import paths updated)
2. **`dropdown.component.spec.ts`** — already adapted in Step 1 (no changes needed)
3. **`home-page.component.spec.ts`** — verify it still works; the component import is now relative instead of from `guitar-toolbox-lib`, but the test should not need changes since it imports `HomePageComponent` which handles its own deps.

Run `npm test` to verify all tests pass.

---

### Step 7 — Cleanup and verify build

1. Run `npm run build` to verify the app compiles without errors
2. Run `npm test` to verify all tests pass
3. Optionally: remove the `../guitar-toolbox` directory if no longer needed (or keep as backup)

---

### Step 8 — Documentation

Update any docs that reference `guitar-toolbox-lib`:
- `ARCHITECTURE.md` — remove references to external toolbox library
- `API_DOCUMENTATION.md` — if it mentions toolbox endpoints
- `BACKLOG.md` — if any backlog items reference the library

---

## Rollback Plan

If something goes wrong:

1. **Revert** `tsconfig.json` — restore the `paths` mapping
2. **Revert** `package.json` — restore the `guitar-toolbox-lib` dependency
3. **Revert** `angular.json` — restore `preserveSymlinks: true`
4. **Revert** `home-page.component.ts` — restore imports from `'guitar-toolbox-lib'`
5. Run `npm install` to reinstall the dependency
6. Delete `src/app/toolbox/` directory
7. Verify build with `npm run build`

---

## Future Considerations

- The `DropdownComponent` is a generic reusable component. If another part of GNUI needs a dropdown, it's now available locally at `src/app/toolbox/dropdown.component.ts`.
- The `model.ts` types (`FretboardCommand`, `MusicKey`, etc.) are now part of the app's shared types. Consider moving `MusicKey` and `Interval` to `src/app/shared/model/` if they're used elsewhere.
- The `guitar-neck-shared` dependency remains in `package.json` — it was a peer dependency of the library but is now a direct dependency of the app (it already was, since `guitar-neck-shared` is listed in `package.json` dependencies).