# Plan: Fix enharmonic handling across the codebase

## Root cause

`neckConfig.chromaticNotes` uses only **sharps** (`C#`, `D#`, `F#`, `G#`, `A#`), but Tonal.js returns **flat spellings** (`Db`, `Eb`, `Gb`, `Ab`, `Bb`) via `simplify()`. String comparison `'Eb' === 'D#'` fails even though they're the same pitch.

## All affected paths

### Path A — `handleShowInterval()` → no interval color (the reported bug)

```
handleShowInterval()          home-page.component.ts:90
  → hardcoded sharp chromatic → computes D# for b3 from C
  → displayCustomPattern(['C', 'D#'], 'C')
  → markIntervals()           music-theory-facade.service.ts:201
    → distance('C', 'D#')     Tonal returns '2A' (augmented 2nd)
    → INTERVAL_MAP['2A']      undefined → interval = '' → no CSS class → no color
```

**Fix needed**: `handleShowInterval()` must produce spelling-correct note names so Tonal's `distance()` returns the expected interval name (`'3m'` for `b3`, not `'2A'`).

### Path B — `displayScale()` / `displayChord()` → missing fretboard positions (backlog bug)

```
resolveScaleNotes() / resolveChordNotes()   music-theory-facade.service.ts:117,139
  → Tonal returns ["C", "Eb", "G"] for Cm
  → simplify() converts to ["C", "Eb", "G"]
  → findPositionsByScaleNotes(["C", "Eb", "G"])   note.service.ts:51
    → filter(note => scaleNotes.includes(note.note))
    → "Eb" !== "D#" → Cm shows only C and G, missing Eb
```

**Fix needed**: `findPositionsByScaleNotes()` must compare by pitch class, not string.

### Path C — `displayScaleWithChord()` → `MarkerRoleService.computeRoles()` → wrong roles

```
displayScaleWithChord()        music-theory-facade.service.ts:68
  → stores simplifiedScaleNotes (flat spellings from Tonal) in scaleChordState

MarkerRoleService.computeRoles()   marker-role.service.ts:66
  → resolveScaleNoteNames() / resolveChordNoteNames()
    → resolveNotesFromIntervals()   pattern-resolver.ts:15
      → uses neckConfig.chromaticNotes (sharps)
  → compares with note.note (sharps from fretboard)
```

**Status**: Works by coincidence (both sides use sharp chromatic), but duplicates theory computation. If one side changes, it breaks silently.

### Path D — `RelationshipStripComponent` → wrong chord-tone-in-scale display

```
resolveChordNoteNames() / resolveScaleNoteNames()   relationship-strip.component.ts:22,38
  → uses neckConfig.chromaticNotes (sharps)
  → compares chordNotes vs scaleNotes via Set.has()
```

**Status**: Works internally (both use sharps), but duplicates theory computation from `FretboardOrchestrationService`. If Tonal and `CHORD_PATTERNS` disagree on spelling, the relationship strip shows different notes than the fretboard.

### Path E — `displayCustomPattern()` → `markIntervals()` (no rawNoteNames)

```
displayCustomPattern(notes, rootNote)   music-theory-facade.service.ts:57
  → markIntervals(rootNote, highlighted)   no rawNoteNames!
    → uses note.note directly (sharp from fretboard)
    → distance('C', 'D#') → '2A' → not in INTERVAL_MAP → no color
```

**Fix needed**: `markIntervals()` must handle enharmonic equivalents when `rawNoteNames` is absent.

---

## Solution: pitch-class-based comparison

### Step 1 — Add `chroma` helper utility

Create `src/app/shared/note-utils.ts`:

```typescript
const CHROMA_MAP: Record<string, number> = {
  'C': 0, 'C#': 1, 'Db': 1,
  'D': 2, 'D#': 3, 'Eb': 3,
  'E': 4, 'Fb': 4,
  'F': 5, 'F#': 6, 'Gb': 6,
  'G': 7, 'G#': 8, 'Ab': 8,
  'A': 9, 'A#': 10, 'Bb': 10,
  'B': 11, 'Cb': 11,
};

export function noteToChroma(noteName: string): number {
  return CHROMA_MAP[noteName] ?? -1;
}

/** Compare two note names by pitch class (enharmonic-aware). */
export function samePitch(a: string, b: string): boolean {
  return noteToChroma(a) === noteToChroma(b);
}
```

### Step 2 — Fix `FretboardNotePositionService.findPositionsByScaleNotes()`

File: [`src/app/services/note.service.ts`](src/app/services/note.service.ts):51

Change from string `includes()` to chroma-based comparison:

```typescript
findPositionsByScaleNotes(scaleNotes: string[]): GuitarNote[] {
  const chromas = new Set(scaleNotes.map(noteToChroma));
  return this.guitarNotes.filter(note => chromas.has(noteToChroma(note.note)));
}
```

This fixes **Path B** — Cm chord will now find `D#` positions when looking for `Eb`.

### Step 3 — Fix `handleShowInterval()` to produce spelling-correct note names

File: [`src/app/home-page/home-page.component.ts`](src/app/home-page/home-page.component.ts):90

Replace the hardcoded sharp-only chromatic with a map that returns **flat spellings for minor intervals** and **sharp spellings for major/perfect intervals**:

```typescript
const NOTE_MAP: Record<string, string[]> = {
  'C':  ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
  'Db': ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'],
  // ... or better: use pitch class to resolve
};
```

**Better approach**: Use `noteToChroma()` to find the note name that matches the target pitch class, preferring the spelling that matches the interval quality (flat for minor intervals, sharp for major).

### Step 4 — Fix `markIntervals()` for enharmonic-aware `distance()`

File: [`src/app/services/music-theory-facade.service.ts`](src/app/services/music-theory-facade.service.ts):201

When `rawNoteNames` is not provided, find a spelling of the note that makes `distance()` return the correct interval. Or better: use a pitch-class-based interval resolver that doesn't depend on Tonal's spelling-sensitive `distance()`.

### Step 5 — Fix `MarkerRoleService.computeRoles()` to use chroma

File: [`src/app/services/marker-role.service.ts`](src/app/services/marker-role.service.ts):66

Replace `Set.has()` string comparisons with chroma-based comparisons:

```typescript
const scaleChromas = new Set([...scaleNoteNames].map(noteToChroma));
const chordChromas = new Set([...chordNoteNames].map(noteToChroma));
const inScale = scaleChromas.has(noteToChroma(note.note));
const inChord = chordChromas.has(noteToChroma(note.note));
```

### Step 6 — Fix `RelationshipStripComponent` to use chroma

File: [`src/app/relationship-strip/relationship-strip.component.ts`](src/app/relationship-strip/relationship-strip.component.ts):22,38

Replace `Set.has()` string comparisons with chroma-based comparisons in both `resolveChordNoteNames()` and `resolveScaleNoteNames()`, and in the `chordTonesInScale` / `chordTonesOutsideScale` getters.

### Step 7 — Remove duplicate theory computation (optional, P1)

Once chroma-based comparison is in place, `MarkerRoleService` and `RelationshipStripComponent` can be refactored to use the already-resolved notes from `FretboardOrchestrationService` instead of recomputing from `CHORD_PATTERNS`/`SCALE_PATTERNS`. This is tracked in backlog item "P1: Consolidate theory computation".

---

## Dependency graph

```
Step 1 (note-utils.ts) ──┬── Step 2 (note.service.ts)
                          ├── Step 3 (home-page.component.ts)
                          ├── Step 4 (music-theory-facade.service.ts)
                          ├── Step 5 (marker-role.service.ts)
                          └── Step 6 (relationship-strip.component.ts)
```

Steps 2-6 are independent once Step 1 is done. They can be implemented in any order.

---

## Validation checklist

- [ ] `b3` from `C` shows `Eb` (not `D#`) and has `minor-3rd` color
- [ ] `b6` from `C` shows `Ab` (not `G#`) and has `minor-6th` color
- [ ] `b7` from `C` shows `Bb` (not `A#`) and has `minor-7th` color
- [ ] `b2` from `C` shows `Db` (not `C#`) and has `minor-2nd` color
- [ ] `b5` from `C` shows `Gb` (not `F#`) and has `diminished-5th` color
- [ ] Cm chord from toolbox shows `C`, `Eb`, `G` on fretboard (not `C`, `D#`, `G`)
- [ ] Fm chord shows `F`, `Ab`, `C` (not `F`, `G#`, `C`)
- [ ] Scale-chord relation `C major` + `Cm` shows correct overlap
- [ ] `npm test` passes
- [ ] `npm run build` succeeds