# Plan: Eliminacja duplikacji stanu — DomainState vs FretboardStateService

## Cel

Usunąć wszystkie duplikacje stanu między `DomainState` (canonical state, ADR 0005) a `FretboardStateService` (legacy). Wzór: każdy konsument czyta/zapisuje przez `DomainService.currentState` + `execute({ type: 'set-view', ... })`.

## Audyt — 3 zdublowane pola

| Pole w DomainState | Pole w FretboardStateService | Konsumenci FretboardStateService (do przepięcia) |
|---|---|---|
| `fretRange: {min, max}` | `fretRange = {minFret, maxFret}` | `FreatboardComponent.fretRange`, `isNoteInRange()` |
| `enabledStrings: boolean[]` | `activeStrings: boolean[]` | `FreatboardComponent.activeStrings`, `onStringToggled()`, `FretboardNoteQueryService` |
| `markerDisplayMode` | `markerDisplayMode` | `FretboardDisplayService`, `LegendComponent` (getter + setter) |

## Plan — 6 kroków

### Krok 1: HomePageComponent.onRangeChange()
**Plik:** `src/app/home-page/home-page.component.ts:58-60`
- Zastąpić TODO → `domainService.execute({ type: 'set-view', fretRange: { min: range.minFret, max: range.maxFret } })`

### Krok 2: FreatboardComponent
**Plik:** `src/app/freatboard/freatboard.component.ts`
- `fretRange` getter → `domainService.currentState.fretRange`
- `activeStrings` getter → `domainService.currentState.enabledStrings`
- `onStringToggled()` → `domainService.execute({ type: 'set-view', enabledStrings: noweEnabledStrings })`
- Wstrzyknąć `DomainService`

### Krok 3: FretboardNoteQueryService
**Plik:** `src/app/services/fretboard-note-query.service.ts`
- `guitarNeckService.activeStrings[stringIndex]` → `domainService.currentState.enabledStrings[stringIndex]`
- Wstrzyknąć `DomainService` zamiast (lub obok) `FretboardStateService`

### Krok 4: FretboardDisplayService
**Plik:** `src/app/services/fretboard-display.service.ts`
- `guitarNeckService.markerDisplayMode` → `domainService.currentState.markerDisplayMode`
- Wstrzyknąć `DomainService`

### Krok 5: LegendComponent
**Plik:** `src/app/legend/legend.component.ts`
- Getter `markerDisplayMode` → `domainService.currentState.markerDisplayMode`
- Setter `markerDisplayMode` → `domainService.execute({ type: 'set-view', markerDisplayMode: value })`
- Wstrzyknąć `DomainService`

### Krok 6: FretboardStateService — usuń zdublowane pola
**Plik:** `src/app/services/fretboard-state.service.ts`
- Usuń: `fretRange`, `activeStrings`, `markerDisplayMode`, `toggleString()`, `resetActiveStrings()`
- Zostaw: `notes`, `notesMap`, `scaleChordState`, `hasActiveResult`, `currentSelection`, `applyHighlightedNotes()`, `clearFretboard()`, `hideAllNotes()`, `showAll()`, `clearSelection()`

### Krok 7: Testy
- Zaktualizuj: `fretboard-state.service.spec.ts`, `fretboard-display.service.spec.ts`, `freatboard.component.spec.ts`, `legend.component.spec.ts`, `fretboard-note-query.service.spec.ts`
- Usuń testy dla usuniętych pól/metod

## Diagram przepływu po zmianie

```mermaid
flowchart LR
    subgraph "Źródło prawdy"
        DS["DomainService<br/>currentState"]
    end
    
    subgraph "Konsumenci"
        HPC["HomePageComponent<br/>onRangeChange()"]
        FC["FreatboardComponent<br/>fretRange, enabledStrings"]
        FQS["FretboardNoteQueryService<br/>enabledStrings"]
        FDS["FretboardDisplayService<br/>markerDisplayMode"]
        LC["LegendComponent<br/>markerDisplayMode"]
    end
    
    HPC -->|"set-view"| DS
    FC -->|"currentState"| DS
    FC -->|"set-view"| DS
    FQS -->|"currentState"| DS
    FDS -->|"currentState"| DS
    LC -->|"currentState + set-view"| DS
    
    subgraph "Tylko stan gryfu (OK)"
        FSS["FretboardStateService<br/>notes, notesMap, scaleChordState"]
    end