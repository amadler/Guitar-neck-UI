# Plan: Remove AppMode — redundant UI mode type

## Background

Full analysis: [`plans/querytypes-appmode-fretboardcommand-analysis.md`](plans/querytypes-appmode-fretboardcommand-analysis.md)
Backlog item: [`BACKLOG.md`](BACKLOG.md) (section "Remove AppMode — redundant UI mode type")

## Summary of changes

`AppMode` type and `AppStateService` are removed. The only real consumer — `PatternDisplayComponent.isScaleChordMode` — switches to deriving its value from `FretboardStateService.scaleChordState.chord !== null`.

## Tickets (execution order)

### Ticket 1: Remove `AppMode` from `PatternDisplayComponent`

**Files to change:**
- [`src/app/pattern-display/pattern-display.component.ts`](src/app/pattern-display/pattern-display.component.ts)

**Changes:**
1. Remove import of `AppStateService` and `AppMode`
2. Remove `appMode` getter (lines 20-22)
3. Remove constructor injection of `AppStateService`
4. Replace `isScaleChordMode` getter:
   - **Before:** `return this.appMode === 'scale-chord';`
   - **After:** `return this.guitarNeckService.scaleChordState?.chord !== null;`
5. Inject `FretboardStateService` (already available via `PatternBuilderService`? No — inject directly)

**Test impact:** `pattern-display.component.spec.ts` — update mock to provide `scaleChordState`

---

### Ticket 2: Remove `AppMode` from `RangeToolbarComponent`

**Files to change:**
- [`src/app/range-toolbar/range-toolbar.component.ts`](src/app/range-toolbar/range-toolbar.component.ts)
- [`src/app/range-toolbar/range-toolbar.component.spec.ts`](src/app/range-toolbar/range-toolbar.component.spec.ts)

**Changes:**
1. Remove import of `AppStateService` and `AppMode`
2. Remove `appMode` getter (lines 27-29)
3. Remove `switchMode()` method (lines 32-35)
4. Remove constructor injection of `AppStateService`

**Test impact:** Remove `switchMode` and `appMode` describe blocks from spec.

---

### Ticket 3: Delete `AppStateService` and its spec

**Files to delete:**
- [`src/app/app-state.service.ts`](src/app/app-state.service.ts)
- [`src/app/app-state.service.spec.ts`](src/app/app-state.service.spec.ts)

**Changes:**
1. Delete both files
2. Verify no remaining imports reference them

---

### Ticket 4: Verify no remaining references

**Action:** Run:
```
grep -r 'AppMode' src/
grep -r 'app-state.service' src/
grep -r 'AppStateService' src/
```

All should return zero results.

---

### Ticket 5: Run tests and build

**Action:**
1. `npm test` — all tests must pass
2. `npm run build` — must succeed

---

## Dependency graph

```mermaid
flowchart LR
    T1[Ticket 1: PatternDisplayComponent] --> T3[Ticket 3: Delete AppStateService]
    T2[Ticket 2: RangeToolbarComponent] --> T3
    T3 --> T4[Ticket 4: Verify no references]
    T4 --> T5[Ticket 5: Test & build]
```

Tickets 1 and 2 are independent and can be done in parallel.

## Validation checklist

- [ ] `PatternDisplayComponent` shows single-panel layout when no chord relation is active
- [ ] `PatternDisplayComponent` shows two-card layout when `scaleChordState.chord` is set
- [ ] `RangeToolbarComponent` no longer has `switchMode()` or `appMode` getter
- [ ] `AppStateService` files are deleted
- [ ] `grep -r 'AppMode' src/` returns zero
- [ ] `grep -r 'app-state.service' src/` returns zero
- [ ] `npm test` passes
- [ ] `npm run build` succeeds