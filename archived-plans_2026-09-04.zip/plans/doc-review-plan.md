# Guitar Neck UI — Dokumentacja Review & Update Plan

## Cel

Przegląd całego kodu GNUI i Toolboxa, weryfikacja roadmapy, inspekcja jakości kodu, oraz **kompleksowa aktualizacja dokumentacji technicznej** po serii zmian które nie zostały udokumentowane.

---

## 🔍 Podsumowanie Audytu (Phase 1-2)

### Co się zmieniło (niedokumentowane)

| Zmiana | Szczegóły |
|--------|-----------|
| **Tonal.js zastąpił API** | `music-theory-api` backend usunięty. Wszystkie obliczenia lokalne przez `@tonaljs/tonal` v4. |
| **AppMode przebudowany** | `'idle' \| 'scale' \| 'scale-chord'` → `'custom-pattern' \| 'scale-or-chord' \| 'scale-chord'`. Domyślny tryb to `'scale-or-chord'`. |
| **Toolbox wymieniony** | `ToolboxFormComponent` (lokalny) → `FormsWrapperComponent` z `guitar-toolbox-lib`. Komunikacja przez `FretboardCommand` zamiast `UICommands`. |
| **ModeSelector usunięty** | Ekran startowy z wyborem trybu usunięty. Aplikacja startuje od razu w `scale-or-chord`. |
| **ScaleForm/ScaleChordForm usunięte** | Formularze zastąpione przez `FormsWrapperComponent` z biblioteki. |
| **IntervalService usunięty** | Logika interwałów inline w `FretboardOrchestrationService`. |
| **MusicPatternApiService usunięty** | Zastąpiony przez Tonal.js + fallback do `CHORD_PATTERNS`/`SCALE_PATTERNS`. |
| **GuitarNeck.ts usunięty** | Zastąpiony przez `FretboardNotePositionService`. |
| **Docker usunięty** | `Dockerfile`, `docker-compose.yml`, `nginx.conf` — wszystkie usunięte. |
| **apiUrl usunięty z env** | Środowiska nie mają już `apiUrl`. |
| **guitar-toolbox-lib lokalny** | Z `^1.0.2` (npm) → `file:../guitar-toolbox/dist/guitar-toolbox-lib` (lokalny workspace). |

### Nowe serwisy (nieudokumentowane)

| Serwis | Plik | Odpowiedzialność |
|--------|------|-----------------|
| `FretboardNoteQueryService` | `fretboard-note-query.service.ts` | Zapytania o nuty na gryfie (isNoteOnFret, getNote, getNoteName) |
| `PatternBuilderService` | `pattern-builder.service.ts` | Buduje `PatternInfo` dla UI (nuty, interwały, kroki W/H) |
| `FretboardDisplayService` | `fretboard-display.service.ts` | Decyduje o klasach CSS (interwałowe vs role-based) |

### Dead Code do usunięcia

| Plik | Status | Akcja |
|------|--------|-------|
| `UICommands.ts` | Nieużywany (zastąpiony przez `FretboardCommand` z biblioteki) | Usunąć |
| `ChordDegreeSelectorComponent` | Nieużywany (przyszły feature) | Tag git + usunąć |
| `LoadingService` | Nieużywany (brak HTTP) | Usunąć (łatwy do napisania od nowa) |
| `toolbox.models.ts` | `ToolboxSearchQuery` i `ScaleChordRelation` nieużywane | Usunąć |
| Docker scripts w `package.json` | `docker:build`, `docker:up`, `docker:down`, `docker:logs` | Usunąć |

---

## 📋 Plany Działania

### Phase 3: Write comprehensive plan document (this file)

### Phase 4: Update ARCHITECTURE.md

**Zmiany:**
1. **AppMode**: `'idle' \| 'scale' \| 'scale-chord'` → `'custom-pattern' \| 'scale-or-chord' \| 'scale-chord'`
2. **Usunąć z tabeli komponentów**: `ModeSelectorComponent`, `ScaleFormComponent`, `ScaleChordFormComponent`
3. **Zaktualizować**: `ToolboxFormComponent` → `FormsWrapperComponent` (selector `lib-forms-wrapper`)
4. **Usunąć**: `IntervalService`, `MusicPatternApiService` z warstwy serwisów
5. **Dodać**: `FretboardNoteQueryService`, `PatternBuilderService`, `FretboardDisplayService`
6. **Zaktualizować przepływ danych**: Toolbox → `FretboardCommand` → `HomePageComponent.onToolboxEvent()` → bezpośrednio do serwisów (bez Command Pattern)
7. **Usunąć**: Sekcję Docker/CSS Variables API (przeniesione do biblioteki)
8. **Zaktualizować**: Sekcję Tonal.js — dodać `resolveScaleNotes()`, `resolveChordNotes()`, `resolveFromPatterns()`
9. **Zaktualizować**: Backlog summary w ARCHITECTURE.md

### Phase 5: Update API_DOCUMENTATION.md

**Zmiany:**
1. **Usunąć**: `IntervalService` (cała sekcja)
2. **Usunąć**: `MusicPatternApiService` (cała sekcja)
3. **Usunąć**: `AppStateService` (przeniesione do ARCHITECTURE.md lub zostawić zaktualizowane)
4. **Dodać**: `FretboardNoteQueryService` — pełna dokumentacja API
5. **Dodać**: `PatternBuilderService` — pełna dokumentacja API
6. **Dodać**: `FretboardDisplayService` — pełna dokumentacja API (już częściowo jest)
7. **Zaktualizować**: `FretboardOrchestrationService` — dodać prywatne metody `resolveScaleNotes`, `resolveChordNotes`, `resolveFromPatterns`
8. **Zaktualizować**: `FretboardStateService` — dodać `activeStrings`, `markerDisplayMode`, `hasActiveResult`, `currentSelection`
9. **Zaktualizować**: `FretboardNotePositionService` — usunąć `findPositionsByChordNotes` (nieużywane, zastąpione przez `findPositionsByScaleNotes`)
10. **Zaktualizować**: `UICommands` — oznaczyć jako **DEPRECATED** (zastąpione przez `FretboardCommand` z `guitar-toolbox-lib`)
11. **Usunąć**: Sekcję AI Chat (przeniesione do osobnego dokumentu lub zostawić jako POSTPONED)

### Phase 6: Update PRODUCT_OVERVIEW.md

**Zmiany:**
1. **Sekcja 0 (Wybór Trybu)**: Usunąć — nie ma już ekranu startowego
2. **Zaktualizować przepływ pracy**: Toolbox → `FormsWrapperComponent` → `FretboardCommand`
3. **Usunąć**: Wzmianki o Dockerze
4. **Usunąć**: Wzmianki o backendzie API
5. **Zaktualizować**: Sekcję integracji — Tonal.js jako jedyny silnik
6. **Dodać**: Wzmiankę o planowanym deployment na Cloudflare Pages
7. **Zaktualizować**: Sekcję "Planowany Rozwój"

### Phase 7: Update DEVELOPMENT.md

**Zmiany:**
1. **Usunąć**: Docker scripts, `Dockerfile`, `docker-compose.yml`, `nginx.conf`
2. **Usunąć**: `apiUrl` z konfiguracji środowiska
3. **Zaktualizować**: Strukturę projektu — usunąć nieistniejące pliki
4. **Usunąć**: `scales-and-triads.service.ts`, `interval.service.ts`, `GuitarNeck.ts`
5. **Dodać**: `fretboard-note-query.service.ts`, `pattern-builder.service.ts`
6. **Usunąć**: Zmienne środowiskowe `.env` (CORS_ORIGIN niepotrzebne)
7. **Dodać**: Sekcję deploymentu na Cloudflare Pages
8. **Zaktualizować**: Wersje pakietów (`guitar-toolbox-lib` lokalny)

### Phase 8: Update CONTEXT.md

**Zmiany:**
1. **AppMode**: `'idle' \| 'scale' \| 'scale-chord'` → `'custom-pattern' \| 'scale-or-chord' \| 'scale-chord'`
2. **Usunąć**: `ModeSelectorComponent` — nie istnieje
3. **Usunąć**: `ScaleFormComponent` — nie istnieje
4. **Usunąć**: `ScaleChordFormComponent` — nie istnieje
5. **Zaktualizować**: `AppStateService` — usunąć wzmiankę o `idle`
6. **Zaktualizować**: `Tonal.js` — dodać informację o fallbacku do `CHORD_PATTERNS`/`SCALE_PATTERNS`
7. **Dodać**: `FormsWrapperComponent` — nowy komponent toolboxu
8. **Dodać**: `FretboardCommand` — nowy typ eventu z toolboxu

### Phase 9: Update CHANGELOG.md

**Dodać wpis v0.8.0:**

```markdown
## [0.8.0] — 2026-08-29

### Added
- Tonal.js integration — local music theory engine replaces backend API
- `FretboardNoteQueryService` — query helper for fretboard note lookups
- `PatternBuilderService` — builds PatternInfo for UI display
- `FretboardDisplayService` — CSS class decision layer for markers
- `FormsWrapperComponent` from `guitar-toolbox-lib` — new toolbox form
- `FretboardCommand` event type for toolbox → UI communication
- Fallback resolution for exotic scales/chords not in Tonal.js

### Changed
- `AppMode` values: `'idle' | 'scale' | 'scale-chord'` → `'custom-pattern' | 'scale-or-chord' | 'scale-chord'`
- Default app mode: `'idle'` → `'scale-or-chord'` (no start screen)
- Toolbox: local `ToolboxFormComponent` → `FormsWrapperComponent` from library
- `guitar-toolbox-lib` dependency: `^1.0.2` → local `file:` reference
- `FretboardOrchestrationService` — interval logic moved inline, added Tonal.js resolution
- Environment config — removed `apiUrl`, removed `music-theory-api` references

### Removed
- `ModeSelectorComponent` — start screen removed
- `ScaleFormComponent`, `ScaleChordFormComponent` — replaced by library forms
- `IntervalService` (`interval.service.ts`) — logic inline in facade
- `MusicPatternApiService` (`scales-and-triads.service.ts`) — replaced by Tonal.js
- `GuitarNeck.ts` — replaced by `FretboardNotePositionService`
- Docker: `Dockerfile`, `docker-compose.yml`, `nginx.conf`, docker scripts
- `UICommands.ts` — replaced by `FretboardCommand` from library
- `ChordDegreeSelectorComponent` — tagged in git, removed from codebase
- `LoadingService` — no HTTP calls remain
- `toolbox.models.ts` — unused types removed

### Planned
- Cloudflare Pages deployment (replacing Docker/VPS)
```

### Phase 10: Update BACKLOG.md

**Zmiany:**
1. **Zweryfikować** wszystkie istniejące pozycje backlogu
2. **Dodać**: Cloudflare Pages migration jako nowy item backlogu
3. **Zaktualizować** statusy jeśli któreś zostały zrealizowane

### Phase 11: Update ADRs

**ADR 0001 (AppStateService):**
- Zaktualizować wartości AppMode z `'idle' | 'scale' | 'scale-chord'` na `'custom-pattern' | 'scale-or-chord' | 'scale-chord'`
- Dodać adnotację że `idle` został usunięty

### Phase 12: Code Quality Review

**Problemy znalezione:**

1. **Duplikacja logiki**: `MarkerRoleService.resolveChordNoteNames()` i `resolveScaleNoteNames()` powielają logikę z `PatternBuilderService.setCurrentPattern()` i `FretboardOrchestrationService.resolveFromPatterns()`. Wszystkie 3 miejsca robią to samo — obliczają nuty z patternu + root.

2. **`findPositionsByChordNotes` w `FretboardNotePositionService`** — identyczna implementacja jak `findPositionsByScaleNotes`. Można usunąć.

3. **`FretboardStateService` konstruktor** — ustawia `this.notes = this.noteService.getAllPositions()` ale potem `FreatboardComponent.ngOnInit()` nadpisuje `this.guitarNeckService.notes = this.notes`. To sugeruje że inicjalizacja w konstruktorze jest nadpisywana.

4. **`FretboardNoteQueryService.fretNoteClicked()`** — metoda istnieje ale nie jest używana przez `FreatboardComponent` (który ma własną logikę).

5. **`AppStateService.switchMode()`** — metoda tylko deleguje do `setMode()`, jest redundantna.

6. **Brak testów** dla nowych serwisów: `FretboardNoteQueryService`, `PatternBuilderService`, `FretboardDisplayService`.

### Phase 13: Roadmap Alignment

**Planowany rozwój z PRODUCT_OVERVIEW.md vs rzeczywistość:**

| Plan | Status | Uwagi |
|------|--------|-------|
| Nowe wzory muzyczne | OPEN | Zależne od `guitar-neck-shared` |
| Rozszerzenie AI | POSTPONED | `projects/guitar-chat` istnieje, czeka na klucz |
| Ćwiczenia i zadania | OPEN | Practice prompts istnieją, ale brak systemu progresji |
| Personalizacja | OPEN | Nie rozpoczęte |
| Rozbudowa metronomu | OPEN | W BACKLOG.md |
| System progresji ćwiczeń | OPEN | Nie rozpoczęte |

**Nowe pozycje roadmapy:**
- Cloudflare Pages deployment (zastępuje Docker/VPS)
- Refaktor duplikacji logiki (MarkerRoleService vs PatternBuilderService)

### Phase 14: Dead Code Removal Plan

Kolejność usuwania (do wykonania przez Code mode):

1. **Tag + remove ChordDegreeSelectorComponent**:
   ```bash
   git tag -a chord-degree-selector -m "ChordDegreeSelectorComponent — saved before removal, may be reused for degree feature"
   git rm -r src/app/chord-degree-selector/
   ```

2. **Remove UICommands.ts**:
   ```bash
   git rm src/app/shared/UICommands.ts
   ```

3. **Remove LoadingService**:
   ```bash
   git rm src/app/services/loading.service.ts
   ```

4. **Remove toolbox.models.ts** (po weryfikacji że nie jest importowany):
   ```bash
   git rm src/app/shared/model/toolbox.models.ts
   ```

5. **Remove Docker scripts from package.json**:
   ```json
   // Remove: "docker:build", "docker:up", "docker:down", "docker:logs"
   ```

6. **Remove `findPositionsByChordNotes`** from `note.service.ts` (identyczne z `findPositionsByScaleNotes`)

---

## 📐 Diagram: Architektura po zmianach

```mermaid
flowchart TD
    subgraph UI_Layer ["Warstwa UI"]
        HPC[HomePageComponent]
        FC[FreatboardComponent]
        PD[PatternDisplayComponent]
        RS[RelationshipStripComponent]
        L[LegendComponent]
    end

    subgraph Toolbox ["Toolbox (guitar-toolbox-lib)"]
        FWC[FormsWrapperComponent]
        FCmd[FretboardCommand]
    end

    subgraph Services ["Warstwa Serwisów"]
        FOS[FretboardOrchestrationService]
        FSS[FretboardStateService]
        FNPS[FretboardNotePositionService]
        FNQS[FretboardNoteQueryService]
        MRS[MarkerRoleService]
        FDS[FretboardDisplayService]
        PBS[PatternBuilderService]
    end

    subgraph Engine ["Silnik Muzyczny"]
        Tonal[Tonal.js]
        Fallback[CHORD_PATTERNS / SCALE_PATTERNS]
    end

    FWC -->|toolboxEv| HPC
    HPC -->|onToolboxEvent| FOS
    HPC -->|onToolboxEvent| PBS
    HPC -->|onToolboxEvent| FSS
    FOS --> Tonal
    FOS --> Fallback
    FOS --> FNPS
    FOS --> FSS
    FOS --> MRS
    FSS --> FDS
    MRS --> FDS
    FNQS --> FSS
    FC --> FDS
    FC --> FNQS
    FC --> FSS
    PD --> PBS
    RS --> FSS
    RS --> MRS
```

---

## ✅ Lista weryfikacyjna przed merge

- [ ] Wszystkie 7 plików .md zaktualizowane
- [ ] ADR 0001 zaktualizowany
- [ ] CHANGELOG.md ma wpis v0.8.0
- [ ] BACKLOG.md zawiera Cloudflare Pages migration
- [ ] Dead code usunięty (UICommands, ChordDegreeSelector, LoadingService, toolbox.models)
- [ ] Docker scripts usunięte z package.json
- [ ] `findPositionsByChordNotes` usunięte
- [ ] `npm test` przechodzi po zmianach
- [ ] `npm run build` przechodzi po zmianach
- [ ] Dokumentacja consistency validation (AGENTS.md checklist) przechodzi