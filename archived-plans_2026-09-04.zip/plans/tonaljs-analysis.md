# Tonal.js — Analiza i Rekomendacja dla Guitar Neck UI

## 0. Kod który możemy wyeliminować — konkretne liczby

### Pliki do usunięcia (całkowicie)

| Plik | Linie | Zastąpiony przez |
|------|-------|-----------------|
| `src/app/services/scales-and-triads.service.ts` | **52** | `MusicTheoryEngineService` (Tonal) — HTTP → synchroniczne |
| `src/environments/environment.ts` (apiUrl) | częściowo | Nie potrzebujemy `apiUrl` dla teorii muzyki |

### Pliki do uproszczenia

| Plik | Linie teraz | Linie po | Oszczędność | Co się zmienia |
|------|------------|---------|-------------|----------------|
| `src/app/services/interval.service.ts` | 92 | ~50 | **-42** | `getIntervalName()` (17 linii) + ręczne liczenie interwałów (12 linii) → `Distance.interval()` |
| `src/app/services/marker-role.service.ts` | 164 | ~110 | **-54** | `resolveChordNoteNames()` (26 linii) + `resolveScaleNoteNames()` (26 linii) → Tonal. Logika ról (60 linii) zostaje |
| `src/app/services/pattern-builder.service.ts` | 109 | ~75 | **-34** | Ręczne liczenie nut z `CHORD_PATTERNS`/`SCALE_PATTERNS` (30 linii) → Tonal |
| `src/app/services/music-theory-facade.service.ts` | 186 | ~130 | **-56** | Client-side chord resolution (17 linii) + HTTP Observable wrapper (30 linii) → synchroniczne Tonal |

### Pliki, które NIE zmieniają rozmiaru (logika pozostaje)

| Plik | Uzasadnienie |
|------|-------------|
| `src/app/services/note.service.ts` | Geometria gryfu — Tonal nie ma pojęcia o fizycznym gryfie |
| `src/app/services/guitar-neck.service.ts` | Stan gryfu — Angular state management |
| `src/app/services/fretboard-display.service.ts` | CSS klasy — UI-specific |
| `src/app/shared/UICommands.ts` | Command pattern — nasz wzorzec |

### Nowe pliki (dodajemy)

| Plik | Linie | Opis |
|------|-------|------|
| `src/app/services/music-theory-engine.service.ts` | ~60 | Wrapper na Tonal: `resolveScaleNotes()`, `resolveChordNotes()`, `getInterval()`, `detectScale()` |
| `src/app/shared/tonal-adapter.ts` | ~30 | Mapowanie nazw Tonal ↔ nasze (`'3M'` → `'major-3rd'`) |

### Podsumowanie

| Metryka | Wartość |
|---------|---------|
| **Linie usunięte** | ~52 (cały plik) + ~186 (uproszczenia) = **~238 linii mniej** |
| **Linie dodane** | ~90 (2 nowe pliki) |
| **Netto** | **~148 linii mniej** |
| **Zależności usunięte** | `HttpClient`, `environment.apiUrl`, `catchError`/`finalize`/`map` z RxJS (w teorii muzyki) |
| **Zależności dodane** | `@tonaljs/tonal` (~30KB) |
| **Pliki do testów do aktualizacji** | `interval.service.spec.ts` (156 linii), `marker-role.service.spec.ts` (139 linii) |
| **Pliki do testów do usunięcia** | `scales-and-triads.service.ts` (nie ma speca) |

## 1. Podsumowanie obecnej architektury

Obecnie logika teorii muzyki jest rozdzielona między:

| Warstwa | Co robi | Gdzie |
|---------|---------|-------|
| **Backend API** (music-theory-api) | HTTP → oblicza nuty skal i akordów | `GET /api/scales/:name/:root`, `GET /api/chords/:name/:root` |
| **Client-side duplicate** | Rozwiązywanie nut akordów z `CHORD_PATTERNS` (bez API) | `music-theory-facade.service.ts:110-125`, `marker-role.service.ts:29-54`, `pattern-builder.service.ts:43-50` |
| **Client-side interval logic** | Mapowanie półtonów → nazwy interwałów | `interval.service.ts:74-90`, `pattern-builder.service.ts:7-10` |
| **Client-side fretboard** | Geometria gryfu, stany, role markerów | `note.service.ts`, `guitar-neck.service.ts`, `marker-role.service.ts` |

**Kluczowy problem**: logika teorii muzyki jest powielona w 3 miejscach po stronie klienta (`music-theory-facade`, `marker-role.service`, `pattern-builder.service`) — każdy z nich ręcznie iteruje po `CHORD_PATTERNS`/`SCALE_PATTERNS` i `neckConfig.chromaticNotes`.

---

## 2. Czy Tonal.js może zastąpić część obecnego Music Theory API?

**Tak, znacząco.** Obecne backend API jest cienką warstwą REST wokół obliczeń, które Tonal wykonuje natywnie w JavaScript:

| Obecne API | Tonal odpowiednik |
|------------|-------------------|
| `GET /api/scales/:name/:root` → `["C","D","E","F","G","A","B"]` | `Scale.notes("C", "major")` → `["C","D","E","F","G","A","B"]` |
| `GET /api/chords/:name/:root` → `["C","E","G"]` | `Chord.notes("C", "major")` → `["C","E","G"]` |
| `GET /api/find-compatible-scales/:name/:root` | `Scale.detect(notes)` + `Key` analysis |

**Wniosek**: Tonal może całkowicie zastąpić backend API dla podstawowych obliczeń skal i akordów. Backend staje się opcjonalny.

---

## 3. Które funkcje delegujemy do Tonal?

| Funkcja | Obecnie | Tonal | Decyzja |
|---------|---------|-------|---------|
| **Skale** — lista nut dla patternu | HTTP API + `SCALE_PATTERNS` | `Scale.notes(root, name)` | ✅ **Zastąpić** |
| **Akordy** — lista nut dla patternu | HTTP API + `CHORD_PATTERNS` (duplikowany w 3 plikach) | `Chord.notes(root, name)` | ✅ **Zastąpić** — eliminuje duplikację |
| **Interwały** — nazwy interwałów | `IntervalService.getIntervalName()` — ręczna mapa 0-11 | `Interval.name()` + `Distance.interval()` | ✅ **Zastąpić** |
| **Pitch classes** — lista 12 nut | `neckConfig.chromaticNotes` | `Note.chromatic()` | ✅ **Zastąpić** (ale zostawiamy `neckConfig` dla strojenia) |
| **Transpozycje** — obliczanie nuty + półtony | Ręczne `(index + offset) % 12` w `note.service.ts` | `Note.transpose()` | ✅ **Zastąpić** |
| **Akordy diatoniczne** — jakie akordy są w skali | Nie zaimplementowane | `Key.scale("C", "major").chords` → `["Cmaj7","Dm7"...]` | ✅ **Nowa capability** (przydatna dla AI) |
| **Relacje skala–akord** — które nuty akordu są w skali | `MarkerRoleService` — ręczne set diff | `Chord.notes()` + `Scale.notes()` → set intersection | ⚠️ **Częściowo** — Tonal daje surowe zbiory, logika ról (5 ról) zostaje po naszej stronie |

---

## 4. Co zostaje po naszej stronie (NIE zastępujemy)

| Obszar | Serwis | Uzasadnienie |
|--------|--------|-------------|
| **Mapowanie nut na gryf** | `FretboardNotePositionService` | Tonal nie ma pojęcia o fizycznym gryfie, strunach, progach |
| **Role markerów** (5 ról) | `MarkerRoleService` | Logika UI-specific: scale-tone, chord-tone, chord-tone-outside-scale itd. Tonal dostarcza tylko zbiory nut |
| **Zakres progów** | `RangeToolbarComponent` | Czysto UI |
| **Strojenie instrumentu** | `neckConfig.stringNotes` | Guitar-specific, Tonal tego nie ma |
| **Stan gryfu** | `FretboardStateService` | Angular state management |
| **Komendy UI** | `UICommands.ts` | Command pattern — nasz wzorzec |
| **Pattern display info** | `PatternBuilderService` | `PatternInfo` z krokami (W/H) i półtonami — UI formatting |
| **Kontrakt FE ↔ API** | `FretboardOrchestrationService` | Fasada pozostaje stabilna |

---

## 5. Czy Tonal powinien zastąpić API, czy działać jako silnik wewnątrz API?

**Decyzja: Silnik wewnątrz warstwy API (za fasadą).**

```
Obecnie:
  UI → Facade → MusicPatternApiService → HTTP → music-theory-api (Docker)

Proponowany:
  UI → Facade → MusicTheoryEngineService (Tonal) → dane
                └→ MusicPatternApiService (opcjonalny fallback)
```

**Zalety tego podejścia:**
- `FretboardOrchestrationService` (fasada) **nie zmienia swojego public API** — żaden komponent UI nie wymaga zmian
- `MusicPatternApiService` może pozostać jako fallback (jeśli chcemy zachować backend)
- Możliwość stopniowego wdrażania: najpierw Tonal dla skal/akordów, potem dla interwałów
- Backend API można wyłączyć feature flagą, bez zmian w UI

---

## 6. Czy obecny kontrakt FE ↔ Music Theory API trzeba zmieniać?

**Nie.** Fasada (`FretboardOrchestrationService`) zachowuje wszystkie metody:

- `displayScale(scaleName, rootNote)` → `Observable<GuitarNote[]>`
- `displayChord(triadType, rootNote)` → `Observable<GuitarNote[]>`
- `displayScaleWithChord(scaleName, scaleRoot, chordName, chordRoot)` → `Observable<GuitarNote[]>`
- `displaySingleNote(noteName)`, `displayAllNotes()`, `displayCustomPattern()`, `resetFretboard()`, `clearRelation()`

**Jedyna zmiana**: `MusicPatternApiService.resolveScaleNotes()` i `resolveChordNotes()` przestają być HTTP — stają się synchroniczne (Tonal). Fasada nadal zwraca `Observable` (można użyć `of()`).

---

## 7. Jak dane z Tonal przełożyć na obecny model?

### Scale notes
```typescript
// Tonal → nasz model
import { Scale } from '@tonaljs/scale';

// Tonal zwraca: ['C', 'D', 'E', 'F', 'G', 'A', 'B']
// Nasz model: string[] — bezpośrednie mapowanie
const scaleNotes = Scale.notes('C', 'major'); // ['C', 'D', 'E', 'F', 'G', 'A', 'B']
```

### Chord notes
```typescript
import { Chord } from '@tonaljs/chord';

// Tonal zwraca: ['C', 'E', 'G', 'B'] (z octave: 'C4', 'E4', 'G4', 'B4')
// Potrzebujemy strip octave: note.slice(0, -1) lub Note.simplify()
const chordNotes = Chord.notes('Cmaj7').map(n => n.slice(0, -1));
// → ['C', 'E', 'G', 'B']
```

### Interval labels
```typescript
import { Distance } from '@tonaljs/tonal';

// Tonal: Distance.interval('C', 'E') → '3M'
// Nasz model: 'major-3rd'
// Potrzebny adapter: '3M' → 'major-3rd', '3m' → 'minor-3rd', '1P' → 'root'
const intervalMap: Record<string, string> = {
  '1P': 'root', '2m': 'minor-2nd', '2M': 'major-2nd',
  '3m': 'minor-3rd', '3M': 'major-3rd', '4P': 'perfect-4th',
  '5d': 'diminished-5th', '5P': 'perfect-5th',
  '6m': 'minor-6th', '6M': 'major-6th',
  '7m': 'minor-7th', '7M': 'major-7th',
};
```

### Chord tones in/outside scale
```typescript
const scaleNotes = Scale.notes('C', 'major');       // ['C','D','E','F','G','A','B']
const chordNotes = Chord.notes('Emajor').map(n => n.slice(0, -1)); // ['E','G#','B']

const inScale = chordNotes.filter(n => scaleNotes.includes(n));     // ['E','B']
const outside = chordNotes.filter(n => !scaleNotes.includes(n));    // ['G#']
// To dokładnie to, co robi obecnie music-theory-facade.service.ts:128
```

---

## 8. Ryzyka

| Ryzyko | Opis | Mitigacja |
|--------|------|-----------|
| **Zależność od biblioteki** | Tonal to zewnętrzna zależność. Jeśli przestanie być maintainowana, tracimy silnik. | Tonal jest stabilny (v4+), open source, szeroko używany. Funkcje których używamy to podstawowa teoria — łatwa do zastąpienia własnym kodem. |
| **Różnice nazewnictwa** | Tonal używa `'maj7'` zamiast naszego `'major-7th'`, `'3M'` zamiast `'major-3rd'` | Warstwa adaptera mapuje nazwy. Można też dostosować nasze słowniki. |
| **Enharmonia** | Tonal domyślnie używa `#`, ale akceptuje `b`. Może zwrócić `Bb` zamiast `A#`. | Ustawić preferencję `Note.simplify('Bb')` lub dodać normalizację do `#`. |
| **Rozszerzenia akordów** | Tonal obsługuje 9/11/13 natywnie. Nasze `CHORD_PATTERNS` mają 26 patternów — trzeba zweryfikować czy Tonal pokrywa wszystkie. | Spike powinien sprawdzić coverage. Jeśli nie, można rozszerzyć Tonal własnymi definicjami. |
| **Octave w nutach** | Tonal zwraca `'C4'` z oktawą. Nasz model używa tylko pitch class `'C'`. | Strip octave: `note.slice(0, -1)` lub `Note.simplify(note)`. |
| **Bundle size** | Tonal to ~30KB minified (tree-shakeable). | Importować tylko potrzebne moduły: `@tonaljs/scale`, `@tonaljs/chord`, `@tonaljs/note`, `@tonaljs/interval`. |

---

## 9. Czy Tonal daje funkcje istotne później dla AI-nauczyciela?

**Tak, kilka kluczowych:**

| Funkcja Tonal | Zastosowanie w AI Teacher | Wpływ na MVP |
|---------------|--------------------------|--------------|
| `Key.scale()` — akordy diatoniczne | AI może sugerować progresje akordów w skali | Brak — nowa capability |
| `Chord.detect(notes)` — detekcja akordu z zestawu nut | AI może analizować co użytkownik zagrał | Brak — nowa capability |
| `Scale.detect(notes)` — detekcja skali | AI może identyfikować skalę | Brak — nowa capability |
| `Progression.fromRomanNumerals()` | AI może tłumaczyć funkcje harmoniczne | Brak — nowa capability |
| `RomanNumeral` — analiza harmoniczna | AI może wyjaśniać "to jest ii-V-I w C" | Brak — nowa capability |
| `Mode` — modal interchange | AI może sugerować borrowing modalny | Brak — nowa capability |

**Wszystkie te funkcje są niezależne od obecnego MVP** — nie wymagają zmian w obecnym kodzie, ale będą dostępne gdy AI Teacher będzie wdrażany.

---

## 10. Rekomendacja końcowa

### Decyzja: **Używać Tonal jako wewnętrznego silnika API**

### Zakres zastąpienia

| Komponent | Co się zmienia |
|-----------|---------------|
| `MusicPatternApiService` | **Zastąpiony** przez `MusicTheoryEngineService` (Tonal). HTTP → synchroniczne Tonal calls. Klasa może pozostać jako fallback. |
| `IntervalService` | **Uproszczony** — `getIntervalName()` zastąpiony przez `Distance.interval()` + adapter nazw. Reszta logiki (markIntervals, removeIntervals) zostaje. |
| `MarkerRoleService` | **Opcjonalnie** — `resolveChordNoteNames()` i `resolveScaleNoteNames()` mogą używać Tonal zamiast `CHORD_PATTERNS`/`SCALE_PATTERNS`. Logika ról (5 ról) pozostaje. |
| `PatternBuilderService` | **Opcjonalnie** — może używać Tonal do resolvowania nut. `PatternInfo` model pozostaje. |
| `music-theory-api` (backend) | **Staje się opcjonalny** — można go wyłączyć feature flagą. Przydatny tylko jeśli potrzebujemy endpointu `find-compatible-scales`. |

### Wpływ na kod

```
Nowe pliki:
  src/app/services/music-theory-engine.service.ts  ← NOWY: wrapper na Tonal
  src/app/shared/tonal-adapter.ts                   ← NOWY: mapowanie nazw Tonal ↔ nasze

Zmodyfikowane:
  src/app/services/music-theory-facade.service.ts   ← wstrzykuje MusicTheoryEngineService zamiast MusicPatternApiService
  src/app/services/interval.service.ts              ← używa Distance.interval() zamiast ręcznej mapy
  src/app/services/marker-role.service.ts           ← opcjonalnie używa Tonal
  src/app/services/pattern-builder.service.ts       ← opcjonalnie używa Tonal

Usunięte/opcjonalne:
  src/app/services/scales-and-triads.service.ts     ← może zostać jako fallback
  src/environments/environment.ts                   ← apiUrl może być tylko dla backendu (jeśli保留)
```

### Ryzyka (podsumowanie)

- **Nazewnictwo**: wymaga warstwy adaptera (1 plik, ~30 linii)
- **Octave stripping**: `note.slice(0, -1)` — 1 linia
- **Enharmonia**: normalizacja do `#` — 1 funkcja
- **Coverage**: spike sprawdzi czy Tonal pokrywa wszystkie 26 patternów
- **Bundle**: ~30KB, tree-shakeable

---

## 11. Minimalny spike techniczny

### Cel
Zweryfikować, czy Tonal.js działa w kontekście Angular 18 i pokrywa nasze przypadki użycia.

### Scope (1-2 godziny)

1. **Instalacja**: `npm install @tonaljs/tonal`
2. **Test skal** — sprawdzić 5 skal (major, minor, dorian, phrygian, diminished) czy zwracają te same nuty co obecne API
3. **Test akordów** — sprawdzić 5 akordów (major, minor, diminished, maj7, dom7) czy zwracają te same nuty
4. **Test enharmonii** — `C#` vs `Db`, `F#` vs `Gb`
5. **Test non-diatonic** — C major scale + E major chord → czy `G#` jest poprawnie identyfikowane jako outside
6. **Test interwałów** — `Distance.interval('C', 'E')` → `'3M'`, mapowanie na `'major-3rd'`
7. **Test bundle** — `ng build` i sprawdzenie rozmiaru

### Kryteria sukcesu
- Wszystkie testy skal i akordów zwracają identyczne nuty jak obecne API
- Enharmonia jest poprawnie normalizowana do `#`
- Non-diatonic chord tones są poprawnie identyfikowane
- Bundle size wzrost < 50KB
- `ng build` i `npm test` przechodzą

### Plik spike'a
```typescript
// spike-tonal.ts — do uruchomienia jako osobny skrypt lub w istniejącym testbie
import { Scale } from '@tonaljs/scale';
import { Chord } from '@tonaljs/chord';
import { Distance } from '@tonaljs/interval';
import { Note } from '@tonaljs/note';

// Test 1: Scale notes
console.log('C major:', Scale.notes('C', 'major'));
// Expected: ['C', 'D', 'E', 'F', 'G', 'A', 'B']

// Test 2: Chord notes (strip octave)
console.log('Cmaj7:', Chord.notes('Cmaj7').map(n => Note.simplify(n)));
// Expected: ['C', 'E', 'G', 'B']

// Test 3: Non-diatonic
const scale = Scale.notes('C', 'major');
const chord = Chord.notes('Emajor').map(n => Note.simplify(n));
const outside = chord.filter(n => !scale.includes(n));
console.log('Outside C major + E major:', outside);
// Expected: ['G#']

// Test 4: Interval mapping
console.log('C→E:', Distance.interval('C', 'E'));
// Expected: '3M'
```

---

## 12. Plan wdrożenia (po spike'u)

```
Krok 1: Spike (1-2h) → potwierdza coverage i nazewnictwo
Krok 2: MusicTheoryEngineService + tonal-adapter.ts (2-3h)
Krok 3: Refactor MusicPatternApiService → opcjonalny fallback (1h)
Krok 4: Uproszczenie IntervalService (1h)
Krok 5: Opcjonalny refactor MarkerRoleService + PatternBuilderService (1-2h)
Krok 6: Testy (2h)
Krok 7: Usunięcie backend API z docker-compose (opcjonalnie, 30min)
```

**Łącznie**: ~8-10h roboczych, 0 zmian w UI, 0 zmian w kontrakcie fasady.