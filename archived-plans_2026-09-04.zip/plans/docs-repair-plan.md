# Plan naprawy dokumentacji

> Na podstawie audytu: [`docs-audit-report.md`](docs-audit-report.md)
> Priorytety: P0 = błędy (nieaktualne informacje), P1 = brakujące dokumenty, P2 = niespójności

---

## P0 — Błędy w istniejących dokumentach

### [x] 0.1 Poprawić ścieżki w `API_DOCUMENTATION.md`

| Linia | Jest | Zamienić na |
|---|---|---|
| 394 | `src/app/freatboard/components/legend/legend.component.ts` | `src/app/legend/legend.component.ts` |
| 438 | `src/app/shared/model/musicElements.ts` | `src/app/shared/model/music-selection.ts` |

### [x] 0.2 Poprawić nazwę `@Output` w `API_DOCUMENTATION.md`

Linia 408: `@Output() onSubmit$` → `@Output() onSubmit`

### [x] 0.3 Poprawić endpoint w `API_DOCUMENTATION.md` i `ARCHITECTURE.md`

- `API_DOCUMENTATION.md` linia 543: `findCompatibleScales` → `find-compatible-scales`
- `ARCHITECTURE.md` linia 129: `findCompatibleScales` → `find-compatible-scales`

### [x] 0.4 Poprawić `PRODUCT_OVERVIEW.md` — nieaktualna info o Unicode

Linia 81: "Backend nie dekoduje Unicode w nazwach patternów" — to zostało naprawione w music-theory-api v0.1.0. Usunąć lub dodać adnotację "FIXED".

---

## P1 — Brakujące dokumenty

### [ ] 1.1 Utworzyć dokumenty w `guitar-neck-shared`

- [`AGENTS.md`](c:/code/Guitar-neck-app/shared/AGENTS.md) — instrukcje dla agentów AI (stack: TypeScript, build: `npm run build`, projekt modeli)
- [`BACKLOG.md`](c:/code/Guitar-neck-app/shared/BACKLOG.md) — backlog zadań dla shared models
- [`CHANGELOG.md`](c:/code/Guitar-neck-app/shared/CHANGELOG.md) — historia zmian shared models

### [ ] 1.2 Utworzyć `CHANGELOG.md` w root `guitar-toolbox`

W [`c:/code/Guitar-neck-app/guitar-toolbox/CHANGELOG.md`](c:/code/Guitar-neck-app/guitar-toolbox/CHANGELOG.md)
— obecnie jest tylko w `projects/guitar-toolbox-lib/`, ale wg wytycznych plik powinien być w root.

### [ ] 1.3 Utworzyć `ARCHITECTURE.md` w `music-theory-api`

W [`c:/code/Guitar-neck-app/music-theory-api/ARCHITECTURE.md`](c:/code/Guitar-neck-app/music-theory-api/ARCHITECTURE.md)
— opisać strukturę: Elysia routes → services → error handling, diagram przepływu danych.

---

## P2 — Niespójności

### [ ] 2.1 Przekonwertować `music-theory-api/BACKLOG.md` na standardowy format

Z epików + sub-itemów + P0-P3 → 6-sekcyjny szablon (Title, Motivation, Solution, MVP, Done when, Status).

### [ ] 2.2 Przetłumaczyć `CHANGELOG.md` w `guitar-neck-ui` na angielski

Obecnie [`CHANGELOG.md`](CHANGELOG.md) jest po polsku. Wg wytycznych changelogi mają być po angielsku.

### [ ] 2.3 Wyczyścić `TODO_DEPLOY.md`

Pozycje oznaczone "DONE" obok OPEN — przenieść DONE do osobnej sekcji lub usunąć.

---

## Kolejność wykonania

1. Najpierw P0 (błędy) — szybkie fixy w 1-2 plikach
2. Potem P1 (brakujące dokumenty) — wymaga utworzenia nowych plików
3. Na końcu P2 (niespójności) — tłumaczenia i konwersje formatów
