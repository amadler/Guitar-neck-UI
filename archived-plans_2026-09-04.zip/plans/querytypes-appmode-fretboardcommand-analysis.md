# Analiza: QueryTypes vs AppMode vs FretboardCommand.kind — trzy typy opisujące podobne koncepcje

## Cel

Zbadać wszystkie typy w codebase (lokalnym i w `guitar-toolbox-lib`), które opisują "rodzaj" zapytania muzycznego, trybu UI lub komendy, i zidentyfikować nakładanie się, niespójności oraz dead code.

---

## 1. Inwentaryzacja wszystkich typów

### A. `QueryTypes` — zewnętrzna biblioteka `guitar-toolbox-lib`

**Plik:** [`node_modules/guitar-toolbox-lib/lib/shared/model/musicElements.d.ts:6`](node_modules/guitar-toolbox-lib/lib/shared/model/musicElements.d.ts:6)

```typescript
export type QueryTypes = 'scale' | 'chord' | 'basic' | 'custom';
```

**Użycie:** `ToolboxSearchQuery.type`, `ScaleOrChordComponent.selectedElementType`  
**Opis:** Typ zapytania w formularzu toolbox — co użytkownik wybrał w dropdownie.

---

### B. `AppMode` — lokalny `app-state.service.ts`

**Plik:** [`src/app/app-state.service.ts:4`](src/app/app-state.service.ts:4)

```typescript
export type AppMode = 'custom-pattern' | 'scale-or-chord' | 'scale-chord';
```

**Użycie:** `AppStateService`, `PatternDisplayComponent`, `RangeToolbarComponent`  
**Opis:** Tryb aplikacji — kontroluje UI (np. czy pokazywać pattern display, czy przełączać między scale a scale+chord).

---

### C. `FretboardCommand.kind` — zewnętrzna biblioteka `guitar-toolbox-lib`

**Plik:** [`node_modules/guitar-toolbox-lib/lib/toolbox-forms/toolbox-forms/toolbox.builder/model.d.ts:33`](node_modules/guitar-toolbox-lib/lib/toolbox-forms/toolbox-forms/toolbox.builder/model.d.ts:33)

```typescript
export type FretboardCommand = ShowScaleCommand | ShowChordCommand | ShowIntervalPatternCommand | CompareCommand;
```

Gdzie `kind` to dyskryminator unii:
- `ShowScaleCommand.kind` → `'scale'`
- `ShowChordCommand.kind` → `'chord'`
- `ShowIntervalPatternCommand.kind` → `'intervalPattern'`
- `CompareCommand.kind` → `'scaleChordRelation'`

**Użycie:** `HomePageComponent.onToolboxEvent()` — switch po `command.kind`  
**Opis:** Dyskryminator komendy z toolboxa — określa który typ komendy został wysłany.

---

### D. `ShowKind` — zewnętrzna biblioteka `guitar-toolbox-lib`

**Plik:** [`node_modules/guitar-toolbox-lib/lib/toolbox-forms/toolbox-forms/toolbox.builder/model.d.ts:7`](node_modules/guitar-toolbox-lib/lib/toolbox-forms/toolbox-forms/toolbox.builder/model.d.ts:7)

```typescript
export type ShowKind = 'chord' | 'scale' | 'intervalPattern';
```

**Opis:** Podtyp komendy "pokaż" — prawie to samo co `FretboardCommand.kind` ale bez `'scaleChordRelation'`.

---

### E. `MusicSelectionType` — lokalny `music-selection.ts`

**Plik:** [`src/app/shared/model/music-selection.ts:1`](src/app/shared/model/music-selection.ts:1)

```typescript
export type MusicSelectionType = 'scale' | 'chord' | 'note' | 'custom' | 'all-notes';
```

**Użycie:** `MusicSelection.type`, `FretboardStateService.currentSelection`, `ScaleChordState`  
**Opis:** Typ encji domenowej — co jest aktualnie wybrane na gryfie.

---

### F. `PatternInfo.type` — lokalny `patternInfo.ts`

**Plik:** [`src/app/shared/model/patternInfo.ts:4`](src/app/shared/model/patternInfo.ts:4)

```typescript
type: 'scale' | 'chord';
```

**Użycie:** `PatternBuilderService.setCurrentPattern()`  
**Opis:** Typ patternu w builderze.

---

### G. `ToolboxIntent` — zewnętrzna biblioteka `guitar-toolbox-lib`

**Plik:** [`node_modules/guitar-toolbox-lib/lib/toolbox-forms/toolbox-forms/toolbox.builder/model.d.ts:1`](node_modules/guitar-toolbox-lib/lib/toolbox-forms/toolbox-forms/toolbox.builder/model.d.ts:1)

```typescript
export type ToolboxIntent = 'show' | 'compare';
```

**Opis:** Intencja użytkownika — czy chce pokazać czy porównać.

---

### H. `DisplayMode` — lokalny `home-page.component.ts`

**Plik:** [`src/app/home-page/home-page.component.ts:18`](src/app/home-page/home-page.component.ts:18)

```typescript
export type DisplayMode = 'legend' | 'relationship' | null;
```

**Opis:** Który overlay jest widoczny na stronie głównej.

---

### I. `MarkerDisplayMode` — lokalny `guitar-neck.service.ts`

**Plik:** [`src/app/services/guitar-neck.service.ts:14`](src/app/services/guitar-neck.service.ts:14)

```typescript
export type MarkerDisplayMode = 'interval-colors' | 'note-names' | 'neutral-dots';
```

**Opis:** Tryb wizualizacji znaczników na gryfie (niezwiązany z pozostałymi typami — osobna koncepcja).

---

## 2. Macierz porównawcza wartości

| Wartość | QueryTypes | AppMode | FretboardCommand.kind | MusicSelectionType | ShowKind | PatternInfo.type |
|---------|-----------|---------|----------------------|-------------------|----------|-----------------|
| `'scale'` | ✅ | — | ✅ | ✅ | ✅ | ✅ |
| `'chord'` | ✅ | — | ✅ | ✅ | ✅ | ✅ |
| `'basic'` | ✅ | — | — | — | — | — |
| `'custom'` | ✅ | — | — | ✅ | — | — |
| `'custom-pattern'` | — | ✅ | — | — | — | — |
| `'scale-or-chord'` | — | ✅ | — | — | — | — |
| `'scale-chord'` | — | ✅ | — | — | — | — |
| `'intervalPattern'` | — | — | ✅ | — | ✅ | — |
| `'scaleChordRelation'` | — | — | ✅ | — | — | — |
| `'note'` | — | — | — | ✅ | — | — |
| `'all-notes'` | — | — | — | ✅ | — | — |

---

## 3. Zidentyfikowane problemy

### 🔴 Problem 1: `AppMode['custom-pattern']` — dead code

Wartość `'custom-pattern'` istnieje w definicji typu [`src/app/app-state.service.ts:4`](src/app/app-state.service.ts:4) i jest testowana w [`src/app/app-state.service.spec.ts:36`](src/app/app-state.service.spec.ts:36), ale **NIGDZIE** nie jest ustawiana przez żaden komponent. Metoda `switchMode()` w [`range-toolbar.component.ts:33`](src/app/range-toolbar/range-toolbar.component.ts:33) przełącza tylko między `'scale-or-chord'` a `'scale-chord'`.

**Wniosek:** `'custom-pattern'` to pozostałość po poprzedniej iteracji — można usunąć.

### 🔴 Problem 2: `QueryTypes['basic']` — wartość bez odpowiednika

`'basic'` istnieje tylko w [`QueryTypes`](node_modules/guitar-toolbox-lib/lib/shared/model/musicElements.d.ts:6) i nie ma odpowiednika w żadnym lokalnym typie. Pochodzi z zewnętrznej biblioteki — nie mamy na nią wpływu, ale warto wiedzieć, że istnieje.

### 🔴 Problem 3: Brak formalnego mapowania między `FretboardCommand.kind` a `AppMode`

W [`HomePageComponent.onToolboxEvent()`](src/app/home-page/home-page.component.ts:50) switch po `command.kind` prowadzi do handlerów, ale **nigdzie nie jest ustawiany `AppMode`**. Oznacza to, że:
- `command.kind === 'scaleChordRelation'` logicznie odpowiada `AppMode === 'scale-chord'`, ale typy tego nie wymuszają.
- `command.kind === 'scale' | 'chord' | 'intervalPattern'` logicznie odpowiada `AppMode === 'scale-or-chord'`, ale też nie jest wymuszone.

### 🔴 Problem 4: `AppMode` miesza dwie koncepcje

- `'scale-or-chord'` vs `'scale-chord'` — to **tryb UI** (pojedynczy vs podwójny wybór)
- `'custom-pattern'` — to **typ zawartości**, ale jest nieużywany

To sugeruje, że `AppMode` powinien być albo przemianowany, albo rozdzielony na dwie osobne koncepcje.

### 🟡 Problem 5: `MusicSelectionType` ma wartości bez odpowiednika

`'note'` i `'all-notes'` istnieją tylko w [`MusicSelectionType`](src/app/shared/model/music-selection.ts:1). Nie ma jasnego związku z innymi typami — to osobna warstwa domenowa.

### 🟡 Problem 6: `PatternInfo.type` jest zawężony

[`PatternInfo.type`](src/app/shared/model/patternInfo.ts:4) to tylko `'scale' | 'chord'`, podczas gdy `MusicSelectionType` ma 5 wartości. To może być celowe (pattern builder obsługuje tylko scale i chord), ale warto sprawdzić czy to ograniczenie jest świadome.

---

## 4. Diagram relacji

```mermaid
flowchart TB
    subgraph External["guitar-toolbox-lib (external)"]
        QT[QueryTypes<br/>scale | chord | basic | custom]
        SK[ShowKind<br/>scale | chord | intervalPattern]
        FC[FretboardCommand.kind<br/>scale | chord | intervalPattern | scaleChordRelation]
        TI[ToolboxIntent<br/>show | compare]
    end

    subgraph Local["src/app (local)"]
        AM[AppMode<br/>custom-pattern | scale-or-chord | scale-chord]
        MST[MusicSelectionType<br/>scale | chord | note | custom | all-notes]
        PT[PatternInfo.type<br/>scale | chord]
        DM[DisplayMode<br/>legend | relationship | null]
    end

    FC -->|"switch(kind) →"| HPC[HomePageComponent]
    HPC -->|"sets"| DM
    HPC -->|"calls"| FOS[FretboardOrchestrationService]
    HPC -->|"calls"| PBS[PatternBuilderService]
    
    AM -->|"read by"| PDC[PatternDisplayComponent]
    AM -->|"toggled by"| RTC[RangeToolbarComponent]
    
    MST -->|"used in"| FSS[FretboardStateService]
    MST -->|"used in"| PBS
    
    PT -->|"used in"| PBS

    style AM fill:#f99,stroke:#333
    style QT fill:#99f,stroke:#333
    style FC fill:#99f,stroke:#333
```

---

## 5. Proponowane działania

### Krok 1: Usunąć dead code — `'custom-pattern'` z `AppMode`

- Usunąć `'custom-pattern'` z definicji [`AppMode`](src/app/app-state.service.ts:4)
- Usunąć test dla `'custom-pattern'` z [`app-state.service.spec.ts:36`](src/app/app-state.service.spec.ts:36)
- Zmniejsza to `AppMode` do: `'scale-or-chord' | 'scale-chord'`

### Krok 2: Dodać jawne mapowanie między `FretboardCommand.kind` a `AppMode`

Rozważyć dodanie funkcji mapującej lub stałej w [`HomePageComponent`](src/app/home-page/home-page.component.ts):

```typescript
const COMMAND_TO_APP_MODE: Record<FretboardCommand['kind'], AppMode> = {
  scale: 'scale-or-chord',
  chord: 'scale-or-chord',
  intervalPattern: 'scale-or-chord',
  scaleChordRelation: 'scale-chord',
};
```

I użyć jej w `onToolboxEvent()` aby automatycznie ustawić `AppMode`.

### Krok 3: Rozważyć zmianę nazwy `AppMode` na `UIMode`

Ponieważ `AppMode` opisuje tryb UI (pojedynczy vs podwójny wybór), a nie typ danych muzycznych, nazwa `UIMode` lub `ViewMode` byłaby bardziej adekwatna.

### Krok 4: Udokumentować intencję każdego typu

Dodać komentarze JSDoc do każdego typu, aby wyjaśnić jego rolę i związek z innymi typami.

---

## 6. Podsumowanie

| Typ | Lokalizacja | Wartości | Problem |
|-----|------------|----------|---------|
| `QueryTypes` | external | 4 | `'basic'` bez odpowiednika lokalnego |
| `AppMode` | local | 3 | `'custom-pattern'` to dead code |
| `FretboardCommand.kind` | external | 4 | brak formalnego mapowania na `AppMode` |
| `MusicSelectionType` | local | 5 | `'note'` i `'all-notes'` bez odpowiednika |
| `ShowKind` | external | 3 | podzbiór `FretboardCommand.kind` |
| `PatternInfo.type` | local | 2 | zawężony do scale/chord |
| `ToolboxIntent` | external | 2 | osobna koncepcja (show vs compare) |
| `DisplayMode` | local | 3 | osobna koncepcja (overlay UI) |
| `MarkerDisplayMode` | local | 3 | osobna koncepcja (wizualizacja) |

**Główna rekomendacja:** Najpilniejsza zmiana to usunięcie dead code (`'custom-pattern'`) i dodanie jawnego mapowania między `FretboardCommand.kind` a `AppMode`, aby typy wymuszały spójność stanu.