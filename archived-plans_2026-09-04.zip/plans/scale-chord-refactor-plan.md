# Refactor Plan: Scale-to-Chord Relation

## Status: Draft for review

## 1. Problem Summary

The scale-to-chord relation feature was built entirely client-side, with logic spread across multiple files and duplicated in 3 places:

| Problem | Location | Impact |
|---------|----------|--------|
| `resolveChordNoteNames` / `resolveScaleNoteNames` duplicated | `marker-role.service.ts`, `relationship-strip.component.ts`, `music-theory-facade.service.ts` (inlined) | 3 copies of identical logic |
| Chord notes resolved client-side from `CHORD_PATTERNS` | `music-theory-facade.service.ts:109-125` | Inconsistent with API (scale notes come from API, chord notes from local patterns) |
| ScaleChordFormComponent in app | `scale-chord-form/` | Should be in toolbox (UI console) |
| ChordDegreeSelectorComponent | `chord-degree-selector/` | To be removed entirely |
| Domain logic in UI components | `chord-degree-selector.component.ts:26-103` | Degree-to-chord mapping is pure music theory, shouldn't be in Angular component |

## 2. Target Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    guitar-neck-ui (host app)                 │
│                                                             │
│  HomePageComponent                                          │
│    ├── toolboxSubmit() handles ScaleChordQuery              │
│    │     └── FretboardOrchestrationService                  │
│    │           └── MusicPatternApiService                   │
│    │                 └── HTTP GET /api/scale-chord/...      │
│    │                                                       │
│    ├── MarkerRoleService.computeRoles()                     │
│    │     └── Uses API response data (no local resolution)   │
│    │                                                       │
│    ├── RelationshipStripComponent                           │
│    │     └── Uses API response data (no local resolution)   │
│    │                                                       │
│    └── PatternBuilderService.setRelatedChord()              │
│          └── Stays client-side (UI display concern)         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                    guitar-toolbox-lib                        │
│                                                             │
│  ScaleChordFormComponent (new)                              │
│    ├── Loads scales/chords via own HTTP service             │
│    ├── Emits ScaleChordQuery (discriminated union)          │
│    └── No domain logic — pure UI console                    │
│                                                             │
│  ToolboxSearchQuery (extended)                              │
│    └── ScaleChordQuery extends ToolboxSearchQuery           │
│          type: 'scale-chord'                                │
│          scaleName: string                                  │
│          scaleRoot: string                                  │
│          chordName: string                                  │
│          chordRoot: string                                  │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                    music-theory-api (backend)                │
│                                                             │
│  GET /api/scale-chord/:scaleName/:scaleRoot/:chordName/:chordRoot
│    Response: {                                              │
│      scaleNotes: string[],          // nuty skali           │
│      chordNotes: string[],          // nuty akordu          │
│      chordTonesInScale: string[],   // overlap              │
│      chordTonesOutsideScale: string[] // poza skalą         │
│    }                                                        │
└─────────────────────────────────────────────────────────────┘
```

## 3. Detailed Contract

### 3.1 API Endpoint

```
GET /api/scale-chord/:scaleName/:scaleRoot/:chordName/:chordRoot
```

**Parameters** (all URL-encoded):
- `scaleName`: e.g. "major", "dorian"
- `scaleRoot`: e.g. "C", "F#"
- `chordName`: e.g. "major", "diminished"
- `chordRoot`: e.g. "E", "G#"

**Response** (200):
```typescript
{
  scaleNotes: string[],              // e.g. ["C","D","E","F","G","A","B"]
  chordNotes: string[],              // e.g. ["E","G#","B"]
  chordTonesInScale: string[],       // e.g. ["E","B"] — chord notes that ARE in the scale
  chordTonesOutsideScale: string[]   // e.g. ["G#"] — chord notes NOT in the scale
}
```

**Error** (400/500): `{ error: string }`

### 3.2 ToolboxSearchQuery Extension

Current interface stays unchanged. New discriminated union type:

```typescript
// In guitar-toolbox-lib

// Existing — unchanged
interface ToolboxSearchQuery {
  musicElements: string | number[];
  keys: string;
  type: 'scale' | 'chord' | 'basic' | 'custom';
}

// New — discriminated union
interface ScaleChordQuery extends ToolboxSearchQuery {
  type: 'scale-chord';
  scaleName: string;
  scaleRoot: string;
  chordName: string;
  chordRoot: string;
  // musicElements and keys are ignored when type='scale-chord'
}
```

### 3.3 ScaleChordFormComponent (in toolbox)

**Selector**: `lib-scale-chord-form`

**Inputs**: none (loads data via own HTTP service)

**Outputs**:
- `onSubmit: EventEmitter<ScaleChordQuery>` — emitted on "Show" click

**Internal**:
- Loads available scales from `GET /api/scales`
- Loads available chords from `GET /api/chords`
- Uses `neckConfig.chromaticNotes` for key selector (from `guitar-neck-shared`)

**Template**: Two independent select rows:
1. Scale: [scale dropdown] [key dropdown]
2. Chord: [chord dropdown] [key dropdown]
3. Button: "Show"

### 3.4 MusicPatternApiService Changes (in app)

Add new method:

```typescript
interface ScaleChordApiResponse {
  scaleNotes: string[];
  chordNotes: string[];
  chordTonesInScale: string[];
  chordTonesOutsideScale: string[];
}

class MusicPatternApiService {
  // ... existing methods unchanged ...

  resolveScaleChordRelation(
    scaleName: string,
    scaleRoot: string,
    chordName: string,
    chordRoot: string,
  ): Observable<ScaleChordApiResponse> {
    const fmtScale = this.formatName(scaleName);
    const fmtChord = this.formatName(chordName);
    return this.http.get<ScaleChordApiResponse>(
      `${this.API_URL}/scale-chord/${fmtScale}/${encodeURIComponent(scaleRoot)}/${fmtChord}/${encodeURIComponent(chordRoot)}`
    ).pipe(catchError(this.handleError));
  }
}
```

### 3.5 FretboardOrchestrationService Changes

`displayScaleWithChord()` is rewritten to use the new API endpoint:

```typescript
displayScaleWithChord(
  scaleName: string,
  scaleRoot: string,
  chordName: string,
  chordRoot: string,
): Observable<GuitarNote[]> {
  this.loadingService.show();

  return this.patternApi.resolveScaleChordRelation(scaleName, scaleRoot, chordName, chordRoot).pipe(
    map(response => {
      // 1. Clear stale interval data
      this.intervalService.removeIntervals(this.guitarNeckService.notes);

      // 2. Find positions for scale notes AND outside chord notes
      const scalePositions = this.noteService.findPositionsByScaleNotes(response.scaleNotes);
      const outsidePositions = this.noteService.findPositionsByScaleNotes(response.chordTonesOutsideScale);
      const allPositions = [...scalePositions, ...outsidePositions];
      const highlightedNotes = this.guitarNeckService.applyHighlightedNotes(allPositions);

      // 3. Build chord selection
      const chordSelection: MusicSelection = {
        type: 'chord',
        name: chordName,
        rootNote: chordRoot,
      };

      // 4. Set dual selection state
      this.guitarNeckService.scaleChordState = {
        scale: {
          type: 'scale',
          name: scaleName,
          rootNote: scaleRoot,
          notes: response.scaleNotes,
        },
        chord: chordSelection,
      };

      // 5. Store API response for downstream consumers
      this.guitarNeckService.scaleChordApiData = response;

      // 6. Compute marker roles (uses response data, no local resolution)
      this.markerRoleService.computeRoles(
        this.guitarNeckService.notes,
        this.guitarNeckService.scaleChordState.scale,
        chordSelection,
        response,  // NEW: pass API response directly
      );

      return highlightedNotes;
    }),
    catchError(error => {
      console.error('Error displaying scale with chord:', error);
      return of([]);
    }),
    finalize(() => this.loadingService.hide()),
  );
}
```

### 3.6 MarkerRoleService Changes

- Remove `resolveChordNoteNames()` and `resolveScaleNoteNames()` functions
- `computeRoles()` accepts optional API response parameter
- When API response is provided, uses `response.chordNotes` and `response.scaleNotes` directly
- Falls back to empty sets if no API response (defensive)

```typescript
computeRoles(
  notes: GuitarNote[],
  scaleSelection: MusicSelection,
  chordSelection: MusicSelection | null,
  apiResponse?: ScaleChordApiResponse,  // NEW optional parameter
): Map<string, MarkerRole> {
  // ... existing logic ...
  // Instead of calling resolveScaleNoteNames/resolveChordNoteNames:
  const scaleNoteNames = apiResponse
    ? new Set(apiResponse.scaleNotes)
    : new Set<string>();
  const chordNoteNames = apiResponse && chordSelection
    ? new Set(apiResponse.chordNotes)
    : new Set<string>();
  // ... rest of role computation unchanged ...
}
```

### 3.7 RelationshipStripComponent Changes

- Remove `resolveChordNoteNames()` and `resolveScaleNoteNames()` functions
- Read `chordTonesInScale` and `chordTonesOutsideScale` from `FretboardStateService.scaleChordApiData`

```typescript
get chordTonesInScale(): string[] {
  return this.fretboardState.scaleChordApiData?.chordTonesInScale ?? [];
}

get chordTonesOutsideScale(): string[] {
  return this.fretboardState.scaleChordApiData?.chordTonesOutsideScale ?? [];
}
```

### 3.8 FretboardStateService Changes

Add new field for API response cache:

```typescript
/** Cached API response from the last scale-chord relation call. */
scaleChordApiData: ScaleChordApiResponse | null = null;
```

Reset in `clearFretboard()`:
```typescript
clearFretboard() {
  // ... existing ...
  this.scaleChordApiData = null;
}
```

### 3.9 HomePageComponent Changes

- Import `ScaleChordQuery` from `guitar-toolbox-lib`
- Handle `type: 'scale-chord'` in `toolboxSubmit()`
- Remove `onScaleChordFormShow()` (replaced by toolboxSubmit)
- Remove `onChordDegreeSelected()` (ChordDegreeSelector removed)
- Remove `ScaleChordFormComponent` import (now in toolbox)

```typescript
toolboxSubmit(event: ToolboxSearchQuery | ScaleChordQuery): void {
  this.guitarNeckService.clearFretboard();
  this.patternBuilder.clearCurrentPattern();

  if (event.type === 'scale-chord') {
    this.handleScaleChordRelation(event);
    return;
  }

  // ... existing type handling ...
}

private handleScaleChordRelation(query: ScaleChordQuery): void {
  this.fretboardOrchestrationService.displayScaleWithChord(
    query.scaleName,
    query.scaleRoot,
    query.chordName,
    query.chordRoot,
  ).subscribe();

  this.patternBuilder.setCurrentPattern(query.scaleName, query.scaleRoot, 'scale');
  this.patternBuilder.setRelatedChord(query.chordName, query.chordRoot);
}
```

### 3.10 Files to Remove

| File | Reason |
|------|--------|
| `src/app/scale-chord-form/` (entire directory) | Moved to toolbox |
| `src/app/chord-degree-selector/` (entire directory) | Removed entirely |
| `src/app/services/marker-role.service.ts:29-84` | `resolveChordNoteNames` / `resolveScaleNoteNames` functions |
| `src/app/relationship-strip/relationship-strip.component.ts:21-51` | `resolveChordNoteNames` / `resolveScaleNoteNames` functions |
| `src/app/services/music-theory-facade.service.ts:109-125` | Inlined chord note resolution |

## 4. Task Breakdown

### Task Group A: music-theory-api (backend)

| # | Task | Description | File |
|---|------|-------------|------|
| A1 | Add `GET /api/scale-chord/:scaleName/:scaleRoot/:chordName/:chordRoot` endpoint | New endpoint returning `{ scaleNotes, chordNotes, chordTonesInScale, chordTonesOutsideScale }` | `music-theory-api` repo |
| A2 | Add Elysia schema/validation for new endpoint | Validate params, return 400 on invalid scale/chord name | `music-theory-api` repo |
| A3 | Add unit tests for new endpoint | Test major+minor scales, various chord combinations, edge cases | `music-theory-api` repo |
| A4 | Update API documentation | Add new endpoint to README/docs | `music-theory-api` repo |

### Task Group B: guitar-toolbox-lib (toolbox)

| # | Task | Description | File |
|---|------|-------------|------|
| B1 | Add `ScaleChordQuery` interface | Discriminated union extending `ToolboxSearchQuery` with `type: 'scale-chord'` + `scaleName`, `scaleRoot`, `chordName`, `chordRoot` | `guitar-toolbox-lib` |
| B2 | Create `ScaleChordFormComponent` | New standalone component with scale dropdown, chord dropdown, key selectors, "Show" button | `guitar-toolbox-lib` |
| B3 | Add HTTP service in toolbox for loading scales/chords lists | Fetch `GET /api/scales` and `GET /api/chords` | `guitar-toolbox-lib` |
| B4 | Export `ScaleChordFormComponent` and `ScaleChordQuery` from public API | Update `public-api.ts` | `guitar-toolbox-lib` |
| B5 | Add CSS for ScaleChordFormComponent (layout only, no colors) | Follow existing CSS variables pattern | `guitar-toolbox-lib` |
| B6 | Bump version and publish | `npm version patch` + publish | `guitar-toolbox-lib` |

### Task Group C: guitar-neck-ui (host app)

| # | Task | Description | File |
|---|------|-------------|------|
| C1 | Add `resolveScaleChordRelation()` to `MusicPatternApiService` | New method calling `GET /api/scale-chord/...` | `src/app/services/scales-and-triads.service.ts` |
| C2 | Add `ScaleChordApiResponse` interface | Type for API response | `src/app/services/scales-and-triads.service.ts` or shared model |
| C3 | Add `scaleChordApiData` field to `FretboardStateService` | Cache for API response, reset in `clearFretboard()` | `src/app/services/guitar-neck.service.ts` |
| C4 | Rewrite `displayScaleWithChord()` in `FretboardOrchestrationService` | Use new API endpoint, pass response to MarkerRoleService | `src/app/services/music-theory-facade.service.ts` |
| C5 | Update `MarkerRoleService.computeRoles()` | Accept optional API response, remove local resolve functions | `src/app/services/marker-role.service.ts` |
| C6 | Update `RelationshipStripComponent` | Remove local resolve functions, read from `scaleChordApiData` | `src/app/relationship-strip/relationship-strip.component.ts` |
| C7 | Update `HomePageComponent.toolboxSubmit()` | Handle `type: 'scale-chord'`, remove old handlers | `src/app/home-page/home-page.component.ts` |
| C8 | Remove `ScaleChordFormComponent` directory | Entire component moved to toolbox | `src/app/scale-chord-form/` |
| C9 | Remove `ChordDegreeSelectorComponent` directory | Entire component removed | `src/app/chord-degree-selector/` |
| C10 | Remove `ScaleChordFormComponent` and `ChordDegreeSelectorComponent` from imports | Update `home-page.component.ts` imports and template | `src/app/home-page/home-page.component.ts` |
| C11 | Update `package.json` with new toolbox version | `npm install guitar-toolbox-lib@latest` | `package.json` |
| C12 | Update tests for changed services | Update `music-theory-facade.service.spec.ts`, `marker-role.service.spec.ts`, etc. | `src/app/services/` |
| C13 | Update `API_DOCUMENTATION.md` | Document new endpoint, remove old duplication notes | `API_DOCUMENTATION.md` |
| C14 | Update `ARCHITECTURE.md` | Update data flow diagrams, remove ChordDegreeSelector references | `ARCHITECTURE.md` |
| C15 | Update `BACKLOG.md` | Mark relevant items as FIXED | `BACKLOG.md` |

## 5. Dependency Graph

```
A1 ─── A2 ─── A3 ─── A4
                        │
B1 ─── B2 ─── B3 ─── B4 ─── B5 ─── B6
                        │           │
                        └───────────┼────────┐
                                    │        │
C1 ─── C2 ─── C3 ─── C4 ─── C5 ─── C6 ─── C7 ─── C8 ─── C9 ─── C10 ─── C11 ─── C12 ─── C13 ─── C14 ─── C15
```

- **A1-A4** (API) can be done independently
- **B1-B6** (toolbox) can be done independently, but B1 interface should be agreed with C7
- **C1-C15** (host app) depends on A1 (API endpoint existing) and B6 (new toolbox version published)

## 6. Migration Strategy

### Phase 1: API (parallel)
- Implement A1-A4 in `music-theory-api` repo
- Deploy/merge independently

### Phase 2: Toolbox (parallel)
- Implement B1-B6 in `guitar-toolbox-lib` repo
- Publish new version

### Phase 3: Host App (sequential, after Phase 1+2)
1. C1-C3: Add API method and state field (no behavior change yet)
2. C4-C6: Rewrite services to use API data (behavior changes, but UI looks same)
3. C7-C10: Update HomePageComponent, remove old components
4. C11: Update toolbox dependency
5. C12-C15: Tests and docs

## 7. Risk Assessment

| Risk | Impact | Mitigation |
|------|--------|------------|
| API endpoint returns different results than current client-side logic | Medium | Write integration tests comparing old vs new results for same inputs |
| Toolbox version bump breaks existing functionality | Low | Follow semver, test existing toolboxSubmit paths |
| ChordDegreeSelector removal breaks existing user flow | Low | Feature was only in scale-chord mode, user confirmed removal |
| PatternBuilderService.setRelatedChord() still uses CHORD_PATTERNS — could diverge from API | Low | It's a UI display concern (shows interval names/steps), not domain logic |