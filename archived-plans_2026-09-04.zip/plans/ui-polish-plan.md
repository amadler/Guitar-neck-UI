# UI Polish Plan — Bottom Workspace

## Wytyczne dla dewelopera toolbox library

Miejsce: `../guitar-toolbox/projects/guitar-toolbox-lib/`

### 1. Zmiany w template (`src/lib/toolbox-form/toolbox-form.component.html`)

| Linia | Obecnie | Zmienić na |
|-------|---------|------------|
| 1 | `<h2 class="toolbox__title">Select, what you want to see on guitar neck.</h2>` | `<h2 class="toolbox__title">Show on fretboard</h2>` |
| 37 | `<label class="toolbox__label" for="key">Key of:</label>` | `<label class="toolbox__label" for="key">Key</label>` |
| 43 | `<button type="submit" class="toolbox__submit">Show!</button>` | `<button type="submit" class="toolbox__submit">Show</button>` |

Taby "Standard Patterns" i "Custom Pattern" — tekst bez zmian.

### 2. Zmiany w stylach (`src/lib/toolbox-form/toolbox-form.component.scss`)

**Active tab (`.toolbox__mode-btn--active`):**
Uzupełnić istniejący selektor o:
```scss
.toolbox__mode-btn--active {
  // istniejące deklaracje:
  border-color: var(--toolbox-accent, currentColor);
  background: var(--toolbox-accent-bg, transparent);
  color: var(--toolbox-accent, currentColor);
  // dodać:
  font-weight: 700;
}
```

**Inactive tab — dodać delikatniejsze tło:**
```scss
.toolbox__mode-btn:not(.toolbox__mode-btn--active) {
  background: var(--app-surface-soft, #f8faf8);
  border-color: var(--app-border, #dfe4e0);
  color: var(--app-muted, #65706a);
}
```

**Button submit — dodać hover/active:**
```scss
.toolbox__submit {
  // existing
  &:hover {
    opacity: 0.9;
  }
  &:active {
    transform: translateY(1px);
  }
}
```

### 3. Build

1. `cd ../guitar-toolbox`
2. `npm run build` — buduje do `dist/guitar-toolbox-lib`
3. W głównym projekcie (`../guitar-neck-app/Guitar neck UI`):
   - W `package.json` zmienić `"guitar-toolbox-lib": "^1.2.1"` na `"guitar-toolbox-lib": "file:../guitar-toolbox/dist/guitar-toolbox-lib"`
   - `npm install`
4. Walidacja: `npm run build` w głównym projekcie


## Podział na dwa workstreamy

```
┌─────────────────────────────────────────────────────────────────┐
│                    UI Polish — Bottom Workspace                  │
├──────────────────────────────────┬──────────────────────────────┤
│  Workstream 1: Toolbox Library   │  Workstream 2: Main App      │
│  (../guitar-toolbox/)            │  (./ — Guitar neck UI)       │
├──────────────────────────────────┼──────────────────────────────┤
│  • Zmiana tekstów/template       │  • Metronome visual polish   │
│  • Poprawka stylów biblioteki    │  • Dock/metronome host CSS   │
│  • Build + publikacja nowej      │  • Wspólne zmiany w          │
│    wersji (1.2.2)                │    styles.scss               │
└──────────────────────────────────┴──────────────────────────────┘
```

---

## Workstream 1: Toolbox Library (`../guitar-toolbox/`)

Modyfikacje w źródle biblioteki w `projects/guitar-toolbox-lib/`.

### 1.1 ToolboxForm — template (`toolbox-form.component.html`)

| Element | Obecnie | Docelowo |
|---------|---------|----------|
| Nagłówek (linia 1) | `Select, what you want to see on guitar neck.` | `Show on fretboard` |
| Tab 1 (linia 8) | `Standard Patterns` | bez zmian |
| Tab 2 (linia 14) | `Custom Pattern` | bez zmian (może być wizualnie zdegradowany) |
| Label Key (linia 37) | `Key of:` | `Key` |
| Button (linia 43) | `Show!` | `Show` |

### 1.2 ToolboxForm — style (`toolbox-form.component.scss`)

**Aktywny tab (`Standard Patterns`) — `.toolbox__mode-btn--active`:**
- `background: var(--toolbox-accent-bg, transparent)` → ustawić w host jako delikatne zielone tło
- `border-color: var(--toolbox-accent, currentColor)` → zielony border
- `color: var(--toolbox-accent, currentColor)` → ciemnozielony tekst

**Nieaktywny tab:**
- jaśniejsze tło, neutralny border, mniej dominujący

**Wszystkie taby:**
- ten sam `height`, `border-radius`, `font-size`

**Button `.toolbox__submit`:**
- zielone tło (`var(--toolbox-accent)`), biały tekst
- ten sam styl co Start w metronomie
- brak wykrzyknika (zmiana w template)
- wysokość 40px (już jest)

### 1.3 CustomPattern — template + style (`custom-pattern.component.*`)

Jeśli Custom Pattern pozostaje poza MVP — wizualnie zdegradować:
- Zmniejszyć padding/margin
- Dodać klasę do przygaszenia

### 1.4 Build i publikacja

1. `cd ../guitar-toolbox`
2. `npm run build` (buduje `guitar-toolbox-lib` do `dist/guitar-toolbox-lib`)
3. W głównym projekcie: zmienić `package.json` aby wskazywał na lokalny build:
   `"guitar-toolbox-lib": "file:../guitar-toolbox/dist/guitar-toolbox-lib"`
4. `npm install` (zaktualizuje symlink/node_modules)

---

## Workstream 2: Main App (`./` — Guitar neck UI)

### 2.1 Metronome (`src/app/metronome/metronome.component.html` + `.scss`)

#### 2.1.1 Nagłówek (dodać tytuł)
W HTML: dodać `<h2 class="metronome__title">Metronome</h2>` na górze `.metronome-card`
- Styl: taki sam jak `Show on fretboard` (16px, bold, kolor `--toolbox-text` lub `--app-text`)

#### 2.1.2 Beat indicator — zmniejszyć
W SCSS (linia 4): `$beat-circle-size: 80px` → `50px` (~37% redukcji)
- Mniejsze koło, mniejszy font (28px → ~20px)
- Kropki (`$beat-dot-size: 8px` → `6px`, `$beat-dot-accent-size: 10px` → `7px`)
- Zmniejszyć `gap` w `.beat-dots` z `8px` na `6px`

#### 2.1.3 Tempo — ułożyć w jednej linii
W HTML: zmienić strukturę sekcji tempo:
```
Tempo  [slider]  [input]  BPM
```
- Label "TEMPO" → "Tempo" (w HTML jest już "Tempo" — dobrze)
- W stylach: `.tempo-section` → `flex-direction: row` + `align-items: center`
- `.tempo-label` → nie uppercase, nie letter-spacing
- `.tempo-controls` → już flex, dostosować gap
- Slider: dodać zielony aktywny fragment (`background: linear-gradient(to right, var(--green-700) X%, var(--app-border) X%)`)
- Input: styl zbliżyć do selectów (taki sam height, border, radius)
- Wyrównać slider, input, BPM w baseline

#### 2.1.4 Time Signature — poprawić aktywny stan
W SCSS (linia 209-211):
```scss
.time-sig-btn.active {
  border-color: var(--green-700);
  background: var(--green-100);       // bardzo jasne zielone tło
  color: var(--green-800);            // ciemnozielony tekst
}
```
- Wszystkie opcje: ta sama `height`, `border-radius`, spójny `border`
- Obecnie `border-radius: 20px` (zostaje lub zmienić na `--radius-md`)

#### 2.1.5 Buttons — Start i Tap Tempo
**Start:**
- Zostać primary green button (obecnie `background: var(--green-700)`)
- Taka sama wysokość jak `.toolbox__submit` (40px)

**Tap Tempo:**
- Zmienić na secondary/outline button:
  ```scss
  .tap-btn {
    border: 1px solid var(--green-700);
    background: transparent;
    color: var(--green-700);
  }
  ```
- Oba buttony tej samej wysokości (40px)
- Odstęp: `gap: 10px` → sprawdzić

### 2.2 Wspólny styl dla obu paneli (`src/styles.scss`)

**CSS custom properties w `:root` (linia 68-101):**
Dodać/zmodyfikować:
```css
--toolbox-title-font-size: 16px;
--toolbox-title-weight: 700;
```

**Host-level dla `lib-toolbox-form` (linia 546-552):**
- `padding: 22px` → sprawdzić czy nie zmieniać
- `border-right: 1px solid var(--app-border)` — bez zmian
- Dodać spójne `border-radius`

**Dock body (linia 531-536):**
- `.dock__body` — `grid-template-columns: 1fr 1fr` — bez zmian layoutu

**Nowy globalny blok: `/* ===== Bottom panels shared ===== */`**
```css
/* Ujednolicenie border-radius, padding, wysokości kontroli */
lib-toolbox-form,
app-metronome .metronome-card {
  border-radius: var(--radius-lg);
  padding: 22px;
}

/* Select, input, button — ta sama wysokość */
.toolbox__select,
.toolbox__submit,
.metronome .tempo-input,
.metronome .start-stop-btn,
.metronome .tap-btn {
  height: 40px;
  border-radius: var(--radius-sm);
}

/* Focus/hover stany */
.toolbox__select:focus,
.tempo-input:focus {
  border-color: var(--green-700);
  box-shadow: 0 0 0 2px rgba(8, 99, 30, 0.15);
}

/* Typografia nagłówków spójna */
.toolbox__title,
.metronome__title {
  font-size: 16px;
  font-weight: 700;
  color: var(--app-text);
  margin: 0 0 22px;
}
```

### 2.3 Zmniejszyć pustkę w dolnych kartach

- Zmniejszyć `margin-bottom: 26px` w `.toolbox__form` na mniejsze (np. 16px)
- W `.metronome-card`: `padding: 20px` → opcjonalnie dostosować

### 2.4 Złagodzić obramowania

- Upewnić się że `--app-border` (#dfe4e0) jest używany wszędzie
- Aktywne stany: border zamiast samego koloru tła

---

## Definition of Done

| Kryterium | Status |
|-----------|--------|
| Layout pozostał taki sam (grid, pozycje paneli, struktura) | ☐ |
| Dolne panele są wizualnie spójne (border-radius, padding, heights) | ☐ |
| Metronom mniej dominuje (beat indicator zmniejszony o 30-40%) | ☐ |
| Formularz patternów jest czytelniejszy (spójne selecty, button) | ☐ |
| CTA (Show, Start, Tap Tempo) są równo ustawione i spójne stylistycznie | ☐ |
| UI wygląda bardziej dopracowanie bez wrażenia redesignu | ☐ |
| Nowa wersja biblioteki (1.2.2) zbudowana i podpięta lokalnie | ☐ |

---

## Kolejność wykonania

1. **Workstream 1 — Toolbox Library**: zmiany w template i SCSS źródła, build
2. **Workstream 1.5 — Podpięcie lokalne**: update main app package.json + npm install
3. **Workstream 2 — Metronome**: HTML + SCSS zmiany
4. **Workstream 2 — Wspólny styl**: aktualizacja styles.scss
5. **Walidacja**: `npm run build` + sprawdzenie wizualne
