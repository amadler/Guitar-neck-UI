# Plan przejścia na Tonal.js

## Branch
`feat/tonaljs-integration`

## Zakres zmian

### USUWAMY (4 pliki + 3 pliki konfiguracyjne)
| Plik | Linie | Powód |
|------|-------|-------|
| `src/app/services/scales-and-triads.service.ts` | 52 | HTTP → backend, niepotrzebny |
| `src/app/services/interval.service.ts` | 92 | Logika wklejona do fasady (~10 linii) |
| `docker-compose.yml` | - | Backend niepotrzebny |
| `Dockerfile` | - | jw. |
| `nginx.conf` | - | jw. |
| `src/environments/environment.ts` (apiUrl) | częściowo | Niepotrzebne |

### ZOSTAJE (6 serwisów)
- `FretboardOrchestrationService` — cieńsza, synchroniczna
- `MarkerRoleService` — logika 5 ról (UI-specific)
- `FretboardNotePositionService` — geometria gryfu
- `FretboardStateService` — stan gryfu
- `FretboardDisplayService` — CSS klasy
- `PatternBuilderService` — PatternInfo z krokami W/H

### DODAJEMY (1 plik)
| Plik | Linie | Opis |
|------|-------|------|
| `src/app/shared/tonal-adapter.ts` | ~15 | `INTERVAL_MAP` + helpery |

### ZMIENIAMY (2 pliki)
| Plik | Co się zmienia |
|------|---------------|
| `src/app/services/music-theory-facade.service.ts` | Import Tonal zamiast HTTP. Metody synchroniczne (`GuitarNote[]` zamiast `Observable<GuitarNote[]>`). `markIntervals()` jako prywatna metoda. |
| `src/app/shared/UICommands.ts` | `execute()` bez `.subscribe()` |

### AKTUALIZUJEMY (dokumentacja)
- `ARCHITECTURE.md` — przepływ danych, diagram
- `API_DOCUMENTATION.md` — sygnatury metod (bez Observable)
- `PRODUCT_OVERVIEW.md` — integracje (bez backend API)
- `DEVELOPMENT.md` — bez docker-compose
- `CONTEXT.md` — nowe terminy (MusicTheoryEngine, TonalAdapter)

## Kolejność implementacji

```
Krok 1: git checkout -b feat/tonaljs-integration
Krok 2: src/app/shared/tonal-adapter.ts ← NOWY
Krok 3: src/app/services/music-theory-facade.service.ts ← ZMIANA (Tonal, synchroniczne)
Krok 4: src/app/shared/UICommands.ts ← ZMIANA (bez .subscribe())
Krok 5: Usunięcie scales-and-triads.service.ts
Krok 6: Usunięcie interval.service.ts
Krok 7: Usunięcie docker-compose.yml, Dockerfile, nginx.conf
Krok 8: Usunięcie spike-tonal.spec.ts
Krok 9: Aktualizacja dokumentacji (ARCHITECTURE, API_DOCUMENTATION, PRODUCT_OVERVIEW, DEVELOPMENT, CONTEXT)
Krok 10: npm test + npm run build
Krok 11: git commit + push
```

## Ryzyka
- `UICommands.spec.ts` i `music-theory-facade.service.ts` testy wymagają aktualizacji (zmiana z Observable na synchroniczne)
- `app-state.service.spec.ts` ma pre-existing błędy (niezwiązane z Tonal)
- Chrome crash w testach — znany problem środowiskowy