# Plan: Mode Selector + Scale + Chord Relations v2

> **Status**: Updated after grilling session (2026-07-10)
> **Docs**: [CONTEXT.md](../CONTEXT.md), [ADR 0001](../docs/adr/0001-app-state-service.md), [ADR 0002](../docs/adr/0002-independent-chord-selection.md)

## Spis treści

1. [Stan obecny](#1-stan-obecny)
2. [Nowa architektura — przegląd](#2-nowa-architektura--przegląd)
3. [Faza 1: AppStateService + ModeSelector + podstawowe formularze](#3-faza-1-appstateservice--modeselector--podstawowe-formularze)
4. [Faza 2: Nowy system kolorów role-based dla scale+chord](#4-faza-2-nowy-system-kolorów-role-based-dla-scalechord)
5. [Faza 3: RelationshipStrip](#5-faza-3-relationshipstrip)
6. [Faza 4: PatternDisplay + PracticePrompts](#6-faza-4-patterndisplay--practiceprompts)
7. [Faza 5: Czyszczenie i testy](#7-faza-5-czyszczenie-i-testy)
8. [Constraint: nie zepsuć istniejącej funkcjonalności](#8-constraint-nie-zepsuć-istniejącej-funkcjonalności)
9. [Podsumowanie plików](#9-podsumowanie-plików)

---

## 1. Stan obecny

### Layout (`home-page.component.html`)

```
.app-shell
  ├── app-header                          — zawsze widoczne
  ├── div#guitar-neck-container
  │   └── app-guitar-neck                 — range-toolbar + freatboard
  ├── app-legend                          — intervals legend + marker roles legend
  ├── app-pattern-display                 — info o skali/akordzie + practice prompts
  ├── section.dock
  │   ├── app-chord-degree-selector       — zakomentować
  │   └── div.dock__body
  │       ├── lib-toolbox-form            — formularz wyszukiwania (z guitar-toolbox-lib)
  │       └── app-chat / app-metronome
  └── app-footer                          — zawsze widoczne
```

### Obecny przepływ danych — tryb Scale

```
ToolboxForm (wybór skali)
  → HomePageComponent.buildScaleCommand()
    → FretboardStateService.scaleChordState = { scale: {...}, chord: null }
    → DisplayScaleCommand → FretboardOrchestrationService.displayScale()
      → wysyła scale do API → dostaje nuty
      → IntervalService.markIntervals() (koloruje interwały na gryfie)
  → PatternBuilderService.setCurrentPattern()
  → Legend: widoczne, Markers select: widoczne
  → ChordDegreeSelector: visible=true (bo scaleChordState !== null && chord === null)
```

### Obecny przepływ danych — ChordDegreeSelector (istniejący, do zachowania)

```
ToolboxForm (wybór skali)
  → HomePageComponent.buildScaleCommand()
    → scaleChordState = { scale: {...}, chord: null }
    → DisplayScaleCommand → FretboardOrchestrationService.displayScale()
  → ChordDegreeSelector: visible=true (bo scaleChordState.chord === null)
    → User klika stopień
      → HomePageComponent.onChordDegreeSelected()
        → FretboardOrchestrationService.displayScaleWithChord()
          → API: resolveScaleNotes
          → IntervalService.markIntervals() (kolory interwałów)
          → MarkerRoleService.computeRoles() (złote obramki ról)
      → PatternBuilderService.setRelatedChord()
      → ChordDegreeSelector: hidden (bo scaleChordState.chord !== null)
```

> **Uwaga**: To jest **istniejąca funkcjonalność**, która działa przez toolbox + ChordDegreeSelector. Nowy tryb `scale-chord` będzie osobnym przepływem, niezależnym od toolboxa. Istniejący przepływ pozostaje nienaruszony dla użytkowników toolboxa.

### Problemy obecnej implementacji:

1. **Brak koncepcji trybu** — wszystko widać od razu
2. **Kolidujące kolory** — interwały i role markerów nakładają się (`[ngClass]` ma obie klasy CSS)
3. **Nieczytelny start** — wszystkie kontrolki widoczne od razu
4. **Toolbox `guitar-toolbox-lib`** jest zbyt ogólny, miesza skale/chordy/noty w jednym formularzu

---

## 2. Nowa architektura — przegląd

### Decyzje architektoniczne (po grillu)

| Obszar | Decyzja |
|---|---|
| `AppMode` | Nowy serwis `AppStateService` (zamiast w `FretboardStateService`) |
| Akord w relacji | Wybierany **niezależnie** od skali — degree to przyszły skrót |
| Degree w MVP | **Odpada** — dodamy później jako skrót do diatonicznego akordu |
| ChordDegreeSelector | **Komponent zostaje w kodzie** (nie usuwamy plików) — ale jest **ukryty w nowym layoutcie** (nie pojawia się w docku w nowych trybach). Logika degree wyekstrahowana później |
| Show button | Jest — oszczędność API call |
| Reaktywność | Nie — zmiana dropdowna wymaga kliknięcia "Show" |
| Przełączanie trybów | Bezpośrednie (B) — skala zostaje przy przejściu scale ↔ scale-chord |
| Legendy | Scale → `app-legend`, Scale-Chord → `app-relationship-strip` |
| Fit info | Tylko surowe dane (które nuty akordu są w skali), **bez oceny** |
| [change] w PatternDisplay | Placeholder — nic nie robi w MVP |
| Toolbox `lib-toolbox-form` | Ukryty gdy `appMode !== 'idle'` — chord/note/custom wrócą jako osobne tryby |
| Listy skal/chordów | `MusicPatternApiService` przez `FretboardOrchestrationService` (lub bezpośrednio) |
| API caching | API cachuje response — brak klient-side cache |
| `scale-root` vs `chord-root` | `chord-root` (fioletowy) wygrywa gdy oba root-y są tą samą nutą |

### Nowy koncept: `AppMode`

```typescript
// W AppStateService (nowy plik):
export type AppMode = 'idle' | 'scale' | 'scale-chord';
```

### Nowy layout z warunkami `*ngIf`

```
.app-shell
  ├── app-header                              — zawsze widoczne
  ├── div#guitar-neck-container → app-guitar-neck
  │
  ├── app-mode-selector           *ngIf="appMode === 'idle'"
  │
  ├── app-legend                  *ngIf="appMode === 'scale'"
  ├── app-relationship-strip      *ngIf="appMode === 'scale-chord'"
  │
  ├── app-pattern-display         *ngIf="appMode !== 'idle'"
  │
  ├── section.dock
  │   ├── app-scale-form          *ngIf="appMode === 'scale'"
  │   ├── app-scale-chord-form    *ngIf="appMode === 'scale-chord'"
  │   └── div.dock__body          *ngIf="appMode === 'idle'"
  │       ├── lib-toolbox-form
  │       └── app-metronome
  │
  └── app-footer
```

### Diagram przepływu — przełączanie trybów

```mermaid
flowchart TD
    A[Użytkownik wchodzi na stronę] --> B{appMode}
    B -->|idle| C[ModeSelectorComponent]
    C --> D[Kliknięcie Scale]
    C --> E[Kliknięcie Scale + chord]
    D --> F[appMode = scale]
    E --> G[appMode = scale-chord]
    F --> H[ScaleFormComponent + Legend + PatternDisplay]
    G --> I[ScaleChordFormComponent + RelationshipStrip + PatternDisplay]
    
    H -- user zmienia scale --> H
    I -- user zmienia scale/chord + Show --> I
    H -- bezpośrednie przejście --> G
    I -- bezpośrednie przejście --> F
```

---

## 3. Faza 1: AppStateService + ModeSelector + podstawowe formularze

### 3.1 Nowy serwis: `AppStateService`

**Ścieżka**: `src/app/app-state.service.ts`

```typescript
export type AppMode = 'idle' | 'scale' | 'scale-chord';

@Injectable({ providedIn: 'root' })
export class AppStateService {
  private appModeSubject = new BehaviorSubject<AppMode>('idle');
  appMode$ = this.appModeSubject.asObservable();

  get appMode(): AppMode {
    return this.appModeSubject.value;
  }

  setMode(mode: AppMode): void {
    this.appModeSubject.next(mode);
  }

  /** Switch directly between modes — preserves current fretboard state. */
  switchMode(mode: AppMode): void {
    if (mode === this.appMode) return;
    this.appModeSubject.next(mode);
  }
}
```

**Zależności**: Żadne — czysty stan.

**Reaktywny `appMode$`** umożliwia komponentom reagowanie na zmiany trybu przez `async` pipe.

### 3.2 Nowy komponent: `ModeSelectorComponent`

**Ścieżka**: `src/app/mode-selector/mode-selector.component.ts`

**Selektor**: `app-mode-selector`

**Widoczność**: `*ngIf="appMode === 'idle'"` (w `home-page.component.html`)

**Wygląd**: Dwa karty/buttony pod gryfem:

```
┌─────────────────────────────────────────────────┐
│  What do you want to show?                      │
│                                                  │
│  ┌──────────────┐  ┌──────────────────────────┐ │
│  │    Scale      │  │     Scale + chord        │ │
│  │               │  │                          │ │
│  │ Learn scale   │  │ Compare a scale with a   │ │
│  │ notes,        │  │ chord and see chord      │ │
│  │ intervals     │  │ tones and relationships  │ │
│  │ and positions │  │                          │ │
│  └──────────────┘  └──────────────────────────┘ │
└─────────────────────────────────────────────────┘
```

**Po kliknięciu**:
- "Scale" → `appState.setMode('scale')`
- "Scale + chord" → `appState.setMode('scale-chord')`

**Wstrzykuje**: `AppStateService`

### 3.3 Nowy komponent: `ScaleFormComponent`

**Ścieżka**: `src/app/scale-form/scale-form.component.ts`

**Selektor**: `app-scale-form`

**Widoczność**: `*ngIf="appMode === 'scale'"`

**Zawartość** — uproszczony formularz wyboru skali:

```
Scale type: [dropdown: major, minor, harmonic-minor, ...]
Key:        [dropdown: C, C#, D, ...]
            [Show button]
```

**Dane**: Lista skal z `MusicPatternApiService.getAvailableScales()` (przez `FretboardOrchestrationService` lub bezpośrednio).

**Po kliknięciu Show**:
- Uruchamia `DisplayScaleCommand` (przez `FretboardOrchestrationService`)
- Pojawia się Intervals Legend
- Pojawia się Pattern Display (info o skali)
- Formularz pozostaje widoczny w docku (user może zmienić skalę)

### 3.4 Nowy komponent: `ScaleChordFormComponent`

**Ścieżka**: `src/app/scale-chord-form/scale-chord-form.component.ts`

**Selektor**: `app-scale-chord-form`

**Widoczność**: `*ngIf="appMode === 'scale-chord'"`

**Zawartość** — **dwa niezależne** zestawy dropdownów:

```
Scale:   [dropdown]    Key: [dropdown]     ← niezależny
Chord:   [dropdown]    Key: [dropdown]     ← niezależny (nie przez degree!)
                      [Show relationship]
```

**Degree**: NIE występuje w MVP. Zostanie dodany w przyszłości jako skrót do ustawienia diatonicznego akordu.

**Po kliknięciu Show relationship**:
- Wywołuje `FretboardOrchestrationService.displayScaleWithChord(scaleName, scaleRoot, chordName, chordRoot)`
- Pojawia się RelationshipStrip
- Pojawia się Pattern Display (karta skali + karta akordu)
- Formularz pozostaje w docku

### 3.5 Modyfikacje w `home-page.component.html`

Nowa struktura z warunkami `*ngIf` (patrz sekcja 2).

### 3.6 Modyfikacje w `home-page.component.ts`

- Usunąć `appMode` — teraz w `AppStateService`
- Wstrzyknąć `AppStateService`
- `toolboxSubmit()` działa tylko gdy `appMode === 'idle'`
- Dodać obsługę `appState.switchMode()` dla bezpośredniego przełączania trybów

### 3.7 Modyfikacje w `legend.component.ts` i `legend.component.html`

- `app-legend` widoczne tylko gdy `appMode === 'scale'` (obsłużone w `home-page.component.html`)
- Sekcja `legend-roles` (`*ngIf="hasRelation"`) w legendzie pozostaje — będzie używana w trybie scale-only gdy `scaleChordState.chord` w przyszłości będzie nie-null (np. po dodaniu degree)

---

## 4. Faza 2: Nowy system kolorów role-based dla scale+chord

### 4.1 Zasada

W trybie `scale-chord`:
- `getMarkerCssClass()` zwraca **pusty string** `''` — brak kolorów interwałów
- `getRoleCssClass()` zwraca klasę która ustawia **background-color** (role-based fill)

W trybie `scale`:
- `getMarkerCssClass()` zwraca kolory interwałów (bez zmian)
- `getRoleCssClass()` zwraca box-shadow role (złote obramki, obecne zachowanie)

### 4.2 Nowe kolory markerów dla trybu scale-chord

| Rola | Wygląd | Klasa CSS |
|---|---|---|
| `scale-tone` | Neutralny wypełniony dot (szary) | `guitar-neck__role-scale-tone` |
| `scale-root` | Zielony wypełniony dot | `guitar-neck__role-scale-root` |
| `chord-tone-in-scale` | Fioletowy wypełniony dot | `guitar-neck__role-chord-tone` |
| `chord-root` | Fioletowy dot + grubszy ring | `guitar-neck__role-chord-root` |
| `chord-tone-outside-scale` | Pusty / konturowy dot | `guitar-neck__role-chord-tone-outside` |

> **Uwaga**: Gdy `scale-root === chord-root` (ta sama nuta), wygrywa `chord-root` (fioletowy). Kod w `MarkerRoleService` wymaga zmiany: przypisz `chord-root` zamiast `scale-root` gdy oba root-y są identyczne.

### 4.3 Modyfikacje w `fretboard-display.service.ts`

```typescript
getMarkerCssClass(interval: string | undefined): string {
  // Gdy aktywna jest relacja scale+chord, nie pokazujemy kolorów interwałów
  if (this.guitarNeckService.scaleChordState?.chord) {
    return ''; // tylko role-based coloring z getRoleCssClass()
  }
  // ... istniejąca logika
}
```
AM: nie zepsuć dotychczasowej funkcjonalności w tybie scale lub chord!!
### 4.4 Nowe style CSS w `freatboard.component.scss`

```scss
/* ---- Scale + Chord mode marker colors (fill) ---- */

.guitar-neck__role-scale-tone {
  background: #888;
  border: 1px solid #666;
}

.guitar-neck__role-scale-root {
  background: #4caf50;
  border: 2px solid #2e7d32;
}

.guitar-neck__role-chord-tone {
  background: #9c27b0;
  border: 2px solid #7b1fa2;
}

.guitar-neck__role-chord-root {
  background: #9c27b0;
  border: 3px solid #4a148c;
  box-shadow: 0 0 0 2px rgba(156, 39, 176, 0.3);
}

.guitar-neck__role-chord-tone-outside {
  background: transparent;
  border: 2px dashed #9c27b0;
}
```

> **Uwaga**: Istniejące klasy ról (`.guitar-neck__role-chord-tone` itd.) w `freatboard.component.scss` używają `box-shadow` i `border` jako overlay na interwałach. W trybie scale-chord te klasy będą ustawiać `background-color` zamiast box-shadow. Nowe klasy (powyżej) zastępują stare, ale stare zostają dla trybu scale-only.

### 4.5 Modyfikacje w `MarkerRoleService`

Obecnie w `computeRoles()` (linia 128-129):
```typescript
if (note.note === scaleRoot && note.note === chordRoot) {
  roles.set(key, 'scale-root'); // zmienić na 'chord-root'
}
```

Po zmianie:
```typescript
if (note.note === scaleRoot && note.note === chordRoot) {
  roles.set(key, 'chord-root'); // chord-root wygrywa gdy oba root-y są tą samą nutą
}
```
AM: nie zepsuć dotychczasowej funkcjonalności w tybie scale lub chord

### 4.6 Modyfikacje w `FretboardOrchestrationService.displayScaleWithChord()`

Obecnie wywołuje `this.intervalService.markIntervals()`. W trybie scale-chord **NIE** chcemy znaczników interwałów.

```typescript
displayScaleWithChord(scaleName, scaleRoot, chordName, chordRoot): Observable<GuitarNote[]> {
  return this.patternApi.resolveScaleNotes(scaleName, scaleRoot).pipe(
    map(scaleNotes => {
      const selectedNotes = this.noteService.findPositionsByScaleNotes(scaleNotes);
      const highlightedNotes = this.guitarNeckService.applyHighlightedNotes(selectedNotes);

      // NIE wywołuj intervalService.markIntervals() - role-based coloring zamiast tego

      const chordSelection: MusicSelection = {
        type: 'chord',
        name: chordName,
        rootNote: chordRoot,
      };

      this.guitarNeckService.scaleChordState = {
        scale: { type: 'scale', name: scaleName, rootNote: scaleRoot, notes: scaleNotes },
        chord: chordSelection,
      };

      this.markerRoleService.computeRoles(
        this.guitarNeckService.notes,
        this.guitarNeckService.scaleChordState.scale,
        chordSelection,
      );

      return highlightedNotes;
    }),
    ...
  );
}
```
AM: nie zepsuć dotychczasowej funkcjonalności w tybie scale lub chord

---

## 5. Faza 3: RelationshipStrip

### 5.1 Nowy komponent: `RelationshipStripComponent`

**Ścieżka**: `src/app/relationship-strip/relationship-strip.component.ts`

**Selektor**: `app-relationship-strip`

**Widoczność**: `*ngIf="appMode === 'scale-chord' && scaleChordState.chord !== null"`

**Umiejscowienie**: między gryfem a dockiem (zastępuje Legend w trybie scale-chord)

**Wysokość**: ~48px (kompaktowy)

**Zawartość**:

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│ Relationship: C arabic-scale + C major chord                                    │
│                                                                                 │
│ ● scale note  ● scale root  ● chord tone  ◎ chord root  ○ outside scale       │
│                                                                                 │
│ Chord tones in scale: C, E, G  │  Outside: (none)                              │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Dane**:
- `scaleChordState` z `FretboardStateService`
- `lastRoles` z `MarkerRoleService`

**Fit info**: Tylko surowe dane — lista nut akordu które są w skali i lista które są poza skalą. **Brak oceny** ("Great fit" / "Partial fit").

**Degree dropdown**: NIE występuje w MVP. Zostanie dodany w przyszłości.

### 5.2 Logika "Chord tones in scale"

Obliczana lokalnie w komponencie lub przez `MarkerRoleService`:

```typescript
// Dla danego chordSelection i scaleSelection:
const chordNotes = resolveChordNoteNames(chordSelection.name, chordSelection.rootNote);
const scaleNotes = resolveScaleNoteNames(scaleSelection.name, scaleSelection.rootNote);

const inScale = [...chordNotes].filter(n => scaleNotes.has(n));
const outside = [...chordNotes].filter(n => !scaleNotes.has(n));
```

### 5.3 Integracja w `home-page.component.html`

```html
<app-relationship-strip *ngIf="appMode === 'scale-chord' && scaleChordState?.chord">
</app-relationship-strip>
```

---

## 6. Faza 4: PatternDisplay + PracticePrompts

### 6.1 Modyfikacje `app-pattern-display`

W trybie scale-chord PatternDisplay pokazuje dwie karty:

```
┌──────────────────────────────────────┬──────────────────────────────┐
│  Selected patterns        (60%)      │  Practice prompts   (40%)    │
│                                      │                              │
│  ┌──────────────────────┐            │  • Play chord tones in scale │
│  │ Scale                │            │  • Find the chord root       │
│  │ C arabic-scale       │            │  • Play only outside chord   │
│  │ 8 notes: C D E F G A B│           │  • Play scale around chord   │
│  │ [change] (placeholder)│           │                              │
│  └──────────────────────┘            │                              │
│  ┌──────────────────────┐            │                              │
│  │ Chord                │            │                              │
│  │ C major chord        │            │                              │
│  │ C E G                │            │                              │
│  │ [change] (placeholder)│           │                              │
│  └──────────────────────┘            │                              │
└──────────────────────────────────────┴──────────────────────────────┘
```

**Zmiany**:
- Nowa struktura HTML z `display: grid` (60/40)
- Scale card i Chord card obok siebie
- Przycisk `[change]` jest **placeholderem** — nie robi nic w MVP
- Nowa lista practice prompts dla trybu scale-chord

### 6.2 Nowe practice prompts (`practice-prompts.data.ts`)

```typescript
export const PRACTICE_PROMPTS: Record<'scale' | 'chord' | 'scale-chord', string[]> = {
  scale: [
    'Graj gamę w górę i w dół',
    'Wymawiaj nazwy dźwięków podczas gry',
    'Graj tylko dźwięki podstawowe (root)',
    'Graj jeden dźwięk na klik metronomu',
    'Ogranicz się do wybranego zakresu progów',
  ],
  chord: [
    'Uderz akord — wszystkie struny naraz',
    'Graj arpeggio — jedna struna po drugiej, w górę i w dół',
    'Wymawiaj nazwy dźwięków podczas gry',
    'Graj jeden dźwięk na klik metronomu',
    'Ogranicz się do wybranego zakresu progów',
  ],
  'scale-chord': [
    'Play chord tones in scale — find C, E, G across the neck',
    'Find the chord root — locate and play C on different strings',
    'Play only outside chord tones — use tones outside the scale, if any',
    'Play scale around chord — outline the scale around C chord',
  ],
};
```

---

## 7. Faza 5: Czyszczenie i testy

| # | Zadanie | Pliki |
|---|---|---|
| 5.1 | Usunąć niepotrzebne importy starego toolboxa (jeśli już nieużywane) | `src/app/home-page/` |
| 5.2 | Uruchomić `npm run build` i sprawdzić błędy | — |
| 5.3 | Uruchomić `npm test` i sprawdzić czy testy przechodzą | — |
| 5.4 | Przejrzeć testy jednostkowe — dodać/dostosować do nowych komponentów | Odpowiednie `*.spec.ts` |

---

## 8. Podsumowanie plików

### Nowe pliki

| Plik | Odpowiedzialność |
|---|---|
| `src/app/app-state.service.ts` | Zarządzanie `AppMode` |
| `src/app/mode-selector/mode-selector.component.ts` | Ekran startowy — wybór trybu |
| `src/app/mode-selector/mode-selector.component.html` | Template — 2 karty |
| `src/app/mode-selector/mode-selector.component.scss` | Style dla kart |
| `src/app/scale-form/scale-form.component.ts` | Formularz skali (scale-only) |
| `src/app/scale-form/scale-form.component.html` | Template — dropdown scale + key |
| `src/app/scale-form/scale-form.component.scss` | Style |
| `src/app/scale-chord-form/scale-chord-form.component.ts` | Formularz relacji (scale+chord) |
| `src/app/scale-chord-form/scale-chord-form.component.html` | Template — 2x dropdown (scale, chord) |
| `src/app/scale-chord-form/scale-chord-form.component.scss` | Style |
| `src/app/relationship-strip/relationship-strip.component.ts` | Pasek relacji |
| `src/app/relationship-strip/relationship-strip.component.html` | Template — legenda + chord info |
| `src/app/relationship-strip/relationship-strip.component.scss` | Style |

### Modyfikowane pliki

| Plik | Zmiana |
|---|---|
| `src/app/services/guitar-neck.service.ts` | Usunięcie `appMode` (przeniesione do AppStateService) |
| `src/app/services/music-theory-facade.service.ts` | Wyłączenie `intervalService.markIntervals()` w `displayScaleWithChord()` |
| `src/app/services/fretboard-display.service.ts` | `getMarkerCssClass()` zwraca `''` gdy `scaleChordState.chord` istnieje |
| `src/app/services/marker-role.service.ts` | `chord-root` wygrywa gdy `scaleRoot === chordRoot` |
| `src/app/freatboard/freatboard.component.scss` | Nowe role-based fill colors |
| `src/app/home-page/home-page.component.html` | Restrukturyzacja layoutu z `*ngIf` |
| `src/app/home-page/home-page.component.ts` | Zmiana logiki — wstrzyknięcie `AppStateService` |
| `src/app/pattern-display/pattern-display.component.ts` | Obsługa dwóch kart (scale + chord) |
| `src/app/pattern-display/pattern-display.component.html` | Layout 60/40 |
| `src/app/shared/practice-prompts.data.ts` | Dodanie `'scale-chord'` prompts, zmiana typu |

### Pliki zakomentowane (nie usunięte)

| Plik | Status |
|---|---|
| `src/app/chord-degree-selector/` | **Zakomentowany** w `home-page.component.html` — pliki pozostają, logika degree wyekstrahowana do `ChordDegreeResolverService` w przyszłości |

## 8. Constraint: nie zepsuć istniejącej funkcjonalności

**Zasada nadrzędna**: Wszystkie zmiany muszą zachować istniejącą funkcjonalność w trybach `scale` i `chord` dostępnych przez toolbox (`lib-toolbox-form`).

### Co pozostaje nienaruszone:

- `toolboxSubmit()` w `HomePageComponent` — nadal działa dla scale, chord, note, custom, all-notes
- `displayScale()`, `displayChord()`, `displaySingleNote()`, `displayAllNotes()` — bez zmian
- `IntervalService.markIntervals()` — nadal działa w trybie scale/chord przez toolbox
- `PatternBuilderService.setCurrentPattern()` — nadal działa
- `ChordDegreeSelector` — zakomentowany, ale kod istnieje; jeśli ktoś go odkomentuje, wszystko działa
- `FretboardStateService.clearFretboard()` — bez zmian
- `FretboardOrchestrationService` — dodajemy tylko warunek w `displayScaleWithChord()`, nie zmieniamy `displayScale()`

### Czego NIE robimy:

- Nie refaktorujemy istniejących serwisów poza dodaniem `AppStateService`
- Nie zmieniamy logiki `IntervalService`
- Nie zmieniamy API `MusicPatternApiService`
- Nie usuwamy żadnych istniejących plików (tylko zakomentowujemy w template)

---

## Potwierdzone decyzje (z grilla)

| # | Pytanie | Decyzja |
|---|---|---|
| 1 | Gdzie `appMode`? | Nowy `AppStateService` |
| 2 | CSS w scale-chord? | `getMarkerCssClass` → `''`, role-based fill z `getRoleCssClass` |
| 3 | Toolbox hidden? | Tak, poza idle. Chord/note/custom wrócą jako osobne tryby |
| 4 | Degree w formularzu? | Nie — degree tylko w RelationshipStrip (w przyszłości) |
| 5 | ChordDegreeSelector? | Refaktor do `ChordDegreeResolverService` w przyszłości, nie teraz |
| 6 | scale-root vs chord-root? | `chord-root` (fioletowy) wygrywa |
| 7 | Fit info dynamiczne? | Tak, zawsze dynamicznie obliczane |
| 8 | clearFretboard + appMode? | `clearFretboard` programistyczne, appMode zostaje |
| 9 | [change] w PatternDisplay? | Placeholder — nic nie robi w MVP |
| 10 | Degree w MVP? | Odpada — akord niezależny od skali |
| 11 | AM: nie zepsuć dotychczasowej funkcjonalności w tybach scale lub chord
