# Plan: Update documentation for scale-chord feature

## What's missing in documentation

### 1. API_DOCUMENTATION.md — biggest gaps

| Missing item | What to add |
|---|---|
| `AppMode` type / `AppStateService` | New service managing app mode: `idle` / `scale` / `scale-chord` |
| `ScaleChordState` interface | Dual selection state in `FretboardStateService` |
| `FretboardOrchestrationService.displayScaleWithChord()` | Resolves scale via API, resolves chord client-side, highlights union of notes, computes roles |
| `FretboardOrchestrationService.clearRelation()` | Removes chord relation, keeps scale |
| `MarkerRoleService` + `MarkerRole` type | 5 roles: scale-tone, chord-tone, scale-root, chord-root, chord-tone-outside-scale |
| `FretboardDisplayService.getRoleCssClass()` | Returns role-based CSS class for markers in scale-chord mode |
| `FretboardDisplayService.getMarkerCssClass()` | Updated — returns `''` when chord relation is active (role-based coloring) |
| New components | `ModeSelectorComponent`, `ScaleFormComponent`, `ScaleChordFormComponent`, `RelationshipStripComponent` |
| Data flow diagram | Add scale-chord path alongside existing scale-only path |

### 2. ARCHITECTURE.md — gaps

| Missing item | What to add |
|---|---|
| New components in component table | ModeSelector, ScaleForm, ScaleChordForm, RelationshipStrip |
| New services in services table | AppStateService, MarkerRoleService, FretboardDisplayService |
| Scale-chord data flow | Diagram showing displayScaleWithChord() → API → findPositions → applyHighlightedNotes(scale + outside chord) → computeRoles |
| MarkerRole CSS classes | `guitar-neck__role-{scale-tone, chord-tone, scale-root, chord-root, chord-tone-outside}` |

### 3. PRODUCT_OVERVIEW.md — gaps

| Missing item | What to add |
|---|---|
| App mode selection | ModeSelector as the new entry point |
| Scale-chord mode | Description of the dual-selection feature |
| Relationship strip | Role legend replacement when in scale-chord mode |
| Marker roles | Golden border visualization for 5 roles |

### 4. CONTEXT.md — already covers domain language well

No changes needed — already has `AppMode`, `ModeSelectorComponent`, `ScaleFormComponent`, `ScaleChordFormComponent`, `RelationshipStripComponent`, `MarkerRole`, `AppStateService`, `ScaleChordState`, `PatternDisplayComponent`, `Fit info`.

---

## Code smells to annotate (TODO for future extraction)

1. **Duplicate `resolveChordNoteNames` / `resolveScaleNoteNames`** 🔴
   These functions exist in **3 places**: `marker-role.service.ts`, `relationship-strip.component.ts`, and inlined in `music-theory-facade.service.ts` (my fix). Should be extracted to a shared utility or `guitar-neck-shared` package.

2. **Inconsistent note resolution — API vs client-side** 🟡
   `displayScaleWithChord()` resolves chord notes client-side from `CHORD_PATTERNS`, while `displayScale()` calls the API. If patterns diverge between client (npm package) and API (Docker backend), results differ silently.

3. **`FretboardStateService.applyHighlightedNotes()` resets all notes** 🟢
   Every call iterates ALL ~150 notes and sets `visible=false`. Fine for current usage, but if multiple layers need to add notes, this pattern won't compose well.

4. **`MarkerRoleService.computeRoles()` takes GuitarNote[]** 🟡
   Could accept `note names` for better testability. Currently it iterates all fretboard positions and checks each one against scale/chord sets.

---

## Files to modify

1. `src/app/../API_DOCUMENTATION.md` — heaviest changes
2. `src/app/ARCHITECTURE.md` — add components + services + data flow
3. `src/app/PRODUCT_OVERVIEW.md` — add scale-chord mode feature description

---

## Order of changes

1. `API_DOCUMENTATION.md` — add missing services, methods, types, components, data flow
2. `ARCHITECTURE.md` — update component/service tables, add scale-chord data flow
3. `PRODUCT_OVERVIEW.md` — add scale-chord mode + relationship strip + marker roles
