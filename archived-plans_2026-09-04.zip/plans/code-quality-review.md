# Code Quality Review & Roadmap Alignment

## Code Quality Issues Found

### 1. Duplikacja logiki pattern→notes (3 miejsca)
`MarkerRoleService.resolveChordNoteNames()` i `resolveScaleNoteNames()` powielają logikę z `PatternBuilderService.setCurrentPattern()` i `FretboardOrchestrationService.resolveFromPatterns()`. Wszystkie 3 miejsca robią to samo — obliczają nuty z patternu + root.

**Sugestia**: Wyodrębnić wspólny helper `resolvePatternNotes(patternName, rootNote, patterns)` do `tonal-adapter.ts` lub nowego `pattern-resolver.helper.ts`.

### 2. `findPositionsByChordNotes` — dead method
[`note.service.ts:55`](src/app/services/note.service.ts:55) — identyczna implementacja jak `findPositionsByScaleNotes`. Nieużywana.

### 3. Redundantna inicjalizacja w `FretboardStateService`
Konstruktor ustawia `this.notes = this.noteService.getAllPositions()`, ale potem [`FreatboardComponent.ngOnInit()`](src/app/freatboard/freatboard.component.ts:36) nadpisuje `this.guitarNeckService.notes = this.notes`. To sugeruje że inicjalizacja w konstruktorze jest nadpisywana — jedna z nich jest zbędna.

### 4. `FretboardNoteQueryService.fretNoteClicked()` — nieużywana
Metoda istnieje ale nie jest wywoływana przez `FreatboardComponent` (który ma własną logikę kliknięć).

### 5. `AppStateService.switchMode()` — redundantna
Metoda tylko deleguje do `setMode()`. Można usunąć.

### 6. Brak testów dla nowych serwisów
- `FretboardNoteQueryService` — brak spec
- `PatternBuilderService` — brak spec
- `FretboardDisplayService` — brak spec

### 7. `UICommands.spec.ts` — testy dla dead code
Testy istnieją ale kod jest nieużywany.

## Roadmap Alignment

| Plan z PRODUCT_OVERVIEW.md | Status | Uwagi |
|---------------------------|--------|-------|
| Nowe wzory muzyczne | OPEN | Zależne od `guitar-neck-shared` |
| Rozszerzenie AI | POSTPONED | `projects/guitar-chat` istnieje, czeka na klucz |
| Ćwiczenia i zadania | OPEN | Practice prompts istnieją, brak systemu progresji |
| Personalizacja | OPEN | Nie rozpoczęte |
| Rozbudowa metronomu | OPEN | W BACKLOG.md |
| System progresji ćwiczeń | OPEN | Nie rozpoczęte |

### Nowe pozycje roadmapy (dodane)
- **Cloudflare Pages deployment** — zastępuje Docker/VPS
- **Refaktor duplikacji logiki** — wyodrębnienie pattern→notes helpera

### Zgodność z AGENTS.md checklist
- [x] Nazwy serwisów są spójne we wszystkich .md
- [x] `apiUrl` usunięty (nie ma backendu)
- [x] BACKLOG.md statusy zgodne z dokumentacją
- [x] Ścieżki do plików istnieją w repozytorium
- [x] AI Chat oznaczony jako POSTPONED wszędzie
- [x] Żaden .md nie zawiera starych nazw serwisów