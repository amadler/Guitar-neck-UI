# Plan: Fix stale state bugs when transitioning from Compare mode

## Root Cause Analysis

### Bug 1: Stale marker styles after compare → show-scale

**Flow that triggers the bug:**
1. User clicks **Compare** → [`handleComparePatterns()`](src/app/domain/domain.service.ts:152) calls [`orchestration.displayScaleWithChord()`](src/app/services/fretboard-orchestration.service.ts:62)
2. `displayScaleWithChord()` sets [`this.guitarNeckService.scaleChordState`](src/app/services/fretboard-orchestration.service.ts:86) and calls [`markerRoleService.computeRoles()`](src/app/services/fretboard-orchestration.service.ts:96) — markers now use role-based CSS
3. User clicks **Show Scale** → [`handleShowPattern()`](src/app/domain/domain.service.ts:104) calls [`orchestration.displayScale()`](src/app/services/fretboard-orchestration.service.ts:26)
4. **`displayScale()` does NOT clear `scaleChordState`** — it only calls `applyHighlightedNotes()` and `markIntervals()`
5. [`getMarkerCssClass()`](src/app/services/fretboard-display.service.ts:26) checks `scaleChordState?.chord` at line 28 — since it's still set, it returns `''` (empty string)
6. [`getRoleCssClass()`](src/app/services/fretboard-display.service.ts:62) still returns role-based CSS from stale `lastRoles`
7. Result: markers show **old role-based colors** instead of interval-based colors

**Why "doing something more" fixes it:** Any action that clears `scaleChordState` (like `clearFretboard()` at line 46-48, or another `displayScaleWithChord()`) resets the state.

### Bug 2: Stale relatedChord in PatternDisplay after compare → show-chord

**Flow that triggers the bug:**
1. User clicks **Compare** → [`handleComparePatterns()`](src/app/domain/domain.service.ts:152) calls [`patternBuilder.setRelatedChord()`](src/app/services/pattern-builder.service.ts:61) which sets `relatedChord`
2. User clicks **Show Chord** → [`handleShowPattern()`](src/app/domain/domain.service.ts:104) calls [`patternBuilder.setCurrentPattern()`](src/app/services/pattern-builder.service.ts:21) which sets `currentPattern`
3. **`setCurrentPattern()` does NOT clear `relatedChord`** — it only sets `currentPattern` and `currentSelection`
4. [`PatternDisplayComponent`](src/app/pattern-display/pattern-display.component.ts:22-28) shows **both** `currentPattern` and `relatedChord`
5. Result: "C major chord" appears twice in the pattern display

### Bug 3: No marker display mode selector in relationship-strip view (lower priority)

- The `.legend-switches` `<select>` lives only in [`<app-legend>`](src/app/legend/legend.component.html:24-34)
- [`home-page.component.html`](src/app/home-page/home-page.component.html:24-27) shows **either** legend **or** relationship-strip, never both
- In compare mode, `interval-colors` is overridden by role-based CSS anyway, so only `note-names` and `neutral-dots` would be useful
- **Deferred** — low value since role-based CSS overrides interval colors in compare mode

---

## Implementation Plan

### Task 1: Clear `scaleChordState` in `displayScale()` and `displayChord()`

**File:** [`src/app/services/fretboard-orchestration.service.ts`](src/app/services/fretboard-orchestration.service.ts)

Add `this.guitarNeckService.scaleChordState = null;` at the start of both `displayScale()` (line 26) and `displayChord()` (line 35).

This ensures that when switching from compare mode to a single pattern, the marker CSS logic falls back to interval-based styling.

### Task 2: Clear `relatedChord` in `handleShowPattern()`

**File:** [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts)

Add `this.patternBuilder.relatedChord = null;` after `this.patternBuilder.setCurrentPattern(...)` in `handleShowPattern()` (around line 119).

This ensures the pattern display doesn't show the chord twice after compare → show-chord.

### Task 3: Update tests

- Update [`fretboard-orchestration.service.spec.ts`](src/app/services/fretboard-orchestration.service.spec.ts) to verify `scaleChordState` is cleared after `displayScale()`/`displayChord()`
- Update [`domain.service.spec.ts`](src/app/domain/domain.service.spec.ts) if it exists, to verify `relatedChord` is cleared in `handleShowPattern()`

---

## Mermaid: Data flow for both bugs

```mermaid
flowchart TD
    subgraph Compare
        A[User clicks Compare] --> B[handleComparePatterns]
        B --> C[displayScaleWithChord]
        B --> D[setRelatedChord]
        C --> E[set scaleChordState]
        C --> F[computeRoles → lastRoles]
    end

    subgraph ShowScale
        G[User clicks Show Scale] --> H[handleShowPattern]
        H --> I[displayScale]
        I -- MISSING --> J[clear scaleChordState]
        I --> K[applyHighlightedNotes]
        I --> L[markIntervals]
        H --> M[setCurrentPattern]
        M -- OK --> N[clear compareTarget in DomainState]
    end

    subgraph ShowChord
        O[User clicks Show Chord] --> P[handleShowPattern]
        P --> Q[displayChord]
        Q -- has clearFretboard --> R[scaleChordState cleared]
        P --> S[setCurrentPattern]
        S -- MISSING --> T[clear relatedChord]
        T -.-> U[PatternDisplay shows chord twice]
    end

    E -.-> V[scaleChordState still set]
    V --> W[getMarkerCssClass returns '']
    F -.-> X[lastRoles still stale]
    X --> Y[getRoleCssClass returns role CSS]
    W --> Z[Markers show role colors]
    Y --> Z
```

---

## Acceptance Criteria

1. After compare → show-scale, markers show interval-based colors (not role-based)
2. After compare → show-chord, pattern display shows chord only once
3. After compare → show-chord, markers show interval-based colors
4. All existing tests pass
5. `npm run build` succeeds