# Plan: Przeniesienie `calculateNotesFromIntervals` do `IntervalService`

## Cel

Przenieść funkcję `calculateNotesFromIntervals` ze standalone helpera `interval-note.helper.ts` do serwisu `IntervalService`, a następnie usunąć niepotrzebny helper i zaktualizować wszystkie zależności.

## Uzasadnienie architektoniczne

Funkcja wykonuje czystą, synchroniczną operację arytmetyki muzycznej (chodzenie po skali chromatycznej), co jest naturalną odpowiedzialnością `IntervalService`. Backend `music-theory-api` jest zbędny dla tej operacji — dodałby jedynie latency, zależność sieciową i konieczność obsługi błędów dla trywialnego obliczenia.

## Pliki do modyfikacji

| Plik | Operacja | Opis |
|------|----------|------|
| `src/app/services/interval.service.ts` | **Dodanie metody** | Nowa publiczna metoda `calculateNotesFromIntervals(rootNote, intervals): string[]` |
| `src/app/services/interval.service.spec.ts` | **Dodanie testów** | Testy dla nowej metody |
| `src/app/shared/UICommands.ts` | **Edycja** | Zastąpienie importu helpera → wstrzyknięcie `IntervalService` |
| `src/app/shared/UICommands.spec.ts` | **Edycja** | Aktualizacja mocków/testów dla `DisplayCustomPatternCommand` |
| `src/app/shared/interval-note.helper.ts` | **Usunięcie** | Plik przestaje być potrzebny |
| `API_DOCUMENTATION.md` | **Aktualizacja** | Usunięcie sekcji `IntervalNoteHelper`, dodanie metody do `IntervalService` |
| `ARCHITECTURE.md` | **Aktualizacja** | Aktualizacja diagramu przepływu i listy serwisów |

## Kroki implementacji

### Krok 1: Dodaj metodę do `IntervalService` (`src/app/services/interval.service.ts`)

Dodaj publiczną metodę:

```typescript
calculateNotesFromIntervals(rootNote: string, intervals: number[]): string[] {
  const chromaticScale = neckConfig.chromaticNotes;
  const rootIndex = chromaticScale.indexOf(rootNote);
  if (rootIndex === -1) return [];

  const notes = [rootNote];
  let currentIndex = rootIndex;

  for (const interval of intervals) {
    currentIndex = (currentIndex + interval) % 12;
    notes.push(chromaticScale[currentIndex]);
  }

  return notes;
}
```

**Uwaga:** Metoda jest czystą kopią z helpera — nie zmieniaj logiki, tylko przenieś.

### Krok 2: Dodaj testy do `interval.service.spec.ts`

Dodaj nowy blok `describe('calculateNotesFromIntervals', ...)` z przypadkami:

1. Powinna zwrócić `['C', 'E', 'G']` dla C major (`[4, 3]`)
2. Powinna zwrócić `['A', 'C', 'E']` dla A minor (`[3, 4]`)
3. Powinna obsłużyć zawijanie chromatyczne — B major (`[4, 3]`) → `['B', 'D#', 'F#']`
4. Powinna zwrócić pustą tablicę dla nieprawidłowej nuty root
5. Powinna obsłużyć pustą tablicę interwałów → `[rootNote]`

### Krok 3: Zaktualizuj `UICommands.ts`

**Przed:**
```typescript
import { FretboardOrchestrationService } from "../services/music-theory-facade.service";
import { calculateNotesFromIntervals } from './interval-note.helper';

export class DisplayCustomPatternCommand implements Command {
  constructor(
    private fretboardOrchestrationService: FretboardOrchestrationService,
    private intervals: number[],
    private rootNote: string
  ) {}

  execute(): void {
    const notes = calculateNotesFromIntervals(this.rootNote, this.intervals);
    this.fretboardOrchestrationService.displayCustomPattern(notes, this.rootNote);
  }
}
```

**Po:**
```typescript
import { FretboardOrchestrationService } from "../services/music-theory-facade.service";
import { IntervalService } from "../services/interval.service";

export class DisplayCustomPatternCommand implements Command {
  constructor(
    private fretboardOrchestrationService: FretboardOrchestrationService,
    private intervalService: IntervalService,
    private intervals: number[],
    private rootNote: string
  ) {}

  execute(): void {
    const notes = this.intervalService.calculateNotesFromIntervals(this.rootNote, this.intervals);
    this.fretboardOrchestrationService.displayCustomPattern(notes, this.rootNote);
  }
}
```

### Krok 4: Zaktualizuj `UICommands.spec.ts`

**Przed:**
```typescript
const command = new DisplayCustomPatternCommand(fretboardOrchestrationService, [4, 3], 'C');
```

**Po:**
```typescript
const intervalService = jasmine.createSpyObj('IntervalService', ['calculateNotesFromIntervals']);
intervalService.calculateNotesFromIntervals.and.returnValue(['C', 'E', 'G']);
const command = new DisplayCustomPatternCommand(fretboardOrchestrationService, intervalService, [4, 3], 'C');
```

### Krok 5: Zaktualizuj `home-page.component.ts`

Plik: [`src/app/home-page/home-page.component.ts`](src/app/home-page/home-page.component.ts)

**Zmiany:**
1. Dodaj import `IntervalService` z `'../services/interval.service'`
2. Dodaj `private intervalService: IntervalService` do konstruktora (linia 38-42)
3. W metodzie `buildCustomPatternCommand` (linia 66-77), przekaż `this.intervalService` jako drugi argument:

```typescript
return new DisplayCustomPatternCommand(
  this.fretboardOrchestrationService,
  this.intervalService,  // NOWY parametr
  intervals,
  root
);
```

### Krok 6: Usuń `src/app/shared/interval-note.helper.ts`

Usuń plik helpera po upewnieniu się, że nie ma już do niego żadnych referencji.

### Krok 7: Zaktualizuj dokumentację

- `API_DOCUMENTATION.md`: Usuń sekcję `IntervalNoteHelper`, dodaj nową metodę do sekcji `IntervalService`
- `ARCHITECTURE.md`: Usuń wzmiankę o helperze, zaktualizuj przepływ danych dla custom pattern

### Krok 8: Walidacja

- Uruchom `npm test` — wszystkie testy muszą przechodzić
- Uruchom `npm run build` — build musi przechodzić bez błędów
