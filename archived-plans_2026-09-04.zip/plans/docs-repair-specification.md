# Dokumentacja — Specyfikacja Naprawy (P0/P1/P2)

> Na podstawie: [`docs-audit-report.md`](docs-audit-report.md), [`docs-repair-plan.md`](docs-repair-plan.md), [`DOCUMENTATION_GUIDELINES.md`](DOCUMENTATION_GUIDELINES.md), [`TODO_DEPLOY.md`](../TODO_DEPLOY.md)
>
> Przeznaczenie: specyfikacja dla delegacji do trybu `code`

---

## P0 — Fix incorrect information in existing documents

### P0.1 — Poprawić ścieżki w [`API_DOCUMENTATION.md`](../API_DOCUMENTATION.md)

| Lp. | Linia | Jest (nie istnieje) | Zamienić na |
|-----|-------|---------------------|-------------|
| 1 | 394 | `` `src/app/freatboard/components/legend/legend.component.ts` `` | `` `src/app/legend/legend.component.ts` `` |
| 2 | 438 | `` `src/app/shared/model/musicElements.ts` `` | `` `src/app/shared/model/music-selection.ts` `` |

**Uwaga**: Linia 555 również zawiera odwołanie do `musicElements.ts` w kontekście `ToolboxSearchQuery typing`. Jeśli faktyczny plik nazywa się `music-selection.ts` (a nie `musicElements.ts`), należy również poprawić linię 555.

**Plik**: [`API_DOCUMENTATION.md`](../API_DOCUMENTATION.md)
**Zakres**: linie 394, 438 (opcjonalnie 555)
**Typ zmiany**: `apply_diff` — zastąpienie stringa

---

### P0.2 — Poprawić nazwę `@Output` w [`API_DOCUMENTATION.md`](../API_DOCUMENTATION.md)

| Linia | Jest | Zamienić na |
|-------|------|-------------|
| 408 | `@Output() onSubmit$: EventEmitter<ToolboxSearchQuery>;` | `@Output() onSubmit: EventEmitter<ToolboxSearchQuery>;` |

**Plik**: [`API_DOCUMENTATION.md`](../API_DOCUMENTATION.md)
**Zakres**: linia 408
**Typ zmiany**: `apply_diff` — zastąpienie `onSubmit$` → `onSubmit`

---

### P0.3 — Poprawić endpoint w [`API_DOCUMENTATION.md`](../API_DOCUMENTATION.md) i [`ARCHITECTURE.md`](../ARCHITECTURE.md)

**a) [`API_DOCUMENTATION.md`](../API_DOCUMENTATION.md)**

| Linia | Jest | Zamienić na |
|-------|------|-------------|
| 543 | `\| GET \| \`/api/findCompatibleScales/:name/:root\` \| Kompatybilne skale \|` | `\| GET \| \`/api/find-compatible-scales/:name/:root\` \| Kompatybilne skale \|` |

**b) [`ARCHITECTURE.md`](../ARCHITECTURE.md)**

| Linia | Jest | Zamienić na |
|-------|------|-------------|
| 129 | `\| GET \| \`/api/findCompatibleScales/:name/:root\` \| Kompatybilne skale \|` | `\| GET \| \`/api/find-compatible-scales/:name/:root\` \| Kompatybilne skale \|` |

**Uzasadnienie**: Backend (`music-theory-api/API.md` linia 160) używa kebab-case. Dokumentacja UI była nieaktualna.

**Typ zmiany**: `apply_diff` w obu plikach — zastąpienie `findCompatibleScales` → `find-compatible-scales`

---

### P0.4 — Poprawić [`PRODUCT_OVERVIEW.md`](../PRODUCT_OVERVIEW.md) — nieaktualna informacja o Unicode

**Lokalizacja**: linia 81

**Obecna treść**:
```markdown
- Backend nie dekoduje Unicode w nazwach patternów (♭/♯) — zgłoszono do fixa
```

**Wymagana akcja**: Informacja jest nieaktualna — naprawione w `music-theory-api` v0.1.0. Należy:
- **Opcja A**: Usunąć całą linię 81.
- **Opcja B**: Zamienić na:
  ```markdown
  - Backend nie dekoduje Unicode w nazwach patternów (♭/♯) — **FIXED** (naprawione w music-theory-api v0.1.0)
  ```

**Plik**: [`PRODUCT_OVERVIEW.md`](../PRODUCT_OVERVIEW.md)
**Zakres**: linia 81
**Typ zmiany**: `apply_diff`

---

## P1 — Create missing documents

### P1.1 — Utworzyć dokumenty w `guitar-neck-shared`

**Ścieżka repozytorium**: `c:/code/Guitar-neck-app/shared/` (lub odpowiednik znaleziony w systemie)

#### P1.1a — [`AGENTS.md`](c:/code/Guitar-neck-app/shared/AGENTS.md)

Wymagana struktura (wg [`DOCUMENTATION_GUIDELINES.md`](DOCUMENTATION_GUIDELINES.md) sekcja 4.4):

```markdown
# guitar-neck-shared — Agents Instructions

## Tech Stack
- **Runtime:** Node.js (npm workspace)
- **Language:** TypeScript
- **Build:** `npm run build`
- **Testy:** ...

## Key Commands
- Build: `npm run build`
- Test: `npm test` (jeśli istnieją)

## Architecture / Project Map
- `src/models/` — modele danych (GuitarNote, NeckConfig, ChordPattern, ScalePattern)
- `src/constants/` — stałe (CHORD_PATTERNS, SCALE_PATTERNS)
- `public-api.ts` — barrel export

## Conventions
- [dostosować do shared]

## Git Workflow
- [standardowy workflow — branch, commit, squash-merge]

## Documentation Consistency Validation
- [checklista dostosowana do shared]
```

**Źródła do skopiowania/wzorowania się**:
- [`AGENTS.md`](../AGENTS.md) z `guitar-neck-ui` jako wzór składni/stylu
- [`DOCUMENTATION_GUIDELINES.md`](DOCUMENTATION_GUIDELINES.md) sekcja 4.4 — wymagane sekcje

#### P1.1b — [`BACKLOG.md`](c:/code/Guitar-neck-app/shared/BACKLOG.md)

Wymagana struktura (wg [`DOCUMENTATION_GUIDELINES.md`](DOCUMENTATION_GUIDELINES.md) sekcja 4.2):

Każdy wpis MUSI mieć 6 sekcji w tej kolejności:

```markdown
# [Tytuł zadania]

## Motivation
Dlaczego to robimy? Jaki problem rozwiązuje?

## Solution
Jak to zrobimy — opis techniczny.

## MVP
Minimalny zakres — lista kroków do wykonania.

## Done when
Kryteria akceptacji.

## Status
OPEN | FIXED | POSTPONED | WON'T DO
---
```

**Statusy**: tylko `OPEN`, `FIXED`, `POSTPONED`, `WON'T DO`
**Separator**: `---` między wpisami
**Brak tagów priorytetu** — status wystarczy

**Zawartość początkowa**: Backlog dla shared models. Propozycja wpisów:
- Initial project setup
- Version alignment across ecosystem
- Documentation completion (te 3 pliki)

#### P1.1c — [`CHANGELOG.md`](c:/code/Guitar-neck-app/shared/CHANGELOG.md)

Wymagana struktura (wg [`DOCUMENTATION_GUIDELINES.md`](DOCUMENTATION_GUIDELINES.md) sekcja 4.3):

```markdown
# Changelog

All notable changes to this project are documented in this file.

Format oparty na [Keep a Changelog](https://keepachangelog.com/),
a projekt stosuje [Semantic Versioning](https://semver.org/).

---

## [wersja] — YYYY-MM-DD

### Added
- ...

### Changed
- ...

### Fixed
- ...
```

**Język**: angielski (per guidelines — changelogi publiczne)
**Daty**: ISO `YYYY-MM-DD`

---

### P1.2 — Utworzyć `CHANGELOG.md` w root `guitar-toolbox`

**Ścieżka**: [`c:/code/Guitar-neck-app/guitar-toolbox/CHANGELOG.md`](c:/code/Guitar-neck-app/guitar-toolbox/CHANGELOG.md)

**Problem**: Obecnie plik istnieje tylko w `projects/guitar-toolbox-lib/`, ale wg wytycznych powinien być w root repozytorium.

**Wymagana struktura**: taka sama jak P1.1c — Keep a Changelog format, język angielski.

**Zawartość**: Skopiować historię z `projects/guitar-toolbox-lib/CHANGELOG.md` (jeśli istnieje) lub utworzyć początkowy wpis.

---

### P1.3 — Utworzyć `ARCHITECTURE.md` w `music-theory-api`

**Ścieżka**: [`c:/code/Guitar-neck-app/music-theory-api/ARCHITECTURE.md`](c:/code/Guitar-neck-app/music-theory-api/ARCHITECTURE.md)

Wymagana struktura (wg [`DOCUMENTATION_GUIDELINES.md`](DOCUMENTATION_GUIDELINES.md) sekcja 4.6):

```markdown
# music-theory-api — Architektura Systemu

## 1. Przegląd architektury
Warstwy, wzorce, diagram przepływu.

## 2. Główne komponenty
Tabelka komponentów/routes.

## 3. Serwisy
Tabelka serwisów.

## 4. Przepływ danych
Diagram (np. Mermaid).

## 5. Wzorce projektowe
Np. Elysia routes → services → error handling.

## 6. Zależności zewnętrzne
Docker, Elysia, itd.

## 7. Konfiguracja środowiska
Zmienne środowiskowe, port.
```

**Język**: polski (per guidelines — ARCHITECTURE.md to dokument wewnętrzny)
**Źródła**: 
- [`ARCHITECTURE.md`](../ARCHITECTURE.md) z `guitar-neck-ui` jako wzór formatowania/tabelek
- Kod źródłowy `music-theory-api` do opisania routes/services

---

## P2 — Format conversions and translations

### P2.1 — Przekonwertować `music-theory-api/BACKLOG.md` na standardowy format

**Plik źródłowy**: `c:/code/Guitar-neck-app/music-theory-api/BACKLOG.md`
**Problem**: Używa formatu epików z sub-itemami i tagami P0-P3. Nie używa standardowego 6-sekcyjnego szablonu.

**Wymagana konwersja**:

| Obecny element | Docelowy element |
|----------------|------------------|
| Epik (np. `## [P0] ...`) | `# [Tytuł]` |
| Sub-itemy z `- [ ]` | Osobne wpisy z własnym `---` |
| Tagi P0/P1/P2/P3 | Usunąć — status `OPEN`/`FIXED`/`POSTPONED`/`WON'T DO` wystarczy |
| Dowolny opis | Rozbić na sekcje: Motivation, Solution, MVP, Done when |

**Szablon docelowy** (z [`DOCUMENTATION_GUIDELINES.md`](DOCUMENTATION_GUIDELINES.md) sekcja 4.2):

```markdown
# [Tytuł zadania]

## Motivation
Dlaczego to robimy? Jaki problem rozwiązuje?

## Solution
Jak to zrobimy — opis techniczny.

## MVP
Minimalny zakres — lista kroków do wykonania.

## Done when
Kryteria akceptacji.

## Status
OPEN | FIXED | POSTPONED | WON'T DO

---
```

**Proces**:
1. Dla każdego epika → jeden wpis
2. Dla każdego sub-itemu (jeśli stanowi osobną jednostkę pracy) → osobny wpis
3. Mapowanie priorytetów P0-P3 nie jest potrzebne — status wystarczy

---

### P2.2 — Przetłumaczyć [`CHANGELOG.md`](../CHANGELOG.md) w `guitar-neck-ui` na angielski

**Plik**: [`CHANGELOG.md`](../CHANGELOG.md) w `guitar-neck-ui`
**Język źródłowy**: polski (entries od `[0.6.0]` w dół są po polsku)
**Język docelowy**: angielski

**Zakres tłumaczenia**:

| Sekcja | Linie | Obecny język | Uwagi |
|--------|-------|-------------|-------|
| Nagłówek | 1-8 | angielski | OK, nie zmieniać |
| `[0.7.0]` | 10-24 | angielski + polski | Linie 12-13 "Added" EN; linia 17 opis "toolboxSubmit()" PL |
| `[0.6.0]` | 26-50 | **polski** | Całość do tłumaczenia |
| `[0.5.0]` | 52-66 | **polski** | Całość do tłumaczenia |
| `[0.4.0]` | 68-81 | **polski** | Całość do tłumaczenia |
| `[0.3.0]` | 83-95 | **polski** | Całość do tłumaczenia |
| `[0.2.0]` | 97-112 | **polski** | Całość do tłumaczenia |
| `[0.1.0]` | 114-132 | **polski** | Całość do tłumaczenia |
| `[0.0.0]` | 134-143 | **polski** | Całość do tłumaczenia |
| Postponed | 146-155 | **polski** | Całość do tłumaczenia |
| Backlog | 158-165 | **polski** | Całość do tłumaczenia |
| Footer | 167 | angielski | OK, nie zmieniać |

**Zasady tłumaczenia** (z [`DOCUMENTATION_GUIDELINES.md`](DOCUMENTATION_GUIDELINES.md) sekcja 3):
- Kod źródłowy w blokach \`\`\` (zmienne, typy, interfejsy) — pozostaje w oryginalnym języku (angielski)
- Nazwy własne (endpointy, zmienne środowiskowe, klasy) — angielskie, opis w języku dokumentu
- Opisy changelogu — angielski

**Przykład tłumaczenia** (linie 37-41):
```diff
- Przeniesiono URL API z `scales-and-triads.service.ts` do zmiennych środowiskowych (`environment.apiUrl`)
- Wyłączono domyślnie AI Chat (`chatEnabled: false`)
- Rotacja klucza Gemini API — usunięto z frontendowego bundle'a
+ Moved API URL from `scales-and-triads.service.ts` to environment variables (`environment.apiUrl`)
+ Disabled AI Chat by default (`chatEnabled: false`)
+ Rotated Gemini API key — removed from frontend bundle
```

**Plik**: [`CHANGELOG.md`](../CHANGELOG.md)
**Typ zmiany**: `write_to_file` (kompletny plik) lub seria `apply_diff`

---

### P2.3 — Wyczyścić [`TODO_DEPLOY.md`](../TODO_DEPLOY.md)

**Plik**: [`TODO_DEPLOY.md`](../TODO_DEPLOY.md)

**Stan obecny**: Miesza pozycje DONE, FIXED i OPEN w jednym dokumencie — dezorientujące.

**Wymagana struktura docelowa**:

```markdown
# Deployment TODO

## ✅ Completed

- Rotate the previously exposed Gemini API key...
- Move the music pattern API base URL...
- Restore string labels before the fretboard...
- Feature flag for Chat (`chatEnabled` in environment, disabled by default)
- Dockerfile + nginx.conf for production frontend build
- docker-compose.yml (backend + frontend razem)
- Build & deploy scripts (`npm run build:prod`, `npm run docker:*`)

## 🧹 Removed from Code

- `ToolboxSearchQuery` typing — removed `CustomToolboxSearchQuery` and `isCustomToolboxSearchQuery()`.
- `refreshNotesInRange()` dead code — removed from `freatboard.component.ts`.

## 📋 Open Tasks

- [ ] Refactor `toolboxSubmit` in `src/app/home-page/home-page.component.ts` into a command factory or private builder methods.
- [ ] Pattern name Unicode w backendzie — `:name` param nie dekodowany (backend `music-theory-api`).
- [ ] Fret numbering starts at 0 zamiast 1 — zmiana w template na `fret + 1`.
- [ ] Remove unused uuid from GuitarNote — zbędny import, 150 UUID generowanych bez użycia.
- [ ] FretboardStateService O(n) → O(1) — zastąpić Array.find Mapą.
- [ ] Template bezpośrednio wywołuje serwisy — przenieść logikę do komponentu / DisplayCell.
- [ ] UI Color Palette Refresh — odświeżenie palety kolorów interwałowych.

## 🔍 Pre-Deploy Verification

- Re-test custom pattern from the toolbox against the deployed API after typing cleanup.
- Build the app against production environment values.
- Verify chat behavior when `geminiApiKey` is missing or injected externally.
```

**Zmiany specyficzne**:

| Obecna sekcja (linie) | Akcja |
|-----------------------|-------|
| "Highest Priority (wszystkie DONE)" (3-12) | Przenieść pod "✅ Completed", zmienić `- DONE:` na `-` |
| "FIXED (usunięte z kodu)" (14-19) | Przenieść pod "🧹 Removed from Code", zmienić `- FIXED:` na `-` |
| "OPEN (do wykonania)" (20-28) | Przenieść pod "📋 Open Tasks", dodać `[ ]` checkboxy |
| "Pre-Deploy Verification" (30-34) | Zachować pod "🔍 Pre-Deploy Verification" |

**Uwaga**: Pozycja "Pattern name Unicode w backendzie" w OPEN jest obecnie nieaktualna (naprawiona w v0.1.0) — oznaczyć jako `[x] (FIXED)` lub przenieść do "✅ Completed".

**Plik**: [`TODO_DEPLOY.md`](../TODO_DEPLOY.md)
**Typ zmiany**: `write_to_file` (kompletna podmiana) lub `apply_diff` (sekwencyjnie)
