# Plan: Domain Contract dla Toolbox i AI

## Cel

Stworzyć wspólną warstwę domenową (`src/app/domain/`), z której korzystają zarówno Toolbox (obecny UI), jak i przyszły AI asystent (Langchain). AI jest równoprawnym klientem, nie specjalnym API.

## Decyzje architektoniczne (podsumowanie)

Szczegółowo udokumentowane w [`docs/adr/0005-domain-contract-toolbox-ai.md`](../docs/adr/0005-domain-contract-toolbox-ai.md).
Glossary w [`docs/glossary.md`](../docs/glossary.md).

1. **Wspólna warstwa domenowa** — `src/app/domain/` z komendami, kwerendami, stanem i serwisem
2. **DomainCommand to intencja użytkownika** — nie instrukcja mutacji stanu
3. **Jedna komenda z parametrami** — `emphasis` jako parametr, nie osobny overlay
4. **Canonical state minimalny i immutable** — 9 pól (patternType usunięty — wyliczany z mode)
5. **Jeden kontrakt dla Toolbox i AI** — bez rozszerzeń AI-specific
6. **Immutable state z snapshotami** — każda komenda → nowy obiekt stanu
7. **DomainResult** — `{ success, data } | { success, error, message }` (nazwa: DomainResult, nie CommandResult)
8. **Brak wersjonowania** — optional fields na razie
9. **MCP później** — najpierw kontrakt, potem ewentualnie MCP

## Canonical State

```typescript
interface DomainState {
  mode: 'scale' | 'chord' | 'scale-chord' | 'custom';
  rootNote: string;
  patternName: string;
  compareTarget?: { rootNote: string; patternName: string; patternType: 'scale' | 'chord' };
  fretRange: { min: number; max: number };
  enabledStrings: boolean[];
  emphasis?: { intervals?: string[]; roles?: string[] };
  markerDisplayMode: 'interval-colors' | 'note-names' | 'neutral-dots';
  selectedNotes?: Array<{ note: string; string: number; fret: number }>;
}
```

**Uwagi:**
- `patternType` usunięty — wyliczany z `mode` gdy potrzebny
- `selectedNotes` to tablica pozycji (string+fret), nie tylko nazw nut — kliknięcie dotyczy konkretnego miejsca na gryfie

## Komendy (Commands)

| Komenda | Parametry | Opis |
|---------|-----------|------|
| `show-pattern` | `patternType, patternName, rootNote, fretRange?, emphasis?` | Wyświetla pattern (skalę/akord) na gryfie. Zastępuje poprzedni widok. |
| `compare-patterns` | `primary: { patternType, patternName, rootNote }, secondary: { patternType, patternName, rootNote }` | Porównuje dwa patterny (scale-chord mode). |
| `set-view` | `fretRange?, enabledStrings?, markerDisplayMode?` | Zmienia konfigurację widoku bez zmiany patternu. |
| `set-emphasis` | `intervals?: string[], roles?: string[]` | Zmienia emphasis na bieżącym patternie. |
| `clear-view` | — | Czyści gryf, resetuje stan do domyślnego. |

## Kwerendy (Queries)

| Kwerenda | Zwraca | Opis |
|----------|--------|------|
| `get-current-view` | `DomainState` | Aktualny stan aplikacji. |
| `get-available-patterns` | `{ scales: string[], chords: string[] }` | Lista dostępnych patternów. |
| `get-pattern-details` | `PatternInfo` | Szczegóły patternu (nut, interwałów). |

## Wzorce — żeby się nie zakopać

### A. Command Pattern — prosty switch, nie CQRS framework

`DomainService` używa prostego switcha, nie command busa ani middleware chaina:

```typescript
execute(command: DomainCommand): DomainResult<DomainState> {
  switch (command.type) {
    case 'show-pattern': return this.handleShowPattern(command);
    case 'compare-patterns': return this.handleComparePatterns(command);
    case 'clear-view': return this.handleClearView();
    default: return { success: false, error: 'UNKNOWN_COMMAND', message: '' };
  }
}
```

**Zasada:** dopóki switch ma <10 case'ów, nie potrzebujemy wzorca dispatchera.

### B. Facade nad istniejącymi serwisami

`DomainService` to **nie nowa logika** — to facade delegujący do istniejących serwisów:

```typescript
private handleShowPattern(cmd: ShowPatternCommand): DomainResult<DomainState> {
  if (!this.isValidPattern(cmd.patternName, cmd.patternType)) {
    return { success: false, error: 'PATTERN_NOT_FOUND', message: `Unknown: ${cmd.patternName}` };
  }
  const notes = cmd.patternType === 'scale'
    ? this.orchestration.displayScale(cmd.patternName, cmd.rootNote)
    : this.orchestration.displayChord(cmd.patternName, cmd.rootNote);
  const newState = this.createSnapshot(cmd, notes);
  this.stateSubject.next(newState);
  return { success: true, data: newState };
}
```

### C. Immutable state — structuredClone, nie Immer

Nie dodajemy Immer.js. `structuredClone` jest wbudowany:

```typescript
private createSnapshot(cmd: ShowPatternCommand, notes: GuitarNote[]): DomainState {
  return {
    ...this.currentState,
    mode: cmd.patternType === 'scale' ? 'scale' : 'chord',
    rootNote: cmd.rootNote,
    patternName: cmd.patternName,
    emphasis: cmd.emphasis ?? this.currentState.emphasis,
  };
}
```

### D. FretboardDisplayService — Angularowy serwis, jedyne miejsce dla derived state

`FretboardDisplayService` zostaje jako Angularowy serwis z DI. Jest **jedynym miejscem** odpowiedzialnym za derived state:

```typescript
@Injectable({ providedIn: 'root' })
export class FretboardDisplayService {
  constructor(private domainService: DomainService) {}

  getMarkerCssClass(note: VisibleNote, state: DomainState): string {
    if (state.mode === 'scale-chord') return '';
    // state.markerDisplayMode, note.interval — wszystko z immutable state
  }

  getActiveIntervals(state: DomainState): string[] {
    // derived state z DomainState, nie z notes[]
  }
}
```

## Plan implementacji (kroki)

### Krok 1: Utworzyć strukturę `src/app/domain/`

Pliki:
- `src/app/domain/commands.ts` — typy komend (intencje użytkownika)
- `src/app/domain/queries.ts` — typy kwerend
- `src/app/domain/state.ts` — `DomainState` + `DomainError` + `DomainResult`
- `src/app/domain/domain.service.ts` — serwis przyjmujący komendy/kwerendy

### Krok 2: Zrefaktorować `FretboardStateService`

- Zmienić na immutable state
- `notes[]` przestaje być mutowany in-place
- `currentSelection`, `scaleChordState` → zastąpione przez `DomainState`
- Dodać `BehaviorSubject<DomainState>` jako źródło stanu

### Krok 3: Zrefaktorować `FretboardOrchestrationService`

- Metody przyjmują `DomainCommand` zamiast gołych stringów
- Zwracają `DomainResult<GuitarNote[]>` zamiast `GuitarNote[]`
- Derived state wyliczany przez `FretboardDisplayService`

### Krok 4: Zrefaktorować `ToolboxBuilderComponent`

- Emituje `DomainCommand` zamiast własnego `FretboardCommand`
- Usunąć `toolbox/model.ts` (lub zostawić jako alias)

### Krok 5: Zrefaktorować `FretboardDisplayService`

- Przejść z mutacji `notes[]` na derived state z `DomainState`
- `getMarkerCssClass`, `getRoleCssClass` — czytać z immutable state
- To jedyne miejsce odpowiedzialne za derived state

### Krok 6: Zaktualizować testy

- `fretboard-state.service.spec.ts`
- `fretboard-orchestration.service.spec.ts`
- `fretboard-display.service.spec.ts`
- `toolbox-builder.component.spec.ts`

### Krok 7: Dodać adapter dla AI (Langchain)

**Co zawiera adapter:**

Po stronie Angular:
- `src/app/domain/ai-adapter.service.ts` — serializuje `DomainState` do formatu zrozumiałego dla AI
- Jeden endpoint HTTP (lub WebSocket) wystawiający `DomainService.execute(command)`
- Zwraca `SerializedView` — uproszczony obraz stanu dla AI (bez Angular-specific details)

```typescript
// ai-adapter.service.ts
@Injectable({ providedIn: 'root' })
export class AiAdapterService {
  constructor(private domain: DomainService) {}

  execute(command: DomainCommand): DomainResult<SerializedView> {
    const result = this.domain.execute(command);
    if (!result.success) return result;
    return {
      success: true,
      data: this.serializeView(result.data)
    };
  }

  private serializeView(state: DomainState): SerializedView {
    return {
      mode: state.mode,
      currentPattern: `${state.rootNote} ${state.patternName}`,
      fretRange: state.fretRange,
      enabledStrings: state.enabledStrings,
      emphasis: state.emphasis,
    };
  }
}
```

Po stronie Langchain (Python/Node.js):
- Tool definition dla LLM (np. `show_pattern`, `get_current_view`)
- HTTP client wołający Angular endpoint
- Parsowanie `DomainResult` na odpowiedź dla LLM

**Nie robimy na razie:**
- MCP server
- Rate limiting
- Auth
- Queue

## Diagram przepływu

```mermaid
flowchart TD
    Toolbox[Toolbox UI] -->|DomainCommand intent| DomainService[DomainService]
    AI[AI Langchain] -->|DomainCommand intent| AiAdapter[AiAdapterService]
    AiAdapter -->|DomainCommand intent| DomainService
    DomainService -->|validate| Validation{DomainResult}
    Validation -->|success| Orchestration[FretboardOrchestrationService]
    Validation -->|error| Error[Zwraca DomainResult.error]
    Orchestration -->|resolve pattern| Tonal[TonalFacadeService]
    Orchestration -->|find positions| NoteService[FretboardNotePositionService]
    Orchestration -->|compute roles| MarkerRole[MarkerRoleService]
    Orchestration -->|new snapshot| State[DomainState]
    State -->|derived| Display[FretboardDisplayService]
    Display -->|CSS classes| Fretboard[Fretboard Component]
```

## Stan po refaktorze

```
src/app/domain/
├── commands.ts              # DomainCommand types (user intents)
├── queries.ts               # DomainQuery types
├── state.ts                 # DomainState, DomainError, DomainResult
├── domain.service.ts        # DomainService — execute(command), query(query)
└── ai-adapter.service.ts    # Serializacja dla AI (krok 7)

src/app/services/
├── fretboard-state.service.ts       # REFACTORED: immutable, BehaviorSubject<DomainState>
├── fretboard-orchestration.service.ts # REFACTORED: accepts DomainCommand
├── fretboard-display.service.ts     # REFACTORED: jedyne miejsce dla derived state
├── fretboard-note-query.service.ts  # UNCHANGED or merged into DomainService
├── marker-role.service.ts           # UNCHANGED
├── tonal-facade.service.ts          # UNCHANGED
└── note.service.ts                  # UNCHANGED

src/app/toolbox/
├── toolbox-builder.component.ts     # REFACTORED: emits DomainCommand
└── model.ts                         # REMOVED or kept as re-export alias