# Plan naprawczy — problemy w codebase

## Priorytety

| Priorytet | Obszar | Uzasadnienie |
|-----------|--------|-------------|
| **P0** | Zepsute testy | `app-state.service.spec.ts` rzuca błędami — blokuje CI |
| **P0** | Martwy kod | Usunięcie nieużywanych funkcji zmniejsza koszt utrzymania |
| **P1** | Duplikacja logiki | 6x ten sam algorytm = 6x więcej miejsc do poprawki przy zmianach |
| **P1** | Brakujące testy fasady | `music-theory-facade.service` to najważniejszy serwis — 0 testów |
| **P2** | Luki w testach | Pozostałe serwisy bez testów |
| **P2** | Bug: notesMap nieaktualna | `GuitarNeckComponent` nadpisuje `notes` ale `notesMap` nie jest przebudowana |

---

## Ticket 1: Naprawa zepsutego testu `app-state.service.spec.ts`

**Plik:** [`src/app/app-state.service.spec.ts`](src/app/app-state.service.spec.ts)

**Problem:** Testy używają wartości `'idle'` i `'scale'` które nie istnieją w typie `AppMode`. Rzeczywisty typ to `'custom-pattern' | 'scale-or-chord' | 'scale-chord'`.

**Zadania:**
1. Zaktualizować wszystkie asercje w `app-state.service.spec.ts`:
   - `'idle'` → `'scale-or-chord'` (domyślna wartość)
   - `'scale'` → `'scale-or-chord'`
   - `'scale-chord'` → pozostaje bez zmian
2. Zweryfikować `npm test` przechodzi

**Blokery:** Brak

**Done when:** `npm test` przechodzi, testy `AppStateService` są zielone

---

## Ticket 2: Usunięcie martwego kodu z `music-theory-facade.service.ts`

**Plik:** [`src/app/services/music-theory-facade.service.ts`](src/app/services/music-theory-facade.service.ts)

**Problem:** 4 metody publiczne nie są używane przez żaden komponent ani serwis.

**Do usunięcia:**
- [`displaySingleNote()`](src/app/services/music-theory-facade.service.ts:51) — nikt nie woła
- [`displayAllNotes()`](src/app/services/music-theory-facade.service.ts:57) — nikt nie woła
- [`resetFretboard()`](src/app/services/music-theory-facade.service.ts:62) — nikt nie woła (jest `clearFretboard()` który robi to samo)
- [`clearRelation()`](src/app/services/music-theory-facade.service.ts:128) — nikt nie woła

**Zadania:**
1. Usunąć 4 metody z `FretboardOrchestrationService`
2. Zweryfikować `npm run build` przechodzi (TypeScript wyłapie brakujące referencje)

**Blokery:** Brak

**Done when:** Build przechodzi, żaden inny plik nie importuje tych metod

---

## Ticket 3: Usunięcie martwego kodu z `app-state.service.ts`

**Plik:** [`src/app/app-state.service.ts`](src/app/app-state.service.ts)

**Problem:** `switchMode()` jest aliasem `setMode()` — nikt nie woła `switchMode()`. `appMode$` Observable nie ma subskrybentów.

**Do usunięcia:**
- [`switchMode()`](src/app/app-state.service.ts:22) — nikt nie woła
- [`appMode$`](src/app/app-state.service.ts:9) — nikt nie subskrybuje (opcjonalnie: zostawić jeśli planowany jest przyszły użytek)

**Zadania:**
1. Usunąć `switchMode()` z serwisu i testów
2. Opcjonalnie: usunąć `appMode$` jeśli nie jest planowany
3. Zweryfikować build

**Blokery:** Brak

**Done when:** Build przechodzi

---

## Ticket 4: Usunięcie martwego pliku `interval-note.helper.ts`

**Plik:** [`src/app/shared/interval-note.helper.ts`](src/app/shared/interval-note.helper.ts)

**Problem:** Funkcja `calculateNotesFromIntervals()` nie jest importowana przez żaden inny plik. Cały plik to dead code.

**Zadania:**
1. Usunąć plik `src/app/shared/interval-note.helper.ts`
2. Zweryfikować build

**Blokery:** Brak

**Done when:** Plik usunięty, build przechodzi

---

## Ticket 5: Refaktor duplikacji — algorytm "interwały → nuty"

**Problem:** Ten sam algorytm (chromatic notes + rootIndex + cumulative steps → note names) istnieje w 6 miejscach.

**Miejsca:**
1. [`music-theory-facade.service.ts:resolveFromPatterns()`](src/app/services/music-theory-facade.service.ts:207) — linie 218-231
2. [`PatternBuilderService.setCurrentPattern()`](src/app/services/pattern-builder.service.ts:20) — linie 29-50
3. [`PatternBuilderService.setRelatedChord()`](src/app/services/pattern-builder.service.ts:63) — linie 70-90
4. [`MarkerRoleService.resolveChordNoteNames()`](src/app/services/marker-role.service.ts:29) — linie 36-53
5. [`MarkerRoleService.resolveScaleNoteNames()`](src/app/services/marker-role.service.ts:59) — linie 66-83
6. [`interval-note.helper.ts:calculateNotesFromIntervals()`](src/app/shared/interval-note.helper.ts:3) — całość (dead code)

**Rozwiązanie:** Wydzielić do jednej funkcji w `tonal-adapter.ts` (lub nowym `shared/pattern-resolver.ts`):

```typescript
export function resolveNotesFromIntervals(
  rootNote: string,
  intervals: number[],
  chromatic?: string[]
): string[] {
  const scale = chromatic ?? neckConfig.chromaticNotes;
  const rootIndex = scale.indexOf(rootNote);
  if (rootIndex === -1) return [];

  const notes = [rootNote];
  let cumulative = 0;
  for (const step of intervals) {
    cumulative += step;
    notes.push(scale[(rootIndex + cumulative) % 12]);
  }
  return [...new Set(notes)];
}
```

**Zadania:**
1. Utworzyć `src/app/shared/pattern-resolver.ts` z funkcją `resolveNotesFromIntervals()`
2. Zrefaktorować `music-theory-facade.service.ts` — użyć nowej funkcji w `resolveFromPatterns()`
3. Zrefaktorować `PatternBuilderService` — użyć nowej funkcji w `setCurrentPattern()` i `setRelatedChord()`
4. Zrefaktorować `MarkerRoleService` — zastąpić `resolveChordNoteNames()` i `resolveScaleNoteNames()` nową funkcją
5. Usunąć `interval-note.helper.ts` (jeśli nie usunięty w Ticket 4)
6. Dodać testy dla nowej funkcji
7. Zweryfikować `npm test` i `npm run build`

**Blokery:** Ticket 4 (usunięcie dead code)

**Done when:** Wszystkie 6 miejsc używa tej samej funkcji, testy przechodzą

---

## Ticket 6: Refaktor `markIntervals()` i `markCustomIntervals()`

**Plik:** [`src/app/services/music-theory-facade.service.ts`](src/app/services/music-theory-facade.service.ts)

**Problem:** Dwie prawie identyczne metody — różnią się tylko tym, że `markIntervals()` szuka `rawName` w `rawNoteNames`.

**Rozwiązanie:** Połączyć w jedną metodę z parametrem `rawNoteNames?: string[]`:

```typescript
private markIntervals(
  rootNote: string,
  notes: GuitarNote[],
  rawNoteNames?: string[]
): void {
  for (const note of notes) {
    if (note.note === rootNote) {
      note.interval = 'root';
    } else {
      const rawName = rawNoteNames
        ? (rawNoteNames.find(n => simplify(n) === note.note) || note.note)
        : note.note;
      note.interval = INTERVAL_MAP[distance(rootNote, rawName)] || '';
    }
  }
}
```

**Zadania:**
1. Połączyć `markIntervals()` i `markCustomIntervals()` w jedną metodę
2. Zaktualizować wszystkie miejsca wołające
3. Zweryfikować `npm test`

**Blokery:** Brak

**Done when:** Tylko jedna metoda `markIntervals()` istnieje, testy przechodzą

---

## Ticket 7: Naprawa buga — `notesMap` nieaktualna po nadpisaniu `notes`

**Pliki:**
- [`src/app/guitar-neck/guitar-neck.component.ts:26`](src/app/guitar-neck/guitar-neck.component.ts:26)
- [`src/app/services/guitar-neck.service.ts:41`](src/app/services/guitar-neck.service.ts:41)
- [`src/app/freatboard/freatboard.component.ts:36`](src/app/freatboard/freatboard.component.ts:36)

**Problem:** `FretboardStateService` w konstruktorze woła `noteService.getAllPositions()` i buduje `notesMap`. Potem `GuitarNeckComponent` nadpisuje `this.guitarNeckService.notes = this.guitarNotes` — ale `notesMap` nie jest przebudowana. `FreatboardComponent.ngOnInit()` też nadpisuje `notes`.

**Rozwiązanie:** Dodać setter dla `notes` który automatycznie przebudowuje `notesMap`:

```typescript
set notes(value: GuitarNote[]) {
  this._notes = value;
  this.buildNotesMap();
}

get notes(): GuitarNote[] {
  return this._notes;
}
```

Lub prościej: po każdym nadpisaniu `notes` wołać `buildNotesMap()`.

**Zadania:**
1. Dodać setter/getter dla `notes` w `FretboardStateService` z automatycznym `buildNotesMap()`
2. Usunąć bezpośrednie przypisania `notes` w `GuitarNeckComponent` i `FreatboardComponent` — używać settera
3. Zweryfikować `npm test`

**Blokery:** Brak

**Done when:** `notesMap` jest zawsze spójna z `notes`, testy przechodzą

---

## Ticket 8: Dodanie testów dla `music-theory-facade.service.ts`

**Plik:** [`src/app/services/music-theory-facade.service.ts`](src/app/services/music-theory-facade.service.ts)

**Problem:** Najważniejszy serwis (fasada) nie ma żadnych testów.

**Scenariusze do pokrycia:**
- `displayScale()` — z Tonal i z fallbackiem (exotic scale)
- `displayChord()` — z Tonal, z fallbackiem (`add11`), z `CHORDS_NOT_IN_TONAL`
- `displayCustomPattern()` — poprawny i pusty wynik
- `displayScaleWithChord()` — diatoniczny i niediatoniczny akord
- `resolveScaleNotes()` — Tonal success, Tonal empty, fallback
- `resolveChordNotes()` — Tonal success, `add11`, fallback, unknown mapping
- `markIntervals()` — root detection, interval mapping

**Zadania:**
1. Utworzyć `src/app/services/music-theory-facade.service.spec.ts`
2. Zamockować `FretboardNotePositionService`, `FretboardStateService`, `MarkerRoleService`
3. Dodać testy dla wszystkich publicznych metod
4. Zweryfikować `npm test`

**Blokery:** Ticket 5, 6 (refaktory które zmieniają ten plik)

**Done when:** Coverage dla `music-theory-facade.service.ts` > 80%, testy przechodzą

---

## Ticket 9: Dodanie brakujących testów dla serwisów

**Brakujące pliki:**
- `pattern-builder.service.spec.ts`
- `fretboard-note-query.service.spec.ts`
- `metronome-engine.service.spec.ts`

**Zadania:**
1. `pattern-builder.service.spec.ts` — testy dla `setCurrentPattern()`, `setRelatedChord()`, `clearCurrentPattern()`, `SEMITONE_TO_INTERVAL` mapping
2. `fretboard-note-query.service.spec.ts` — testy dla `isNoteOnFret()`, `getNote()`, `getNoteName()`, `fretNoteClicked()`, `activeStrings` filtering
3. `metronome-engine.service.spec.ts` — testy dla `initAudioContext()`, `scheduleBeat()`, `scheduleMeasure()`, `stop()`, `isReady`, `currentTime`

**Blokery:** Ticket 5 (refaktor PatternBuilderService)

**Done when:** Wszystkie 3 pliki istnieją, testy przechodzą

---

## Ticket 10: Dodanie testów dla komponentów

**Brakujące pliki:**
- `home-page.component.spec.ts`
- `range-toolbar.component.spec.ts`

**Zadania:**
1. `home-page.component.spec.ts` — testy dla `onToolboxEvent()` z każdym rodzajem `FretboardCommand`, `displayMode` signal
2. `range-toolbar.component.spec.ts` — testy dla `selectPreset()`, `applyCustom()`, `switchMode()`, `emitRange()`

**Blokery:** Brak

**Done when:** Oba pliki istnieją, testy przechodzą

---

## Kolejność realizacji

```
Ticket 1 (zepsute testy)
    ↓
Ticket 2 + 3 + 4 (dead code — można równolegle)
    ↓
Ticket 5 (refaktor duplikacji) ──→ Ticket 6 (refaktor markIntervals)
    ↓                                    ↓
Ticket 8 (testy fasady)           Ticket 8 (zależy od refaktora)
    ↓
Ticket 7 (bug notesMap)
    ↓
Ticket 9 + 10 (pozostałe testy — można równolegle)
```

## Podsumowanie

| Ticket | Obszar | Typ | Priorytet |
|--------|--------|-----|-----------|
| 1 | Zepsuty test `AppStateService` | Bug | P0 |
| 2 | Dead code w facade | Cleanup | P0 |
| 3 | Dead code w AppStateService | Cleanup | P0 |
| 4 | Dead code interval-note.helper.ts | Cleanup | P0 |
| 5 | Duplikacja algorytmu (6 miejsc) | Refaktor | P1 |
| 6 | Duplikacja markIntervals | Refaktor | P1 |
| 7 | Bug notesMap | Bug | P2 |
| 8 | Brak testów fasady | Testy | P1 |
| 9 | Brak testów serwisów | Testy | P2 |
| 10 | Brak testów komponentów | Testy | P2 |