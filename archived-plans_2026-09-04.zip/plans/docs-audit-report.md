# Audyt spójności dokumentacji — raport

> Przeprowadzony: 2026-07-08
> Zakres: wszystkie 4 repozytoria ekosystemu

---

## 1. Brakujące dokumenty

| Repozytorium | Brakuje | Wg wytycznych |
|---|---|---|
| `guitar-neck-shared` | `AGENTS.md` | wymagany |
| `guitar-neck-shared` | `BACKLOG.md` | wymagany |
| `guitar-neck-shared` | `CHANGELOG.md` | wymagany |
| `guitar-toolbox` | `CHANGELOG.md` (w root) | wymagany (jest tylko w `projects/guitar-toolbox-lib/`) |
| `music-theory-api` | `ARCHITECTURE.md` | wymagany (>1 komponent) |

---

## 2. Nieaktualne ścieżki w `API_DOCUMENTATION.md`

| Linia | Jest (nie istnieje) | Powinno być |
|---|---|---|
| 394 | `src/app/freatboard/components/legend/legend.component.ts` | `src/app/legend/legend.component.ts` |
| 438 | `src/app/shared/model/musicElements.ts` | `src/app/shared/model/music-selection.ts` |

---

## 3. Nieaktualna nazwa `@Output`

| Dokument | Linia | Jest | Powinno |
|---|---|---|---|
| `API_DOCUMENTATION.md` | 408 | `@Output() onSubmit$` | `@Output() onSubmit` |

(guitar-toolbox zmienił nazwę z `onSubmit$` na `onSubmit` — dokumentacja nie została zaktualizowana)

---

## 4. Nieaktualne endpointy API

| Dokument | Linia | Jest (camelCase) | Powinno (kebab-case) |
|---|---|---|---|
| `API_DOCUMENTATION.md` | 543 | `GET /api/findCompatibleScales/:name/:root` | `GET /api/find-compatible-scales/:name/:root` |
| `ARCHITECTURE.md` | 129 | `GET /api/findCompatibleScales/:name/:root` | `GET /api/find-compatible-scales/:name/:root` |

Backend (`music-theory-api/API.md` linia 160) poprawnie używa kebab-case.

---

## 5. Niespójny format `BACKLOG.md`

| Repozytorium | Problem |
|---|---|
| `music-theory-api/BACKLOG.md` | Używa formatu epików z sub-itemami i tagami P0-P3. Nie używa standardowego 6-sekcyjnego szablonu (Title, Motivation, Solution, MVP, Done when, Status). |

---

## 6. Niespójności językowe

| Dokument | Obecny język | Wymagany (wg wytycznych) | Zgodny? |
|---|---|---|---|
| `README.md` (guitar-neck-ui) | angielski | angielski | ✅ |
| `README.md` (music-theory-api) | angielski | angielski | ✅ |
| `README.md` (guitar-toolbox) | angielski | angielski | ✅ |
| `README.md` (shared) | angielski | angielski | ✅ |
| `CHANGELOG.md` (guitar-neck-ui) | **polski** | **angielski** | ❌ |
| `CHANGELOG.md` (music-theory-api) | angielski | angielski | ✅ |
| `AGENTS.md` (guitar-neck-ui) | angielski | angielski | ✅ |
| `AGENTS.md` (music-theory-api) | angielski | angielski | ✅ |
| `AGENTS.md` (guitar-toolbox) | angielski | angielski | ✅ |

---

## 7. Drobne problemy

| Problem | Szczegóły |
|---|---|
| `TODO_DEPLOY.md` miesza DONE z OPEN | Pozycje oznaczone "DONE" obok rzeczywistych otwartych zadań — dezorientujące |
| `PRODUCT_OVERVIEW.md` linia 81 | "Backend nie dekoduje Unicode" — to już naprawione w music-theory-api (v0.1.0) |

---

## Podsumowanie

17 znalezionych problemów w 4 repozytoriach.
