# Analiza długu technicznego i polerki UI

## Priorytety

| Priorytet | Obszar | Opis |
|-----------|--------|------|
| 🔴 **CRITICAL** | Architektura | Template'y wołają serwisy bezpośrednio |
| 🔴 **CRITICAL** | Architektura | `FretboardStateService` to Bóg-serwis — robi za dużo |
| 🟠 **HIGH** | Performance | `Array.find()` zamiast Mapy — O(n) na gorącej ścieżce |
| 🟠 **HIGH** | UX | Fret numbering: pokazuje 1–24, model 0–23 — off-by-one |
| 🟠 **HIGH** | UX | Czytelność nut na gryfie — wąskie progi, małe kropki |
| 🟡 **MEDIUM** | Architektura | `toolboxSubmit()` monolit — OPEN w backlogu |
| 🟡 **MEDIUM** | UX | Metronom: słaba wizualizacja beatów — OPEN w backlogu |
| 🟡 **MEDIUM** | UX | Paleta kolorów interwałowych — WCAG AA? |
| 🟡 **MEDIUM** | UI | Komunikacja jednojęzyczna (PL) |
| 🔵 **LOW** | Czystość | Zakomentowany dead code w HTML i SCSS |
| 🔵 **LOW** | Czystość | `freatboard` zamiast `fretboard` — literówka w nazwie folderu |
| 🔵 **LOW** | UX | Brak obsługi klawiatury na gryfie (tylko click) |
| 🔵 **LOW** | UX | Metronom znika na mobile (`display: none !important`) |

---

## Szczegółowy opis bolączek

### 🔴 [CRITICAL] Template'y wołają serwisy bezpośrednio

**Plik:** [`freatboard.component.html`](src/app/freatboard/freatboard.component.html)
**Plik:** [`pattern-display.component.html`](src/app/pattern-display/pattern-display.component.html)
**Plik:** [`legend.component.html`](src/app/legend/legend.component.html)

3 template'y odnoszą się do `guitarNeckService.*` bezpośrednio:

- `freatboard.component.html` — `guitarNeckService.activeStrings[i]` (linie 15, 20), `guitarNeckService.showNoteLabels` (linie 30, 35, 38, 40, 51, 55, 58, 59), `guitarNeckService.getMarkerCssClass()` (linie 38, 58)
- `pattern-display.component.html` — `guitarNeckService.currentPattern` (linia 1)
- `legend.component.html` — `guitarNeckService.markerDisplayMode` (linia 27), `guitarNeckService.hasActiveResult` (linia 28)

**Problem:** Template powinien tylko bindować do properties/metod komponentu, nie do serwisów. To uniemożliwia `ChangeDetectionStrategy.OnPush`, utrudnia testowanie i refaktoryzację.

**Rozwiązanie:** Dodać właściwości/gettery w każdym komponencie, np.:
- `FreatboardComponent.get activeStrings()` → `this.guitarNeckService.activeStrings`
- `PatternDisplayComponent.get currentPattern()` → `this.guitarNeckService.currentPattern`
- `LegendComponent.get markerDisplayMode()` → `this.guitarNeckService.markerDisplayMode`

---

### 🔴 [CRITICAL] `FretboardStateService` to service-omnibus

**Plik:** [`guitar-neck.service.ts`](src/app/services/guitar-neck.service.ts)

Klasa robi WSZYSTKO:
- Stan nut (visible, selected)
- Stan stringów (active/inactive)
- Stan patternu (currentPattern)
- Marker CSS logic (`getMarkerCssClass()`, `showNoteLabels`)
- Display mode (`markerDisplayMode`)
- Generowanie PatternInfo (`setCurrentPattern()`)
- Interwał lookup (`SEMITONE_TO_INTERVAL`)

**Problem:** Nie po to mamy 5 serwisów, żeby jeden robił robotę za wszystkich. Narusza SRP.

**Rozwiązanie:** Wydzielić do osobnych serwisów/klas:
- `FretboardViewService` — marker display mode, showNoteLabels, getMarkerCssClass
- Przenieść `SEMITONE_TO_INTERVAL` i `setCurrentPattern()` do `IntervalService` lub osobnego `PatternInfoService`

---

### 🟠 [HIGH] O(n) zamiast O(1) — Array.find na gorącej ścieżce

**Plik:** [`guitar-neck.service.ts`](src/app/services/guitar-neck.service.ts)

Metody `getNote()`, `getNoteName()`, `isNoteOnFret()`, `fretNoteClicked()` używają `Array.find()` i `Array.some()` na tablicy 150+ elementów.

**Problem:** Renderowanie 6 strun × 25 pozycji = 150 iteracji. Każdy `find()` to kolejne 150 iteracji. Przy zmianie zakresu progu, odświeżaniu widoku — kumuluje się.

**Rozwiązanie:** Stworzyć `Map<string, GuitarNote>` z kluczem `"${stringIndex}-${fret}"`. Backlog item OPEN.

---

### 🟠 [HIGH] Fret numbering — off-by-one

**Plik:** [`guitar-neck.service.ts`](src/app/services/guitar-neck.service.ts:30)
**Plik:** [`freatboard.component.html`](src/app/freatboard/freatboard.component.html:9)

```typescript
frets = Array.from({ length: neckConfig.numberOfFrets }, (_, i) => i + 1);
```

Wyświetla 1–24 zamiast 0–23. Model danych (fret 0 = open string) vs wizualizacja (1 = pierwszy próg). Użytkownik widzi nuty na "progu 1", ale w modelu to fret 0.

**Rozwiązanie:** Template `{{ fret }}` → {{ fret }} (zostawić jako 0-indeksowane). Backlog item OPEN.

---

### 🟠 [HIGH] Czytelność nut na gryfie (POSTPONED)

**Plik:** [`BACKLOG.md`](BACKLOG.md:194)

Małe kropki, wąskie progi — szczególnie na dolnych progach (1–5) nazwy nachodzą na siebie. Problem zgłoszony, odłożony, ale wciąż boli.

**Rozwiązanie (MVP):** Pills/badges z wysokim kontrastem, tooltip na hover. Dynamiczna wielkość fontu.

---

### 🟡 [MEDIUM] `toolboxSubmit()` to monolit

**Plik:** [`home-page.component.ts`](src/app/home-page/home-page.component.ts:41)

Jedna wielka metoda z if-else drzewem konstruującym komendy. Backlog item OPEN.

---

### 🟡 [MEDIUM] Metronom — słaba wizualizacja

**Plik:** [`metronome.component.html`](src/app/metronome/metronome.component.html)
**Plik:** [`BACKLOG.md`](BACKLOG.md:436)

Tylko podstawowe `[class.accent]` dla beat 1 i delikatna klasa `pulse`. Brak animacji, brak wyróżnienia miary taktu.

---

### 🟡 [MEDIUM] Paleta kolorów — WCAG AA?

**Plik:** [`styles.scss`](src/styles.scss:48-59)

Kolory interwałowe (`--interval-root: rgb(168,18,35)` itd.) nie były testowane pod kątem WCAG. Dla color-blind użytkowników różnice między minor-3rd a major-3rd są niewidoczne.

---

### 🟡 [MEDIUM] Komunikacja tylko po polsku

**Plik:** [`pattern-display.component.html`](src/app/pattern-display/pattern-display.component.html)
**Plik:** [`practice-prompts.data.ts`](src/app/shared/practice-prompts.data.ts)

Practice prompts i etykiety w pattern-display są po polsku ("Dźwięki", "Interwały", "Półtony", "Kroki", "Pomysły na ćwiczenia"). Brak wsparcia dla EN.

---

### 🔵 [LOW] Dead code w HTML i SCSS

**`home-page.component.html`:** Zakomentowane `<!-- <%- include(...) -->` (linie 7-9, 24) — pozostałość po EJS.

**`styles.scss`:** Zakomentowane:
- `.flex-container` (linie 2-12)
- `.dock__header`, `.dock-tabs`, `.dock-tab`, `.dock-actions` (linie 466-529)

---

### 🔵 [LOW] `freatboard` — literówka

Folder `src/app/freatboard/` powinien nazywać się `fretboard`. Zmiana wymaga rename migration.

---

### 🔵 [LOW] Brak keyboard accessibility

**Plik:** [`freatboard.component.html`](src/app/freatboard/freatboard.component.html)

Wszystkie nuty to `<button>` z `(click)`, ale brak `(keydown)`, `(focus)`, `(blur)`. Użytkownicy klawiatury nie mogą nawigować po gryfie.

---

### 🔵 [LOW] Metronom znika na mobile

**Plik:** [`styles.scss`](src/styles.scss:692-694)

```scss
app-metronome {
  display: none !important;
}
}

Kategoryczne ukrycie metronomu na urządzeniach mobilnych bez alternatywy.

---

## Cross-cutting: Architektura serwisów

**Plik:** [`music-theory-facade.service.ts`](src/app/services/music-theory-facade.service.ts)

`displayScale()` i `displayChord()` — różnie traktują `clearFretboard()`:
- `displayScale()` — **nie** woła `clearFretboard()`
- `displayChord()` — woła `clearFretboard()`, ale potem `HomePageComponent.toolboxSubmit()` też woła `clearFretboard()`, więc dubel

`displaySingleNote()` i `displayCustomPattern()` — **nie używają** `LoadingService`, więc nie ma spinnera podczas długich operacji.

---

## Cross-cutting: `GuitarNote` property naming

**Plik:** [`guitarNote.ts`](src/app/shared/model/guitarNote.ts)

Pole `string: number` — mylące, bo `string` to typ danych w TypeScript.

---

## Podsumowanie

| Kategoria | Ilość |
|-----------|-------|
| 🔴 CRITICAL | 2 |
| 🟠 HIGH | 3 |
| 🟡 MEDIUM | 4 |
| 🔵 LOW | 4 |
| **Razem** | **13** |
