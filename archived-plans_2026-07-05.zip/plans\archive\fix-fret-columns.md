# Plan: Remove open string (fret 0) as separate column

## Problem

After adding `+1` to frets array, fret 0 became an empty column with no label. The open string position is already handled by `guitar-neck__nut-label`. Having both creates a redundant empty column.

## Solution

Change `frets` to start from 1:
- `[0, 1, ..., 24]` → `[1, 2, ..., 24]` (24 elements)
- Open string notes rendered separately outside the `*ngFor`
- Header shows 1-24

## Changes

### 1. `guitar-neck.service.ts:12` — frets from 1
```typescript
frets = Array.from({ length: neckConfig.numberOfFrets }, (_, i) => i + 1);
// → [1, 2, 3, ..., 24]
```

### 2. `freatboard.component.html` — restructure

**Header labels:** Show 1-24
```html
<div *ngFor="let fret of frets" class="guitar-neck__fret-index-cell">{{ fret }}</div>
```

**Open string notes:** Add inside each string row, before the `*ngFor` loop:
```html
<div *ngFor="let string of strings; let i = index" [class]="'guitar-neck__string '+ string">
  <div class="guitar-neck__nut-label">{{ string }}</div>
  <!-- Open string -->
  <div class="guitar-neck__fret" *ngIf="isNoteOnFret(string, 0) && isNoteInRange(0)">
    ...render note at fret 0 with same conditions as before...
  </div>
  <!-- Frets 1-24 -->
  <div *ngFor="let fret of frets" class="guitar-neck__fret">
    ...
  </div>
</div>
```

### 3. Tests — update assertions

| File | Line | Change |
|------|------|--------|
| `guitar-neck.service.spec.ts` | 43 | `+ 1` → `numberOfFrets` |
| `freatboard.component.spec.ts` | 49 | Auto-updates (24 × 6 = 144) |
| `freatboard.component.spec.ts` | 60 | `toBe('')` → `toBe('1')` |
| `freatboard.component.spec.ts` | 61 | `frets.length - 1` → `frets.length` (24) |

## Verification

- Open string → nut label, no empty column
- First column header → "1"
- Last column header → "24"
- Em chord: open E, B, E visible on nut; A(II)=B, D(II)=E on fret 2
- All notes on frets 1-24 render correctly
- 53/53 tests
