# Phase 2 — Repo Agent Instructions

## Task 6: Remove `custom_metal_riff` from all repositories

### Scope
- Repository: `guitar-neck-shared` (shared models package)
- File: `src/models/scaleTypes.ts` (or equivalent path containing scale pattern definitions)

### Current state
The entry is already **commented out** in the file. The agent needs to **remove it entirely** — delete the commented-out block — and ensure no other references to `custom_metal_riff` exist anywhere in that repository.

### Exact change needed
1. Open `src/models/scaleTypes.ts` (or wherever `SCALE_PATTERNS` / scale type definitions live)
2. Locate the `custom_metal_riff` entry — currently commented out around lines 123-126
3. Delete the commented-out block entirely
4. Search the entire repo for any remaining references to `custom_metal_riff` (comments, docs, tests)
5. Remove any found traces

### Files that may also need attention
- `src/models/scaleTypes.ts` (primary)
- Any test files that reference `custom_metal_riff`
- Any documentation `.md` files that list scale types

### Validation
- `npm run build` (or equivalent) — must pass
- `grep -ri "custom_metal_riff" .` — must return zero results

---

## Task 8: Sort scales and chords alphabetically in Toolbox selects

### Scope
- Repository: `guitar-toolbox` (the guitar-toolbox-lib library project)
- File: `projects/guitar-toolbox-lib/src/lib/toolbox-form/toolbox-form.component.ts`

### Current code (around lines 31-33)
The component maps `SCALE_PATTERNS` and `CHORD_PATTERNS` (or `TRIAD_PATTERNS`) into arrays of display names for `<select>` options. Currently these lists appear in the order defined in the constants — they need to be sorted alphabetically.

### Exact change needed
1. Open `projects/guitar-toolbox-lib/src/lib/toolbox-form/toolbox-form.component.ts`
2. Find where the select option arrays are built from pattern constants (around lines 31-33)
3. Append `.sort()` to each array after the `.map()` call
4. Example (adjust to match actual variable names):
   ```typescript
   // Before:
   this.scaleNames = SCALE_PATTERNS.map(p => p.name);
   this.chordNames = CHORD_PATTERNS.map(p => p.name);

   // After:
   this.scaleNames = SCALE_PATTERNS.map(p => p.name).sort();
   this.chordNames = CHORD_PATTERNS.map(p => p.name).sort();
   ```

### Files that may also need attention
- `projects/guitar-toolbox-lib/src/lib/toolbox-form/toolbox-form.component.ts` (primary)

### Validation
- `npm run build` for the library project — must pass
- Visual: both `<select>` dropdowns should display options in alphabetical order

---

## Git workflow for  tasks
1. Create branch: `fix/<short-description>` (e.g. `fix/remove-metal-riff`, `fix/sort-selects`)
2. Commit with descriptive message
3. Open PR or ask for merge approval before merging to `master`
4. Squash-merge preferred
