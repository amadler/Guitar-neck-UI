# Analiza odpowiedzi na brief — zmiana podejścia do planowania produktu

> Odpowiedzi na 5 pytań z [`plans/Business aproach brief.md`](plans/Business%20aproatach%20brief.md) na podstawie analizy kodu źródłowego (commit baseline).

---

## Pytanie 1: Czy obecna architektura jest gotowa na scenariusze operujące na relacjach pomiędzy bytami?

**Krótka odpowiedź: NIE — ale przygotowanie jest możliwe przy niskim koszcie.**

### Dowody z kodu

Obecny model komend w [`UICommands.ts`](src/app/shared/UICommands.ts) i [`FretboardOrchestrationService`](src/app/services/music-theory-facade.service.ts) jest **entity-centric**:

| Komenda | Operuje na | Wynik |
|---------|-----------|-------|
| `DisplayScaleCommand` | 1 byt (skala) | Nadpisuje stan gryfu |
| `DisplayChordCommand` | 1 byt (akord) | Nadpisuje stan gryfu |
| `DisplaySingleNoteCommand` | 1 byt (nuta) | Nadpisuje |
| `DisplayAllNotesCommand` | wszystkie nuty | Nadpisuje |
| `DisplayCustomPatternCommand` | 1 pattern | Nadpisuje |

Każda komenda woła [`FretboardStateService.applyHighlightedNotes()`](src/app/services/guitar-neck.service.ts:47), która **zeruje** `visible` i `selected` dla wszystkich nut, a następnie ustawia tylko dla nowego zestawu. Nie ma mechanizmu **kumulowania** warstw.

### Co jest potrzebne

Scenariusz *"które dźwięki akordu należą do skali"* wymaga:

1. Wyświetlenia skali (tła)
2. Nałożenia akordu (na wierzch)
3. Wizualnego rozróżnienia: *chord tone in scale* vs *chord tone outside scale*
4. Zachowania interwałów OSOBNO dla skali i OSOBNO dla akordu

Obecny `GuitarNote.interval` (pojedynczy string) nie może przechowywać dwóch etykiet jednocześnie (np. `"root of chord"` i `"perfect-5th of scale"`).

### Zalecenie

Wprowadzić abstrakcję **`MusicSelection`** (już zdefiniowaną w [`BACKLOG.md:124`](BACKLOG.md:124) jako OPEN) jako warunek wstępny. To pozwoli zastąpić 5 osobnych komend jedną `ApplySelectionCommand`, która będzie mogła operować na **wielu selekcjach jednocześnie** (primary + overlay).

---

## Pytanie 2: Czy obecny model gryfu pozwala jednocześnie wyświetlić wszystkie wymagane elementy?

**Krótka odpowiedź: NIE — model `GuitarNote` ma zbyt mało wymiarów.**

### Obecny model [`GuitarNote`](src/app/shared/model/guitarNote.ts)

```typescript
class GuitarNote {
  id?: string;
  string: number;
  fret: number;
  note: string;
  visible: boolean;        // 1 bit
  selected: boolean;       // 1 bit
  interval: string;        // 1 wartość
}
```

### Mapa wymaganych stanów wizualnych

| Element wizualny | Obecne mapowanie | Problem |
|-----------------|-----------------|---------|
| Nuta skali | `visible=true` | OK |
| Nuta akordu | `selected=true` | W konflikcie z `selected` innych nut |
| Dźwięk akordu w skali | `interval="major-3rd"` | OK tylko dla 1 roli |
| Pryma akordu | `interval="root"` | Gubi się jeśli nuta ma też interwał skali |
| Dźwięk spoza skali | brak | Nie istnieje w modelu |
| Dźwięk akordu poza skalą | brak | Nie istnieje w modelu |

### Przykład konkretnego problemu

Dla: C major scale + Cmaj7 chord (C E G B)

| Nuta | W skali? | W akordzie? | Obecnie | Potrzebne |
|------|---------|------------|---------|-----------|
| C | tak (tonic) | tak (root) | `interval="root"` | role: `{scale-tone, chord-tone, root-of-scale, root-of-chord}` |
| E | tak (major-3rd) | tak (major-3rd) | `interval="major-3rd"` | role: `{scale-tone, chord-tone}` |
| G | tak (perfect-5th) | tak (perfect-5th) | `interval="perfect-5th"` | role: `{scale-tone, chord-tone}` |
| B | tak (major-7th) | tak (major-7th) | `interval="major-7th"` | role: `{scale-tone, chord-tone}` |
| D | tak (major-2nd) | nie | `interval="major-2nd"` | role: `{scale-tone}` |
| F | tak (perfect-4th) | nie | `interval="perfect-4th"` | role: `{scale-tone}` |
| A | tak (major-6th) | nie | `interval="major-6th"` | role: `{scale-tone}` |

Obecnie każda nuta ma JEDEN interwał — ale w tym scenariuszu interwał skali i interwał akordu to różne rzeczy. Nuta C jest zarówno *tonic of scale* jak i *root of chord* — w modelu nie ma miejsca na drugi interwał.

### Zalecenie

Wprowadzić **`roles: Set<MarkerRole>`** zamiast pojedynczego `interval: string`. Interwał pozostaje jako obliczona pochodna (dla CSS), ale role umożliwiają zapytania typu *"czy ta nuta jest jednocześnie tone skali i tone akordu?"*.

---

## Pytanie 3: Czy potrzebujemy warstw (layers) / ról markerów?

**Krótka odpowiedź: TAK — to kluczowa zmiana enablingowa.**

### Uzasadnienie

Obecnie:
- `visible` = "czy ta nuta jest w ogóle pokazana"
- `selected` = "czy ta nuta jest częścią wybranego wzorca"
- `interval` = "jaki interwał ma ta nuta względem root"

To jest model **1-wymiarowy**: każda nuta należy do co najwyżej jednego "zbioru" naraz.

Scenariusze relacyjne potrzebują modelu **N-wymiarowego**:

```
GuitarNote {
  ...
  roles: Set<MarkerRole>
}

MarkerRole = 'scale-tone'
           | 'chord-tone'
           | 'root-of-scale'
           | 'root-of-chord'
           | 'highlighted'
           | 'outside-scale'
           | 'selected'
```

CSS mógłby wtedy wyglądać tak:

```scss
// Nuta należąca do skali — podstawowe tło
.guitar-neck__scale-tone { background: var(--interval-scale-default); }

// Nuta będąca również dźwiękiem akordu — dodatkowe obramowanie
.guitar-neck__scale-tone.guitar-neck__chord-tone {
  outline: 2px solid var(--interval-root);
}

// Dźwięk akordu spoza skali — ostrzeżenie
.guitar-neck__chord-tone.guitar-neck__outside-scale {
  background: var(--interval-outside);
  outline: 2px dashed var(--warning-color);
}
```

### Znalezione zależności

| Plik | Co się zmieni |
|------|--------------|
| [`GuitarNote`](src/app/shared/model/guitarNote.ts) | Dodać `roles: MarkerRole[]` zamiast `interval: string` |
| [`IntervalService`](src/app/services/interval.service.ts) | `markIntervals()` → `assignRoles()` ustawiająca role zamiast stringa |
| [`FretboardStateService`](src/app/services/guitar-neck.service.ts) | `applyHighlightedNotes()` → `applyRoles()` kumulująca role, nie zerująca |
| [`FreatboardComponent`](src/app/freatboard/freatboard.component.ts) | Template potrzebuje nowej logiki CSS — `ngClass` oparty na `roles` |
| [`LegendComponent`](src/app/legend/legend.component.html) | Legenda wymaga rozszerzenia o nowe role |
| [`styles.scss`](src/styles.scss) | Nowe zmienne CSS dla: `--interval-outside`, `--interval-chord-tone`, itp. |

### Czy można to zrobić ewolucyjnie?

TAK — pod warunkiem że:
1. `GuitarNote.interval` zostaje jako **getter** zwracający pierwszą/dominującą rolę (kompatybilność wsteczna)
2. Nowe `roles` to osobne pole — stare testy nie psują się
3. `applyHighlightedNotes()` może być stopniowo wypierana przez `applyRoles()`

---

## Pytanie 4: Czy ten kierunek jest zgodny z obecną architekturą?

**Krótka odpowiedź: TAK — kierunek jest zgodny, ale wymaga 3 konkretnych zmian przed implementacją pierwszego scenariusza.**

### Zgodność

| Wzorzec/cecha architektury | Czy nowy kierunek łamie? |
|---------------------------|------------------------|
| **Command Pattern** | NIE — wystarczy jedna `ApplySelectionCommand` zamiast 5; Open-Closed Principle zostaje zachowany |
| **Facade Pattern** | NIE — `FretboardOrchestrationService` zyskuje metodę `applyRelations()` obok istniejących |
| **Service Pattern (SRP)** | NIE — każdy serwis nadal ma jedną odpowiedzialność |
| **Reactive (Observable)** | NIE — pipeline `API → position → state → interval` pozostaje |
| **Standalone Angular 18** | NIE — bez zmian |

### Wymagane zmiany (w kolejności)

#### Zmiana 1: [`GuitarNote`](src/app/shared/model/guitarNote.ts) — dodać role

Dodać pole `roles: Set<string>` (lub enum). `interval` zostaje jako getter dla kompatybilności.

**Koszt:** mały — 1 plik, ~10 linii.
**Ryzyko regresji:** niskie — stare testy używają `interval`, getter zapewnia kompatybilność.

#### Zmiana 2: [`FretboardStateService`](src/app/services/guitar-neck.service.ts) — nowa metoda `applyRoles()`

- Nie zeruje `roles` wszystkich nut (kumulacja)
- Przyjmuje selekcję + jej typ ("primary", "overlay")
- Oznacza nuty odpowiednimi rolami

**Koszt:** średni — nowa metoda, stare `applyHighlightedNotes()` pozostaje.
**Ryzyko regresji:** niskie — stara metoda niezmieniona.

#### Zmiana 3: [`FretboardOrchestrationService`](src/app/services/music-theory-facade.service.ts) — nowa metoda `displayScaleWithChordOverlay()`

Pipeline:
```
1. resolveScaleNotes() → findPositionsByScaleNotes() → applyRoles(scale, 'primary')
2. resolveChordNotes() → findPositionsByChordNotes() → applyRoles(chord, 'overlay')
3. markIntervalsForSelection(root) → CSS gotowe
```

**Koszt:** średni — nowa metoda, stare metody niezmienione.
**Ryzyko regresji:** niskie — dodanie, nie zmiana.

#### Zmiana 4: [`FreatboardComponent`](src/app/freatboard/freatboard.component.html) — template CSS

- Obecnie `ngClass` opiera się na `getNoteInterval()` → zwraca jeden string
- Nowy: `ngClass` opiera się na `getNoteRoles()` → zwraca tablicę klas

**Koszt:** średni — zmiana template'u i dodanie helpera.
**Ryzyko regresji:** średnie — trzeba uważać na istniejące klasy CSS.

### Kolejność zmian (topologicznie)

```
1. GuitarNote (model)
    ↓
2. IntervalService (assignRoles zamiast markIntervals)
    ↓
3. FretboardStateService (applyRoles)
    ↓
4. FretboardOrchestrationService (displayScaleWithChordOverlay)
    ↓
5. FreatboardComponent (template CSS)
    ↓
6. LegendComponent (rozszerzenie legendy)
    ↓
7. styles.scss (nowe zmienne CSS)
```

Każdy krok jest **backward-compatible** — można go wdrożyć osobno i testować.

---

## Pytanie 5: Inne scenariusze o wysokim stosunku wartości do kosztu?

### Scenariusz A: "Pokaż mi skalę i zaznacz w niej dźwięki akordu" ★ REFERENCYJNY

**Koszt:** średni (jak opisano wyżej)
**Wartość:** wysoka — uczy relacji skala ↔ akord
**Zależności:** MusicSelection + roles

### Scenariusz B: "Pokaż mi, które dźwięki akordu SĄ w skali, a które NIE"

**Koszt:** niski (wariant scenariusza A — tylko dodatkowy CSS dla `outside-scale`)
**Wartość:** bardzo wysoka — kluczowa wiedza dla improwizacji
**Zależności:** Scenariusz A + klasa CSS `outside-scale`

### Scenariusz C: "Pokaż mi wszystkie pozycje prymy akordu na gryfie"

**Koszt:** niski
- `findPositionsByNoteName(root)` już istnieje w [`FretboardNotePositionService`](src/app/services/note.service.ts:47)
- Wystarczy wywołać dla roota akordu po wyświetleniu akordu
- Dodać rolę `all-roots` z osobnym kolorem

**Wartość:** średnia — pomaga zrozumieć, gdzie na gryfie jest ten sam dźwięk

### Scenariusz D: "Pokaż mi skalę i zaznacz dźwięki, które NIE należą do skali (outside)"

**Koszt:** niski
- Znaleźć dopełnienie zbioru nut skali względem wszystkich 12 nut
- Oznaczyć jako `outside-scale`
- CSS: przyciemnione/wyblakłe kropki

**Wartość:** wysoka — pomaga zrozumieć, czego NIE grać

### Scenariusz E: "Porównaj dwie skale na jednym gryfie"

**Koszt:** średni/wysoki
- Wymaga dwóch niezależnych warstw overlay
- Możliwe konflikty wizualne
- **WARTO ROZWAŻYĆ PÓŹNIEJ** — po udowodnieniu koncepcji na scenariuszu A

### Scenariusz F: "Pokaż mi interwał pomiędzy dwiema klikniętymi nutami"

**Koszt:** niski
- `fretNoteClicked()` już istnieje w [`FreatboardComponent`](src/app/freatboard/freatboard.component.ts:77)
- Wystarczy dodać: kliknięcie #1 → zapamiętaj nutę, kliknięcie #2 → oblicz interwał
- Wykorzystać istniejący `IntervalService.getIntervalName()`
- Wyświetlić w legendzie lub tooltipie

**Wartość:** wysoka — podstawowe narzędzie edukacyjne, brak AI/API

### Ranking (stosunek wartość/koszt)

| # | Scenariusz | Koszt | Wartość edukacyjna | Priorytet |
|---|-----------|-------|-------------------|-----------|
| 1 | **A** — dźwięki akordu w skali | średni | ★★★★★ | **1. (referencyjny)** |
| 2 | **B** — dźwięki akordu poza skalą | niski (dodatek do A) | ★★★★★ | **2. (po A)** |
| 3 | **F** — interwał między nutami | niski | ★★★★ | **3. (niski wiszący owoc)** |
| 4 | **D** — outside scale | niski | ★★★★ | **4. (po A+B)** |
| 5 | **C** — wszystkie pozycje root | niski | ★★★ | 5. |
| 6 | **E** — porównanie skal | średni/wysoki | ★★★ | 6. (future) |

---

## Podsumowanie dla zespołu

### Czego NIE trzeba robić

- ❌ Dużego refactora — wszystkie zmiany są lokalne i backward-compatible
- ❌ Przebudowy renderowania — template wymaga tylko zmiany `ngClass`
- ❌ AI ani Practice Mode — scenariusz referencyjny ich nie wymaga
- ❌ Zmian w backendzie API — wszystkie obliczenia są już po stronie frontendu

### Co TRZEBA zrobić (kolejność)

1. **Model `GuitarNote`** — dodać `roles: Set<MarkerRole>`, `interval` jako getter
2. **`MusicSelection` abstraction** — zrealizować backlog item [`BACKLOG.md:124`](BACKLOG.md:124)
3. **`IntervalService`** — dodać `assignRoles()` obok istniejącego `markIntervals()`
4. **`FretboardStateService`** — dodać `applyRoles()` (kumulacja, nie zerowanie)
5. **`FretboardOrchestrationService`** — dodać `displayScaleWithChordOverlay()`
6. **`FreatboardComponent` template** — nowa logika CSS oparta na `roles`
7. **`LegendComponent` + `styles.scss`** — rozszerzenie o nowe role wizualne
8. **Scenariusz referencyjny** — integracja toolbox → gryf

### Mermaid: proponowany przepływ danych dla scenariusza referencyjnego

```mermaid
flowchart TD
    User[User] --> Toolbox[ToolboxFormComponent]
    Toolbox -->|scale + chord params| HP[HomePageComponent]
    HP --> AS[ApplySelectionCommand]
    AS --> O[FretboardOrchestrationService]

    subgraph Orchestration[displayScaleWithChordOverlay]
        O -->|1| API1[MusicPatternApiService.resolveScaleNotes]
        O -->|2| Pos1[FretboardNotePositionService.findPositionsByScaleNotes]
        O -->|3| State1[FretboardStateService.applyRoles scale as primary]

        O -->|4| API2[MusicPatternApiService.resolveChordNotes]
        O -->|5| Pos2[FretboardNotePositionService.findPositionsByChordNotes]
        O -->|6| State2[FretboardStateService.applyRoles chord as overlay]

        O -->|7| Intervals[IntervalService.assignRoles root + intervals]
    end

    State2 --> Notes[GuitarNote[] with roles]
    Notes --> FB[FreatboardComponent]
    FB -->|ngClass on roles| Render[Visual output: scale bg + chord highlight + root marker]
```

---

*Koniec analizy. Odpowiedzi na wszystkie 5 pytań zawarte powyżej.*
