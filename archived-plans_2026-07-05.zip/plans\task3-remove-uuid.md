# Task 3: Remove unused uuid from GuitarNote

## Motivation

The `GuitarNote` model has no `id` or `uuid` field in the current codebase, but historical references mention an `id` field. Any residual references in documentation should be cleaned up.

## Investigation Results

### ✅ Already Clean — No Code Changes Needed
| Check | Result |
|-------|--------|
| `uuid` in `src/app/*.ts` | 0 results |
| `uuid` in `src/app/*.html` | 0 results |
| `uuid` in `src/app/*.spec.ts` | 0 results |
| `uuid` in `projects/guitar-chat/*.ts` | 0 results |
| `GuitarNote.id` or `.uuid` in model | No such field |
| `note.id` / `note.uuid` in src/app | 0 results |

### ❌ Outdated Documentation (3 files need fixes)
- `API_DOCUMENTATION.md` — class diagram shows `id?: string`
- `TODO_DEPLOY.md` — lists as OPEN
- `CHANGELOG.md` — lists in Backlog as open task
- `BACKLOG.md` — status says OPEN

## Steps

1. Remove `id` field from `API_DOCUMENTATION.md` GuitarNote class diagram
2. Move entry from OPEN to FIXED in `TODO_DEPLOY.md`
3. Remove from `CHANGELOG.md` Backlog list
4. Update `BACKLOG.md` status to `FIXED`
5. Run `npm test` and `npm run build` for validation

## Status

FIXED — 2026-07-05
