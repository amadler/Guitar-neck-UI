# Plan: Toolbox Markup Replacement (guitar-toolbox-lib)

## 1. Aktualna sytuacja

### Co mamy?

| Element | Lokalizacja | Uwagi |
|---------|-------------|-------|
| [`guitar-toolbox-lib`](node_modules/guitar-toolbox-lib/package.json:1) | `node_modules/` jako npm dependency `^1.0.2` | **To nie jest lokalny projekt biblioteki** — to zewnętrzny pakiet |
| `ToolboxFormComponent` | Wewnątrz liba, selector: `lib-toolbox-form` | Template + style **inline**, skompilowane do JS |
| `CustomPatternComponent` | Wewnątrz liba, selector: `app-custom-pattern` | Template + style **inline**, skompilowane do JS |
| Style toolboxa | [`src/styles.scss:542-641`](src/styles.scss:542) | Klasy: `.toolbox-panel`, `.toolbox-form`, `.toolbox-form__field`, `.toolbox-form__submit`, `.active-summary`, `.quick-chip`, etc. |
| Użycie w host app | [`src/app/home-page/home-page.component.html:44`](src/app/home-page/home-page.component.html:44) | `<lib-toolbox-form>` wrapper w docku |

### Kluczowy problem: Mismatch klas CSS

Biblioteka renderuje markup z **własnymi klasami**, a host app ma style z **innymi klasami**:

| Klasy w bibliotece (template) | Klasy w `styles.scss` (host) | Efekt |
|---|---|---|
| `.section-title`, `.mode-selector` | `.toolbox-panel`, `.toolbox-tabs` | ❌ Brak dopasowania |
| `.form-row`, `.form-select` | `.toolbox-form`, `.toolbox-form__field` | ❌ Brak dopasowania |
| `.form-input` | `.toolbox-form__submit` | ❌ Brak dopasowania |

**Wniosek**: Style w [`styles.scss:542-641`](src/styles.scss:542) **nie są aktualnie aplikowane** do toolboxa, bo nazwy klas nie pasują. Biblioteka działa na swoich inline stylach.

## 2. Diagram przepływu danych

```mermaid
flowchart TD
    A["Host App<br>home-page.component.html"] -->|używa| B["lib-toolbox-form<br>ToolboxFormComponent"]
    B -->|emituje| C["onSubmit$ Event"]
    C -->|toolboxSubmit| D["FretboardStateService"]
    B ---|zawiera| E["app-custom-pattern<br>CustomPatternComponent"]

    subgraph "guitar-toolbox-lib (npm package)"
        B
        E
    end

    subgraph "Host App styles.scss"
        F[".toolbox-form"]
        G[".toolbox-form__field"]
        H[".toolbox-form__submit"]
        I[".toolbox-panel"]
        J[".active-summary"]
        K[".quick-chip"]
    end

    style F stroke:red,stroke-dasharray: 5 5
    style G stroke:red,stroke-dasharray: 5 5
    style H stroke:red,stroke-dasharray: 5 5
    style I stroke:red,stroke-dasharray: 5 5
    style J stroke:red,stroke-dasharray: 5 5
    style K stroke:red,stroke-dasharray: 5 5

    linkStyle 4,5,6,7,8,9 stroke:red,color:red
```

## 3. Opcje podejścia

### Opcja A: Lokalne "przejście na własne" — skopiowanie biblioteki do workspace'a

**Kroki:**
1. Skopiować źródła `guitar-toolbox-lib` do `projects/guitar-toolbox-lib/` (wzorem `guitar-chat`)
2. Zmienić `package.json` dependency z `^1.0.2` na path reference
3. Przerobić template komponentów na nowy markup z klasami z `styles.scss`
4. Usunąć inline style z komponentów
5. Zbudować lokalną bibliotekę (`ng build guitar-toolbox-lib`)

**Zalety:**
- Pełna kontrola nad markupem i stylami
- Można użyć klas CSS z `styles.scss` bezpośrednio
- Można dzielić style między libem a hostem

**Wady/Zagrożenia:**
- **Duży scope zmian** — trzeba utrzymywać forka
- Trzeba pilnować wersjonowania i aktualizacji z upstreama
- Ryzyko rozjazdu z oryginalnym libem
- Build pipeline się komplikuje

---

### Opcja B: CSS override przez host app — targetowanie klas biblioteki

**Kroki:**
1. Dodać w [`styles.scss`](src/styles.scss:542) style targetujące faktyczne klasy renderowane przez lib
2. Nadpisać inline style biblioteki przez `::ng-deep` lub wyższy specificity

```scss
// styles.scss
lib-toolbox-form {
  .section-title { /* nowy styling */ }
  .form-row { /* nowy styling */ }
  .form-select { /* nowy styling */ }
  button[type="submit"] { /* nowy styling */ }
}
```

**Zalety:**
- Szybkie do wdrożenia
- Zero zmian w bibliotece
- Łatwy rollback

**Wady/Zagrożenia:**
- **Brudne rozwiazanie** — walczymy z enkapsulacją
- `::ng-deep` jest deprecated i może nie działać z `ViewEncapsulation.Emulated`
- Nadal ograniczeni strukturą markupu biblioteki
- Inline style biblioteki mają wyższy specificity i mogą być trudne do nadpisania

---

### Opcja C: Wrapper component + nowy markup (rekomendowana)

**Kroki:**
1. Stworzyć nowy komponent lokalny `ToolboxWrapperComponent` w `src/app/toolbox/`
2. Skopiować logikę z `ToolboxFormComponent` (FormBuilder, `guitarForm`, `onSubmit$`)
3. Użyć nowego markupu z klasami z [`styles.scss`](src/styles.scss:542) (`.toolbox-form`, `.toolbox-form__field`, `.toolbox-form__submit`)
4. Zastąpić `<lib-toolbox-form>` w [`home-page.component.html`](src/app/home-page/home-page.component.html:44) nowym wrapperem
5. Przenieść inline style z biblioteki do [`styles.scss`](src/styles.scss) (zostawić tam na razie)

```mermaid
flowchart LR
    subgraph "Przed"
        A1["home-page"] -->|używa| A2["lib-toolbox-form<br>obcy markup"]
        A2 -->|inline style| A3["stary wygląd"]
        A4["styles.scss"] -->|style nie pasują| A2
    end

    subgraph "Po"
        B1["home-page"] -->|używa| B2["app-toolbox-wrapper<br>nowy markup"]
        B2 -->|deleguje logikę| B3["guitar-toolbox-lib?<br>lub inline"]
        B4["styles.scss"] -->|.toolbox-form itd.| B2
    end
```

**Zalety:**
- Pełna kontrola nad markupem
- Można użyć klas CSS z `styles.scss` — style od razu działają
- Nie trzeba forkowac biblioteki
- Łatwy rollback (wystarczy wrócić do `<lib-toolbox-form>`)
- Można stopniowo przepisywać komponenty

**Wady/Zagrożenia:**
- Duplikacja logiki (FormBuilder, walidacja) — ale to tylko ~30 linii
- Trzeba utrzymywać zgodność z API biblioteki (`ToolboxSearchQuery`, `onSubmit$`)
- Jeśli biblioteka doda nowe funkcje, trzeba je ręcznie dodać do wrappera

---

### Opcja D: Angular Template Override (hack)

**Kroki:**
1. Użyć `@Component` decorator override lub `provideComponentTemplate` (jeśli Angular 18 wspiera)
2. Ewentualnie użyć InjectionToken + factory do podmiany template'u

**Zalety:**
- Minimalna ilość kodu
- Zachowanie logiki biblioteki w 100%

**Wady/Zagrożenia:**
- **Nie wspierane oficjalnie** przez Angular
- Może przestać działać po aktualizacji Angulara
- Bardzo trudny debugging
- Ryzyko błędów runtime

---

## 4. Rekomendacja: Opcja C — Wrapper Component

### Uzasadnienie:
- Najbezpieczniejsze podejście — nie modyfikujemy biblioteki
- Style z [`styles.scss`](src/styles.scss) od razu działają (wystarczy dodać odpowiednie klasy do markupu wrappea)
- Host app ma pełną kontrolę nad strukturą DOM
- Możemy zrobić to iteracyjnie: najpierw wrapper dla `ToolboxFormComponent`, potem ewentualnie dla `CustomPatternComponent`

### Plan implementacji:

1. **Stworzyć** [`src/app/toolbox/toolbox-wrapper.component.ts`](src/app/toolbox/toolbox-wrapper.component.ts) — nowy standalone component
2. **Skopiować logikę** z `ToolboxFormComponent`:
   - `FormBuilder` + `guitarForm` z `elementType`, `pattern`, `key`
   - `onSubmit$` EventEmitter
   - `keys`, `elementTypes`, `patterns`, `availablePatterns`
   - `onSubmit()` i `onCustomPatternSubmit(query)`
3. **Nowy markup** z klasami z [`styles.scss:542-641`](src/styles.scss):
   - `.toolbox-tabs` dla przełącznika Standard/Custom
   - `.toolbox-form` dla grid formularza
   - `.toolbox-form__field` dla pól
   - `.toolbox-form__submit` dla przycisku
   - `.active-summary` dla podsumowania aktywnego wyboru
   - `.quick-chip` dla szybkich przykładów
4. **Zintegrować `CustomPatternComponent`** jako wewnętrzny sub-component
5. **Wymienić** `<lib-toolbox-form>` w [`home-page.component.html:44`](src/app/home-page/home-page.component.html:44) na `<app-toolbox-wrapper>`

### Pytania dla Ciebie przed rozpoczęciem:

1. Czy wolisz **Opcję C** (wrapper), czy rozważasz inne podejście?
2. Czy `CustomPatternComponent` też ma być przepisany lokalnie, czy na razie zostaje jako sub-komponent z biblioteki (używany we wrapperze)?
3. Czy chcesz zachować pełną funkcjonalność trybu "Standard Patterns" i "Custom Pattern" w nowym wrapperze?
4. Czy aktualne style w `styles.scss` to już docelowy wygląd, czy to dalej POC który będzie ewoluował?
5. Czy `guitar-toolbox-lib` jest rozwijany przez Ciebie (masz do niego source), czy to zewnętrzny package bez dostępu do źródła?

---

## 5. Zagrożenia (Risk Assessment)

| Ryzyko | Prawdopodobieństwo | Wpływ | Mitigacja |
|--------|-------------------|-------|-----------|
| Rozjazd z upstream library przy Opcji C | Niskie | Średni | Regularnie sprawdzać zmiany w API liba |
| Duplikacja kodu (wrapper vs lib) | Wysokie (przy Opcji C) | Niski | Tylko ~30 linii logiki; łatwe do utrzymania |
| Inline style biblioteki kolidują z hostem | Średnie (przy Opcji B) | Wysoki | Unikać Opcji B; przy Opcji C wrapper nie ma inline styli |
| `::ng-deep` przestanie działać | Średnie | Wysoki | Nie polegać na `::ng-deep` |
| Utrata aktualizacji z npm | Wysokie (przy Opcji A) | Średni | Opcja C nie forknije — dalej używa liba |
| CSS specificity war | Średnie | Średni | Używać BEM i świadomie zarządzać specyficity |
