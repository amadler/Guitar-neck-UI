# Analiza architektoniczna — MusicSelection i AI integration

**Źródło:** Brief architektoniczny z dn. 2026-06-28
**Kont tekst:** 1 deweloper, Angular, ~50 testów, brak NgRx

## Pytanie 1: Czy MusicSelection jest przedwczesne?

**Tak.** `ToolboxSearchQuery` w `musicElements.ts` jest już w 90% modelem "tego, co użytkownik wybrał":

```typescript
interface ToolboxSearchQuery {
  musicElements: string | number[];
  keys: string;
  type: 'scale' | 'chord' | 'basic' | 'custom';
}
```

Wprowadzenie nowego interfejsu to przemianowanie, a nie dodanie wartości.

**Próg opłacalności:** pojawienie się drugiego klienta (AI, MCP) produkującego `ToolboxSearchQuery`. Wtedy refactor rozwiązuje realny problem duplikacji.

## Pytanie 2: Czy lista akcji z AI to dobry kontrakt?

**Tak.** Istniejący `home-page.toolboxSubmit()` już akceptuje `ToolboxSearchQuery`. AI zwracające `{ type: 'showScale', params: { musicElements: 'major', keys: 'C' } }` pasuje do tego samego kontraktu. `AIFacadeService` tłumaczy odpowiedź AI na `ToolboxSearchQuery` i wywołuje `toolboxSubmit()`.

**Zero zmian w istniejącym kodzie.** AI = kolejne źródło eventu.

## Pytanie 3: Jakie minimalne API zaprojektować już teraz?

**Żadnego.** Obecny kod ma już wszystko:

```
ToolboxSearchQuery → toolboxSubmit() → Command → Facade → Serwisy
```

## Zalecana kolejność

1. ~~Naprawić backend (Unicode w :name)~~ ✅ ZROBIONE
2. Zintegrować AI przez istniejący `toolboxSubmit()` — 0 kosztu
3. Dodać MusicSelection DOPIERO gdy pojawi się trzeci klient

## Zasada architektoniczna

AI orkiestruje. Domena decyduje. UI renderuje.

## Uwaga na przyszłość — nazewnictwo

`ToolboxSearchQuery` jest dziś dobrą nazwą, bo jedynym klientem jest toolbox.
Jeśli pojawią się inni klienci (AI, MCP, mobile, import pliku), nazwa może zacząć ograniczać.
Wtedy refactor: `ToolboxSearchQuery` → `MusicSelection` (lub `NeckSelection`).
Nie zmieniać przed pojawieniem się drugiego klienta.
