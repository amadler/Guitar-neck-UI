# Plan: Improve Guitar Neck Note Readability

## Current CSS Architecture

### Rendering Elements

| Element | CSS Class | Current Style | File:Line |
|---------|-----------|--------------|-----------|
| Note dot (default) | `.guitar-neck__dot` | 20px circle, 12px bold white text, absolute centered | [`freatboard.component.scss:109-127`](../src/app/freatboard/freatboard.component.scss:109) |
| Note dot (selected) | `.guitar-neck__selected` | Same as dot but `background: rgb(32, 1, 27)` (dark) | [`freatboard.component.scss:128-130`](../src/app/freatboard/freatboard.component.scss:128) |
| Interval dots (root..7th) | `.guitar-neck__root`, `.guitar-neck__minor-3rd`, etc. | Each sets `background-color` to a CSS variable | [`freatboard.component.scss:132-178`](../src/app/freatboard/freatboard.component.scss:132) |
| Fret cell | `.guitar-neck__fret` | 22px height, flex-grow, `border-right: 1px solid #ddd` | [`freatboard.component.scss:70-79`](../src/app/freatboard/freatboard.component.scss:70) |
| String row | `.guitar-neck__string` | `outline: 1px solid #ddd`, `outline-offset: -12px` | [`freatboard.component.scss:45-53`](../src/app/freatboard/freatboard.component.scss:45) |
| Fretboard BG | `.guitar-neck__fretboard` | `background: #333` (dark) | [`freatboard.component.scss:35-43`](../src/app/freatboard/freatboard.component.scss:35) |
| Fret markers (dots) | `.guitar-neck__marker` | 20px white circle, absolute | [`freatboard.component.scss:81-89`](../src/app/freatboard/freatboard.component.scss:81) |

### CSS Variables (from `styles.scss`)

```css
--guitar-neck-bg-color: #333;           // dark fretboard
--guitar-neck-fret-color: #ddd;         // light fret lines
--guitar-neck-string-color: #ddd;        // light string lines
--guitar-neck-dot-color: #fff;           // fret marker dots
--guitar-neck-dot-size: 20px;            // note dot size
--guitar-neck-dot-border-radius: 50%;    // circle shape
--guitar-neck-marker-bg-color: rgb(168, 110, 110);  // default note bg
--guitar-neck-marker--color: rgb(255, 255, 255);    // note text color
```

### Template Rendering Logic

There are 3 conditional containers per fret cell, rendered in order:

1. **Default dot** — when `note exists && NOT selected && in range` → `<button class="guitar-neck__dot">`
2. **Selected div** — when `note exists && selected && in range` → `<div class="guitar-neck__selected">`
3. **Interval div** — when `note exists && has interval && in range` → `<div class="guitar-neck__dot guitar-neck__{interval}">`

Note: When a note has BOTH `selected=true` AND an interval, containers 2 AND 3 render — resulting in 2 overlapping absolutely-positioned divs. Container 3 (interval-colored) is on top because it appears later in the DOM.

## Identified Issues

1. **Note dots too small** — 20px circle is tight for 12px text, especially with 1-2 character note names
2. **No border** — dots blend into the dark fretboard; no visual boundary
3. **No shadows** — no depth to separate notes from fret lines and strings
4. **Root not visually distinct** — only color differentiator, same size/shape/border as other intervals
5. **Fret/string lines too prominent** — `#ddd` on `#333` bg creates high contrast that competes with notes
6. **Text contrast varies** — some interval colors (e.g., major-7th: `rgb(160,160,160)`) are light and white text may be hard to read
7. **Selected state (dark bg) overlaps interval rendering** — unnecessary double render

## Proposed CSS Changes

All changes are limited to:
- [`src/styles.scss`](../src/styles.scss) — CSS variables
- [`src/app/freatboard/freatboard.component.scss`](../src/app/freatboard/freatboard.component.scss) — component styles
- [`src/app/freatboard/freatboard.component.html`](../src/app/freatboard/freatboard.component.html) — only if template structural change is needed (minimal)

### 1. Increase Note Dot Size

**File:** [`src/styles.scss`](../src/styles.scss) — CSS variables

```diff
- --guitar-neck-dot-size: 20px;
+ --guitar-neck-dot-size: 26px;
```

**File:** [`src/app/freatboard/freatboard.component.scss`](../src/app/freatboard/freatboard.component.scss):

```diff
-  font-size: 12px;
+  font-size: 13px;
```

### 2. Add Border to All Note Dots

**File:** [`src/app/freatboard/freatboard.component.scss`](../src/app/freatboard/freatboard.component.scss) — `.guitar-neck__dot, .guitar-neck__selected` block:

```diff
+ border: 2px solid rgba(255, 255, 255, 0.85);
```

### 3. Add Box Shadow for Depth

```diff
+ box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4), inset 0 1px 2px rgba(255, 255, 255, 0.15);
```

### 4. Add Text Shadow for Readability

```diff
+ text-shadow: 0 1px 3px rgba(0, 0, 0, 0.7);
```

### 5. Make Root Note Visually Distinct

**File:** [`src/app/freatboard/freatboard.component.scss`](../src/app/freatboard/freatboard.component.scss):

```diff
  .guitar-neck__root {
    background-color: var(--interval-root);
+   border-color: #ffd700;       /* gold border */
+   border-width: 2.5px;
+   box-shadow: 0 0 8px rgba(255, 215, 0, 0.5), 0 2px 6px rgba(0, 0, 0, 0.4);
+   transform: translate(-50%, -50%) scale(1.1);  /* slightly larger */
+   font-weight: 900;             /* extra bold */
  }
```

### 6. Reduce Fret Line and String Line Contrast

**File:** [`src/styles.scss`](../src/styles.scss):

```diff
- --guitar-neck-fret-color: #ddd;
+ --guitar-neck-fret-color: rgba(255, 255, 255, 0.15);
- --guitar-neck-string-color: #ddd;
+ --guitar-neck-string-color: rgba(255, 255, 255, 0.2);
```

### 7. Improve Fret Marker Dots

```diff
- --guitar-neck-dot-color: #fff;
+ --guitar-neck-dot-color: rgba(255, 255, 255, 0.25);
```

### 8. Optional: Fix Template Double-Render for Selected+Interval

**File:** [`src/app/freatboard/freatboard.component.html`](../src/app/freatboard/freatboard.component.html):

Currently, when `selected=true` AND interval is set, both the `.guitar-neck__selected` div and the interval div render. The interval div wins (on top) but there's still an extra hidden div. We could simplify by only rendering the interval div when it has an interval:

```html
<!-- Replace container 2 (selected) with: -->
<ng-container *ngIf="isNoteOnFret(string, fret) && isNoteSelected(string, fret) && !getNoteInterval(string, fret) && isNoteInRange(fret)">
  <div class="guitar-neck__selected">{{ getNoteName(string, fret) }}</div>
</ng-container>
```

This ensures only ONE div renders per fret per note, eliminating overlap.

## Summary of Changes

| Location | Change | Impact |
|----------|--------|--------|
| `styles.scss` | `--guitar-neck-dot-size: 20px → 26px` | Bigger dots |
| `styles.scss` | `--guitar-neck-fret-color: #ddd → rgba(255,255,255,0.15)` | Subtler fret lines |
| `styles.scss` | `--guitar-neck-string-color: #ddd → rgba(255,255,255,0.2)` | Subtler string lines |
| `styles.scss` | `--guitar-neck-dot-color: #fff → rgba(255,255,255,0.25)` | Subtler fret markers |
| `freatboard.scss` | `.guitar-neck__dot` — add `border`, `box-shadow`, `text-shadow`, font-size ↑ | Readable dots |
| `freatboard.scss` | `.guitar-neck__root` — gold border, scale(1.1), glow shadow, font-weight 900 | Distinct root |
| `freatboard.html` | Add `!getNoteInterval` guard to selected container | Fix double-render |

## Test Cases (Manual)

After implementation, test these scenarios:

1. **C major scale** — check all 7 notes are readable, root C stands out
2. **A minor pentatonic** — check dense pattern on dark bg, no clutter
3. **C augmented scale** — check readability with close intervals
4. **G major chord** — check G (root), B (3rd), D (5th) are distinct
5. **A minor chord** — check A (root), C (m3), E (5th) readability
6. **B diminished chord** — check B (root), D (m3), F (d5) on fretboard
7. **G7 chord** — check all 4 notes with intervals

## Acceptance Criteria

- [ ] Note names readable without zooming (13px+ text, text-shadow)
- [ ] Root note immediately recognizable (gold border, slightly larger, glow)
- [ ] Dense scales remain readable (border + shadow separates overlapping dots)
- [ ] Fretboard not more chaotic (subdued fret/string lines)
- [ ] Changes limited to CSS + minor template fix (no music logic changes)
