# Prompt for Library Agent (`guitar-toolbox-lib`)

## Goal

Update `guitar-toolbox-lib` (separate workspace) to use new BEM markup with CSS Custom Properties API, removing hardcoded colors/styles in favor of themeable variables consumed from the host app.

## Key design decision: Library provides NO color values

Biblioteka definiuje **wyłącznie layout i geometrię** (grid, flex, gap, padding, min-width, height). Nie definiuje żadnych kolorów, fontów, backgroundów, border-radiusy ani shadowy — nawet jako fallbacki CSS variables.

**Dlaczego:**
- Kolory i style dziedziczone należą do host app
- Biblioteka może być podmieniona na mobilną w przyszłości
- CSS variables z neutralnymi fallbackami (`transparent`, `inherit`) służą jako **API contract** — dokumentują jakie wartości host app może ustawić
- Host app ustawia wartości w `:root` lub na selektorze `lib-toolbox-form` / `app-custom-pattern`

**Reguła:**
- Layout/geometria → w bibliotece, z realnymi wartościami fallback
- Kolory/bg/border/shadow/font → tylko `var(--toolbox-*)` z fallbackiem `transparent`, `inherit` lub `currentColor`

---

## Scope

This task covers **only the library workspace** (`guitar-toolbox-lib`). The host app (`guitar-neck-ui`) will be updated separately.

## Files to modify

Two component files in `projects/guitar-toolbox-lib/src/lib/`:

1. [`toolbox-form/toolbox-form.component.ts`](projects/guitar-toolbox-lib/src/lib/toolbox-form/toolbox-form.component.ts) — inline template + inline styles
2. [`custom-pattern/custom-pattern.component.ts`](projects/guitar-toolbox-lib/src/lib/custom-pattern/custom-pattern.component.ts) — inline template + inline styles

---

## What to do

Keep egzisting functionallity hwen applyying new markup !

### 1. Replace templates with new BEM markup

#### For `ToolboxFormComponent`:

Replace the `template` string with:

```html
<h2 class="toolbox__title">Select, what you want to see on guitar neck.</h2>

<div class="toolbox__mode-selector">
  <button type="button"
          class="toolbox__mode-btn"
          [class.toolbox__mode-btn--active]="!showCustomPattern"
          (click)="showCustomPattern = false">
    Standard Patterns
  </button>
  <button type="button"
          class="toolbox__mode-btn"
          [class.toolbox__mode-btn--active]="showCustomPattern"
          (click)="showCustomPattern = true">
    Custom Pattern
  </button>
</div>

<form *ngIf="!showCustomPattern"
      [formGroup]="guitarForm"
      (ngSubmit)="onSubmit()"
      class="toolbox__form">
  <div class="toolbox__field">
    <label class="toolbox__label" for="elementType">Type:</label>
    <select class="toolbox__select" id="elementType" formControlName="elementType">
      <option *ngFor="let type of elementTypes" [value]="type.id">{{type.name}}</option>
    </select>
  </div>

  <div class="toolbox__field">
    <label class="toolbox__label" for="pattern">Pattern:</label>
    <select class="toolbox__select" id="pattern" formControlName="pattern">
      <option *ngFor="let pattern of availablePatterns" [value]="pattern">{{pattern}}</option>
    </select>
  </div>

  <div class="toolbox__field">
    <label class="toolbox__label" for="key">Key of:</label>
    <select class="toolbox__select" id="key" formControlName="key">
      <option *ngFor="let key of keys" [value]="key">{{key}}</option>
    </select>
  </div>

  <button type="submit" class="toolbox__submit">Show!</button>
</form>

<app-custom-pattern
  *ngIf="showCustomPattern"
  (onCustomPatternSubmit)="onCustomPatternSubmit($event)">
</app-custom-pattern>
```

#### For `CustomPatternComponent`:

Replace the `template` string with:

```html
<form [formGroup]="customPatternForm"
      (ngSubmit)="onSubmit()"
      class="toolbox__custom-form">
  <div class="toolbox__field">
    <label class="toolbox__label" for="intervals">Intervals:</label>
    <input type="text"
           id="intervals"
           formControlName="intervals"
           placeholder="e.g. 1,3,5"
           class="toolbox__input">
    <small class="toolbox__hint">Enter comma-separated intervals</small>
  </div>

  <div class="toolbox__field">
    <label class="toolbox__label" for="rootNote">Root note:</label>
    <select id="rootNote" formControlName="rootNote" class="toolbox__select">
      <option *ngFor="let note of keys" [value]="note">{{note}}</option>
    </select>
  </div>

  <button type="submit"
          class="toolbox__submit"
          [disabled]="!customPatternForm.valid">
    Show Pattern
  </button>
</form>
```

### 2. Replace inline `styles` arrays with CSS Custom Properties API

#### For `ToolboxFormComponent`:

Replace the `styles` array with:

```scss
// ===========================================================
// ToolboxFormComponent styles (guitar-toolbox-lib)
// Library provides: layout, geometry, basic sizing
// Host app provides: colors, backgrounds, borders, fonts via CSS vars
// ===========================================================

:host {
  display: block;
}

.toolbox__title {
  margin: 0 0 22px;
  font-size: 16px;
  color: var(--toolbox-text, inherit);
}

.toolbox__mode-selector {
  display: flex;
  gap: 10px;
  margin-bottom: 22px;
}

.toolbox__mode-btn {
  min-width: 150px;
  height: 42px;
  padding: 0 16px;
  background: var(--toolbox-bg, transparent);
  border-width: 1px;
  border-style: solid;
  border-color: var(--toolbox-border-color, transparent);
  border-radius: var(--toolbox-radius, 0);
  color: var(--toolbox-text, inherit);
  cursor: pointer;
  font-size: 14px;
}

.toolbox__mode-btn--active {
  // Host app provides: border-color, background, color via CSS vars
  border-color: var(--toolbox-accent, currentColor);
  background: var(--toolbox-accent-bg, transparent);
  color: var(--toolbox-accent, currentColor);
}

.toolbox__form {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr auto;
  gap: var(--toolbox-gap, 18px);
  align-items: end;
  margin-bottom: 26px;
}

.toolbox__field {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.toolbox__label {
  color: var(--toolbox-text, inherit);
  font-size: 14px;
  margin-bottom: 4px;
}

.toolbox__select {
  width: 100%;
  height: 40px;
  padding: 0 12px;
  background: var(--toolbox-bg, transparent);
  border-width: 1px;
  border-style: solid;
  border-color: var(--toolbox-border-color, transparent);
  border-radius: var(--toolbox-radius-sm, 0);
  color: var(--toolbox-text, inherit);
  font-size: 14px;
}

.toolbox__submit {
  min-width: 88px;
  height: 40px;
  padding: 0 16px;
  background: var(--toolbox-accent, transparent);
  color: var(--toolbox-accent-text, inherit);
  border: none;
  border-radius: var(--toolbox-radius-sm, 0);
  cursor: pointer;
  font-size: 14px;
}

.toolbox__submit:hover {
  opacity: 0.9;
}

.toolbox__submit:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
```

#### For `CustomPatternComponent`:

Replace the `styles` array with:

```scss
// ===========================================================
// CustomPatternComponent styles (guitar-toolbox-lib)
// Library provides: layout, geometry, basic sizing
// Host app provides: colors, backgrounds, fonts via CSS vars
// ===========================================================

.toolbox__custom-form {
  display: flex;
  flex-direction: row;
  align-items: flex-end;
  gap: var(--toolbox-gap, 20px);
  width: auto;
  margin: 0 auto;
  padding: 0 25%;
}

.toolbox__field {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.toolbox__label {
  color: var(--toolbox-text, inherit);
  font-size: 14px;
}

.toolbox__hint {
  color: var(--toolbox-muted, inherit);
  font-size: 0.8em;
}

.toolbox__input {
  padding: 8px 12px;
  background: var(--toolbox-bg, transparent);
  border-width: 1px;
  border-style: solid;
  border-color: var(--toolbox-border-color, transparent);
  border-radius: var(--toolbox-radius-sm, 0);
  font-size: 14px;
  color: var(--toolbox-text, inherit);
}

.toolbox__input:focus {
  outline: none;
  border-color: var(--toolbox-accent, currentColor);
}

.toolbox__select {
  width: 100%;
  height: 40px;
  padding: 0 12px;
  background: var(--toolbox-bg, transparent);
  border-width: 1px;
  border-style: solid;
  border-color: var(--toolbox-border-color, transparent);
  border-radius: var(--toolbox-radius-sm, 0);
  color: var(--toolbox-text, inherit);
  font-size: 14px;
}

.toolbox__submit {
  height: 37px;
  padding: 8px 16px;
  border: none;
  border-radius: var(--toolbox-radius-sm, 0);
  background: var(--toolbox-accent, transparent);
  color: var(--toolbox-accent-text, inherit);
  cursor: pointer;
}

.toolbox__submit:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.toolbox__submit:hover:not(:disabled) {
  opacity: 0.9;
}
```

### 3. Remove hardcoded inline styles

- **`ToolboxFormComponent`**: Remove `[style.backgroundColor]="'#004400'"` and `[style.color]="'#ffffff'"` from the submit button — these are now handled by `.toolbox__submit` class and CSS variables.
- **`CustomPatternComponent`**: All inline styles are already replaced by the new `styles` array above.

---

## CSS Variables API (contract)

These are the CSS custom properties the library exposes. The host app sets them to theme the toolbox.

**Neutral fallback rule**: All visual/color variables use `transparent`, `inherit`, `currentColor` or `0` as fallback — the library does NOT define any opinionated colors. Layout/geometry values like `gap` have real fallback values because they are structural.

| Variable | Fallback | Used by | Category |
|----------|----------|---------|----------|
| `--toolbox-bg` | `transparent` | all components | Background color |
| `--toolbox-text` | `inherit` | all components | Text color |
| `--toolbox-border-color` | `transparent` | inputs, selects | Border color |
| `--toolbox-radius` | `0` | buttons, mode selector | Border radius (large) |
| `--toolbox-radius-sm` | `0` | inputs, selects | Border radius (small) |
| `--toolbox-gap` | `18px` (or `20px`) | forms, mode selector | Gap — **layout** |
| `--toolbox-accent` | `currentColor` | submit btn, active | Accent color |
| `--toolbox-accent-text` | `inherit` | submit btn | Text on accent |
| `--toolbox-accent-bg` | `transparent` | active mode btn | Background when active |
| `--toolbox-muted` | `inherit` | hints | Muted text color |

---

## Validation checklist

### Build
- [ ] Both components compile without errors (`ng build`)
- [ ] Library builds and publishes successfully (`ng build` → `npm publish`)

### Template
- [ ] No hardcoded `[style.*]` bindings remain in templates
- [ ] `ToolboxFormComponent` — submit button has class `toolbox__submit` and no inline style bindings
- [ ] `CustomPatternComponent` — all classes are `.toolbox__*` (no `.custom-pattern-form`, `.form-row`, `.form-input`, etc.)
- [ ] `CustomPatternComponent` — hint text uses `.toolbox__hint` class

### Styles — Neutral fallback rule
- [ ] All `background` values use `var(--toolbox-bg, transparent)` or `var(--toolbox-accent-bg, transparent)`
- [ ] All `color` values use `var(--toolbox-text, inherit)` or `var(--toolbox-accent, currentColor)` or `var(--toolbox-accent-text, inherit)`
- [ ] All `border-color` is always separated from `border-width/border-style` — color uses `var(--toolbox-border-color, transparent)` or `var(--toolbox-accent, currentColor)`
- [ ] All `border-radius` uses `var(--toolbox-radius, 0)` or `var(--toolbox-radius-sm, 0)` — no numeric fallback
- [ ] All `opacity` and `cursor` values are real (interaction behavior — library concern)

### BEM naming
- [ ] All component classes follow `.toolbox__*` pattern
- [ ] Modifier classes follow `.toolbox__*--*` pattern (e.g., `.toolbox__mode-btn--active`)
- [ ] No remnant of old classes: `.form-row`, `.form-select`, `.form-input`, `.section-title`, `.mode-selector`, `.custom-pattern-form`

---

## References

- Detailed plan: `plans/toolbox-markup-replacement-plan.md` in host workspace
- Architecture decision: `ARCHITECTURE.md` section "Styling Strategy: Library vs Host App Separation"
- Current (broken) state reference: `node_modules/guitar-toolbox-lib/esm2022/lib/toolbox-form/toolbox-form.component.mjs` in host workspace
