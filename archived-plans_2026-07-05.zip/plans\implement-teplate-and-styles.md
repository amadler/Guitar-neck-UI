2. Plug in Legend - easy - Done
  
3. Plug in range fret - medium/easy
4. Plug  in toolbox form - hard
5. replace guitar neck component with styling - Milestone
6. Coment out/ FF postponed functionallity
1. Break up css style.scss for proper Angular components - Later / hard


Remove as much code from .dock element to components. Layout should be just containers probobly to replace with CSS Grid

Plan and implement docking functionallity
