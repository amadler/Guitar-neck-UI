# Metronome Feature — Plan

## Overview

Add a standalone metronome component to help practicing scales with tempo control. The component will live in the right panel of the dock (currently occupied by `.ai-placeholder` / AI chat placeholder).

---

## Architecture

```
src/app/metronome/
├── metronome.component.ts        # UI logic + template bindings
├── metronome.component.html      # Template
├── metronome.component.scss      # Component-scoped styles
├── metronome.component.spec.ts   # Unit tests
└── metronome-engine.service.ts   # Audio engine + beat scheduling
```

**Pattern**: Standalone Angular component (no NgModule needed).

**Integration point**: Replace the `.ai-placeholder` block in [`home-page.component.html`](src/app/home-page/home-page.component.html:18) with `<app-metronome></app-metronome>`.

**Feature toggle**: Chat is already gated by `chatEnabled` flag (currently `false`). The metronome will live in the `#chatDisabled` template, directly replacing the placeholder.

---

## Component Design

### `MetronomeComponent`

| Property | Type | Default | Description |
|---|---|---|---|
| `bpm` | `number` | `120` | Current tempo (beats per minute) |
| `timeSignature` | `'2/4' \| '3/4' \| '4/4' \| '6/8'` | `'4/4'` | Beats per measure |
| `isRunning` | `boolean` | `false` | Whether metronome is playing |
| `currentBeat` | `number` | `0` | Current beat index (1-based, for visual) |
| `meter` | `number` | `4` | Computed from timeSignature (top number) |
| `beatUnit` | `number` | `4` | Computed from timeSignature (bottom number) |

### Data Flow

```
User input (BPM slider/input, time sig, start/stop, tap)
        │
        ▼
MetronomeComponent
        │
        ├──► MetronomeEngineService
        │       ├── AudioContext (Web Audio API)
        │       ├── scheduleBeat()
        │       ├── accentSound()
        │       └── normalSound()
        │
        └──► CSS class binding on .beat-indicator
                └── .beat-indicator--accent / .beat-indicator--normal
```

---

## Detailed Features

### 1. Tempo Control
- **Slider**: Range 20–300 BPM, step 1
- **Numeric input**: Editable field, validated 20–300
- Two-way binding between slider and input

### 2. Time Signature Selector
- Segmented button group with options: 2/4, 3/4, 4/4, 6/8
- Changing resets the beat counter

### 3. Start / Stop
- Single toggle button: "Start" → "Stop"
- On start: initialize AudioContext, begin scheduling beats
- On stop: cancel all scheduled beats, reset visual beat to 0

### 4. Tap Tempo
- Button labeled "Tap"
- **Po 2 tapnięciach** → pokazuje wstępne BPM (pierwszy interwał)
- **Przy 3. i kolejnych** → uśrednia z ostatnich N tapnięć (rolling window 5-6), BPM aktualizuje się na bieżąco
- Reset if gap > 2 seconds (stale tap detection)
- Updates the BPM control and slider

### 5. Visual Beat Indicator
- Large circle that flashes on each beat
- **Accent beat** (beat 1): larger / green color (--green-700)
- **Normal beats**: smaller / muted color (--app-muted)
- CSS transition for the flash effect (scale pulse + opacity)

### 6. Audio (Web Audio API) — Noise Burst
- Use **AudioBuffer with white noise burst** for realistic click sound
- **Accent beat**: noise burst ~30ms, lower-pitched filter or longer decay
- **Normal beat**: noise burst ~20ms, higher-pitched filter
- **Precision**: Use `AudioContext.currentTime` scheduling (not `setInterval` alone) for drift-free timing
- Fallback: if AudioContext not available, use visual-only mode

---

## Wireframe

```
┌──────────────────────────────┐
│         Metronome            │
│                              │
│         ┌────────┐           │
│         │  ●     │  ← beat   │
│         │  ●     │  indicator│
│         │  ● ● ● │           │
│         └────────┘           │
│                              │
│   Tempo: [===●=====] 120     │
│          slider    input     │
│                              │
│   Time: [2/4] [3/4] [4/4]   │
│         [6/8]                │
│                              │
│   ┌──────────┐ ┌──────────┐  │
│   │  ▶ Start │ │ ╳ Tap    │  │
│   └──────────┘ └──────────┘  │
└──────────────────────────────┘
```

---

## Change Summary — Files to Modify / Create

| File | Action | Description |
|---|---|---|
| `src/app/metronome/metronome-engine.service.ts` | **CREATE** | Audio engine with noise burst generation via Web Audio API |
| `src/app/metronome/metronome.component.ts` | **CREATE** | Component logic |
| `src/app/metronome/metronome.component.html` | **CREATE** | Component template |
| `src/app/metronome/metronome.component.scss` | **CREATE** | Component styles (beat indicator, layout) |
| `src/app/metronome/metronome.component.spec.ts` | **CREATE** | Unit tests |
| `src/app/home-page/home-page.component.ts` | **MODIFY** | Import MetronomeComponent and add to `imports` |
| `src/app/home-page/home-page.component.html` | **MODIFY** | Replace `.ai-placeholder` block with `<app-metronome>` |
| `src/styles.scss` | **MODIFY** | Add `.metronome` section styles (wraps ai-placeholder area, responsive) |
| `BACKLOG.md` | **MODIFY** | Add metronome backlog entry |

---

## Effort Assessment

**Low to Medium** (~1 hour for implementation).

Why it's manageable:
- No external dependencies — pure Angular + native Web Audio API
- Standalone component — no changes needed to existing services or routing
- Replaces existing placeholder slot — no layout restructuring
- No backend or data persistence needed
- The component is self-contained with simple state

Potential complexities:
- AudioContext browser restrictions (requires user gesture to start → start button is a user gesture ✅)
- Precise beat timing at high BPM → use `AudioContext.currentTime` scheduling
- Tap tempo edge cases (stale taps, rapid taps) → straightforward debounce/reset logic

---

## Implementation Order

1. Create `metronome-engine.service.ts` — pure logic, testable independently
2. Create `metronome.component.ts` + `.html` + `.scss` — consume the engine
3. Modify `home-page.component.ts` — import and register component
4. Modify `home-page.component.html` — replace placeholder with `<app-metronome>`
5. Add global styles in `styles.scss` for `.metronome` section (responsive fallback matching `.ai-placeholder`)
6. Create `metronome.component.spec.ts` — unit tests
7. Add backlog entry to `BACKLOG.md`
