# Jak działa FreatboardComponent — wytłumaczenie od zera

Zacznijmy od pytania: **co to w ogóle jest "fretboard"?** To wizualna reprezentacja gryfu gitary — 6 strun, progi, nuty na progach.

## Główne puzzle tej układanki

System składa się z kilku warstw. Oto one:

```mermaid
flowchart TB
    subgraph UI_Warstwa ["Warstwa UI (widoczna)"]
        GC[GuitarNeckComponent<br/>rodzic]
        FC[FreatboardComponent<br/>dziecko - rysuje gryf]
        RT[RangeToolbarComponent<br/>wybór zakresu progów]
    end

    subgraph Stan_Warstwa ["Warstwa stanu (niewidoczna)"]
        FSS[FretboardStateService<br/>guitar-neck.service.ts<br/>przechowuje: visible, selected, interval]
    end

    subgraph Logika_Warstwa ["Warstwa logiki (niewidoczna)"]
        NPS[FretboardNotePositionService<br/>note.service.ts<br/>generuje wszystkie nuty na gryfie]
        IS[IntervalService<br/>oblicza interwały: root, 3rd, 5th...]
        OPS[FretboardOrchestrationService<br/>music-theory-facade.service.ts<br/>orchestruje wyświetlanie]
        APS[MusicPatternApiService<br/>scales-and-triads.service.ts<br/>pobiera dane z backendu]
    end

    GC --> FC
    FC --> FSS
    OPS --> FSS
    OPS --> NPS
    OPS --> APS
    OPS --> IS
```

---

## Krok 1: Najpierw trzeba wiedzieć, jakie nuty istnieją na gryfie

Kiedy aplikacja startuje, [`FretboardNotePositionService`](src/app/services/note.service.ts:16) generuje **wszystkie możliwe nuty na gitarze**. Robi to pętlą:

```
dla każdej struny (E, A, D, G, B, E):
  dla każdego progu (0 do 24):
    oblicz nutę (przesuwając się po gamie chromatycznej)
    stwórz obiekt GuitarNote
```

Efekt: 6 strun × 25 pozycji (0-24) = **150 obiektów [`GuitarNote`](src/app/shared/model/guitarNote.ts)**.

Każdy `GuitarNote` to prosty obiekt z polami:
- `string: number` — która struna (1=E, 2=A, 3=D, 4=G, 5=B, 6=e)
- `fret: number` — który próg (0 = open string)
- `note: string` — nazwa nuty (C, C#, D, D#...)
- `visible: boolean` — czy pokazać na ekranie
- `selected: boolean` — czy jest zaznaczona
- `interval: string` — jaka ma interwał (root, major-3rd...)

```mermaid
flowchart LR
    subgraph Generowanie_Nut ["Generowanie nut na gryfie"]
        A[NoteService constructor] --> B[generateFretboard]
        B --> C[Pętla: dla string 1..6]
        C --> D[Pętla: dla fret 0..24]
        D --> E[calculateNoteOnFret]
        E --> F[new GuitarNote<br/>string, fret, note]
        F --> G[push do tablicy]
        G --> C
    end

    H["Wynik: 150 obiektów GuitarNote<br/>z domyślnie visible=true, selected=false, interval=''"]
    G --> H
```

---

## Krok 2: Stan — kto decyduje co widać?

Stanem zarządza [`FretboardStateService`](src/app/services/guitar-neck.service.ts). To jest **centralne miejsce pamięci** dla aktualnego stanu gryfu. Przechowuje:

- `notes: GuitarNote[]` — wszystkie 150 nut
- `strings` — lista strun (E, A, D, G, B, E)
- `frets` — lista progów (1, 2, 3...24)

Kluczowe metody:

| Metoda | Co robi |
|--------|---------|
| `hideAllNotes()` | Ukrywa wszystkie nuty (`visible = false`) |
| `showAll()` | Pokazuje wszystkie nuty (`visible = true`) |
| `clearSelection()` | Odznacza wszystkie (`selected = false`) |
| `applyHighlightedNotes(notes)` | Przyjmuje listę nut do pokazania, ustawia im `visible=true, selected=true` |
| `clearFretboard()` | Resetuje wszystko — chowa nuty, czyści zaznaczenia, usuwa interwały |
| `isNoteOnFret(string, fret)` | Sprawdza czy na danej strunie/progu jest widoczna nuta |

---

## Krok 3: Co się dzieje, gdy użytkownik wybiera skalę lub akord?

Tu wchodzi [`FretboardOrchestrationService`](src/app/services/music-theory-facade.service.ts). On koordynuje cały proces:

```mermaid
sequenceDiagram
    participant U as Użytkownik
    participant O as FretboardOrchestrationService
    participant API as MusicPatternApiService
    participant NS as FretboardNotePositionService
    participant SS as FretboardStateService
    participant IV as IntervalService

    U->>O: "Pokaż skalę C-major"
    O->>SS: clearFretboard() - ukryj wszystko
    O->>API: resolveScaleNotes('major', 'C')
    API-->>O: ["C", "D", "E", "F", "G", "A", "B"]
    O->>NS: findPositionsByScaleNotes(["C","D","E"...])
    NS-->>O: [GuitarNote na strunie 6/prog 8, ...]
    O->>SS: applyHighlightedNotes(selectedNotes)
    Note over SS: ustawia visible=true, selected=true
    O->>IV: markIntervals('C', 'major', highlightedNotes, 'scale')
    Note over IV: oblicza interwały: root, major-2nd, major-3rd...
    IV-->>O: nuty mają wypełnione pole 'interval'
    O-->>U: gotowe!
```

**Po polsku:**
1. Wyczyść gryf (schowaj wszystko)
2. Idź do backendu po nuty skali/akordu
3. Znajdź na gryfie wszystkie pozycje tych nut
4. Oznacz je jako widoczne i zaznaczone
5. Oblicz interwały (root = czerwony, tercja = niebieski, kwinta = zielony...)

---

## Krok 4: A jak to się rysuje na ekranie?

HTML [`FreatboardComponent`](src/app/freatboard/freatboard.component.html) to właściwie jedna wielka pętla.

```mermaid
flowchart TB
    T[<div class='guitar-neck'>] --> T1[<app-range-toolbar>]
    T --> T2[<div class='guitar-neck__fret-indices'>]
    T2 --> T2a[Nagłówek z numerami progów<br/>1 2 3 4 5...]

    T --> T3[Pętla: dla każdej struny]
    T3 --> S1[<div class='guitar-neck__string E'>]
    S1 --> S1a[Etykieta struny: E]
    S1 --> S1b[Próg 0 (open string)<br/>jeśli isNoteOnFret]
    S1 --> S1c[Pętla: dla każdego progu]

    S1c --> F1{Czy nuta istnieje<br/>i jest w zakresie?}
    F1 -->|Tak, nie zaznaczona| B1[button - klikalna kropka]
    F1 -->|Tak, zaznaczona| B2[div - statyczna kropka]
    F1 -->|Ma interwał| B3[div z klasą CSS<br/>guitar-neck__major-3rd etc.]
    F1 -->|Nie| Pusty[puste pole]

    S1c --> S2[następny próg]
    S3[następna struna]
```

Dla **każdej struny** i **każdego progu** template pyta serwis:
- `isNoteOnFret(E, 3)` — czy na strunie E, progu 3 jest widoczna nuta?
- `isNoteSelected(E, 3)` — czy jest zaznaczona?
- `getNoteInterval(E, 3)` — jaki ma interwał?
- `getNoteName(E, 3)` — jak się nazywa (C, D, E...)?

Dopiero na podstawie odpowiedzi decyduje, co narysować.

---

## Krok 5: Dlaczego możesz mieć wrażenie, że nie masz kontroli?

Prawdopodobnie przez **splot odpowiedzialności** — w [`GuitarNeckComponent`](src/app/guitar-neck/guitar-neck.component.ts) dzieje się kilka rzeczy naraz w konstruktorze:

```typescript
constructor(
    private noteService: FretboardNotePositionService,
    private guitarNeckService: FretboardStateService
) {
    this.guitarNotes = this.noteService.getAllPositions();  // (1) bierze 150 nut
    this.guitarNeckService.notes = this.guitarNotes;        // (2) zapisuje w serwisie stanu
    this.guitarNeckService.hideAllNotes();                  // (3) natychmiast chowa wszystkie!
}
```

**Po starcie aplikacji wszystkie nuty są ukryte** — dopiero po wybraniu skali/akordu pojawiają się konkretne.

`FreatboardComponent` dostaje `[notes]="guitarNotes"` (150 nut) przez `@Input`, ale nie filtruje ich sam — on **tylko pyta serwis** czy nuta jest widoczna. Jeśli nie ma widocznych nut... widzisz pusty gryf.

---

## Podsumowanie: architektura jednym schematem

```mermaid
flowchart TB
    Start[Aplikacja startuje] --> NS[NoteService<br/>generuje 150 GuitarNote]
    NS --> GNC[GuitarNeckComponent]
    GNC -->|setter| FSS[FretboardStateService<br/>chowa wszystkie nuty]
    GNC -->|@Input notes| FC[FreatboardComponent<br/>renderuje]

    FC -.->|pyta co widać| FSS

    User[Użytkownik wybiera skalę/akord] --> OPS[FretboardOrchestrationService]
    OPS -->|1. czyści| FSS
    OPS -->|2. pyta API| API[MusicPatternApiService]
    API -->|3. zwraca nuty| OPS
    OPS -->|4. znajduje pozycje| NS
    OPS -->|5. zaznacza| FSS
    OPS -->|6. oznacza interwały| IS[IntervalService]

    FC -.->|widzi visible=true| FSS
    FC -->|rysuje kolorowe kropki| Widok[Widok gryfu]
```

---

## Ściągawka: pliki które musisz znać

| Plik | Rola |
|------|------|
| [`src/app/shared/model/guitarNote.ts`](src/app/shared/model/guitarNote.ts) | Model nuty — 6 pól |
| [`src/app/services/note.service.ts`](src/app/services/note.service.ts) | Generuje i wyszukuje nuty na gryfie |
| [`src/app/services/guitar-neck.service.ts`](src/app/services/guitar-neck.service.ts) | **Stan gryfu** — centralne miejsce pamięci |
| [`src/app/services/music-theory-facade.service.ts`](src/app/services/music-theory-facade.service.ts) | **Orkiestrator** — to tu dzieje się magia |
| [`src/app/services/interval.service.ts`](src/app/services/interval.service.ts) | Oznacza nuty interwałami (root, third...) |
| [`src/app/freatboard/freatboard.component.ts`](src/app/freatboard/freatboard.component.ts) | "Głupi malarz" — tylko rysuje |
| [`src/app/guitar-neck/guitar-neck.component.ts`](src/app/guitar-neck/guitar-neck.component.ts) | Rodzic — składa wszystko razem |
| [`src/app/shared/UICommands.ts`](src/app/shared/UICommands.ts) | Wzorzec Command — operacje na gryfie jako obiekty |
| [`src/app/shared/GuitarNeck.ts`](src/app/shared/GuitarNeck.ts) | Klasa narzędziowa — generuje tablicę [stringi][progi] |

## Twoje opcje sterowania

| Chcesz... | Użyj... |
|-----------|---------|
| Pokaż konkretną skalę | `FretboardOrchestrationService.displayScale('major', 'C')` |
| Pokaż konkretny akord | `FretboardOrchestrationService.displayChord('major', 'C')` |
| Pokaż pojedynczą nutę | `FretboardOrchestrationService.displaySingleNote('C')` |
| Pokaż wszystkie nuty | `FretboardOrchestrationService.displayAllNotes()` |
| Wyczyść gryf | `FretboardOrchestrationService.resetFretboard()` |
| Zmień zakres progów | Wyślij event do `<app-range-toolbar>` |
| Reaguj na kliknięcie nuty | Obsłuż `(onNoteClicked$)="handler($event)"` w rodzicu |

## Najważniejsze rzeczy do zapamiętania

1. **`GuitarNote`** to zwykły obiekt z 6 polami — to nie jest magiczne
2. **`FretboardStateService`** trzyma stan wszystkich nut i mówi komponentowi co widać
3. **`FretboardOrchestrationService`** jest mózgiem — decyduje co, kiedy i jak pokazać
4. **`FreatboardComponent`** jest "głupi" — on tylko rysuje to, co serwis mu każe
5. Jeśli chcesz coś pokazać, zawsze idź przez `FretboardOrchestrationService.displayScale()` / `displayChord()` / `displaySingleNote()`
