# Cross-Project Documentation — lekki plan

## Problem

4 osobne repozytoria (`Guitar neck UI`, `guitar-toolbox`, `music-theory-api`, `shared`) — każdy ma własną dokumentację ale:
- **Orkiestrator** nie widzi zmian w podprojektach
- **Agenci** nie znają domeny i postępu innych
- **Decyzje** giną w promptach

## Rozwiązanie

Lekkie, bez nowych katalogów ani repozytoriów.

### 1. `CROSS_PROJECT.md` w `Guitar neck UI/`

Jeden plik w głównym repozytorium (Twoim workspace), który jest **entry pointem** dla każdego agenta:

```markdown
# Guitar Neck App — Cross-Project Overview

## Repozytoria

| Projekt | Ścieżka | Opis | Kluczowe dokumenty |
|---------|---------|------|-------------------|
| Guitar neck UI | `../Guitar neck UI/` | Frontend Angular 18 | BACKLOG.md, ARCHITECTURE.md |
| music-theory-api | `../music-theory-api/` | Backend Elysia/Bun | API.md, AGENTS.md |
| guitar-toolbox | `../guitar-toolbox/` | Toolbox Angular library | BACKLOG.md |
| shared | `../shared/` | Wspólne typy TS | README.md |

## Agent Workflow
1. PRZED taskiem → przeczytaj ten plik + BACKLOG.md docelowego projektu
2. CZYTAJ też STATUS.md sąsiednich projektów (przez ../ścieżkę)
3. PO tasku → zaktualizuj STATUS.md w swoim projekcie
```

### 2. `STATUS.md` w każdym repozytorium

Nowy plik w każdym z 4 projektów. Template:

```markdown
# Status

## Obecny task
- Cel: ...
- Agent: ...

## Zakończone
- YYYY-MM-DD — opis

## W toku
- opis

## Planowane
- opis

## Blockery
- opis lub brak

## Ostatnia aktualizacja: YYYY-MM-DD
```

### 3. Aktualizacja `AGENTS.md` w każdym repozytorium

Dodać sekcję:

```markdown
## Cross-Project Awareness
Before starting work, read:
- ../Guitar neck UI/CROSS_PROJECT.md — ecosystem overview
- ../music-theory-api/STATUS.md — backend status
- ../guitar-toolbox/STATUS.md — toolbox status
- ../shared/STATUS.md — shared types status
```

### 4. Unified Git Workflow (wszystkie repozytoria)

**Problem:** `shared/` nie ma AGENTS.md z git workflow, a niektórzy agenci commitują bezpośrednio na master. Każde repo musi mieć tę samą politykę.

#### Polityka (dla każdego repozytorium)

Poniższa treść trafi do sekcji `## Git workflow` w `AGENTS.md` każdego z 4 repozytoriów.

```markdown
## Git workflow

### Podstawowe zasady
- **Nigdy nie commitować bezpośrednio do `master`** — zawsze utwórz branch najpierw.
- Przed rozpoczęciem pracy: `git pull --rebase origin master` (zawsze startuj ze świeżego mastera).
- Po skończeniu pracy na branchu: **zapytaj użytkownika o zgodę na merge** — nigdy nie merguj samodzielnie.
- Squash-merge jest preferowany (czystsza historia).

### Nazewnictwo branchy
| Prefix | Kiedy użyć | Przykład |
|--------|-----------|----------|
| `feat/` | Nowa funkcjonalność | `feat/add-pentatonic-scales` |
| `fix/` | Naprawa błędu | `fix/scale-octave-off-by-one` |
| `chore/` | Refactor, dokumentacja, deps, config | `chore/update-elysia-version` |
| `experiment/` | Eksploracja bez zobowiązań (MOŻNA commitować na master po eksperymencie) | `experiment/websocket-streaming` |

### Commit messages
- Preferuj format: `typ(krótki kontekst): opis`
- Przykłady: `feat(scales): add diminished arpeggio patterns`, `fix(api): normalize root note casing`
- Nie wymuszamy — ale zachęcamy, bo squash-merge i tak zredukuje do jednej wiadomości.

### shared/ — osobności
- Jako repozytorium typów zmienia się rzadziej, ale polityka branchy jest taka sama.
- `chore/` będzie dominującym prefixem (aktualizacje typów, wersji publikacji).
```

### Cross-repo feature — uwaga dla Orkiestratora

Gdy jeden feature wymaga zmian w wielu repozytoriach (np. dodanie typu skali do `shared/`, potem API w `music-theory-api/`, potem UI w `guitar-toolbox/` i `Guitar neck UI/`):

- **To Orkiestrator zarządza sekwencją** — nie pojedynczy agent, bo każdy agent widzi tylko swoje repo.
- Orkiestrator używa tego **samego branch name** we wszystkich repozytoriach (np. `feat/add-diminished-arpeggio`), ale każdy agent tworzy go w swoim repo niezależnie na polecenie Orkiestratora.
- Kolejność prac (wynika z łańcucha zależności):

```mermaid
flowchart LR
    shared --> music-theory-api
    shared --> guitar-toolbox
    music-theory-api --> Guitar-neck-UI
    guitar-toolbox --> Guitar-neck-UI
    style shared fill:#ddf,stroke:#333
    style music-theory-api fill:#dfd,stroke:#333
    style guitar-toolbox fill:#ffd,stroke:#333
    style Guitar-neck-UI fill:#fdd,stroke:#333
```

Sekwencja: shared (1) → music-theory-api i guitar-toolbox (2, równolegle) → Guitar neck UI (3).
Każdy merge za zgodą użytkownika, w tej właśnie kolejności.

## Podsumowanie zmian

| Co | Gdzie | Typ zmiany |
|----|-------|------------|
| `CROSS_PROJECT.md` | `Guitar neck UI/` | **NOWY** |
| `STATUS.md` | `Guitar neck UI/` | **NOWY** |
| `STATUS.md` | `guitar-toolbox/` | **NOWY** |
| `STATUS.md` | `music-theory-api/` | **NOWY** |
| `STATUS.md` | `shared/` | **NOWY** |
| `AGENTS.md` | `Guitar neck UI/` | **EDYCJA** — dodaj cross-project links + unified git workflow |
| `AGENTS.md` | `guitar-toolbox/` | **EDYCJA** — dodaj cross-project links + unified git workflow |
| `AGENTS.md` | `music-theory-api/` | **EDYCJA** — dodaj cross-project links + unified git workflow |
| `AGENTS.md` | `shared/` | **NOWY** — utwórz z unified git workflow + cross-project links |
