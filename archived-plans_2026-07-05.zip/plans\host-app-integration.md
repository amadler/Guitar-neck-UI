# Host App Integration: CSS Variables + BEM Styling for guitar-toolbox-lib

## Status

| Phase | Status |
|-------|--------|
| Library migration (BEM + CSS vars) | ✅ Done |
| Host app integration | 📋 Planned (this document) |

## Context

The library `guitar-toolbox-lib` now uses:
- **BEM classes**: `.toolbox__title`, `.toolbox__mode-selector`, `.toolbox__mode-btn`, `.toolbox__mode-btn--active`, `.toolbox__form`, `.toolbox__field`, `.toolbox__label`, `.toolbox__select`, `.toolbox__submit`, `.toolbox__custom-form`, `.toolbox__input`, `.toolbox__hint`
- **CSS Custom Properties API**: All visual properties use `var(--toolbox-*)` with neutral fallbacks (`transparent`, `inherit`, `currentColor`, `0`)

The host app currently has:
- **Old dead CSS** in [`src/styles.scss:542-641`](src/styles.scss:542) — classes `.toolbox-panel`, `.toolbox-tabs`, `.toolbox-tabs__button`, `.toolbox-form`, `.toolbox-form__field`, `.toolbox-form__submit`, `.active-summary`, `.quick-chip`, etc. — **none of these are referenced in any `.html` template**
- **No CSS variable definitions** for `--toolbox-*` — the library components will render with neutral fallbacks (transparent/inherit/0) so they'll be invisible without host values
- **Responsive breakpoints** at [`src/styles.scss:724-726`](src/styles.scss:724) and [`src/styles.scss:759-761`](src/styles.scss:759) still target old class names
- **CSS Variables API contract** already documented in [`ARCHITECTURE.md:159-214`](ARCHITECTURE.md:159)

---

## Tasks

### 1. Add CSS variable definitions in `:root`

**File**: [`src/styles.scss`](src/styles.scss:18)

Add these variables inside the existing `:root` block (around line 90, after the `--dock-height` declaration):

```scss
// Toolbox — consumed by guitar-toolbox-lib via CSS Custom Properties API
--toolbox-bg: var(--app-surface);
--toolbox-text: var(--app-text);
--toolbox-border-color: var(--app-border);
--toolbox-radius: var(--radius-md);
--toolbox-radius-sm: var(--radius-sm);
--toolbox-gap: 18px;
--toolbox-accent: var(--green-800);
--toolbox-accent-text: #ffffff;
--toolbox-accent-bg: transparent;
--toolbox-muted: var(--app-muted);
```

**Neutral fallback rule**: These are real values — the library only uses neutral fallbacks. The host provides the actual theme.

**Validation**: After adding, inspect the library component in the browser — buttons, inputs, labels should have proper colors.

---

### 2. Refactor old toolbox host styles

**File**: [`src/styles.scss`](src/styles.scss:542-641)

**2a. Remove dead CSS** — delete the entire block `/* Toolbox */` section (lines 542–641). The following classes have zero references in any `.html` template (confirmed via grep):

| Class | Lines | Status |
|-------|-------|--------|
| `.toolbox-panel` | 546–551 | 🗑️ Dead |
| `.toolbox-tabs` | 553–557 | 🗑️ Dead |
| `.toolbox-tabs__button` | 559–563 | 🗑️ Dead |
| `.toolbox-form` | 565–571 | 🗑️ Dead |
| `.toolbox-form__field` | 573–576 | 🗑️ Dead |
| `.toolbox-form__submit` | 578–584 | 🗑️ Dead |
| `.active-summary` | 586–596 | 🗑️ Dead |
| `.active-summary__item` | 598–610 | 🗑️ Dead |
| `.active-summary__clear` | 612–615 | 🗑️ Dead |
| `.quick-examples__title` | 617–619 | 🗑️ Dead |
| `.quick-examples__list` | 622–625 | 🗑️ Dead |
| `.quick-chip` | 628–640 | 🗑️ Dead |

**2b. Add host-level panel styles** — the old `.toolbox-panel` provided padding, border-right, overflow, and min-height. These need to be applied to the library's host element `lib-toolbox-form`:

```scss
// Toolbox host panel — wraps lib-toolbox-form
lib-toolbox-form {
  display: block;
  padding: 22px;
  border-right: 1px solid var(--app-border);
  overflow: auto;
  min-height: 800px;
}
```

**Why `lib-toolbox-form` instead of `#toolbox-container`?**
- `#toolbox-container` is a `<section>` wrapper that also exists in the template
- Styling `lib-toolbox-form` directly is more semantically correct — it's the component's host element
- The `#toolbox-container` section can remain as a structural wrapper

---

### 3. Fix responsive breakpoints

**File**: [`src/styles.scss`](src/styles.scss:700-770)

Update two selectors that reference old class names:

**3a. Line 724** — `.toolbox-panel` → `lib-toolbox-form`:
```scss
@media (max-width: 1200px) {
  lib-toolbox-form {
    border-right: 0;
  }
}
```

**3b. Lines 759-761** — `.toolbox-form` → `::ng-deep` override for `.toolbox__form`:
```scss
@media (max-width: 900px) {
  lib-toolbox-form .toolbox__form {
    grid-template-columns: 1fr;
  }
}
```

**Note on `::ng-deep`**: Angular's emulated ViewEncapsulation scopes component styles with `[_ngcontent-xxx]` attributes. Global styles in `styles.scss` cannot reach into the library component's template without `::ng-deep`. This is the standard approach for responsive layout overrides in Angular 18. Angular has no plans to remove `::ng-deep`.

**3c. Line 763** — `.active-summary` → remove entirely (dead CSS):
```scss
// Remove this entire block — .active-summary is dead CSS
// .active-summary {
//   grid-template-columns: 1fr 1fr;
// }
```

---

### 4. Verify output

| Check | How |
|-------|-----|
| Build passes | `ng build` — zero errors |
| Toolbox renders | Open the app — toolbox panel should show with proper colors |
| BEM classes in DOM | Inspect `<lib-toolbox-form>` — children should use `.toolbox__*` classes |
| CSS variables applied | Check Computed Styles — `--toolbox-bg`, `--toolbox-text`, etc. should have values from `:root` |
| Responsive < 900px | `.toolbox__form` grid collapses to single column |
| No dead CSS | Verify no `.toolbox-form`, `.toolbox-panel`, `.active-summary` references remain |

---

### 5. Update documentation

**5a. [`ARCHITECTURE.md`](ARCHITECTURE.md:144)** — The "Styling Strategy: Library vs Host App Separation" section already documents the CSS Variables API (lines 159-214). No changes needed — the contract was written before implementation.

**5b. [`plans/library-review.md`](plans/library-review.md)** — Add a subsection noting host app integration is complete with the CSS variables defined in `:root`.

---

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| `::ng-deep` stops working in future Angular | Low | High | Add `--toolbox-form-grid` CSS var to library as migration path |
| CSS variable name mismatch between lib and host | Low | High | Both sides already implemented; verify via `ng build` |
| `lib-toolbox-form` selector collides with other components | Low | Low | Only one `<lib-toolbox-form>` exists in the app |

## Mermaid: Host App Integration Flow

```mermaid
flowchart TD
    A["src/styles.scss :root"] -->|defines| B["--toolbox-bg: var(--app-surface)<br>--toolbox-text: var(--app-text)<br>--toolbox-accent: var(--green-800)<br>..."]
    B -->|consumed by| C["lib-toolbox-form<br>ToolboxFormComponent"]
    
    D["src/styles.scss (global)"] -->|styles host| E["lib-toolbox-form<br>padding, border-right, min-height"]
    D -->|::ng-deep override| F[".toolbox__form<br>responsive grid"]
    
    C -->|contains| G["app-custom-pattern<br>CustomPatternComponent"]
    B -->|consumed by| G

    subgraph "Library (guitar-toolbox-lib)"
        C
        G
    end

    subgraph "Host App (styles.scss)"
        A
        D
    end
```
