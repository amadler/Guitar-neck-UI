# Brief Biznesowy — Guitar Neck UI

## 1. Zrozumienie Projektu

Guitar Neck UI to **interaktywne narzędzie edukacyjne dla gitarzystów** — webowa aplikacja Angular 18, której centrum stanowi interaktywny gryf gitary.

### Wizja produktu (z [`GuitarNeckUi PO vision.md`](../GuitarNeckUi%20PO%20vision.md))

Aplikacja **nie zastępuje teorii muzyki** — jej celem jest uczynienie teorii natychmiast widoczną i aplikowalną na gryfie. Gryf jest core produktu; wszystko inne (toolbox, AI, practice) istnieje po to, by go kontrolować, wyjaśniać lub rozszerzać.

### Grupa docelowa
- **Primary:** początkujący i niżej średnio zaawansowani gitarzyści
- **Secondary:** doświadczeni gitarzyści (szybki wizualny reference), nauczyciele

### Filozofia produktu
- Silnik muzyczny jest **deterministyczny** — teoria jest obliczana przez aplikację
- AI jest **asystentem** — wyjaśnia koncepcje i wywołuje istniejące funkcje, **nie** staje się silnikiem muzycznym
- Ewolucja: od "encyklopedii gryfu" do interaktywnego środowiska nauki

### Architektura
- Frontend: Angular 18 + TypeScript + RxJS
- Backend: `music-theory-api` (Elysia, Docker, port 3000) — oblicza nuty dla skal/akordów
- Biblioteki zewnętrzne: `guitar-neck-shared` (stałe, patterny), `guitar-toolbox-lib` (formularz toolbox)
- AI Chat (Gemini): kod istnieje w `projects/guitar-chat`, ale **POSTPONED** — brak klucza API

**Wzorce projektowe:** Facade (`FretboardOrchestrationService`), Command (`UICommands.ts`), Service Pattern.

---

## 2. Stan Obecny — Zrealizowane Funkcjonalności

### Działające
| Funkcja | Status |
|---------|--------|
| Interaktywny gryf gitary (6 strun × 24 progi) | ✅ Działa |
| Wizualizacja skal (26 patternów) z interwałami | ✅ Działa |
| Wizualizacja akordów (26 patternów: triady, extended 7/9/11/13, sus, add) | ✅ Działa |
| Custom pattern — użytkownik wpisuje interwały | ✅ Działa |
| Zaznaczanie pojedynczej nuty / wszystkich nut | ✅ Działa |
| Legenda kolorów interwałowych | ✅ Działa |
| String Toggle (włączanie/wyłączanie strun) | ✅ Działa |
| Range Toolbar (presety zakresu progów) | ✅ Działa |
| Toolbox (formularz wyboru skali/akordu) | ✅ Działa |
| Docker + nginx dla produkcyjnego deploymentu | ✅ Gotowe |
| Feature flag dla AI Chata (`chatEnabled: false`) | ✅ Gotowe |

### W budowie / do refactoringu
- `toolboxSubmit()` — łańcuch if/else do wydzielenia do Command Factory
- `MusicSelection` — abstrakcja domenowa (ujednolicenie interfejsu dla skal/akordów/nut/custom)
- Wydajność lookupów — przejście z `Array.find` O(n) na `Map` O(1)

### Wstrzymane (POSTPONED)
- AI Chat (Gemini) — kod istnieje, wymaga klucza API i włączenia flagi
- Note readability — poprawa kontrastu i czytelności nut (CSS)

---

## 3. Backlog Itemy

### Z `BACKLOG.md` (techniczny)

Łącznie **12 pozycji**:

| # | Item | Status | Typ |
|---|------|--------|-----|
| 1 | **AI Chat (Gemini)** — czat z asystentem muzycznym | POSTPONED | Feature |
| 2 | **refreshNotesInRange() dead code** — usunięta | ✅ FIXED | Cleanup |
| 3 | **ToolboxSearchQuery typing** — usunięto runtime coercion | ✅ FIXED | Cleanup |
| 4 | **toolboxSubmit() Command Factory** — wydzielenie fabryki | 🔴 OPEN | Refactor |
| 5 | **Pattern name Unicode w backendzie** — `7♭9` nie działa | 🔴 OPEN | Bug (backend) |
| 6 | **MusicSelection domain abstraction** — ujednolicenie API | 🔴 OPEN | Refactor |
| 7 | **Note readability** — poprawa widoczności nut | POSTPONED | UI/UX |
| 8 | **Fret numbering starts at 0** — zamiast 1 | 🔴 OPEN | UI/UX |
| 9 | **Remove unused uuid z GuitarNote** — zbędny import | 🔴 OPEN | Cleanup |
| 10 | **FretboardStateService O(n) → O(1)** — wydajność | 🔴 OPEN | Performance |
| 11 | **Template woła serwisy** — przenieść logikę do komponentu | 🔴 OPEN | Refactor |
| 12 | **UI Color Palette Refresh** — odświeżenie palety | 🔴 OPEN | UI/UX |

### Z `GuitarNeckUi PO vision.md` (biznesowy)

| Priorytet | Feature | Value |
|-----------|---------|-------|
| **HIGH** | Interval Color Toggle — wyłączanie kolorów interwałowych | Nauka bez podpowiedzi wizualnych |
| **HIGH** | UI Color Palette Refresh — readability | Lepsze UX, mniej szumu wizualnego |
| **HIGH** | Range Toolbar — presety pozycji | Szybsza nawigacja podczas ćwiczeń |
| **HIGH** | Open Chords — dedykowane kształty | Bardzo wysoka wartość dla początkujących |
| **HIGH** | Barre Chords — wizualizacja | Ważny milestone edukacyjny |
| **MEDIUM** | One-String Scales — skale na jednej strunie | Ear training, improvisation |
| **MEDIUM** | Practice Mode — interaktywne ćwiczenia | Zmiana z reference tool → learning platform |
| **MEDIUM** | AI Actions — AI wywołuje akcje aplikacji | Naturalna interakcja edukacyjna |
| **LOW** | AI Chat — pełna integracja Gemini | POSTPONED — najpierw dojrzały produkt |

### Z `Business aproach brief.md` — nowy kierunek

Kluczowa zmiana podejścia: **przejście z modelu "wyświetl obiekt" na "pokaż relację pomiędzy obiektami"**. Backlog powinien być generowany przez scenariusze użytkownika, a nie listę funkcji.

**Pierwszy scenariusz referencyjny:** *"Chcę zobaczyć, które dźwięki akordu należą do skali."*

To wymaga odpowiedzi na pytania architektoniczne:
- Czy obecny model gryfu pozwala na warstwy (layers) / role markerów?
- Czy potrzebujemy `MusicSelection` / `DisplayCell` zanim przejdziemy do scenariuszy?
- Jak evoluować kod bez dużego refactora?

### Priorytety rekomendowane
1. **Bug:** Unicode w backendzie (blokuje `7♭9`, `7♯5`)
2. **Architektura:** MusicSelection, DisplayCell — przygotowanie pod scenariusze
3. **Performance:** O(n) → O(1) — UX przy każdej interakcji
4. **UI/UX:** Color Palette, Fret numbering, Note readability
5. **Business features:** Open Chords, Barre Chords, Interval Color Toggle
6. **Postponed:** AI Chat, Practice Mode, monetyzacja

---

## 4. Problemy i Ryzyka

### 🔴 Aktywne
1. **Brak backendu na produkcji** — `music-theory-api` wymaga Docker. Bez backendu aplikacja nie wyświetli skal ani akordów.
2. **Unicode w backendzie** — patterny z ♭/♯ nie działają. Business impact: niski (tylko zaawansowani użytkownicy).
3. **Brak klucza API Gemini** — AI Chat zablokowany. Świadoma decyzja: AI postponed.

### 🟡 Zagrożenia techniczne
4. **CSS Variables API kontrakt** — biblioteka i host mogą się rozejść.
5. **uuid w GuitarNote** — 150 UUID generowanych, 0 używanych. Narzut na bundle.
6. **Scope creep** — ryzyko dodawania funkcji zamiast rozwijania scenariuszy użytkownika.
7. **Za wczesne AI** — zwiększa złożoność bez pewności, że zwiększa wartość.

### 🟢 Rozbieżności dokumentacji (już poprawione)
- **ARCHITECTURE.md** — poprawiono ścieżki `LegendComponent`, `RangeToolbarComponent`, dodano `StringToggleComponent`
- **TODO_DEPLOY.md** — zaktualizowano statusy FIXED/OPEN, dodano brakujące backlog itemy
- **BACKLOG.md** — zgodny z kodem (2 FIXED, reszta aktualna)
- **TODO_DEPLOY.md → Functional Cleanup** — zduplikowane pozycje usunięte, rozdzielone na FIXED i OPEN
