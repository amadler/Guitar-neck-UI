# Brief dla zespołu — zmiana podejścia do planowania produktu

## Kontekst

Do tej pory backlog rozwijał się głównie wokół nowych funkcji:

- pokaż skalę,
- pokaż akord,
- zakres progów,
- AI,
- Practice Mode.

Po analizie produktu doszliśmy do wniosku, że kolejne etapy powinny wynikać przede wszystkim ze **scenariuszy użytkownika**, a nie z listy funkcjonalności.

Scenariusze mają stać się głównym źródłem backlogu.

---

# Pierwszy scenariusz referencyjny

> **"Chcę zobaczyć, które dźwięki akordu należą do skali."**

Dlaczego właśnie ten?

- wykorzystuje praktycznie cały obecny silnik,
- ma wysoką wartość edukacyjną,
- nie wymaga AI,
- nie wymaga Practice Mode,
- rozwija produkt zgodnie z jego misją — pokazuje relacje muzyczne zamiast kolejnych bytów.

---

# Pytania do zespołu

## 1.

Czy obecna architektura jest gotowa na scenariusze, które operują na **relacjach pomiędzy bytami**, a nie na pojedynczych akcjach typu:

- pokaż skalę,
- pokaż akord,
- pokaż nutę?

---

## 2.

Czy obecny model gryfu pozwala jednocześnie wyświetlić:

- skalę,
- akord,
- wyróżnione dźwięki akordu,
- prymę,
- (w przyszłości) dźwięki spoza skali,

bez przebudowy całego modelu renderowania?

---

## 3.

Czy potrzebujemy wprowadzić pojęcie **warstw (layers)** lub **ról markerów (marker roles)** na gryfie?

Przykład:

- scale tone,
- chord tone,
- root,
- highlighted,
- selected,
- outside scale.

Czy obecny model jest gotowy na takie rozszerzenie?

---

## 4.

Czy taki kierunek jest zgodny z obecną architekturą, czy wymaga zmian, które lepiej wykonać wcześniej?

Interesuje nas przede wszystkim ewolucja obecnego kodu, a nie duży refactor.

---

## 5.

Czy widzicie inne scenariusze o podobnym stosunku wartości do kosztu implementacji?

Szukamy funkcji, które:

- wykorzystują istniejący silnik,
- zwiększają wartość edukacyjną,
- nie wprowadzają dużej złożoności.

---

# Cel

Nie projektujemy jeszcze rozwiązania.

Chcemy ocenić, czy obecna architektura pozwala naturalnie przejść z modelu:

> "wyświetl obiekt"

do modelu:

> "pokaż relację pomiędzy obiektami"

bez utraty prostoty projektu.
