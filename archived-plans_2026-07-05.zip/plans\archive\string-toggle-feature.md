# String Toggle Feature — Per-String Visibility for Scale Display

## Motivation

When practicing scales on the guitar, a musician often wants to focus on a subset of strings (e.g., only the top 3 strings for a melodic pattern, or only the bass strings for rhythm work). Currently, the fretboard shows all notes across all strings for any displayed scale. Adding per-string checkboxes lets the user selectively hide/show notes on individual strings, keeping the fretboard uncluttered.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│  FreatboardComponent                                            │
│  ┌───────────────────────────────────────────────────────────┐   │
│  │  app-range-toolbar                                         │   │
│  ├───────────────────────────────────────────────────────────┤   │
│  │  .guitar-neck__fret-indices                                │   │
│  │    [checkbox spacer]  [fret number cells...]               │   │
│  ├───────────────────────────────────────────────────────────┤   │
│  │  .guitar-neck__string-row (for each string)               │   │
│  │    [app-string-toggle]  [.guitar-neck__string content...] │   │
│  │      ┌──────────┐                                         │   │
│  │      │ ☑ E      │  .guitar-neck__nut-label + frets        │   │
│  │      ├──────────┤                                         │   │
│  │      │ ☑ B      │  ...                                    │   │
│  │      ├──────────┤                                         │   │
│  │      │ ☑ G      │  ...                                    │   │
│  │      ├──────────┤                                         │   │
│  │      │ ☑ D      │  ...                                    │   │
│  │      ├──────────┤                                         │   │
│  │      │ ☑ A      │  ...                                    │   │
│  │      ├──────────┤                                         │   │
│  │      │ ☑ E      │  ...                                    │   │
│  │      └──────────┘                                         │   │
│  └───────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow

```
User clicks checkbox
       │
       ▼
StringToggleComponent          (dumb component, emits event)
       │  @Output() stringToggled
       ▼
FreatboardComponent            (manages activeStrings state)
       │  adds/removes CSS class on string row
       ▼
CSS .guitar-neck__string--disabled  (hides dots/selected/interval elements)
```

**CSS-only approach** — no mutation of `GuitarNote.visible` or other model properties. This keeps the approach simple and reversible. The underlying scale/chord state is preserved.

## Component: `StringToggleComponent`

| Aspect | Detail |
|--------|--------|
| **File** | `src/app/string-toggle/string-toggle.component.ts` |
| **Selector** | `app-string-toggle` |
| **Type** | Standalone, dumb component |
| **Input** | `stringName: string` — the note name (E, B, G, D, A, E) |
| **Input** | `stringIndex: number` — 0-based index |
| **Input** | `active: boolean` — whether the string is currently active |
| **Input** | `disabled: boolean` — whether the checkbox is disabled (e.g., in chord mode) |
| **Output** | `stringToggled: EventEmitter<{stringIndex: number, active: boolean}>` |

No external dependencies. Pure `@Input`/`@Output` contract.

## State Management

The `activeStrings` state lives in `FreatboardComponent` as a local `Set<number>`:

```typescript
activeStrings: Set<number> = new Set([0, 1, 2, 3, 4, 5]); // all active by default
```

Methods added to `FreatboardComponent`:
- `isStringActive(index: number): boolean` — checks if index is in the set
- `onStringToggled(event: {stringIndex: number, active: boolean}): void` — adds/removes from set

## CSS Approach

Add a CSS class to each `.guitar-neck__string` row:

```html
<div *ngFor="let string of strings; let i = index" 
     class="guitar-neck__string-row"
     [class.guitar-neck__string--disabled]="!isStringActive(i)">
```

CSS rule to hide notes on disabled strings:

```scss
.guitar-neck__string--disabled {
  .guitar-neck__dot,
  .guitar-neck__selected,
  [class*="guitar-neck__interval"],
  [class*="guitar-neck__root"],
  [class*="guitar-neck__minor"],
  [class*="guitar-neck__major"],
  [class*="guitar-neck__perfect"],
  [class*="guitar-neck__diminished"] {
    display: none;
  }
}
```

Note: We hide ALL note elements (dots, selected, interval-colored) on the disabled string. The nut label (string name) and fret markers remain visible so the player can still see the string layout.

## Layout Changes

### Current layout (simplified)
```
.guitar-neck__fretboard (flex column)
  .guitar-neck__fret-indices
  .guitar-neck__string × N  (each is flex row)
```

### New layout (simplified)
```
.guitar-neck__fretboard (flex column)
  .guitar-neck__fret-indices
    .guitar-neck__fret-index-spacer  (matches checkbox column width)
    .guitar-neck__fret-index-track
  .guitar-neck__string-row × N  (each is flex row)
    app-string-toggle  (fixed width ~30px)
    .guitar-neck__string  (existing content)
```

The `.guitar-neck__string-row` wraps both the checkbox and the existing string content:

```html
<div *ngFor="let string of strings; let i = index" 
     class="guitar-neck__string-row"
     [class.guitar-neck__string--disabled]="!isStringActive(i)">
  
  <app-string-toggle 
    [stringName]="string"
    [stringIndex]="i"
    [active]="isStringActive(i)"
    (stringToggled)="onStringToggled($event)">
  </app-string-toggle>
  
  <div class="guitar-neck__string">
    <div class="guitar-neck__nut-label">...</div>
    <div *ngFor="let fret of frets" class="guitar-neck__fret">...</div>
  </div>
</div>
```

## Disabled State (Scale Mode vs Other Modes)

Currently there is no explicit "mode" tracking in the application. For MVP, we can:

- **Always show** checkboxes (to prevent layout shifts)
- **Disable** them by default — they only become active when a scale/pattern is displayed
- Track a simple `isScaleActive: boolean` in `FretboardStateService`

But for simplicity, the **initial implementation can have checkboxes always interactive** — they work regardless of mode. This is simpler and still useful. The user can always disable them later with the `disabled` input.

## Files to Create

| File | Purpose |
|------|---------|
| `src/app/string-toggle/string-toggle.component.ts` | Component class |
| `src/app/string-toggle/string-toggle.component.html` | Template with checkbox |
| `src/app/string-toggle/string-toggle.component.scss` | Styles for checkbox |
| `src/app/string-toggle/string-toggle.component.spec.ts` | Unit tests |

## Files to Modify

| File | Changes |
|------|---------|
| `src/app/freatboard/freatboard.component.ts` | Add `activeStrings` state, `isStringActive()`, `onStringToggled()`, import `StringToggleComponent` |
| `src/app/freatboard/freatboard.component.html` | Wrap strings in `.guitar-neck__string-row`, add `app-string-toggle`, update fret index spacer |
| `src/app/freatboard/freatboard.component.scss` | Add `.guitar-neck__string-row` style, `.guitar-neck__string--disabled` rule, checkbox column alignment |
| `src/app/freatboard/freatboard.component.spec.ts` | Update tests for new structure |

## Implementation Steps (Ordered)

1. **Create `StringToggleComponent`** — dumb component with `@Input()`s and `@Output()`
2. **Update `FreatboardComponent` template** — restructure to add checkbox column before each string
3. **Update `FreatboardComponent` class** — add active state tracking and event handler
4. **Add CSS rules** — layout alignment and disabled string hiding
5. **Update tests** — ensure existing tests pass and add new ones for string toggle behavior
6. **Run validation** — `npm test` and `npm run build`

## Future Considerations (Out of Scope)

- Disabling checkboxes when a chord or all-notes mode is active
- Persisting string toggle state across scale changes
- Keyboard shortcuts for toggling strings
