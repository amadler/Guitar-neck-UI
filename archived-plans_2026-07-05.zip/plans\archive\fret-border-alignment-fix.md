# Plan: Fix Fret Border Misalignment (Open String Notes)

## Problem Analysis

### Root Cause

In [`src/app/freatboard/freatboard.component.html`](src/app/freatboard/freatboard.component.html:14-22), the template **conditionally** renders a `.guitar-neck__fret--open` div for fret 0 only when `isNoteOnFret(string, 0)` is true:

```html
<div class="guitar-neck__fret guitar-neck__fret--open"
     *ngIf="isNoteOnFret(string, 0) && isNoteInRange(0)">
  ...note button content...
</div>
```

This causes **inconsistent child counts** across strings:

| Scenario | Children in `.guitar-neck__string` |
|---|---|
| String with open note visible | `nut-label` (20px) + `fret--open` (flex:1) + 24 frets (flex:1 each) = **26 elements** |
| String without open note visible | `nut-label` (20px) + 24 frets (flex:1 each) = **25 elements** |

Since `.guitar-neck__string` uses `display: flex` and each `.guitar-neck__fret` has `flex-grow: 1`, the browser distributes the available width differently:
- 26 children → each gets slightly **less** width
- 25 children → each gets slightly **more** width

This misaligns the `border-right` (the fret lines) vertically across strings.

### Why It Happens

In [`note.service.ts`](src/app/services/note.service.ts:19-33), `generateFretboard()` creates notes for **all 25 positions** (fret 0 through fret 24) on every string. When a chord/scale command executes (e.g., [`DisplayChordCommand`](src/app/shared/UICommands.ts:42-56) calls [`FretboardOrchestrationService.displayChord()`](src/app/services/music-theory-facade.service.ts:33-49)), notes matching the pattern are marked `visible = true`. If an open string note matches (fret 0), the template renders the extra div for that string only.

### Fret Index Display

The fret indices row correctly starts numbering from **1** (see [`guitar-neck.service.ts`](src/app/services/guitar-neck.service.ts:12)):
```typescript
frets = Array.from({ length: neckConfig.numberOfFrets }, (_, i) => i + 1);
```

There is no "fret 0" label — the gutter space is occupied by `.guitar-neck__fret-index-spacer` (20px) aligned with the nut-label column.

## Solution: Move Open String Notes Into the Nut-Label

### Principle

Every string must have **exactly the same number of direct children** inside `.guitar-neck__string`. The open string note should be displayed **inside** the `.guitar-neck__nut-label` element rather than as a separate flex child.

### Before/After Architecture

```
BEFORE (inconsistent):
┌─────────────────────────────────────────────┐
│ .guitar-neck__string                        │
│  ├── .nut-label ("E")                       │
│  ├── .fret--open (ONLY if note visible) ❌  │  ← extra child
│  ├── .fret (1)                              │
│  ├── .fret (2)                              │
│  ...                                        │
│  └── .fret (24)                             │
└─────────────────────────────────────────────┘

AFTER (consistent):
┌─────────────────────────────────────────────┐
│ .guitar-neck__string                        │
│  ├── .nut-label ("E" + optional note dot)   │
│  ├── .fret (1)                              │
│  ├── .fret (2)                              │
│  ...                                        │
│  └── .fret (24)                             │
└─────────────────────────────────────────────┘
```

### Detailed Changes

#### 1. [`src/app/freatboard/freatboard.component.html`](src/app/freatboard/freatboard.component.html)

**Remove** the entire `.guitar-neck__fret--open` div block (lines 14-22).

**Modify** the `.guitar-neck__nut-label` div (line 13) to include the open string note dot when applicable:

```html
<div class="guitar-neck__nut-label">
  {{ string }}
  <span class="guitar-neck__open-note"
        *ngIf="isNoteOnFret(string, 0) && isNoteInRange(0)"
        (click)="fretNoteClicked(string, 0)">
    {{ getNoteName(string, 0) }}
  </span>
</div>
```

**Note on selection/interval styling**: The open note inside the nut-label should preserve the same visual classes as the fret notes (dot, selected, interval classes). We'll need to handle this.

**Refined HTML approach**:

```html
<div class="guitar-neck__nut-label" 
     [ngClass]="{'guitar-neck__nut-label--has-note': isNoteOnFret(string, 0) && isNoteInRange(0)}">
  <span class="guitar-neck__nut-label__string-name">{{ string }}</span>
  <ng-container *ngIf="isNoteOnFret(string, 0) && isNoteInRange(0)">
    <button class="guitar-neck__dot guitar-neck__open-note-btn"
            *ngIf="!isNoteSelected(string, 0)"
            (click)="fretNoteClicked(string, 0)">
      {{ getNoteName(string, 0) }}
    </button>
    <div class="guitar-neck__selected"
         *ngIf="isNoteSelected(string, 0) && !getNoteInterval(string, 0)"
         (click)="fretNoteClicked(string, 0)">
      {{ getNoteName(string, 0) }}
    </div>
    <div *ngIf="getNoteInterval(string, 0)"
         [ngClass]="['guitar-neck__dot guitar-neck__'+getNoteInterval(string, 0)]"
         (click)="fretNoteClicked(string, 0)">
      {{ getNoteName(string, 0) }}
    </div>
  </ng-container>
</div>
```

#### 2. [`src/app/freatboard/freatboard.component.scss`](src/app/freatboard/freatboard.component.scss)

Update `.guitar-neck__nut-label` to support the additional open note content:

- Increase `min-width` if needed (currently 20px — may need to be slightly wider or use `position: relative` to overlay)
- Add styles for `.guitar-neck__open-note-btn` inside the nut-label
- Ensure the nut-label uses `position: relative` so the note dot can be positioned properly
- Remove the now-unused `.guitar-neck__fret--open` styles if any exist (currently there are none — line 14 uses it as a class but `.guitar-neck__fret` styles in line 70-79 apply to it via inheritance)

**CSS considerations**:
- `.guitar-neck__nut-label` currently has `width: 20px; min-width: 20px; height: 22px;`
- The open note dot should appear centered or to the right of the string name
- Since the nut-label is narrow, we may want to overlay the note rather than add it inline

**Alternative approach — overlay**: Keep the nut-label at 20px and use `position: absolute` for the open note dot:

```scss
.guitar-neck__nut-label {
  position: relative;
  
  .guitar-neck__open-note-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 16px;
    height: 16px;
    font-size: 8px;
  }
}
```

#### 3. Fret Index Row

Verify the fret indices row still aligns correctly. The spacer (`.guitar-neck__fret-index-spacer`) is already 20px matching the nut-label width, so it should remain aligned.

#### 4. Update Tests (if applicable)

Check [`freatboard.component.spec.ts`](src/app/freatboard/freatboard.component.spec.ts) to see if any tests reference the open fret behavior and update accordingly.

#### 5. Build & Test

- Run `npm test` to verify no regressions
- Run `npm run build` to verify TypeScript/template compilation

## Visual Impact

| State | Before | After |
|---|---|---|
| No scale/chord selected | All strings: nut-label only | Same (no open note shown) |
| Scale/chord with open notes | Some strings get extra `.fret--open` div causing misalignment | Open note shown inside nut-label, all strings equal |
| "Open" preset (range 0-4) | Open notes shown as fret 0 | Open notes shown in nut-label |

## Edge Cases

1. **Range toolbar with `minFret: 0`** — the `isNoteInRange(0)` check still works correctly; open notes only show when the range includes fret 0
2. **"Open" preset (min: 0, max: 4)** — open notes properly shown in nut-labels, frets 1-4 shown normally
3. **No open notes in pattern** — nut-label shows only string name, no dot; equal child count maintained
4. **Interval colors on open notes** — preserved via `getNoteInterval(string, 0)` in the nut-label's inner content

## Mermaid Diagram — Data Flow

```mermaid
flowchart TD
    A[User selects chord/scale] --> B[Command.execute]
    B --> C[FretboardOrchestrationService]
    C --> D[noteService.findPositionsByScaleNotes]
    D --> E[guitarNeckService.applyHighlightedNotes]
    E --> F[visible=true on matching notes]
    F --> G[intervalService.markIntervals]
    G --> H[notes array updated with intervals]
    H --> I[FreatboardComponent renders]
    I --> J{isNoteOnFret string, 0?}
    J -- Yes --> K[Show open note in nut-label]
    J -- No --> L[Show only string name in nut-label]
    K --> M[All strings: 25 flex children]
    L --> M
    M --> N[Borders align correctly]
```
