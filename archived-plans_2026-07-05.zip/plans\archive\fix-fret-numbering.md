# Plan: Fix fret numbering and column count

## Problem

The `frets` array in `FretboardStateService` contains `[0, 1, ..., 22]` (23 elements) but the fretboard has 25 note positions (frets 0–24). This means frets 23 and 24 are never rendered. Additionally, changing `{{ fret }}` to `{{ fret + 1 }}` in the header shifted labels by 1 — open string shows "1", fret 3 shows "4", etc.

## Root cause

```typescript
// guitar-neck.service.ts:12
frets = Array.from({ length: neckConfig.numberOfFrets - 1 }, (_, i) => i);
// numberOfFrets = 24 → length = 23 → [0..22]
// Should be numberOfFrets + 1 (25) → [0..24] — all positions
```

## Changes

### 1. `guitar-neck.service.ts:12` — Fix array size
```diff
- frets = Array.from({ length: neckConfig.numberOfFrets - 1 }, (_, i) => i);
+ frets = Array.from({ length: neckConfig.numberOfFrets + 1 }, (_, i) => i);
```
`[0..24]` — 25 elements matching all note positions.

### 2. `freatboard.component.html:7` — Fix header labels
```diff
- <div *ngFor="let fret of frets" class="guitar-neck__fret-index-cell">{{ fret + 1 }}</div>
+ <div *ngFor="let fret of frets" class="guitar-neck__fret-index-cell">{{ fret === 0 ? '' : fret }}</div>
```
Open string gets no label. Frets 1-24 show correct numbers.

### 3. `guitar-neck.service.spec.ts:43` — Fix test assertion
```diff
- expect(service.frets.length).toBe(neckConfig.numberOfFrets - 1);
+ expect(service.frets.length).toBe(neckConfig.numberOfFrets + 1);
```

### 4. `freatboard.component.spec.ts:49` — Fix fret cell count
```diff
- expect(component.frets.length * component.strings.length).toBe(fretElements.length);
```
The count will automatically match `25 * 6 = 150` after the array fix.

### 5. `freatboard.component.spec.ts:60-61` — Fix last label value
```diff
- expect(fretIndexElements[fretIndexElements.length - 1].nativeElement.textContent.trim()).toBe(String(component.frets.length));
+ expect(fretIndexElements[fretIndexElements.length - 1].nativeElement.textContent.trim()).toBe(String(component.frets.length - 1));
```
Last label should be `24`, not `frets.length` (which is 25).

## Impact

- All 25 note positions (0-24) are now rendered as columns
- Header labels: no label for open string, "1" for first fret, "24" for last
- Template already handles `fret === 0` with special styling (`.guitar-neck__fret-number`)
- Rendering not affected: `isNoteOnFret(string, fret)` uses the same fret value from the array
- `RangeToolbar` and `FretRangeSelector` work with fret numbers 0-24 — unchanged

## Verification

1. Build: `npm run build`
2. Tests: `npm test` — expect 53/53 SUCCESS
3. Manual: Open string has no number, first fret shows "1", last shows "24"
