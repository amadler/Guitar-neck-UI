# Layout — Specyfikacja techniczna dla grafika

## Stack CSS
- Brak Bootstrapa — własne style w SCSS
- Flexbox (display: flex)
- CSS Custom Properties dla kolorów i rozmiarów
- Angular standalone components z emulacją widoczności: ViewEncapsulation.Emulated (domyślne)

## Komponenty (selektory)

| Komponent | Selektor | Źródło | Uwagi |
|-----------|----------|--------|-------|
| HomePage (wrapper) | `app-home-page` | src/app/home-page | `.flex-container` w styles.scss |
| RangeToolbar | `app-range-toolbar` | src/app/range-toolbar | `.range-toolbar` |
| Fretboard | `app-freatboard` | src/app/freatboard | `.guitar-neck`, `.guitar-neck__fretboard` |
| Legend | `app-legend` | src/app/freatboard/components/legend | `.legend` |
| Toolbox | `lib-toolbox-form` | guitar-toolbox-lib (npm) | **Nie modyfikować** |
| AI Chat | `lib-chat` | projects/guitar-chat | POSTPONED |
| Nut label | — | — | `.guitar-neck__nut-label` |
| Fret cell | — | — | `.guitar-neck__fret` |
| Note dot | — | — | `.guitar-neck__dot` |
| Interval | — | — | `.guitar-neck__root`, `.guitar-neck__minor-3rd`, itd. |

## Obecna struktura HTML

```html
<app-home-page>
  <app-guitar-neck>
    <app-freatboard>
      <app-range-toolbar />
      <div class="guitar-neck__fretboard">
        <!-- header z numerami progów -->
        <!-- strings + frets + nuty -->
      </div>
      <app-legend />
    </app-freatboard>
  </app-guitar-neck>
  <lib-toolbox-form />   <!-- pod gryfem -->
</app-home-page>
```

## CSS Variables (styles.scss :root)

```css
/* Guitar neck theme */
--guitar-neck-bg-color: #333;
--guitar-neck-fret-color: rgba(255,255,255,0.15);
--guitar-neck-string-color: rgba(255,255,255,0.2);
--guitar-neck-dot-color: rgba(255,255,255,0.25);
--guitar-neck-open-string-color: #bf500b;
--guitar-neck-dot-size: 26px;
--guitar-neck-dot-border-radius: 50%;
--guitar-neck-marker-bg-color: rgb(168,110,110);
--guitar-neck-marker--color: rgb(255,255,255);

/* Interval colors */
--interval-root: rgb(128,0,15);
--interval-minor-2nd: rgb(230,92,0);
--interval-major-2nd: rgb(255,136,0);
--interval-minor-3rd: rgb(219,180,0);
--interval-major-3rd: rgb(139,195,0);
--interval-perfect-4th: rgb(0,153,76);
--interval-diminished-5th: rgb(0,128,128);
--interval-perfect-5th: rgb(0,102,204);
--interval-minor-6th: rgb(106,0,179);
--interval-major-6th: rgb(153,51,204);
--interval-minor-7th: rgb(179,0,134);
--interval-major-7th: rgb(160,160,160);
```

## Note dot class binding

```html
<div [ngClass]="['guitar-neck__dot guitar-neck__'+interval]">
```

Klasy: `.guitar-neck__root`, `.guitar-neck__minor-3rd`, `.guitar-neck__major-3rd`, `.guitar-neck__perfect-5th`, itd.

## Zasady dla grafika

1. **Nie modyfikować** `lib-toolbox-form` — zewnętrzna biblioteka npm
2. **Nie zmieniać** klas `.guitar-neck__*` — używane przez wiele komponentów
3. **Strona nigdy nie scrolluje** — tylko aktywny panel docka scrolluje
4. **Dock (planowany)** — kontener CSS, nie zna Toolboxa ani AI. Zawiera zakładki (Tab → Component). 3 stany: collapsed / expanded 30-40% / maximized 70-80%.
5. **Pixel perfect nie jest wymagany** — projekt ewoluuje
6. **Layout ma działać** w `display: flex` (nie grid)
7. **Header (planowany)** — shell aplikacji (logo, nazwa, theme toggle, future: GitHub, Settings, Help, User)
8. **Wszystkie kolory interwałów** są zdefiniowane jako CSS vars — zmiana palety = zmiana zmiennych
