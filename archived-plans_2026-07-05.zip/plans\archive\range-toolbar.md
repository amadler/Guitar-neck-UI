# Plan: RangeToolbar

## Cel
Dodać pasek presetów zakresu progów nad gryfem, bez przebudowy istniejącego `FretRangeSelectorComponent`.

## Architektura

```
FreatboardComponent
├── RangeToolbar (NOWY)
│   ├── Presets: [Open] [5th] [9th] [12th] [Full]
│   └── FretRangeSelector (istniejący, bez zmian)
├── Fretboard
└── Legend
```

## Zasady

- `RangeToolbar` nie zna przyszłych features (left handed, tuning itp.)
- `FretRangeSelector` nie jest modyfikowany — tylko włożony w nowy wrapper
- Presety emitują ten sam `rangeChange` co suwak

## Implementacja

### 1. Nowy komponent: `RangeToolbarComponent`

**Selektor:** `app-range-toolbar`
**Input/Output:** `@Output() rangeChange = new EventEmitter<{minFret, maxFret}>()`

**Presets:**
| Przycisk | minFret | maxFret |
|----------|---------|---------|
| Open | 0 | 4 |
| 5th | 5 | 8 |
| 9th | 9 | 12 |
| 12th | 12 | 15 |
| Full | 0 | 24 |

**Stan:** aktywny preset (class `.active` na wybranym)

### 2. Template

```html
<div class="range-toolbar">
  <div class="range-toolbar__presets">
    <button *ngFor="let preset of presets"
            [class.active]="preset.min === activePreset.min && preset.max === activePreset.max"
            (click)="selectPreset(preset)">
      {{ preset.label }}
    </button>
    <button [class.active]="isCustom"
            (click)="selectCustom()">
      Custom
    </button>
  </div>
  <app-fret-range-selector (rangeChange)="onSliderChange($event)"></app-fret-range-selector>
</div>
```

### 3. RangeToolbar — logika

- Gdy użytkownik kliknie preset → emituje `rangeChange` + ustawia `activePreset`
- Gdy użytkownik przesunie suwak → emituje `rangeChange` + ustawia `isCustom = true`
- `isCustom` = true gdy suwak nie odpowiada żadnemu presetowi

### 4. Zmiana w FreatboardComponent

- Zastąpić `<app-fret-range-selector>` nowym `<app-range-toolbar>`
- Ten sam binding: `(rangeChange)="fretRange = $event"`
- Usunąć import `FretRangeSelectorComponent` z `freatboard.component.ts`, dodać `RangeToolbarComponent`

### 5. Pliki

| Plik | Operacja |
|------|----------|
| `src/app/range-toolbar/range-toolbar.component.ts` | NOWY |
| `src/app/range-toolbar/range-toolbar.component.html` | NOWY |
| `src/app/range-toolbar/range-toolbar.component.scss` | NOWY |
| `src/app/freatboard/freatboard.component.ts` | Zmiana importów + template |
| `src/app/freatboard/freatboard.component.html` | Zamiana `<app-fret-range-selector>` → `<app-range-toolbar>` |

## Testowanie

- Kliknięcie presetu emituje poprawne wartości min/max
- Przesunięcie suwaka ustawia `isCustom` i emituje wartości z suwaka
- `FretRangeSelectorComponent` nadal działa (testy istniejące — nie zmieniamy go)

## Kryteria akceptacji

- [ ] Presety ustawiają zakres progów
- [ ] Suwak działa tak samo jak przed zmianą
- [ ] Przycisk Custom aktywny gdy suwak nie pasuje do presetów
- [ ] CSS: presety w jednym rzędzie przed suwakiem
- [ ] Zero zmian w logice FretRangeSelector
- [ ] 52/52 testów przechodzi
