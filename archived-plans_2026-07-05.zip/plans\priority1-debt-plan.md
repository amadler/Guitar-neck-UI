# Plan spłaty długu technicznego — Priority 1

## Status po analizie kodu

| Item w BACKLOG.md | Status w backlogu | Faktyczny stan |
|---|---|---|
| `toolboxSubmit()` command factory | OPEN | 🔴 Do zrobienia |
| FretboardStateService O(n) → O(1) | OPEN | 🔴 Do zrobienia |
| Template woła serwisy bezpośrednio | OPEN | ✅ **Już FIXED** |
| Remove unused uuid from GuitarNote | OPEN | ✅ **Już FIXED** |
| MusicSelection domain abstraction | OPEN | 🔴 Do zrobienia |

> **Aktualizacja BACKLOG.md**: Po implementacji należy zmienić status 2 itemów na FIXED.

---

## Task 1: `toolboxSubmit()` → command factory

**Plik:** [`src/app/home-page/home-page.component.ts`](src/app/home-page/home-page.component.ts)
**Test:** [`src/app/services/guitar-neck.service.spec.ts`](src/app/services/guitar-neck.service.spec.ts) + ewentualnie test dla home-page

### Co jest teraz
Metoda `toolboxSubmit()` (linie 43-73) to jeden blok `if/else if/else` który ręcznie konstruuje 5 typów komend:
- `DisplayCustomPatternCommand`
- `DisplayAllNotesCommand`
- `DisplaySingleNoteCommand`
- `DisplayChordCommand`
- `DisplayScaleCommand`

Każdy przypadek też miesza logikę z `patternBuilder.setCurrentPattern()`/`clearCurrentPattern()`.

### Co trzeba zrobić

1. **Dodać prywatne metody builder** w `HomePageComponent`:

```typescript
private buildCustomPatternCommand(musicElements: number[], keys: string): Command {
  return new DisplayCustomPatternCommand(
    this.fretboardOrchestrationService, musicElements, keys
  );
}

private buildAllNotesCommand(): Command {
  return new DisplayAllNotesCommand(this.fretboardOrchestrationService);
}

private buildSingleNoteCommand(keys: string): Command {
  return new DisplaySingleNoteCommand(this.fretboardOrchestrationService, keys);
}

private buildChordCommand(name: string, root: string): Command {
  this.patternBuilder.setCurrentPattern(name, root, 'chord');
  return new DisplayChordCommand(this.fretboardOrchestrationService, name, root);
}

private buildScaleCommand(name: string, root: string): Command {
  this.patternBuilder.setCurrentPattern(name, root, 'scale');
  return new DisplayScaleCommand(this.fretboardOrchestrationService, name, root);
}
```

2. **Uprościć `toolboxSubmit()`** do postaci dyspozytora:

```typescript
toolboxSubmit(event: ToolboxSearchQuery): void {
  this.guitarNeckService.clearFretboard();
  this.patternBuilder.clearCurrentPattern();

  const { musicElements, keys, type } = event;
  let command: Command | null = null;

  if (type === 'custom' && Array.isArray(musicElements)) {
    command = this.buildCustomPatternCommand(musicElements, keys);
  } else if (type === 'basic' && musicElements === 'All notes') {
    command = this.buildAllNotesCommand();
  } else if (type === 'basic') {
    command = this.buildSingleNoteCommand(keys);
  } else if (type === 'chord' && typeof musicElements === 'string') {
    command = this.buildChordCommand(musicElements, keys);
  } else if (type === 'scale' && typeof musicElements === 'string') {
    command = this.buildScaleCommand(musicElements, keys);
  }

  command?.execute();
}
```

3. **Dodać testy** dla każdej ścieżki buildera (opcjonalnie — istniejący `npm test` powinien dalej przechodzić).

### Kryteria akceptacji
- `toolboxSubmit()` deleguje do builderów zamiast inline konstrukcji
- `patternBuilder.setCurrentPattern()` wołany tylko dla `chord` i `scale` (zachowanie istniejące)
- `npm run build` przechodzi
- `npm test` przechodzi

---

## Task 2: FretboardStateService O(n) → O(1)

**Plik:** [`src/app/services/guitar-neck.service.ts`](src/app/services/guitar-neck.service.ts)
**Test:** [`src/app/services/guitar-neck.service.spec.ts`](src/app/services/guitar-neck.service.spec.ts)

### Co jest teraz
- `applyHighlightedNotes()` używa `this.notes.filter(n => n.note === noteToShow.note && n.string === noteToShow.string)` — O(n) per wywołanie
- Inne metody też iterują po całej tablicy (`forEach`)
- 150 nut (6 strun × 25 progów) × wiele operacji = zbędne O(n)

### Co trzeba zrobić

1. **Dodać `Map<string, GuitarNote>`** w `FretboardStateService`:

```typescript
private notesMap: Map<string, GuitarNote> = new Map();

// w konstruktorze, po inicjalizacji notes:
private buildNotesMap(): void {
  this.notesMap.clear();
  this.notes.forEach(note => {
    const key = `${note.string}-${note.fret}`;
    this.notesMap.set(key, note);
  });
}
```

2. **Zoptymalizować `applyHighlightedNotes()`**:

```typescript
applyHighlightedNotes(notes: GuitarNote[]): GuitarNote[] {
  // Reset everything
  this.notes.forEach(note => {
    note.visible = false;
    note.selected = false;
  });

  // Direct O(1) lookup
  notes.forEach(noteToShow => {
    const key = `${noteToShow.string}-${noteToShow.fret}`;
    const note = this.notesMap.get(key);
    if (note) {
      note.visible = true;
      note.selected = true;
    }
  });

  this.hasActiveResult = notes.length > 0;
  return this.notes.filter(note => note.selected);
}
```

3. **Zaktualizować `hideAllNotes()`, `showAll()`, `clearSelection()`** — te metody już używają `forEach` na `this.notes`, co jest O(n) i OK (muszą dotknąć każdą nutę). Nie wymagają zmiany.

4. **Zaktualizować testy** — sprawdzić czy `notesMap` jest poprawnie budowana i używana.

### Kryteria akceptacji
- `applyHighlightedNotes()` nie używa `Array.find()` ani `Array.filter()` na pełnej tablicy w hot path
- `npm test` przechodzi
- `npm run build` przechodzi
- Brak regresji w zaznaczaniu nut na gryfie

---

## Task 3: MusicSelection domain abstraction

**Nowy plik:** [`src/app/shared/model/music-selection.ts`](src/app/shared/model/music-selection.ts)
**Modyfikacja:** [`src/app/services/guitar-neck.service.ts`](src/app/services/guitar-neck.service.ts), [`src/app/shared/UICommands.ts`](src/app/shared/UICommands.ts)

### Co jest teraz
- `PatternInfo` istnieje w [`patternInfo.ts`](src/app/shared/model/patternInfo.ts) ale obejmuje tylko `scale | chord`
- `UICommands.ts` ma osobne klasy komend, każda z własnymi typami parametrów
- Nie ma jednego interfejsu reprezentującego "aktualny wybór muzyczny"

### Co trzeba zrobić

1. **Stworzyć `MusicSelection` interface** w nowym pliku:

```typescript
// src/app/shared/model/music-selection.ts

export type MusicSelectionType = 'scale' | 'chord' | 'note' | 'custom' | 'all-notes';

export interface MusicSelection {
  type: MusicSelectionType;
  name?: string;        // pattern name for scale/chord
  rootNote?: string;    // root/tonic note
  notes?: string[];     // resolved note names
  intervals?: number[]; // for custom patterns
}
```

2. **Dodać `currentSelection: MusicSelection | null`** do `FretboardStateService` jako single source of truth.

3. **Zintegrować z `PatternBuilderService`** — `setCurrentPattern()` może też ustawiać `currentSelection`.

4. **Zaktualizować `UICommands`** — opcjonalnie, aby Command mógł zwrócić `MusicSelection` po wykonaniu.

### Kryteria akceptacji
- `MusicSelection` interfejs zdefiniowany i exportowany
- `FretboardStateService` przechowuje `currentSelection`
- `npm run build` przechodzi
- `npm test` przechodzi

---

## Kolejność wykonania

1. **Task 1** — `toolboxSubmit()` command factory (najmniejszy risk, izolowana zmiana)
2. **Task 2** — FretboardStateService O(n) → O(1) (średni risk, zmiana w serwisie stanu)
3. **Task 3** — MusicSelection domain abstraction (największy risk, nowa abstrakcja)
4. **Aktualizacja BACKLOG.md** — zmiana statusu 2 itemów na FIXED, pozostałe na FIXED po implementacji

---

## Diagram przepływu (Task 1)

```mermaid
flowchart LR
    A[toolboxSubmit event] --> B{type?}
    B -->|custom| C[buildCustomPatternCommand]
    B -->|basic + All notes| D[buildAllNotesCommand]
    B -->|basic| E[buildSingleNoteCommand]
    B -->|chord| F[buildChordCommand]
    B -->|scale| G[buildScaleCommand]
    C --> H[command.execute]
    D --> H
    E --> H
    F --> H
    G --> H
    H --> I[FretboardOrchestrationService]
```

## Diagram przepływu (Task 2)

```mermaid
flowchart LR
    A[applyHighlightedNotes] --> B[Reset all notes: visible=false, selected=false]
    B --> C[For each noteToShow: build key string-fret]
    C --> D[notesMap.getkey - O1 lookup]
    D --> E{found?}
    E -->|yes| F[Set visible=true, selected=true]
    E -->|no| G[Skip - no note at this position]
    F --> H[Set hasActiveResult]
    G --> H
