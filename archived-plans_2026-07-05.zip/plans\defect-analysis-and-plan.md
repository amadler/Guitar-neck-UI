# Guitar Neck UI — Defect Analysis & Work Plan

## Overview

This document analyzes 12 reported defects/improvements and provides a detailed, ordered plan for implementation. Each issue includes root cause analysis, location, and proposed fix.

---

## 1. Fret range custom does not sync with preset selection

**Root Cause:** When `selectPreset()` is called for a non-custom preset, the range is emitted but `fretRange` is set on [`FreatboardComponent`](Guitar neck UI/src/app/freatboard/freatboard.component.ts:41). However, the `frets` array used in the `*ngFor` template loop is statically generated once (line 27) and never re-filtered. So all frets are always rendered — only notes outside range are hidden via [`isNoteInRange()`](Guitar neck UI/src/app/freatboard/freatboard.component.ts:44).

Additionally, when switching from Custom back to a preset, the Custom values (`customMin`, `customMax`) are not reset, so re-entering Custom mode shows stale values.

**Scope:** [`RangeToolbarComponent`](Guitar neck UI/src/app/range-toolbar/range-toolbar.component.ts) + [`FreatboardComponent`](Guitar neck UI/src/app/freatboard/freatboard.component.ts)

**Fix:**
- In [`RangeToolbarComponent`](Guitar neck UI/src/app/range-toolbar/range-toolbar.component.ts:39-48), reset `customMin`/`customMax` to match the selected preset when switching from Custom to a preset.
- In [`FreatboardComponent`](Guitar neck UI/src/app/freatboard/freatboard.component.ts), compute a filtered `visibleFrets` array based on `fretRange` for the `*ngFor` loop, instead of rendering all frets.
- Update the html template to iterate over `visibleFrets` instead of `frets`.

---

## 2. Neutral dots are invisible

**Root Cause:** When `markerDisplayMode` is `'neutral-dots'`, [`getMarkerCssClass()`](Guitar neck UI/src/app/services/guitar-neck.service.ts:103-112) returns an empty string `''`. The dot gets only base class `.guitar-neck__dot` with `background-color: var(--guitar-neck-marker-bg-color)` = `rgba(168, 110, 110, 0.3)` — very transparent. [`showNoteLabels`](Guitar neck UI/src/app/services/guitar-neck.service.ts:115-117) returns `false`, so no text labels appear either.

**Fix:** Add a CSS class for neutral-dots mode with white background while keeping the existing dot style (border-radius, size, etc.).

---

## 3. Remove Toolbox buttons and knobs

**Scope:** [`home-page.component.html`](Guitar neck UI/src/app/home-page/home-page.component.html) lines 34-37 (dock-actions)

**Fix:** Remove the dock action buttons (`⌄`, `−`, `□`, `×`) from the dock header.

---

## 4. Legend should indicate which intervals are actually used on the fretboard

**Status:** ⏸️ Postponed — user will think about the approach.

---

## 5. Help button poorly visible and should auto-show popup on first visit

**Root Cause:** The "?" button in [`header.component.html`](Guitar neck UI/src/app/header/header.component.html:10) is just text with class `icon-btn`. It has no special visual treatment. No first-visit detection exists.

**Fix:**
- Make the "?" button more prominent (add background color, make it larger, use a circle with contrast).
- Add first-visit detection using `localStorage` — if no `'guitar-neck-ui-visited'` key exists, auto-show the help modal and set the key.

---

## 6. Remove custom_metal_riff from ALL repositories

**Note:** Already commented out in [`scaleTypes.ts`](shared/src/models/scaleTypes.ts:123-126). Need to delegate to repo agents to verify no traces remain across all sub-projects.

---

## 7. Add musical scale/chord patterns

**Status:** ⏸️ To discuss — user wants to discuss patterns like C Hungarian Minor, whole/half step schemas.

---

## 8. Sort scales and chords alphabetically in Toolbox selects

**Fix:** Delegate to repo agent — add `.sort()` after mapping in [`toolbox-form.component.ts`](guitar-toolbox/projects/guitar-toolbox-lib/src/lib/toolbox-form/toolbox-form.component.ts:31-33).

---

## 9. Guitar Neck has different border around container

**Fix:** Add consistent border styling to `#guitar-neck-container` matching the design system (`--app-border-strong`, `--radius-lg`, `--shadow-soft`).

---

## 10. Add loading spinner for API calls

**Scope:** [`MusicPatternApiService`](Guitar neck UI/src/app/services/scales-and-triads.service.ts), [`FretboardOrchestrationService`](Guitar neck UI/src/app/services/music-theory-facade.service.ts), [`HomePageComponent`](Guitar neck UI/src/app/home-page/home-page.component.ts)

**Fix:** Add `loading$` observable + spinner overlay on the fretboard.

---

## 11. Password protection

**Priority:** 🟢 Low — defer to later.

---

## 12. RWD overhaul

**Status:** ⏸️ Separate session — user wants to participate as peer.

---

## Implementation Priority

| Priority | Issue | Effort | Notes |
|----------|-------|--------|-------|
| **P0** | 10 — Loader for API | Low | UX critical — API is slow |
| **P1** | 1 — Fret range sync | Medium | Functional defect |
| **P1** | 2 — Neutral dots invisible | Low | Functional defect |
| **P1** | 3 — Remove Toolbox buttons | Low | Cleanup |
| **P1** | 5 — Help button + first visit | Low | UX polish |
| **P1** | 9 — Guitar Neck border | Low | Visual polish |
| **P2** | 6 — Remove metal riff | Low | Delegate to repo agents |
| **P2** | 8 — Sort selects | Low | Delegate to repo agents |
| **P3** | 4 — Legend indicators | Medium | User will think about approach |
| **P3** | 7 — Add musical patterns | Medium | To discuss |
| **P3** | 11 — Password protection | Medium | Low priority |
| **P4** | 12 — RWD overhaul | High | Separate session with user |

---

## Execution Plan

### Phase 1 — Immediate (Code mode)
1. Fix neutral dots visibility (white dots, keep style)
2. Fix fret range custom sync with preset selection
3. Remove unnecessary Toolbox buttons/knobs
4. Improve help button visibility + first visit popup
5. Fix Guitar Neck container border consistency
6. Add loading spinner for API calls

### Phase 2 — Delegate to repo agents
7. Remove custom_metal_riff from all repos
8. Sort scales/chords alphabetically in Toolbox selects

### Phase 3 — Discuss & decide
9. Add musical scale/chord patterns
10. Legend interval indicators
11. Password protection

### Phase 4 — Separate session
12. RWD overhaul (user as peer)