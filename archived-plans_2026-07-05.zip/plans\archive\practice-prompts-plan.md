# Practice Prompts for Selected Pattern

## Problem Summary

After selecting a scale or chord, the app shows the pattern info (notes, intervals, semitones, steps) in the `PatternDisplayComponent`, but users may not know what to actually *do* with that information on the guitar.

## Current Architecture

- **`PatternInfo`** (`src/app/shared/model/patternInfo.ts:1`) — model with `type: 'scale' | 'chord'` to distinguish scale vs chord selections
- **`FretboardStateService`** (`src/app/services/guitar-neck.service.ts:27`) — holds `currentPattern: PatternInfo | null`; set via `setCurrentPattern()` from `HomePageComponent.toolboxSubmit()`
- **`PatternDisplayComponent`** (`src/app/pattern-display/pattern-display.component.ts:12`) — standalone component that renders the pattern panel when `currentPattern` is truthy
  - Template: `*ngIf="guitarNeckService.currentPattern as p"` gates the entire panel
- **`HomePageComponent`** (`src/app/home-page/home-page.component.ts:41-71`) — `toolboxSubmit()` determines pattern type and calls `setCurrentPattern()`

When `currentPattern` is null (e.g., after "All notes", single note, custom pattern, or clear), the pattern panel is hidden entirely.

## Proposed Approach

### Option A (recommended): Extend `PatternDisplayComponent` directly

Add a practice prompts section inside the existing pattern panel. Prompts are defined as static arrays keyed by pattern type, rendered below the grid.

**Why not a separate component?**
- Prompts are tightly coupled to the pattern context
- They should appear/disappear together with the pattern panel
- No need for new service or state — just type-check `p.type`

### Data Flow

```
PatternInfo { type: 'scale' | 'chord' }
        │
        ▼
PatternDisplayComponent
  ├── reads p.type from currentPattern
  └── shows relevant prompts from a local constant/map
```

### Prompt Sets

**For scales (`type === 'scale'`):**
- "Play the scale ascending and descending"
- "Say note names while playing each note"
- "Play only root notes"
- "Play one note per metronome click"
- "Limit yourself to the selected fret range"

**For chords (`type === 'chord'`):**
- "Strum the chord — all strings at once"
- "Play arpeggio — one string at a time, up and down"
- "Say note names while playing"
- "Play one note per metronome click"
- "Limit yourself to the selected fret range"

### Template Structure

The prompts section would be added to `pattern-display.component.html` inside the existing `*ngIf` block:

```
<div class="pattern-panel" *ngIf="guitarNeckService.currentPattern as p">
  <!-- existing: title, grid of notes/intervals/semitones/steps -->

  <!-- new: practice prompts -->
  <div class="pattern-panel__prompts">
    <div class="pattern-panel__prompts-title">Practice ideas</div>
    <ul class="pattern-panel__prompts-list">
      <li *ngFor="let prompt of getPromptsForType(p.type)">{{ prompt }}</li>
    </ul>
  </div>
</div>
```

### Implementation Details

1. **Define prompts map** — a `private` readonly map or getter in the component:
   ```typescript
   private readonly scalePrompts = [
     'Play the scale ascending and descending',
     'Say note names while playing each note',
     'Play only root notes',
     'Play one note per metronome click',
     'Limit yourself to the selected fret range',
   ];

   private readonly chordPrompts = [
     'Strum the chord — all strings at once',
     'Play arpeggio, one string at a time, up and down',
     'Say note names while playing',
     'Play one note per metronome click',
     'Limit yourself to the selected fret range',
   ];

   getPromptsForType(type: 'scale' | 'chord'): string[] {
     return type === 'scale' ? this.scalePrompts : this.chordPrompts;
   }
   ```

2. **Add CSS** — simple bullet list below the grid, using existing design tokens

3. **Add template** — inside existing `*ngIf` block, after the `pattern-panel__grid` div

### Edge Cases to Handle

| Case | Behavior |
|------|----------|
| `currentPattern` is `null` | Panel hidden entirely (no prompts shown) |
| Pattern is a single note or custom type | `currentPattern` is null per `toolboxSubmit()` logic, so no prompts |
| Pattern is an unknown/invalid type | `getPromptsForType()` always receives a valid union type at compile time; at runtime only 'scale' or 'chord' are set by `setCurrentPattern()` — `chordPrompts` used as fallback for safety |

### Files to Change

| File | Change |
|------|--------|
| `src/app/pattern-display/pattern-display.component.ts` | Add `getPromptsForType()` method, prompt arrays |
| `src/app/pattern-display/pattern-display.component.html` | Add prompts section inside existing `*ngIf` |
| `src/app/pattern-display/pattern-display.component.scss` | Add `.pattern-panel__prompts` styles |
| `src/app/pattern-display/pattern-display.component.spec.ts` | Add test for prompts rendering |

### Future Extensions (not in MVP)

- Rule-based prompts (e.g., "Break pattern into smaller sections" if more than 7 notes)
- User-configurable prompts
- Scoring/tracking (explicitly out of scope for MVP)

## Summary

This is a small, contained UI change that leverages the existing `PatternInfo.type` field. No new services, components, or state management needed. The prompts are static text arrays defined in the component, rendered with a simple `*ngFor`. Total estimated changes: 3 files (ts, html, scss) plus optional spec updates.
