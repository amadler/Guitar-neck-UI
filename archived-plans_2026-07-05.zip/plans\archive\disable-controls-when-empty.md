# Plan: Disable result display controls when fretboard is empty

## Problem

Controls that affect how an existing result is displayed (interval/show notes/marker style/clear) remain active even when no scale, chord, note, or custom pattern is shown on the fretboard. This is confusing — the user can toggle display modes with nothing to display.

## Architecture

### Current state flow

```
FretboardStateService
├── markerDisplayMode: MarkerDisplayMode  → controls `getMarkerCssClass()` and `showNoteLabels`
├── notes: GuitarNote[]                   → `selected`, `visible` flags on each note
├── activeStrings: boolean[]              → per-string visibility filter
├── clearFretboard()                      → hides all notes, clears selections, removes intervals
└── applyHighlightedNotes()               ← called when a result is shown
```

### Control ownership

| Control | Component | Currently active when empty? | Action |
|---------|-----------|------------------------------|--------|
| Fret range | `RangeToolbarComponent` | Yes — keep as is | No change |
| String toggle | `StringToggleComponent` | Yes — keep as is | No change |
| Toolbox | `ToolboxFormComponent` (external lib) | Yes — keep as is | No change |
| Marker style (`<select>`) | `LegendComponent` | Yes | Add `[disabled]` |
| Note/intervals display (the interval legend + marker rendering) | `LegendComponent` + `FreatboardComponent` | Yes | Disable marker select (controls all modes); optionally dim/hide interval legend |
| Clear | New button (to be added) | N/A | Add button, `[disabled]` when no result |

## Implementation Steps

### Step 1: Add `hasActiveResult` to [`FretboardStateService`](src/app/services/guitar-neck.service.ts:18)

Add a public property that tracks whether the fretboard currently displays a meaningful result.

```typescript
/** Whether a scale, chord, note or custom pattern is currently shown on the fretboard. */
hasActiveResult = false;
```

Update it in key methods:

- **`applyHighlightedNotes(notes)`** (line 48) — after the operation, set `this.hasActiveResult = notes.length > 0` (if at least one note was highlighted, result is active)
- **`showAll()`** (line 85) — set `this.hasActiveResult = true` (displayAllNotes counts as a result)
- **`clearFretboard()`** (line 114) — set `this.hasActiveResult = false`
- **Constructor** (line 20) — initialize as `false` (no result yet)

### Step 2: Disable marker style `<select>` in [`LegendComponent`](src/app/legend/legend.component.html:22)

Bind `[disabled]="!guitarNeckService.hasActiveResult"` on the `<select>` element.

```html
<select [value]="guitarNeckService.markerDisplayMode"
        [disabled]="!guitarNeckService.hasActiveResult"
        (change)="guitarNeckService.markerDisplayMode = $any($event.target).value">
```

This disables switching between Interval colors / Note names / Neutral dots when no result is active. The interval legend section above remains visible (it's just a reference), but the control to change display mode is disabled.

### Step 3: Add "Clear" button to [`LegendComponent`](src/app/legend/legend.component.html)

Add a "Clear" button inside the `.legend-switches` div that resets the fretboard. It is disabled when `hasActiveResult` is false.

```html
<button class="clear-btn"
        [disabled]="!guitarNeckService.hasActiveResult"
        (click)="clearFretboard()">
  Clear
</button>
```

### Step 4: Add `clearFretboard()` method to [`LegendComponent`](src/app/legend/legend.component.ts)

Inject `FretboardOrchestrationService` (or `FretboardStateService`) and delegate to `clearFretboard()`.

The component already injects `FretboardStateService`. We can either:
- Use `guitarNeckService.clearFretboard()` directly (but this is already used internally by the facade)
- Use `FretboardOrchestrationService.resetFretboard()` (cleaner — uses the public API)

Option: Add `FretboardOrchestrationService` as a dependency and call `this.fretboardOrchestrationService.resetFretboard()`.

### Step 5: Update [LegendComponent spec](src/app/legend/legend.component.spec.ts)

Add tests:
- Verify the `<select>` is disabled when `hasActiveResult` is false
- Verify the `<select>` is enabled when `hasActiveResult` is true
- Verify the Clear button exists and is disabled when no result
- Verify clicking Clear calls `resetFretboard()`

### Step 6: Update [`FretboardStateService` spec](src/app/services/guitar-neck.service.spec.ts)

Add tests for `hasActiveResult`:
- Initial value is `false`
- After `applyHighlightedNotes()` with notes → `true`
- After `clearFretboard()` → `false`
- After `showAll()` → `true`
- After `applyHighlightedNotes()` with `[]` → `false`

## Edge cases

| Scenario | Expected behavior |
|----------|-------------------|
| User opens app, no interaction yet | Marker select disabled, Clear disabled |
| User selects a scale | Marker select enabled, Clear enabled |
| User clears the fretboard | Marker select disabled, Clear disabled |
| User clicks "All notes" (displayAllNotes) | Marker select enabled, Clear enabled (result is active) |
| User toggles strings | No effect on disabled state (string toggle is workspace filter) |
| User changes fret range | No effect on disabled state (fret range is workspace filter) |
| API call fails (0 notes returned) | `applyHighlightedNotes([])` → no notes highlighted → `hasActiveResult = false` → controls disabled |

## Files to change

| File | Change |
|------|--------|
| `src/app/services/guitar-neck.service.ts:18` | Add `hasActiveResult` property, wire into `applyHighlightedNotes()`, `showAll()`, `clearFretboard()` |
| `src/app/services/guitar-neck.service.spec.ts:220` | Add tests for `hasActiveResult` lifecycle |
| `src/app/legend/legend.component.html:22` | Add `[disabled]` to `<select>`, add Clear button |
| `src/app/legend/legend.component.ts:14` | Add `clearFretboard()` method, inject `FretboardOrchestrationService` |
| `src/app/legend/legend.component.spec.ts:28` | Add tests for disabled state and Clear button |
| `src/app/services/music-theory-facade.service.ts:59` | Already has `resetFretboard()` — no change needed |

## Visual change summary

```
Legend before:
┌─────────────────────────────┐
│ Intervals Legend             │
│ Root ♭2 2 ♭3 3 ...          │
│                              │
│ Markers: [Interval colors ▾] │  ← always active
└─────────────────────────────┘

Legend after (empty):
┌─────────────────────────────┐
│ Intervals Legend             │
│ Root ♭2 2 ♭3 3 ...          │
│                              │
│ Markers: [Interval colors ▾] │  ← disabled (greyed out)
│ [Clear]                      │  ← disabled (greyed out)
└─────────────────────────────┘

Legend after (result shown):
┌─────────────────────────────┐
│ Intervals Legend             │
│ Root ♭2 2 ♭3 3 ...          │
│                              │
│ Markers: [Interval colors ▾] │  ← active
│ [Clear]                      │  ← active
└─────────────────────────────┘
```

## Notes about "Notes" and "Intervals" controls

The backlog item lists "Notes" and "Intervals" as separate controls to disable. In the current UI, there are no independent Notes/Intervals toggle switches. Instead:

- **Note name display** is controlled by `markerDisplayMode` — in `neutral-dots` mode, labels are hidden; in `interval-colors` and `note-names` modes, labels are shown.
- **Interval colors** are controlled by `markerDisplayMode` too — in `interval-colors` mode, notes get color classes; in `note-names` and `neutral-dots` modes, they don't.
- **The interval legend list** (Root, ♭2, 2, ...) is a static reference that explains colors.

Since `markerDisplayMode` is the single control that governs Notes display + Intervals display + Marker style, disabling the `<select>` effectively disables all three. If future work introduces separate toggles (e.g., "Show note names" checkbox, "Show intervals" checkbox), each would also need `[disabled]` binding.
