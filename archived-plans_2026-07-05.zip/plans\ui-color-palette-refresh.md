# UI Color Palette Refresh — CSS-Only Palette Tuning

## Motivation

The current fretboard color palette evolved organically but has accumulated several UX issues:

1. **Over-saturated interval colors** — colors like `rgb(255, 136, 0)` (major 2nd) and `rgb(128, 0, 15)` (root) are aggressive and compete for attention on the dark fretboard.
2. **White fret markers compete with note markers** — both `.guitar-neck__dot-color: #fff` and note dots use white/light tones, making it hard to distinguish fret position markers from selected notes.
3. **No neutral note mode** — a planned "Note Names" display mode will need note markers that use a neutral color (white/light gray) but remain clearly distinguishable from fret markers.
4. **No visual hierarchy** — all intervals have roughly equal visual weight, making it hard to quickly identify the root or functionally important intervals (3rd, 5th, 7th).

## Scope

**CSS only.** No TypeScript changes. No component changes. No API changes. No logic changes. Only color values and opacity in two files.

## Files to Modify

| File | What changes |
|------|-------------|
| [`src/styles.scss`](src/styles.scss:48-59) | Interval custom properties (`--interval-*`), fret marker custom properties (`--guitar-neck-dot-color`) |
| [`src/app/freatboard/freatboard.component.scss`](src/app/freatboard/freatboard.component.scss:159-205) | Interval class background colors (duplicate of the CSS variables — currently hardcoded again here) |

## Current Color Reference

### Fretboard variables ([`src/styles.scss:34-43`](src/styles.scss:34-43))

```scss
--guitar-neck-bg-color: #333;        // dark fretboard
--guitar-neck-fret-color: #ddd;       // light fret lines
--guitar-neck-string-color: #ddd;     // light string lines
--guitar-neck-dot-color: #fff;        // white fret markers — too bright
--guitar-neck-dot-label-color: #aaa;  // fret number labels
--guitar-neck-open-string-color: #bf500b;  // nut label
--guitar-neck-dot-size: 20px;
--guitar-neck-dot-border-radius: 50%;
```

### Interval variables ([`src/styles.scss:48-59`](src/styles.scss:48-59))

| Variable | Current | HSL | Issue |
|----------|---------|-----|-------|
| `--interval-root` | `rgb(128, 0, 15)` | `hsl(353, 100%, 25%)` | Very dark, low contrast |
| `--interval-minor-2nd` | `rgb(230, 92, 0)` | `hsl(24, 100%, 45%)` | High saturation |
| `--interval-major-2nd` | `rgb(255, 136, 0)` | `hsl(32, 100%, 50%)` | High saturation |
| `--interval-minor-3rd` | `rgb(219, 180, 0)` | `hsl(49, 100%, 43%)` | High saturation |
| `--interval-major-3rd` | `rgb(139, 195, 0)` | `hsl(77, 100%, 38%)` | High saturation |
| `--interval-perfect-4th` | `rgb(0, 153, 76)` | `hsl(150, 100%, 30%)` | High saturation |
| `--interval-diminished-5th` | `rgb(0, 128, 128)` | `hsl(180, 100%, 25%)` | High saturation |
| `--interval-perfect-5th` | `rgb(0, 102, 204)` | `hsl(210, 100%, 40%)` | High saturation |
| `--interval-minor-6th` | `rgb(106, 0, 179)` | `hsl(276, 100%, 35%)` | High saturation |
| `--interval-major-6th` | `rgb(153, 51, 204)` | `hsl(280, 60%, 50%)` | High saturation |
| `--interval-minor-7th` | `rgb(179, 0, 134)` | `hsl(315, 100%, 35%)` | High saturation |
| `--interval-major-7th` | `rgb(160, 160, 160)` | `hsl(0, 0%, 63%)` | Already neutral/gray — good |

### Fret markers ([`src/styles.scss:38`](src/styles.scss:38))

- `--guitar-neck-dot-color: #fff` — pure white dots on frets 3, 5, 7, 9, 12 (double), 15, 17, 19, 21
- `.guitar-neck__marker` uses this as `background-color`

### Duplicated interval colors ([`src/app/freatboard/freatboard.component.scss:159-205`](src/app/freatboard/freatboard.component.scss:159-205))

The component SCSS re-declares the same interval colors using `var(--interval-*)` references — these are correct and will automatically inherit new values from `styles.scss` as long as the variable names don't change.

### Legend colors ([`src/styles.scss:419-430`](src/styles.scss:419-430))

The legend also has hardcoded interval colors, not CSS variables. These need to be updated to use the CSS variables or be changed to match.

## Proposed Palette

### Principles

1. **Preserve hue mapping** — users who already associate root=red, 3rd=green, 5th=blue keep that intuition.
2. **Reduce saturation** — drop from `100%` to `55-75%` range for all intervals.
3. **Slightly adjust lightness** — ensure readable against `#333` background.
4. **Root stays prominent** — root gets the most saturation and a subtle glow/outline.
5. **Fret markers go dark** — from `#fff` to `rgba(255, 255, 255, 0.2)` or a darker solid color, so they don't compete with note dots.

### Proposed Values

```scss
// Fret markers — much more subtle
--guitar-neck-dot-color: rgba(255, 255, 255, 0.15);
--guitar-neck-marker-bg-color: rgba(168, 110, 110, 0.3); // existing color, lowered opacity

// Intervals — reduced saturation, improved contrast
--interval-root:             rgb(168, 18, 35);     // desaturated red, still prominent
--interval-minor-2nd:        rgb(190, 95, 30);     // desaturated orange
--interval-major-2nd:        rgb(210, 130, 20);    // desaturated orange-yellow
--interval-minor-3rd:        rgb(185, 165, 25);    // desaturated yellow
--interval-major-3rd:        rgb(110, 175, 30);    // desaturated green
--interval-perfect-4th:      rgb(20, 140, 85);     // desaturated teal-green
--interval-diminished-5th:   rgb(20, 120, 115);    // desaturated teal
--interval-perfect-5th:      rgb(25, 105, 185);    // desaturated blue
--interval-minor-6th:        rgb(100, 45, 165);    // desaturated purple
--interval-major-6th:        rgb(140, 60, 180);    // desaturated violet
--interval-minor-7th:        rgb(155, 35, 115);    // desaturated magenta
--interval-major-7th:        rgb(145, 145, 145);   // slightly darker gray
```

### Visual Impact Summary

| Element | Before | After |
|---------|--------|-------|
| Root | Very dark red `hsl(353, 100%, 25%)` | Readable red `hsl(353, 65%, 36%)` |
| 3rd (major) | Bright green `hsl(77, 100%, 38%)` | Muted green `hsl(87, 65%, 40%)` |
| 5th (perfect) | Bright blue `hsl(210, 100%, 40%)` | Muted blue `hsl(210, 70%, 42%)` |
| Fret markers | Pure white `#fff` | Subtle `rgba(255,255,255,0.15)` |
| Note dot bg (default) | `rgb(168, 110, 110)` | Same color at 30% opacity |

## Changes

### 1. Update `src/styles.scss` — Interval variables and marker colors

Replace the current values at lines 38-39 (dot/marker colors) and lines 48-59 (interval variables) with the proposed palette.

```diff
-    --guitar-neck-dot-color: #fff;
-    --guitar-neck-dot-label-color: #aaa;
+    --guitar-neck-dot-color: rgba(255, 255, 255, 0.15);
+    --guitar-neck-dot-label-color: rgba(255, 255, 255, 0.4);

-    --guitar-neck-marker-bg-color: rgb(168, 110, 110);
+    --guitar-neck-marker-bg-color: rgba(168, 110, 110, 0.3);
```

```diff
-    --interval-root: rgb(128, 0, 15);
-    --interval-minor-2nd: rgb(230, 92, 0);
-    --interval-major-2nd: rgb(255, 136, 0);
-    --interval-minor-3rd: rgb(219, 180, 0);
-    --interval-major-3rd: rgb(139, 195, 0);
-    --interval-perfect-4th: rgb(0, 153, 76);
-    --interval-diminished-5th: rgb(0, 128, 128);
-    --interval-perfect-5th: rgb(0, 102, 204);
-    --interval-minor-6th: rgb(106, 0, 179);
-    --interval-major-6th: rgb(153, 51, 204);
-    --interval-minor-7th: rgb(179, 0, 134);
-    --interval-major-7th: rgb(160, 160, 160);
+    --interval-root:             rgb(168, 18, 35);
+    --interval-minor-2nd:        rgb(190, 95, 30);
+    --interval-major-2nd:        rgb(210, 130, 20);
+    --interval-minor-3rd:        rgb(185, 165, 25);
+    --interval-major-3rd:        rgb(110, 175, 30);
+    --interval-perfect-4th:      rgb(20, 140, 85);
+    --interval-diminished-5th:   rgb(20, 120, 115);
+    --interval-perfect-5th:      rgb(25, 105, 185);
+    --interval-minor-6th:        rgb(100, 45, 165);
+    --interval-major-6th:        rgb(140, 60, 180);
+    --interval-minor-7th:        rgb(155, 35, 115);
+    --interval-major-7th:        rgb(145, 145, 145);
```

### 2. Update `src/styles.scss` — Legend interval colors

The legend section (lines 419-430) also hardcodes interval colors. These should be changed to reference the CSS variables for consistency:

```diff
-.interval--root { background: #9b0014; }
-.interval--b2 { background: #cf3300; }
-.interval--2 { background: #ff8800; }
-.interval--b3 { background: #caa300; }
-.interval--3 { background: #519600; }
-.interval--4 { background: #047a45; }
-.interval--b5 { background: #00747d; }
-.interval--5 { background: #005fc9; }
-.interval--b6 { background: #5713c5; }
-.interval--6 { background: #9b20c3; }
-.interval--b7 { background: #bc138d; }
-.interval--7 { background: #8a8f91; }
+.interval--root { background: var(--interval-root); }
+.interval--b2 { background: var(--interval-minor-2nd); }
+.interval--2 { background: var(--interval-major-2nd); }
+.interval--b3 { background: var(--interval-minor-3rd); }
+.interval--3 { background: var(--interval-major-3rd); }
+.interval--4 { background: var(--interval-perfect-4th); }
+.interval--b5 { background: var(--interval-diminished-5th); }
+.interval--5 { background: var(--interval-perfect-5th); }
+.interval--b6 { background: var(--interval-minor-6th); }
+.interval--6 { background: var(--interval-major-6th); }
+.interval--b7 { background: var(--interval-minor-7th); }
+.interval--7 { background: var(--interval-major-7th); }
```

### 3. Update `src/styles.scss` — Mock note/interval colors

The mock-fretboard section (lines 370-372) also has hardcoded colors:

```diff
-.note--root { background: #9b0014; }
-.note--3 { background: #519600; }
-.note--5 { background: #005fc9; }
+.note--root { background: var(--interval-root); }
+.note--3 { background: var(--interval-major-3rd); }
+.note--5 { background: var(--interval-perfect-5th); }
```

### 4. No change needed — `src/app/freatboard/freatboard.component.scss`

The interval classes at lines 159-205 already use `var(--interval-*)` references, so they inherit the new values automatically. No change needed here.

### 5. Ensure neutral note color works

For the future "Note Names" mode, the current `.guitar-neck__dot` base style ([`freatboard.component.scss:136-154`](src/app/freatboard/freatboard.component.scss:136-154)) uses:
```scss
background-color: var(--guitar-neck-marker-bg-color); // becomes rgba(168, 110, 110, 0.3)
color: var(--guitar-neck-marker--color);               // rgb(255, 255, 255)
```

With the fret markers reduced to `rgba(255, 255, 255, 0.15)`, a neutral note dot at full white (`#fff` or `rgba(255, 255, 255, 0.9)`) will be clearly distinguishable. The current default note dot background (`rgba(168, 110, 110, 0.3)`) provides enough contrast against both the fretboard (`#333`) and the fret markers.

## Validation

### Readability Checks

| Check | How to verify |
|-------|---------------|
| Contrast on `#333` background | Each interval color should have a luminance contrast ratio ≥ 2.5 against `#333` (WCAG AA for large text/UI components) |
| Root recognizability | Root color should still be the most saturated red in the palette and visually distinct from m2/b2 |
| Fret markers vs note dots | Fret marker opacity ≤ 0.2 vs note dot opacity 1.0 — should be visually distinct |
| Neutral note test | `.guitar-neck__dot` at default color should be clearly different from fret markers |

### Contrast Calculations (approximate)

| Interval | Luminance vs `#333` (approx) | Acceptable? |
|----------|------------------------------|-------------|
| Root `rgb(168, 18, 35)` | ~2.8 | Yes |
| Major 3rd `rgb(110, 175, 30)` | ~3.5 | Yes |
| Perfect 5th `rgb(25, 105, 185)` | ~2.9 | Yes |
| Fret marker `rgba(255,255,255,0.15)` | ~1.3 (nearly invisible — desired) | Yes |
| Note dot `rgba(168,110,110,0.3)` | ~2.0 (subtle but visible — desired) | Yes |

## Implementation Steps

1. Update `--guitar-neck-dot-color` and `--guitar-neck-dot-label-color` in `src/styles.scss:38-39`
2. Update `--guitar-neck-marker-bg-color` in `src/styles.scss:46`
3. Replace interval color values in `src/styles.scss:48-59`
4. Replace legend hardcoded colors with `var(--interval-*)` references in `src/styles.scss:419-430`
5. Replace mock note hardcoded colors with `var(--interval-*)` references in `src/styles.scss:370-372`
6. Run `npm test` to confirm no regressions
7. Run `npm run build` to confirm TypeScript/template compilation
8. Manual visual verification

## Edge Cases

1. **Legend component** — already has its own SCSS at `src/app/legend/legend.component.scss` with commented-out color classes. No action needed since the `interval--*` classes in `styles.scss` are used.
2. **No scale/chord selected** — fret markers should be barely visible, note dots absent (correct).
3. **Dense scale (e.g., diminished, chromatic)** — all intervals displayed; reduced saturation helps readability by reducing visual noise.
4. **Print / high-contrast mode** — not addressed here; out of scope.
5. **"Note Names" mode** — not implemented yet, but palette prepared: neutral note at full white will contrast against `rgba(255,255,255,0.15)` fret markers.

## Out of Scope

- Adding a "Note Names" display mode toggle
- Changing any component logic or templates
- Modifying the `--guitar-neck-bg-color` (keeping `#333`)
- Modifying `--guitar-neck-fret-color` or `--guitar-neck-string-color` (keeping `#ddd`)
- Changing the legend component or adding new display modes
- Accessibility color contrast (WCAG AAA) — only targeting acceptable visual readability
