## Bug: API route params not decoded for pattern names with Unicode chars

### Problem
The frontend sends pattern names with Unicode characters (♭, ♯) in the URL path, e.g. `7♭9`. The browser auto-encodes them as UTF-8 bytes (`%E2%99%AD`), but the backend route `/:name/:root` does NOT decode the `:name` param. It receives the literal encoded string `7%E2%99%AD9` instead of `7♭9`.

### Example failing request
```
GET http://localhost:3000/api/chords/7♭9/C%23
```
The browser encodes this to:
```
GET http://localhost:3000/api/chords/7%E2%99%AD9/C%23
```
Backend receives `params.name = "7%E2%99%AD9"` and `params.root = "C#"` (if root decoding is already fixed). The pattern lookup fails because `"7%E2%99%AD9" !== "7♭9"`.

### Routes affected
- `GET /api/chords/:name/:root` — pattern name `7♭5`, `7♯5`, `7♭9`, `7♯9`
- `GET /api/scales/:name/:root` — scale names are ASCII-only, not affected

### Fix
Apply `decodeURIComponent()` to both `:name` and `:root` params in all three route files:

**src/routes/chords.ts** (line ~9):
```javascript
const chordType = decodeURIComponent(params.name);
const rootNote = decodeURIComponent(params.root);
```

**src/routes/scales.ts** (line ~9):
```javascript
const scaleName = decodeURIComponent(params.name);
const rootNote = decodeURIComponent(params.root);
```

**src/routes/compatibility.ts** (line ~8):
```javascript
const scaleName = decodeURIComponent(params.name);
const rootNote = decodeURIComponent(params.root);
```

### Why this happens
- Elysia (the backend framework) does NOT automatically URL-decode route parameters
- The `#` character in root notes is ASCII and was fixed previously with `decodeURIComponent`
- Unicode characters (♭ U+266D, ♯ U+266F) are multi-byte UTF-8 and also need decoding
- Scale names are ASCII-only, so they work fine without decoding

### Affected pattern names
Chord types with Unicode characters:
- `7♭5` (♭ = U+266D, encoded as `%E2%99%AD`)
- `7♯5` (♯ = U+266F, encoded as `%E2%99%AF`)
- `7♭9`
- `7♯9`

### Available patterns list (for reference)
The select dropdowns get their data from `guitar-neck-shared` npm package:
- **Chords:** `node_modules/guitar-neck-shared/src/models/chordTypes.ts` → `CHORD_PATTERNS`
- **Scales:** `node_modules/guitar-neck-shared/src/models/scaleTypes.ts` → `SCALE_PATTERNS`

The backend should validate against the same list (decoded).
