# Plan: Technical Debt przed Deployem

## Cel

Oczyścić dług techniczny przed deployem nowej wersji UI, minimalizując ryzyko regresji. Priorytet: **szybkie zwycięstwa o niskim ryzyku**.

---

## Assessment OPEN backlog items

### Kryteria oceny

| Poziom | Ryzyko regresji | Wpływ na deploy |
|--------|-----------------|-----------------|
| 🟢 NISKIE | CSS-only lub usunięcie dead code | Redukcja bundle'a, czystszy kod |
| 🟡 ŚREDNIE | Zmiana logiki, ale dobrze izolowana | Lepsza utrzymywalność |
| 🔴 WYSOKIE | Zmiana architektury / duży refactor | Ryzyko > wartość przed deployem |

### Tabela decyzyjna

| # | Backlog item | Ryzyko | Wartość | Decyzja |
|---|-------------|--------|---------|---------|
| 1 | **Remove unused uuid from GuitarNote** | 🟢 NISKIE — usuwa martwy kod, bez zmiany logiki | WYSOKA — mniejszy bundle, -1 zależność npm | **✅ ZRÓB** |
| 2 | **UI Color Palette Refresh** | 🟢 NISKIE — CSS-only | ŚREDNIA — wizualny lifting do nowej wersji | **✅ ZRÓB (opcjonalnie)** |
| 3 | **toolboxSubmit() — Command Factory** | 🟡 ŚREDNIE — zmienia strukturę kodu ale logika bez zmian | ŚREDNIA — lepsza testowalność | **❌ DEFER** — nie blokuje deployu |
| 4 | **Pattern name URL decoding (backend)** | 🔴 WYSOKIE — backend, osobne repo | NISKA — nie dotyczy frontendu | **❌ DEFER** — oddzielny deploy backendu |
| 5 | **MusicSelection — domain abstraction** | 🔴 WYSOKIE — duży refactor architektury | ŚREDNIA | **❌ DEFER** |
| 6 | **FretboardStateService O(n) → O(1)** | 🟡 ŚREDNIE — zmiana struktury danych | ŚREDNIA — performance | **❌ DEFER** |
| 7 | **Template calls services directly** | 🔴 WYSOKIE — duży refactor + DisplayCell | ŚREDNIA | **❌ DEFER** |
| 8 | **Show chord tones inside scale** | 🔴 WYSOKIE — nowa funkcja, nie dług | ŚREDNIA | **❌ DEFER** — nowa funkcja, nie debt |

---

## Tier 1: Zrób przed deployem

### Zadanie 1: Remove unused uuid from GuitarNote

**Szacowany czas:** 10 minut
**Branch:** `fix/remove-unused-uuid`

**Zmiany:**

1. [`src/app/shared/model/guitarNote.ts`](src/app/shared/model/guitarNote.ts)
   - Usuń `import { v4 as uuidv4 } from 'uuid'`
   - Usuń pole `id?: string`
   - Usuń `this.id = uuidv4()` z konstruktora

2. [`package.json`](package.json)
   - Usuń `"uuid": "^10.0.0"` z `dependencies`
   - Usuń `"@types/uuid": "^10.0.0"` z `devDependencies`

3. Uruchom `npm install`, żeby zaktualizować `package-lock.json`

4. Sprawdź w projekcie referencje do `note.id` / `guitarNote.id` — powinno być 0.

**Done when:**
- `GuitarNote` nie importuje uuid
- `GuitarNote` nie ma pola `id`
- `uuid` i `@types/uuid` usunięte z `package.json`
- `npm test` przechodzi (90/90)

---

### Zadanie 2 (opcjonalne): UI Color Palette Refresh

**Szacowany czas:** 30 minut
**Branch:** `fix/ui-color-palette-refresh`

**Zmiany:**

1. [`src/styles.scss:48-59`](src/styles.scss:48-59) — stonować kolory interwałowe:

```css
--interval-root:             rgb(168, 18, 35);     // ← zostaw, root musi być wyrazisty
--interval-minor-2nd:        rgb(180, 110, 60);    // ← zamiast (190, 95, 30)
--interval-major-2nd:        rgb(185, 140, 55);    // ← zamiast (210, 130, 20)
--interval-minor-3rd:        rgb(165, 155, 75);    // ← zamiast (185, 165, 25)
--interval-major-3rd:        rgb(110, 160, 70);    // ← zamiast (110, 175, 30)
--interval-perfect-4th:      rgb(60, 140, 100);    // ← zamiast (20, 140, 85)
--interval-diminished-5th:   rgb(60, 125, 120);    // ← zamiast (20, 120, 115)
--interval-perfect-5th:      rgb(60, 115, 170);    // ← zamiast (25, 105, 185)
--interval-minor-6th:        rgb(110, 75, 155);    // ← zamiast (100, 45, 165)
--interval-major-6th:        rgb(140, 85, 165);    // ← zamiast (140, 60, 180)
--interval-minor-7th:        rgb(145, 65, 115);    // ← zamiast (155, 35, 115)
--interval-major-7th:        rgb(130, 130, 130);   // ← zamiast (145, 145, 145)
```

2. [`src/app/freatboard/freatboard.component.scss`](src/app/freatboard/freatboard.component.scss) — opcjonalnie dostosować rozmiar kropek:
   - `--guitar-neck-dot-size: 22px` (z 20px) — minimalne powiększenie

**Done when:**
- Kolory mniej nasycone, ale wciąż rozróżnialne
- Root nadal wyrazisty
- `npm test` przechodzi (90/90)

---

## Kolejność wykonania

1. `fix/remove-unused-uuid` → commit → merge → master
2. (opcjonalnie) `fix/ui-color-palette-refresh` → commit → merge → master
3. Deploy

## Co NIE idzie przed deployem

| Item | Powód |
|------|-------|
| toolboxSubmit() — Command Factory | Działa, refactor nie zmienia UX |
| Pattern name URL decoding | Backend, osobne repo |
| MusicSelection — domain abstraction | Duży refactor, ryzyko regresji |
| FretboardStateService O(n) → O(1) | Performance, nie bug |
| Template calls services directly | Duży refactor, ryzyko regresji |
| Show chord tones inside scale | Nowa funkcja, nie debt |

## Po deployu (backlog do kolejnego sprintu)

Priority po deployu:

1. **FretboardStateService O(n) → O(1)** — największy gain performance przy średnim ryzyku
2. **toolboxSubmit() — Command Factory** — czysty kod, łatwy do zrobienia
3. **MusicSelection + Template refactor** — można robić razem bo są powiązane
4. **Show chord tones inside scale** — nowa funkcja
