# Metronome Feature — Implementation Specification

> Based on: [`plans/metronome-feature-plan.md`](plans/metronome-feature-plan.md), [`BACKLOG.md`](BACKLOG.md:571)
> Status: Ready for implementation

---

## 1. Summary

Add a standalone metronome component to the right panel of the dock, replacing the current `.ai-placeholder` (AI chat is `POSTPONED` and gated behind `chatEnabled = false`). The metronome uses the Web Audio API for drift-free beat scheduling with noise-burst click sounds. No external dependencies, no routing changes, no backend.

**Scope:**
- 1 new Angular standalone component + template + styles + spec
- 1 new Angular service (injectable, standalone-ready)
- 2 file modifications in `home-page` (`.ts` import + `.html` replacement)
- 1 modification in `styles.scss` (responsive metronome section)
- 1 update to `BACKLOG.md` (already has a backlog entry — verify status)

---

## 2. Files to Create

### 2.1 `src/app/metronome/metronome-engine.service.ts`

**Purpose:** Pure audio engine. Encapsulates all Web Audio API logic. Testable independently of the Angular change detection cycle.

**Interface:**

```typescript
@Injectable({ providedIn: 'root' })
export class MetronomeEngineService {
  private audioCtx: AudioContext | null = null;

  /** Initialize AudioContext (called on user gesture — Start button) */
  initAudioContext(): void;

  /** Schedule a single beat. 'accent' = true for beat 1 of the measure */
  scheduleBeat(when: number, accent: boolean): void;

  /** Schedule beats for an entire measure. Returns array of absolute times */
  scheduleMeasure(startTime: number, bpm: number, meter: number): number[];

  /** Cancel all scheduled beats and optionally close AudioContext */
  stop(): void;

  /** Get the current AudioContext currentTime (for scheduling) */
  get currentTime(): number;
}
```

**Key implementation details:**
- No external dependencies — pure Web Audio API
- `AudioContext` created lazily on `initAudioContext()` (browser autoplay policy requires user gesture)
- Audio output: white noise burst via `AudioBuffer`
  - **Accent beat**: noise burst ~30ms, apply low-pass filter (~800Hz) for deeper sound
  - **Normal beat**: noise burst ~20ms, apply high-pass filter (~2000Hz) for click sound
- Scheduling: use `AudioContext.currentTime` + ahead-of-time scheduling (schedule one measure at a time)
- Fallback: if `AudioContext` creation fails (e.g., unsupported browser), log a warning and allow visual-only mode

---

### 2.2 `src/app/metronome/metronome.component.ts`

**Purpose:** UI logic, state management, and template bindings. Consumes `MetronomeEngineService`. Standalone component.

**Properties (state):**

| Property | Type | Default | Source |
|---|---|---|---|
| `bpm` | `number` | `120` | Two-way bound to slider + input |
| `timeSignature` | `'2/4' \| '3/4' \| '4/4' \| '6/8'` | `'4/4'` | Segmented button group |
| `isRunning` | `boolean` | `false` | Start/Stop state |
| `currentBeat` | `number` | `0` | Visual beat indicator (1-based, 0 = stopped) |
| `meter` | `number` | computed | Derived: `parseInt(timeSignature.split('/')[0])` |

**Methods:**

| Method | Trigger | Behavior |
|---|---|---|
| `start()` | Start button | `initAudioContext()`, begin scheduling loop, set `isRunning = true` |
| `stop()` | Stop button | Cancel scheduling, reset `currentBeat = 0`, `isRunning = false` |
| `toggle()` | Same button | Delegates to start/stop based on `isRunning` |
| `onBpmChange(value: number)` | Slider/input | Clamp to [20, 300], update `bpm` |
| `onTimeSignatureChange(sig: string)` | Segmented buttons | Update `timeSignature`, reset `currentBeat` |
| `onTap()` | Tap button | Rolling window tap detection |
| `getAccent(beat: number): boolean` | Template | `beat === 1` |

**Tap Tempo Algorithm:**
- Store up to 6 tap timestamps in a rolling array `taps: number[]`
- On first tap: store timestamp, do nothing (need 2 taps for interval)
- On second tap: compute BPM from interval, show preliminary value
- On 3rd–6th tap: compute average BPM from last N intervals, update `bpm` on each tap
- Reset if gap > 2000ms (stale tap detection) — clear `taps` array
- Edge case: if interval < 200ms (300 BPM max), treat as accidental double-tap and ignore

**Beat Scheduling Loop:**
- Use `setInterval` at ~50ms (not for timing — just to check if next beat needs scheduling)
- Schedule one full measure at a time using `AudioContext.currentTime`
- Update `currentBeat` via `requestAnimationFrame` for visual sync
- Pre-compute beat intervals: `intervalMs = 60000 / bpm`

---

### 2.3 `src/app/metronome/metronome.component.html`

**Template structure:**

```html
<section class="metronome">
  <!-- Title -->
  <h3 class="metronome__title">Metronome</h3>

  <!-- Visual Beat Indicator -->
  <div class="metronome__indicator">
    <div class="metronome__beat"
         [class.metronome__beat--accent]="currentBeat === 1 && isRunning"
         [class.metronome__beat--active]="currentBeat > 0 && isRunning">
    </div>
  </div>

  <!-- Beat dots (meter visualization) -->
  <div class="metronome__dots">
    <div *ngFor="let beat of [].constructor(meter); let i = index"
         class="metronome__dot"
         [class.metronome__dot--active]="currentBeat === i + 1 && isRunning"
         [class.metronome__dot--accent]="i === 0">
    </div>
  </div>

  <!-- Tempo Control -->
  <div class="metronome__tempo">
    <label class="metronome__label">Tempo</label>
    <div class="metronome__tempo-controls">
      <input type="range"
             [min]="20" [max]="300" [step]="1"
             [(ngModel)]="bpm"
             (input)="onBpmChange(bpm)"
             class="metronome__slider">
      <input type="number"
             [min]="20" [max]="300"
             [(ngModel)]="bpm"
             (change)="onBpmChange(bpm)"
             class="metronome__input">
      <span class="metronome__bpm-label">BPM</span>
    </div>
  </div>

  <!-- Time Signature -->
  <div class="metronome__time">
    <label class="metronome__label">Time</label>
    <div class="metronome__sig-group">
      <button *ngFor="let sig of ['2/4', '3/4', '4/4', '6/8']"
              class="metronome__sig-btn"
              [class.metronome__sig-btn--active]="timeSignature === sig"
              (click)="onTimeSignatureChange(sig)">
        {{ sig }}
      </button>
    </div>
  </div>

  <!-- Controls -->
  <div class="metronome__controls">
    <button class="metronome__btn metronome__btn--start"
            (click)="toggle()">
      {{ isRunning ? 'Stop' : 'Start' }}
    </button>
    <button class="metronome__btn metronome__btn--tap"
            (click)="onTap()">
      Tap
    </button>
  </div>
</section>
```

---

### 2.4 `src/app/metronome/metronome.component.scss`

**Key style requirements:**
- Container fills the right panel (same sizing as `.ai-placeholder`)
- Beat indicator: large circle, `width: 48px`, `height: 48px`, border-radius 50%
  - Default: `background: var(--app-muted)`, opacity 0.3
  - Active: scale(1.15) pulse, `background: var(--green-700)`, transition 80ms
  - Accent (beat 1): `background: var(--green-700)`, larger pulse scale(1.3)
  - CSS transition: `transform 80ms ease, background 80ms ease`
- Beat dots row below indicator: `display: flex`, `gap: 8px`, `justify-content: center`
  - Dot size: `12px`, border-radius 50%
  - Inactive: `background: var(--app-border)`
  - Active: `background: var(--green-700)` with pulse
  - Accent dot (beat 1): slightly larger (`14px`) or different shade
- Tempo slider: full width, use accent green
- Tempo input: `width: 64px`, centered
- Time signature buttons: segmented button group style
- Start/Stop button: prominent, green accent
- Tap button: secondary style
- All text uses existing CSS variables (`--app-text`, `--app-muted`, `--green-700`, etc.)
- Responsive: hide on screens < 1200px (same as `.ai-placeholder` currently does)

---

### 2.5 `src/app/metronome/metronome.component.spec.ts`

**Test coverage (minimal but meaningful):**

| Test | What it covers |
|---|---|
| Component creates | Basic instantiation |
| Toggle start/stop state | `isRunning` flips correctly |
| BPM clamping | Values outside 20–300 are clamped |
| Time signature change resets beat | `currentBeat` resets to 0 |
| Tap tempo accumulates | After 2 taps, BPM is set |
| Tap tempo stale reset | Gap > 2s clears taps array |
| Engine service schedules beat | Spy on `scheduleBeat` |

Use Angular `TestBed` with `provideMetronomeEngine()` mock. No need for AudioContext in unit tests — mock the engine service.

---

## 3. Files to Modify

### 3.1 `src/app/home-page/home-page.component.ts`

**Changes:**
1. Add import: `import { MetronomeComponent } from '../metronome/metronome.component';`
2. Add `MetronomeComponent` to the `imports` array in the `@Component` decorator

**Note:** `NO_ERRORS_SCHEMA` is already present, but explicit import is the Angular standalone best practice.

### 3.2 `src/app/home-page/home-page.component.html`

**Changes:**
1. Replace the entire `<ng-template #chatDisabled>` block (lines 21–31) with:
```html
<ng-template #chatDisabled>
  <app-metronome></app-metronome>
</ng-template>
```
2. The `#chat-container` section (lines 18–20) with `*ngIf="chatEnabled"` stays unchanged — it remains as the AI chat slot for when `chatEnabled` is turned on in the future.

### 3.3 `src/styles.scss`

**Changes:**
1. Add `.metronome` section styles alongside the AI Placeholder section (after line 595):
```scss
/* ==========================================================================
   Metronome
   ========================================================================== */

.metronome {
  min-width: 0;
  overflow: auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #fff;
  // ... additional styles for the metronome container
}
```

2. In the `@media (max-width: 1200px)` block (line 671), update the `.ai-placeholder` hide rule to also hide the metronome:
```scss
.ai-placeholder,
.metronome {
  display: none;
}
```

### 3.4 `BACKLOG.md`

**Changes:**
Update the Metronome backlog entry (lines 571–600) status from `OPEN` to `FIXED` after implementation, with a reference to the commit or location.

---

## 4. Implementation Order

| Step | Action | File(s) | Rationale |
|------|--------|---------|-----------|
| 1 | Create `metronome-engine.service.ts` | New file | Pure logic, no UI dependency. Can be tested immediately. |
| 2 | Create `metronome.component.ts` | New file | Depends on the engine. Component logic. |
| 3 | Create `metronome.component.html` | New file | Template for the component. |
| 4 | Create `metronome.component.scss` | New file | Styles scoped to the component. |
| 5 | Modify `home-page.component.ts` | Existing | Import + register the component. |
| 6 | Modify `home-page.component.html` | Existing | Replace placeholder with `<app-metronome>`. |
| 7 | Modify `src/styles.scss` | Existing | Add global metronome section styles + responsive hide. |
| 8 | Create `metronome.component.spec.ts` | New file | Unit tests. Can be written after or concurrently with steps 2–4. |
| 9 | Update `BACKLOG.md` | Existing | Mark metronome backlog item as FIXED. |

---

## 5. Angular-Specific Patterns & Conventions

### Standalone Component
- `MetronomeComponent` must use `standalone: true` in the `@Component` decorator
- No `NgModule` declarations — import directly in `HomePageComponent.imports`
- Import `NgIf`, `NgFor` from `@angular/common`
- Import `FormsModule` for `[(ngModel)]` two-way binding on slider/input

### Import Pattern
```typescript
import { Component } from '@angular/core';
import { NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MetronomeEngineService } from './metronome-engine.service';

@Component({
  selector: 'app-metronome',
  standalone: true,
  imports: [NgIf, NgFor, FormsModule],
  templateUrl: './metronome.component.html',
  styleUrl: './metronome.component.scss'
})
export class MetronomeComponent { ... }
```

### CSS Variable Usage
- Use existing CSS custom properties from `:root` in `styles.scss`:
  - `--app-text`, `--app-muted` for text
  - `--green-700`, `--green-800` for accents
  - `--app-border` for borders
  - `--radius-md`, `--radius-sm` for border-radius
  - `--shadow-soft` for shadows if needed

### Template Conventions
- Use `[(ngModel)]` for two-way binding on slider and number input
- Use `*ngFor` with `trackBy` for beat dots (if more than 4 items)
- Use `[class.X]` bindings for conditional styling (no `ngStyle` unless necessary)

### Testing
- Use `TestBed.configureTestingModule` with `MetronomeComponent` as the component under test
- Mock `MetronomeEngineService` with a simple object or `jasmine.createSpyObj`
- Test state transitions, not AudioContext internals (those belong in engine service tests)

---

## 6. Edge Cases & Notes

- **AudioContext autoplay policy**: `AudioContext` must be created/resumed inside a user gesture handler (the Start button click). The plan already accounts for this.
- **High BPM (>250)**: At 300 BPM, intervals are 200ms. The scheduling loop must schedule at least one measure ahead to avoid gaps. Use `setInterval` at 50ms for scheduling checks.
- **Low BPM (<30)**: At 20 BPM, intervals are 3 seconds. The scheduling loop should still work correctly (schedule one measure at a time).
- **Tab away / background tab**: `setInterval` may be throttled. Use `AudioContext.currentTime` as the source of truth — if the tab comes back and `currentTime` has advanced, skip missed beats rather than playing them.
- **Browser without Web Audio API**: Check `typeof AudioContext !== 'undefined'`. If unavailable, disable audio and operate in visual-only mode. Show a subtle indicator.
- **Tap tempo rapid consecutive taps**: Filter out intervals < 200ms (accidental double-tap).
- **No routing changes needed**: The metronome lives inside the existing `HomePageComponent` route, no new routes required.
