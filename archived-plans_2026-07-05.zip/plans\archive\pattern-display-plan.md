# Pattern Display Panel — Plan (Grid Layout)

## Goal
Show music theory details of the currently selected scale/chord in a compact grid, wrapped in a container for easy layout placement.

## Layout mockup

```
┌──────────────────────────────────────────────────────────┐
│  C Dorian                                                │
│ ┌────────┬─────────────────────────────────────────────┐ │
│ │Dźwięki │ C    D    Eb   F    G    A    Bb            │ │
│ │Interwał│ 1    2    b3   4    5    6    b7            │ │
│ │Półtony │ 0    2    3    5    7    9    10            │ │
│ │Kroki   │ W    H    W    W    W    H    W             │ │
│ └────────┴─────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
```

## Grid CSS approach

Use `display: grid` with two columns:
- **Col 1**: label (fixed width, e.g. `80px`)
- **Col 2**: values row (remaining space, flexible)

Each property (notes, intervals, semitones, steps) is a separate grid row.
Values inside each row are displayed with `display: flex; gap` or `display: inline-grid`.

## Data flow

```
HomePageComponent.toolboxSubmit()
  │
  ├── stores current pattern info in FretboardStateService:
  │     currentPattern: {
  │       name: string;        // e.g. 'dorian'
  │       rootNote: string;    // e.g. 'C'
  │       type: 'scale'|'chord';
  │       isActive: boolean;
  │       notes: string[];     // computed from chromatic scale + root + intervals
  │       intervals: string[]; // flat/sharp notation e.g. ['1','2','b3',...]
  │       semitones: number[]; // cumulative e.g. [0,2,3,5,7,9,10]
  │       steps: string[];     // W/H e.g. ['W','H','W','W','W','H','W']
  │     }
  │
  └── PatternDisplayComponent reads currentPattern
        └── renders grid rows
```

## Files

| File | Action |
|------|--------|
| `src/app/services/guitar-neck.service.ts` | Add `currentPattern` property + `setCurrentPattern()` + `clearCurrentPattern()` |
| `src/app/shared/model/patternInfo.ts` | New `PatternInfo` interface |
| `src/app/pattern-display/pattern-display.component.ts` | New component |
| `src/app/pattern-display/pattern-display.component.html` | Grid layout with labels |
| `src/app/pattern-display/pattern-display.component.scss` | Grid + compact styling |
| `src/app/home-page/home-page.component.html` | Insert `<app-pattern-display>` |
| `src/app/home-page/home-page.component.ts` | Import + store pattern on toolboxSubmit |

## Implementation steps (in code mode)

1. Create `PatternInfo` interface in `shared/model/`
2. Add `currentPattern` to `FretboardStateService` + setters
3. Create `PatternDisplayComponent` (grid layout)
4. Wire up `HomePageComponent` — store pattern on submit
5. Insert component in template before Legend
6. Build check
