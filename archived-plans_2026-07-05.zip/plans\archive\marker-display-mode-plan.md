# Marker Display Mode — Implementation Plan

## Overview

Replace the boolean `intervalColorsEnabled` toggle with a three-mode system:
1. **Interval colors** — colored markers with note labels (current default)
2. **Note names** — neutral markers with note labels (equivalent to current `intervalColorsEnabled = false`)
3. **Neutral dots** — plain markers without note labels

## Files to Change

| # | File | Change Type | Impact |
|---|------|-------------|--------|
| 1 | [`src/app/services/guitar-neck.service.ts`](src/app/services/guitar-neck.service.ts) | Modify | Replace `intervalColorsEnabled` with `markerDisplayMode` |
| 2 | [`src/app/freatboard/freatboard.component.html`](src/app/freatboard/freatboard.component.html) | Modify | Update marker rendering logic |
| 3 | [`src/app/freatboard/freatboard.component.ts`](src/app/freatboard/freatboard.component.ts) | Modify | Add helper method for CSS classes |
| 4 | [`src/app/freatboard/freatboard.component.scss`](src/app/freatboard/freatboard.component.scss) | Modify | Add `.guitar-neck__dot--no-label` class |
| 5 | [`src/app/legend/legend.component.html`](src/app/legend/legend.component.html) | Modify | Replace checkbox with 3-mode selector |
| 6 | [`src/app/services/guitar-neck.service.spec.ts`](src/app/services/guitar-neck.service.spec.ts) | Modify | Update tests for new property |
| 7 | [`src/app/legend/legend.component.spec.ts`](src/app/legend/legend.component.spec.ts) | Modify | Update tests for new UI control |

No new files needed — the feature fits within existing components and services.

---

## Step-by-step Plan

### Step 1: Add `MarkerDisplayMode` type and update service

**File:** [`src/app/services/guitar-neck.service.ts`](src/app/services/guitar-neck.service.ts)

- Add a type export (or define at top of file):
  ```typescript
  export type MarkerDisplayMode = 'interval-colors' | 'note-names' | 'neutral-dots';
  ```
- Replace `intervalColorsEnabled = true` with:
  ```typescript
  markerDisplayMode: MarkerDisplayMode = 'interval-colors';
  ```
- Add a helper method `getMarkerCssClass(interval: string): string` that returns the CSS class based on the current mode:
  - `'interval-colors'` → returns `'guitar-neck__' + interval` (e.g., `guitar-neck__root`)
  - `'note-names'` → returns `'guitar-neck__neutral'`
  - `'neutral-dots'` → returns `'guitar-neck__neutral'`
- Add a getter `showNoteLabels: boolean`:
  - `'interval-colors'` → `true`
  - `'note-names'` → `true`
  - `'neutral-dots'` → `false`

### Step 2: Update the fretboard template

**File:** [`src/app/freatboard/freatboard.component.html`](src/app/freatboard/freatboard.component.html)

There are **three marker rendering branches** that need updating:

**Branch A** — Unselected interval notes (line 37-43, open string) and (line 57-60, fretted):
```html
<div *ngIf="getNoteInterval(i, fret)"
     [ngClass]="['guitar-neck__dot', guitarNeckService.getMarkerCssClass(getNoteInterval(i, fret))]"
     (click)="fretNoteClicked(i, fret)">
  <span *ngIf="guitarNeckService.showNoteLabels">{{ getNoteName(i, fret) }}</span>
</div>
```

**Branch B** — Unselected notes without interval (line 50-54, line 27-31):
These already show neutral styling. Just add `*ngIf` on the label for neutral-dots:
```html
<button class="guitar-neck__dot"
        *ngIf="!isNoteSelected(i, fret)"
        (click)="fretNoteClicked(i, fret)">
  <span *ngIf="guitarNeckService.showNoteLabels">{{ getNoteName(i, fret) }}</span>
</button>
```

**Branch C** — Selected notes without interval (line 32-36, line 55-56):
Consider if these should also hide labels in neutral-dots mode. Recommendation: **yes**, for consistency.
```html
<div *ngIf="isNoteSelected(i, fret) && !getNoteInterval(i, fret)"
     class="guitar-neck__selected"
     (click)="fretNoteClicked(i, fret)">
  <span *ngIf="guitarNeckService.showNoteLabels">{{ getNoteName(i, fret) }}</span>
</div>
```

### Step 3: Update legend control

**File:** [`src/app/legend/legend.component.html`](src/app/legend/legend.component.html)

Replace the "Interval colors" checkbox with a compact `<select>` dropdown that occupies minimal vertical space:

```html
<label class="switch-line">
  <span>Markers</span>
  <select [value]="guitarNeckService.markerDisplayMode"
          (change)="guitarNeckService.markerDisplayMode = $any($event.target).value">
    <option value="interval-colors">Interval colors</option>
    <option value="note-names">Note names</option>
    <option value="neutral-dots">Neutral dots</option>
  </select>
</label>
```

No new SCSS needed — the `<select>` inherits existing form styles from the legend layout.

Update the legend test in [`src/app/legend/legend.component.spec.ts`](src/app/legend/legend.component.spec.ts) accordingly:
- Replace the "Interval colors" checkbox tests with tests for the `<select>` element
- Add tests:
  - `should render a select element with three options`
  - `should default to 'interval-colors'`
  - `should switch to 'note-names' when selected`
  - `should switch to 'neutral-dots' when selected`

### Step 4: Add CSS for neutral-dot label hiding

**File:** [`src/app/freatboard/freatboard.component.scss`](src/app/freatboard/freatboard.component.scss)

Add a utility class for hiding text when in neutral-dots mode:

```scss
.guitar-neck__dot--no-label {
  font-size: 0;
}
```

However, since we're using `*ngIf` to hide the label text, we may not even need this CSS class. The `*ngIf` approach on a `<span>` wrapper is cleaner.

### Step 5: Update service tests

**File:** [`src/app/services/guitar-neck.service.spec.ts`](src/app/services/guitar-neck.service.spec.ts)

- Replace `intervalColorsEnabled` test references with `markerDisplayMode`
- Add tests:
  - `should initialize markerDisplayMode to 'interval-colors'`
  - `should return correct CSS class for interval-colors mode`
  - `should return neutral CSS class for note-names mode`
  - `should return neutral CSS class for neutral-dots mode`
  - `showNoteLabels should be true for interval-colors mode`
  - `showNoteLabels should be true for note-names mode`
  - `showNoteLabels should be false for neutral-dots mode`

### Step 6: Update legend component tests

**File:** [`src/app/legend/legend.component.spec.ts`](src/app/legend/legend.component.spec.ts)

- Replace "Interval colors" checkbox tests with tests for the 3-radio-button group
- Add tests:
  - `should render three display mode radio buttons`
  - `should default to 'interval-colors' selected`
  - `should switch to 'note-names' when that radio is clicked`
  - `should switch to 'neutral-dots' when that radio is clicked`

---

## Affected rendering paths (all must still work)

| Feature | Interval colors | Note names | Neutral dots |
|---------|----------------|------------|--------------|
| Scale display | Colored markers with labels | Neutral markers with labels | Plain dots |
| Chord display | Colored markers with labels | Neutral markers with labels | Plain dots |
| Single note display | Colored markers with labels | Neutral markers with labels | Plain dots |
| All notes display | Colored markers with labels | Neutral markers with labels | Plain dots |
| Custom pattern | Colored markers with labels | Neutral markers with labels | Plain dots |
| Note selection (click) | Selected state visible | Selected state visible | Selected state visible |
| String toggles | Respects active strings | Respects active strings | Respects active strings |
| Fret range | Respects range | Respects range | Respects range |

---

## Data flow diagram

```
User clicks radio in LegendComponent
    │
    ▼
FretboardStateService.markerDisplayMode = 'interval-colors' | 'note-names' | 'neutral-dots'
    │
    ├──► FretboardStateService.getMarkerCssClass(interval) → CSS class string
    │
    ├──► FretboardStateService.showNoteLabels → boolean
    │
    ▼
FreatboardComponent template re-renders markers with:
    • [ngClass] based on getMarkerCssClass()
    • *ngIf on labels based on showNoteLabels
```

---

## Migration note

The old `intervalColorsEnabled` boolean is **removed** entirely. No backward-compat wrapper needed since:
- The property is used only in [`freatboard.component.html`](src/app/freatboard/freatboard.component.html) (2 places) and [`legend.component.html`](src/app/legend/legend.component.html) (1 place)
- All three files are updated in this change
