# Plan implementacji — Lekcje interaktywne (Lesson System)

## Przegląd

System lekcji pozwala AI agentowi prowadzić użytkownika przez strukturyzowaną lekcję gryfu gitary. Agent tłumaczy, pokazuje na gryfie, zadaje ćwiczenia, a user klika odpowiedzi. Aplikacja waliduje odpowiedzi przez Tonal.js i zwraca wynik agentowi.

## Architektura

```
Landing Page → wybór lekcji → /app?lesson=interwaly
                                    │
                                    ▼
                              AppPage wykrywa parametr
                                    │
                                    ▼
                         ChatService.startLesson(lessonId)
                                    │
                                    ├─ wczytuje .md z lessons/
                                    ├─ resetuje agenta (fresh context)
                                    ├─ wysyła treść lekcji jako pierwszą wiadomość
                                    └─ agent zaczyna prowadzić
                                    │
                                    ▼
                         Agent → start_exercise() → DomainService
                                    │
                                    ▼
                         exerciseMode=true, exerciseTask=...
                                    │
                                    ▼
                         Fretboard: notes clickable, Submit button visible
                                    │
                                    ▼
                         User klika nuty → selectedNotes aktualizowane
                                    │
                                    ▼
                         User klika Submit → walidacja → ExerciseResult
                                    │
                                    ▼
                         Wynik wraca do agenta → agent komentuje
```

## Fazy implementacji

---

### Phase 1: Domain layer — exercise state and commands

**Pliki do zmiany:**
- [`src/app/domain/state.ts`](src/app/domain/state.ts)
- [`src/app/domain/commands.ts`](src/app/domain/commands.ts)
- [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts)
- [`src/app/domain/domain-validator.ts`](src/app/domain/domain-validator.ts)

**Zmiany:**

1. **`DomainState`** — dodaj pola:
   ```typescript
   exerciseMode: boolean;
   exerciseTask?: {
     question: string;
     rootNote: string;
     expectedIntervals: string[];
     fretRange?: { min: number; max: number };
     enabledStrings?: boolean[];
   };
   ```
   Domyślnie: `exerciseMode: false`, `exerciseTask: undefined`.

2. **`DomainCommand`** — dodaj komendy:
   ```typescript
   interface StartExerciseCommand {
     type: 'start-exercise';
     question: string;
     rootNote: string;
     expectedIntervals: string[];
     fretRange?: { min: number; max: number };
     enabledStrings?: boolean[];
   }

   interface SubmitExerciseCommand {
     type: 'submit-exercise';
   }

   interface SelectNoteCommand {
     type: 'select-note';
     note: string;
     string: number;
     fret: number;
   }

   interface DeselectNoteCommand {
     type: 'deselect-note';
     string: number;
     fret: number;
   }
   ```

3. **`DomainError`** — dodaj:
   ```typescript
   NO_ACTIVE_EXERCISE = 'NO_ACTIVE_EXERCISE',
   ```

4. **`DomainService`** — zarejestruj handlery:
   - `start-exercise` → ustawia `exerciseMode=true`, zapisuje `exerciseTask`, resetuje `selectedNotes`
   - `submit-exercise` → wywołuje walidację, zwraca `ExerciseResult`, resetuje `exerciseMode`
   - `select-note` → dodaje pozycję do `selectedNotes`
   - `deselect-note` → usuwa pozycję z `selectedNotes`

5. **`DomainValidator`** — dodaj walidację:
   - `start-exercise`: sprawdź czy `rootNote` jest poprawną nutą, czy `expectedIntervals` to znane interwały
   - `submit-exercise`: sprawdź czy `exerciseMode=true`

---

### Phase 2: Agent tools — add start_exercise tool

**Pliki do zmiany:**
- [`src/app/chat/tools/domain-tools.ts`](src/app/chat/tools/domain-tools.ts)
- [`src/app/chat/services/chat.service.ts`](src/app/chat/services/chat.service.ts)

**Zmiany:**

1. **Nowy tool `start_exercise`:**
   ```typescript
   const startExerciseSchema = z.object({
     question: z.string().describe("Pytanie do użytkownika, np. 'Znajdź wszystkie kwinty względem A'"),
     rootNote: z.string().describe("Nuta podstawowa, np. 'A', 'C'"),
     expectedIntervals: z.array(z.string()).describe("Oczekiwane interwały, np. ['5'], ['1', 'b3']"),
     fretRange: z.object({
       min: z.number().min(0).max(24),
       max: z.number().min(0).max(24),
     }).optional().describe("Opcjonalny zakres progów"),
     enabledStrings: z.array(z.boolean()).length(6).optional().describe("Opcjonalnie które struny"),
   });
   ```
   Tool woła `domainService.execute({ type: 'start-exercise', ... })` i zwraca potwierdzenie.

2. **Nowy tool `cancel_exercise`:**
   ```typescript
   // Prosty tool do anulowania ćwiczenia bez submita
   ```

3. **System prompt** — dodaj instrukcje o lekcjach:
   ```
   "Gdy prowadzisz lekcję, używaj start_exercise do zadawania pytań. "
   "Po otrzymaniu wyniku ćwiczenia skomentuj odpowiedź użytkownika. "
   "Nie zadawaj kolejnego pytania, dopóki nie dostaniesz wyniku poprzedniego."
   ```

---

### Phase 3: UI — lesson selection on landing page

**Pliki do zmiany:**
- [`src/app/landing-page/landing-page.component.ts`](src/app/landing-page/landing-page.component.ts)
- [`src/app/landing-page/landing-page.component.html`](src/app/landing-page/landing-page.component.html)
- Nowy: `src/app/services/lesson-registry.service.ts`

**Zmiany:**

1. **`LessonRegistryService`:**
   ```typescript
   @Injectable({ providedIn: 'root' })
   export class LessonRegistryService {
     readonly lessons = [
       { id: 'interwaly', title: 'Interwały na gryfie', description: 'Poznaj podstawowe interwały', level: 'podstawowy' },
       // future lessons here
     ];
     getLesson(id: string): LessonInfo | undefined;
   }
   ```

2. **Landing page** — dodaj sekcję "Lekcje" po setup formie:
   - Lista dostępnych lekcji z tytułem i opisem
   - Przycisk "Rozpocznij lekcję" → przekierowuje do `/app?lesson=interwaly`
   - Lekcje są widoczne tylko po skonfigurowaniu API key

3. **Routing** — `AppPage` wykrywa parametr `lesson` z query stringa:
   ```typescript
   // app-page.component.ts
   const lessonId = this.route.snapshot.queryParamMap.get('lesson');
   if (lessonId) {
     this.startLesson(lessonId);
   }
   ```

---

### Phase 4: UI — clickable fretboard in exercise mode

**Pliki do zmiany:**
- [`src/app/freatboard/freatboard.component.ts`](src/app/freatboard/freatboard.component.ts)
- [`src/app/freatboard/freatboard.component.html`](src/app/freatboard/freatboard.component.html)
- [`src/app/freatboard/freatboard.component.scss`](src/app/freatboard/freatboard.component.scss)
- [`src/app/guitar-neck/guitar-neck.component.ts`](src/app/guitar-neck/guitar-neck.component.ts)
- Nowy: `src/app/exercise-submit/exercise-submit.component.ts`

**Zmiany:**

1. **Fretboard** — gdy `exerciseMode=true`:
   - Każda nuta (kropka) staje się klikalna (`cursor: pointer`)
   - Kliknięcie woła `select-note` lub `deselect-note` (toggle)
   - Zaznaczone nuty mają inny styl wizualny (np. obwódka, podświetlenie)
   - Tooltip z nazwą nuty przy hoverze

2. **ExerciseSubmitComponent** — nowy komponent:
   - Przycisk "Sprawdź" / "Submit"
   - Widoczny tylko gdy `exerciseMode=true`
   - Po kliknięciu woła `submit-exercise`
   - Wyświetla krótki feedback (ilość poprawnych/niepoprawnych)
   - Wynik leci do agenta

3. **GuitarNeckComponent** — nasłuchuje `exerciseMode` z DomainState:
   - Przekazuje stan do FreatboardComponent
   - Wyświetla ExerciseSubmitComponent nad/pod gryfem

---

### Phase 5: Validation — exercise result computation

**Nowy plik:**
- `src/app/services/exercise-validator.service.ts`

**Zmiany:**

1. **`ExerciseValidatorService`:**
   ```typescript
   @Injectable({ providedIn: 'root' })
   export class ExerciseValidatorService {
     private tonalFacade = inject(TonalFacadeService);

     validate(
       selectedNotes: SelectedNotePosition[],
       rootNote: string,
       expectedIntervals: string[]
     ): ExerciseResult {
       // Dla każdej zaznaczonej nuty:
       //   1. Oblicz interwał od rootNote przez tonalFacade.intervalDistance()
       //   2. Sprawdź czy interwał jest w expectedIntervals
       // Zwróć: { correct: boolean[], selectedNotes: [...], summary: string }
     }
   }
   ```

2. **`ExerciseResult`** — typ:
   ```typescript
   interface ExerciseResult {
     correct: boolean[];           // per selected note
     selectedNotes: SelectedNotePosition[];
     correctCount: number;
     incorrectCount: number;
     summary: string;              // np. "Znalazłeś 3 poprawne kwinty i 1 błędną nutę"
   }
   ```

3. **Handler `submit-exercise`** w DomainService:
   - Woła `ExerciseValidatorService.validate()`
   - Zwraca `ExerciseResult` jako dane w `DomainResult`
   - Resetuje `exerciseMode=false`, `exerciseTask=undefined`
   - Zachowuje `selectedNotes` (agent może je odczytać)

---

### Phase 6: Lesson session — fresh agent context

**Pliki do zmiany:**
- [`src/app/chat/services/chat.service.ts`](src/app/chat/services/chat.service.ts)
- [`src/app/app-page/app-page.component.ts`](src/app/app-page/app-page.component.ts)

**Zmiany:**

1. **`ChatService.startLesson(lessonId: string)`:**
   ```typescript
   async startLesson(lessonId: string): Promise<void> {
     this.resetAgent();  // fresh agent, no history
     const lesson = this.lessonRegistry.getLesson(lessonId);
     const content = await this.loadLessonFile(lessonId);  // fetch .md
     // Send lesson content as first system message
     await this.sendRaw(`Rozpoczynam lekcję: ${lesson.title}\n\n${content}\n\nProwadź mnie krok po kroku przez tę lekcję. Zadawaj pytania i czekaj na moje odpowiedzi.`);
   }
   ```

2. **`AppPageComponent`** — wykrywa parametr `lesson`:
   ```typescript
   ngOnInit() {
     const lessonId = this.route.snapshot.queryParamMap.get('lesson');
     if (lessonId) {
       this.aiModeEnabled.set(true);  // auto-enable AI mode
       this.chatService.startLesson(lessonId);
     }
   }
   ```

3. **System prompt** — rozszerz o lekcje:
   ```
   "Gdy prowadzisz lekcję, trzymaj się ściśle jej treści. "
   "Nie odchodź od tematu. Jeśli użytkownik zada pytanie spoza lekcji, "
   "odpowiedz krótko i wróć do lekcji."
   ```

---

### Phase 7: Wire everything — end-to-end flow

**Testowanie przepływu:**

1. User wchodzi na landing page → widzi setup form + listę lekcji
2. User wybiera "Interwały na gryfie" → redirect do `/app?lesson=interwaly`
3. AI mode włącza się automatycznie
4. Agent wita usera i zaczyna lekcję:
   - "Czym jest interwał? Spójrz na gryf..."
   - "Ćwiczenie 1: znajdź wszystkie A w zakresie progów 0-12"
   - Agent woła `start_exercise({question: "...", rootNote: "A", expectedIntervals: ["1"], fretRange: {min:0, max:12}})`
5. Gryf przechodzi w tryb selekcji — kropki są klikalne
6. User klika nuty A → zaznaczają się
7. User klika "Sprawdź"
8. Aplikacja waliduje → wynik wraca do agenta
9. Agent komentuje: "Dobrze! Znalazłeś 3 z 3 A w tym zakresie."
10. Agent przechodzi do kolejnego ćwiczenia

## Diagram przepływu

```mermaid
sequenceDiagram
    participant User
    participant LandingPage
    participant AppPage
    participant ChatService
    participant Agent
    participant DomainService
    participant Fretboard
    participant Validator

    User->>LandingPage: Wybiera lekcję
    LandingPage->>AppPage: Redirect /app?lesson=interwaly
    AppPage->>ChatService: startLesson('interwaly')
    ChatService->>ChatService: resetAgent()
    ChatService->>Agent: Wyślij treść lekcji
    Agent->>Agent: Analizuje lekcję
    Agent->>DomainService: start_exercise(question, rootNote, expectedIntervals)
    DomainService->>DomainService: exerciseMode=true
    DomainService-->>Fretboard: exerciseTask ustawiony
    Fretboard->>Fretboard: Włącz tryb selekcji
    Fretboard-->>User: Kropki klikalne, przycisk Submit
    User->>Fretboard: Klika nuty
    Fretboard->>DomainService: select-note (x3)
    User->>Fretboard: Klika "Sprawdź"
    Fretboard->>DomainService: submit-exercise
    DomainService->>Validator: validate(selectedNotes, rootNote, expectedIntervals)
    Validator-->>DomainService: ExerciseResult
    DomainService-->>Agent: ExerciseResult
    Agent->>Agent: Komentuje wynik
    Agent-->>User: "Dobrze! Znalazłeś 3 kwinty..."
```

## Pliki do utworzenia

| Plik | Opis |
|------|------|
| `src/app/services/lesson-registry.service.ts` | Rejestr dostępnych lekcji |
| `src/app/services/exercise-validator.service.ts` | Walidacja ćwiczeń przez Tonal.js |
| `src/app/exercise-submit/exercise-submit.component.ts` | Przycisk Submit + feedback |

## Pliki do modyfikacji

| Plik | Zmiany |
|------|--------|
| `src/app/domain/state.ts` | Dodaj exerciseMode, exerciseTask |
| `src/app/domain/commands.ts` | Dodaj StartExerciseCommand, SubmitExerciseCommand, SelectNoteCommand, DeselectNoteCommand |
| `src/app/domain/domain.service.ts` | Zarejestruj handlery dla nowych komend |
| `src/app/domain/domain-validator.ts` | Walidacja nowych komend |
| `src/app/chat/tools/domain-tools.ts` | Dodaj start_exercise tool |
| `src/app/chat/services/chat.service.ts` | Dodaj startLesson(), loadLessonFile() |
| `src/app/landing-page/landing-page.component.ts` | Dodaj sekcję lekcji |
| `src/app/landing-page/landing-page.component.html` | UI listy lekcji |
| `src/app/app-page/app-page.component.ts` | Wykryj parametr lesson, uruchom lekcję |
| `src/app/freatboard/freatboard.component.ts` | Klikalne nuty w exerciseMode |
| `src/app/guitar-neck/guitar-neck.component.ts` | Obsługa exerciseMode, Submit button |