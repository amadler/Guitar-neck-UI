# MVP: Clickable Action Tags in Chat Messages

## Problem

The AI agent can currently send `domain-command` events (via LangChain tools) to change the fretboard. But the agent cannot embed clickable suggestions **inline** in its text response — e.g., offering "1 3 5 → pokaż A major chord" as a clickable link.

## Solution Overview

Add a lightweight custom tag format `[[action:...|label]]` that the agent can include in its text responses. The Angular SPA parses these tags at render time and replaces them with clickable buttons/links. Clicking calls `DomainService.execute(command)` directly — no new SDK, no new libraries, no changes to the streaming/NDJSON flow.

## Architecture

```
Agent text response
  │
  ▼
ChatComponent template
  ├─ parseActionTags(text) → Segment[]
  ├─ <span> for text segments
  └─ <button> for action segments
       │
       ▼
  DomainService.execute(command)
       │
       ▼
  Fretboard updates
```

## Files to Create

### 1. `src/app/chat/models/action-tag.ts` — Model + Parser

```typescript
export interface ActionTag {
  /** Maps to DomainCommand.type — only supported values */
  action: 'show-pattern' | 'show-interval';
  /** Key-value parameters parsed from the tag */
  params: Record<string, string>;
  /** Visible label text */
  label: string;
}

export interface TextSegment {
  type: 'text';
  text: string;
}

export interface ActionSegment {
  type: 'action';
  action: ActionTag;
}

export type Segment = TextSegment | ActionSegment;
```

**Parser function** — regex-based, no dependencies:

```typescript
const ACTION_TAG_REGEX = /\[\[action:([a-z-]+);([^\]]+)\|([^\]]+)\]\]/g;

export function parseActionTags(text: string): Segment[] {
  const segments: Segment[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = ACTION_TAG_REGEX.exec(text)) !== null) {
    // Push preceding text
    if (match.index > lastIndex) {
      segments.push({ type: 'text', text: text.slice(lastIndex, match.index) });
    }

    const action = match[1] as ActionTag['action'];
    const paramsStr = match[2];
    const label = match[3];

    // Parse semicolon-separated key=value pairs
    const params: Record<string, string> = {};
    for (const pair of paramsStr.split(';')) {
      const eqIdx = pair.indexOf('=');
      if (eqIdx > 0) {
        params[pair.slice(0, eqIdx)] = pair.slice(eqIdx + 1);
      }
    }

    segments.push({ type: 'action', action: { action, params, label } });
    lastIndex = match.index + match[0].length;
  }

  // Push remaining text
  if (lastIndex < text.length) {
    segments.push({ type: 'text', text: text.slice(lastIndex) });
  }

  return segments;
}
```

**Validation** — optional helper to check if an action tag is well-formed:

```typescript
export function isValidAction(action: ActionTag): boolean {
  if (action.action === 'show-pattern') {
    return !!action.params['type'] && !!action.params['root'] && !!action.params['name'];
  }
  if (action.action === 'show-interval') {
    return !!action.params['root'] && !!action.params['interval'];
  }
  return false;
}
```

## Files to Modify

### 2. `src/app/chat/chat.component.ts` — Render segments + handle clicks

**Template changes** — replace `{{ msg.text }}` with segment iteration:

```html
@for (segment of parseActionTags(msg.text); track $index) {
  @if (segment.type === 'text') {
    <span>{{ segment.text }}</span>
  } @else {
    <button class="action-tag" (click)="handleAction(segment.action)">
      {{ segment.action.label }}
    </button>
  }
}
```

**Component class changes** — add `parseActionTags` and `handleAction`:

```typescript
import { DomainService } from '../domain/domain.service';
import { parseActionTags, ActionTag, isValidAction } from './models/action-tag';

// In component:
domainService = inject(DomainService);

// Template-bound:
parseActionTags = parseActionTags; // so template can call it

handleAction(action: ActionTag): void {
  if (!isValidAction(action)) return;

  switch (action.action) {
    case 'show-pattern': {
      const command: DomainCommand = {
        type: 'show-pattern',
        patternType: action.params['type'] as 'scale' | 'chord',
        patternName: action.params['name'],
        rootNote: action.params['root'],
      };
      this.domainService.execute(command);
      break;
    }
    case 'show-interval': {
      const command: DomainCommand = {
        type: 'show-interval',
        rootNote: action.params['root'],
        interval: action.params['interval'],
      };
      this.domainService.execute(command);
      break;
    }
  }
}
```

**Styles addition** — minimal button styling:

```scss
.action-tag {
  display: inline-block;
  padding: 2px 8px;
  margin: 2px 4px;
  background: #1976d2;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: inherit;
  font-family: inherit;
  &:hover { background: #1565c0; }
}
```

### 3. `src/app/chat/services/helpers.ts` — System prompt update

Add instructions telling the agent about the tag format:

```typescript
export const BASE_SYSTEM_PROMPT =
  // ... existing content ...
  "Gdy chcesz zaproponować użytkownikowi klikalną opcję, " +
  "użyj znacznika [[action:...|label]] w tekście odpowiedzi. " +
  "Przykłady:\n" +
  "- [[action:show-pattern;type=chord;root=A;name=major|1 3 5]]\n" +
  "- [[action:show-pattern;type=scale;root=C;name=major|C-dur]]\n" +
  "- [[action:show-interval;root=A;interval=b3|b3]]\n" +
  "Obsługiwane akcje: show-pattern (parametry: type, root, name), show-interval (parametry: root, interval).";
```

## Tag Format Specification

```
[[action:<action-name>;<key>=<value>;...|<label>]]
```

| Part | Description | Example |
|------|-------------|---------|
| `[[action:` | Opening marker | `[[action:` |
| `show-pattern` | Action name (maps to `DomainCommand.type`) | `show-pattern` |
| `;type=chord` | Semicolon-separated params | `;type=chord;root=A;name=major` |
| `\|` | Separator between params and label | `\|` |
| `1 3 5` | Visible label text | `1 3 5` |
| `]]` | Closing marker | `]]` |

**Supported actions and their parameters:**

| Action | Required params | Example |
|--------|----------------|---------|
| `show-pattern` | `type` (scale/chord), `root` (note), `name` (pattern name) | `[[action:show-pattern;type=chord;root=A;name=major\|A-dur]]` |
| `show-interval` | `root` (note), `interval` (interval name) | `[[action:show-interval;root=A;interval=b3\|b3]]` |

## Security

- The parser only recognizes the exact `[[action:...|...]]` pattern
- Only two action types are supported: `show-pattern` and `show-interval`
- Parameters are validated before constructing the DomainCommand
- The agent cannot inject arbitrary code — only structured params
- No HTML passthrough, no Markdown parsing, no eval()

## What Does NOT Change

- ❌ ChatMessage model — still `{ role, text, streaming, reasoning }`
- ❌ ChatService — no changes to `processStream`, `send`, `sendRaw`
- ❌ AgentApiService — no changes to NDJSON streaming
- ❌ DomainService — no changes to `execute()` or registry
- ❌ DomainCommand types — no new command types
- ❌ domain-tools.ts — no changes to LangChain tools
- ❌ No new dependencies, no new SDK, no React

## Edge Cases

1. **Streaming**: During streaming, `msg.text` grows incrementally. The parser re-runs on each render. Partial/incomplete tags at the end of the stream will not match the regex and will render as plain text. When the full tag arrives, it snaps into clickable form. This is acceptable behavior.

2. **Nested or malformed tags**: The regex is strict — `[[action:` followed by lowercase/hyphen action, semicolon params, pipe, label, `]]`. Anything that doesn't match exactly is rendered as plain text.

3. **Empty text between tags**: Handled — empty text segments are not pushed.

4. **Multiple tags in one message**: The `while` loop handles multiple matches correctly.

## Implementation Order

1. Create `src/app/chat/models/action-tag.ts` (model + parser)
2. Update `src/app/chat/chat.component.ts` (template + handler)
3. Update `src/app/chat/services/helpers.ts` (system prompt)
4. Verify with a test message containing `[[action:show-pattern;type=chord;root=A;name=major|A-dur]]`