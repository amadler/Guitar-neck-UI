# Plan: FretboardStateService — Immutable Snapshot Refactor

**Based on:** Architecture Review Candidate 1 (Mutable state leak)
**Status:** Approved — ready for implementation

## Decyzje z grillowania

1. **Wszystko w FretboardSnapshot** — `currentSelection` i `scaleChordState` jako pola snapshotu. Zero osobnych signalów.
2. **buildSnapshot jako prywatna metoda** na FretboardStateService (nie osobna funkcja).
3. **notesMap usunięty** — `.find()` na ~150 elementach snapshot.notes wystarczy.
4. **GuitarNote → immutable interface** z `createGuitarNote()` factory.
5. **computeIntervals()** w FretboardOrchestrationService — czysta funkcja zwracająca `Map<string, string>`.
6. **display*() metody zwracają void** — snapshot jest ustawiany na serwisie, nie zwracany.

---

## Problem Summary

`FretboardStateService` holds a public mutable `GuitarNote[]` array. Methods mutate `note.visible`, `note.selected`, `note.interval` in-place. Components directly assign `service.notes = ...`. This violates ADR 0005 (immutable state) and creates a **shallow module** — its interface (6 public methods) is nearly as complex as its implementation.

## Solution: Immutable `FretboardSnapshot`

Replace mutable `GutiarNote[]` with an **immutable snapshot** value object. The orchestration pipeline produces a new snapshot instead of mutating existing objects. `FretboardStateService` becomes a snapshot store — `currentSnapshot: signal<FretboardSnapshot | null>` — updated atomically.

---

## Detailed Implementation Plan

### Step 1: Create `FretboardSnapshot` type

**File:** `src/app/shared/model/fretboard-snapshot.ts` (NEW)

An immutable value object capturing the complete rendering state at a point in time.

```typescript
import { MusicSelection } from './music-selection';
import { ScaleChordState } from '../../services/fretboard-state.service';

export interface FretboardNote {
  readonly string: number;
  readonly fret: number;
  readonly note: string;
  readonly visible: boolean;
  readonly selected: boolean;
  readonly interval: string;
}

export interface FretboardSnapshot {
  readonly notes: readonly FretboardNote[];
  readonly hasActiveResult: boolean;
  readonly currentSelection: MusicSelection | null;
  readonly scaleChordState: ScaleChordState | null;
}
```

**Key decisions:**
- `FretboardNote` is an **interface** (not class) with `readonly` fields — no encapsulation needed, just immutability guarantee.
- `FretboardSnapshot` bundles all rendering state into one value.
- `notes` is `readonly FretboardNote[]` — the array itself is immutable.
- `hasActiveResult` is part of the snapshot (not a separate signal) since it's derived from the same rendering state.
- `ScaleChordState` is imported from `fretboard-state.service.ts` — it stays there since it's tightly coupled to the service's domain.

---

### Step 2: Refactor `GuitarNote` → immutable interface

**File:** `src/app/shared/model/guitarNote.ts`

Replace the mutable class with the immutable interface. Keep the file name for backward compatibility.

```typescript
export interface GuitarNote {
  readonly string: number;
  readonly fret: number;
  readonly note: string;
  readonly visible: boolean;
  readonly selected: boolean;
  readonly interval: string;
}

export function createGuitarNote(
  string: number,
  fret: number,
  note: string,
  visible = true,
  selected = false,
  interval = ''
): GuitarNote {
  return { string, fret, note, visible, selected, interval };
}
```

**Impact:** All existing code that **reads** `note.visible`, `note.selected`, `note.interval` still compiles. Code that **writes** to these fields will break — that's intentional and the whole point.

**Files that will break (writers):**
- `src/app/services/fretboard-state.service.ts` — `note.visible = false`, `note.selected = false`, etc.
- `src/app/services/fretboard-orchestration.service.ts` — `note.interval = 'root'`, `note.interval = ''`
- `src/app/services/fretboard-note-query.service.spec.ts` — `note.visible = true`, `note.visible = false`
- `src/app/services/fretboard-state.service.spec.ts` — `service.notes[0].selected = true`

---

### Step 3: Refactor `FretboardStateService`

**File:** `src/app/services/fretboard-state.service.ts`

Replace the mutable `notes: GuitarNote[]` with `currentSnapshot: signal<FretboardSnapshot | null>`.

**Changes:**

1. **Remove these public fields:**
   - `notes: GuitarNote[]`
   - `hasActiveResult: signal<boolean>`
   - `currentSelection: signal<MusicSelection | null>`
   - `scaleChordState: signal<ScaleChordState | null>`

2. **Remove these private fields:**
   - `notesMap: Map<string, GuitarNote>`

3. **Add these new fields:**
   - `private allPositions: readonly GuitarNote[] = []` — initialized via `initialize()`
   - `readonly currentSnapshot = signal<FretboardSnapshot | null>(null)` — the single source of truth

4. **Constructor changes:**
   - Remove `this.notes = this.noteService.getAllPositions()`
   - Remove `this.buildNotesMap()`
   - Constructor becomes empty (or removed entirely — Angular can handle it)

5. **Add `initialize()` method:**
   ```typescript
   initialize(allNotes: readonly GuitarNote[]): void {
     this.allPositions = allNotes;
   }
   ```

6. **Rewrite `applyHighlightedNotes()`:**
   - No longer mutates in-place
   - Takes `notesToShow: readonly GuitarNote[]` and optional `intervalMap?: Map<string, string>`
   - Calls private `buildSnapshot()` and returns `FretboardSnapshot`
   - Does NOT set `currentSnapshot` — the caller (orchestration) does that

7. **Rewrite `hideAllNotes()`:**
   - Returns `FretboardSnapshot` with all notes having `visible: false`, `selected: false`
   - Does NOT set `currentSnapshot`

8. **Rewrite `showAll()`:**
   - Returns `FretboardSnapshot` with all notes having `visible: true`, `selected: false`
   - `hasActiveResult: true`

9. **Rewrite `clearFretboard()`:**
   - Sets `currentSnapshot.set(null)`
   - No longer calls `hideAllNotes()` or `clearSelection()`

10. **Remove `clearSelection()`** — no longer needed since snapshots are immutable

11. **Add private `buildSnapshot()` method:**
    ```typescript
    private buildSnapshot(
      highlightedNotes: readonly GuitarNote[],
      intervalMap?: Map<string, string>,
      currentSelection?: MusicSelection | null,
      scaleChordState?: ScaleChordState | null,
    ): FretboardSnapshot {
      const highlightedSet = new Set(
        highlightedNotes.map(n => `${n.string}-${n.fret}`)
      );

      const notes: FretboardNote[] = this.allPositions.map(pos => {
        const key = `${pos.string}-${pos.fret}`;
        const isHighlighted = highlightedSet.has(key);
        return {
          string: pos.string,
          fret: pos.fret,
          note: pos.note,
          visible: isHighlighted,
          selected: isHighlighted,
          interval: intervalMap?.get(key) ?? '',
        };
      });

      return {
        notes,
        hasActiveResult: highlightedNotes.length > 0,
        currentSelection: currentSelection ?? null,
        scaleChordState: scaleChordState ?? null,
      };
    }
    ```

**New public interface:**
```typescript
@Injectable({ providedIn: 'root' })
export class FretboardStateService {
  private allPositions: readonly GuitarNote[] = [];
  readonly currentSnapshot = signal<FretboardSnapshot | null>(null);

  initialize(allNotes: readonly GuitarNote[]): void { ... }
  applyHighlightedNotes(
    notesToShow: readonly GuitarNote[],
    intervalMap?: Map<string, string>,
  ): FretboardSnapshot { ... }
  hideAllNotes(): FretboardSnapshot { ... }
  showAll(): FretboardSnapshot { ... }
  clearFretboard(): void { ... }
  private buildSnapshot(...): FretboardSnapshot { ... }
}
```

---

### Step 4: Refactor `FretboardOrchestrationService`

**File:** `src/app/services/fretboard-orchestration.service.ts`

Instead of mutating notes in-place and returning `GuitarNote[]`, each `display*()` method produces a `FretboardSnapshot` and sets it on the service.

**Changes:**

1. **Add `computeIntervals()` method** — pure function returning `Map<string, string>`:
   ```typescript
   private computeIntervals(
     rootNote: string,
     notes: readonly GuitarNote[],
     rawNoteNames?: string[],
   ): Map<string, string> {
     const intervalMap = new Map<string, string>();
     for (const note of notes) {
       const key = `${note.string}-${note.fret}`;
       if (note.note === rootNote) {
         intervalMap.set(key, 'root');
       } else {
         const rawName = rawNoteNames
           ? (rawNoteNames.find(n => this.tonalFacade.simplifyNote(n) === note.note) || note.note)
           : note.note;
         const tonalInterval = this.tonalFacade.intervalBetween(rootNote, rawName);
         intervalMap.set(key, this.tonalFacade.mapInterval(tonalInterval) || '');
       }
     }
     return intervalMap;
   }
   ```

2. **Remove `markIntervals()`** — replaced by `computeIntervals()`

3. **Remove `removeIntervals()`** — no longer needed (snapshots are created fresh each time)

4. **Rewrite `displayScale()`:**
   ```typescript
   displayScale(scaleName: string, rootNote: string): void {
     const { simplified, raw } = this.tonalFacade.resolvePattern(scaleName, rootNote, 'scale');
     const positions = this.noteService.findPositionsByScaleNotes(simplified);
     const intervalMap = this.computeIntervals(rootNote, positions, raw);
     const snapshot = this.guitarNeckService.applyHighlightedNotes(positions, intervalMap);
     this.guitarNeckService.currentSnapshot.set(snapshot);
   }
   ```

5. **Rewrite `displayChord()`** — same pattern as `displayScale()`

6. **Rewrite `clearFretboard()`:**
   ```typescript
   clearFretboard(): void {
     this.guitarNeckService.clearFretboard();
   }
   ```

7. **Rewrite `displayCustomPattern()`** — same pattern as `displayScale()`

8. **Rewrite `displayPositions()`:**
   ```typescript
   displayPositions(positions: GuitarNote[], rootNote?: string): void {
     const intervalMap = rootNote ? this.computeIntervals(rootNote, positions) : undefined;
     const snapshot = this.guitarNeckService.applyHighlightedNotes(positions, intervalMap);
     this.guitarNeckService.currentSnapshot.set(snapshot);
   }
   ```

9. **Rewrite `displayScaleWithChord()`:**
   ```typescript
   displayScaleWithChord(
     scaleName: string, scaleRoot: string,
     chordName: string, chordRoot: string,
   ): void {
     const { simplified: simplifiedScaleNotes } = this.tonalFacade.resolvePattern(scaleName, scaleRoot, 'scale');
     const { simplified: simplifiedChordNotes } = this.tonalFacade.resolvePattern(chordName, chordRoot, 'chord');

     const outsideChordNotes = simplifiedChordNotes.filter(n => !simplifiedScaleNotes.includes(n));
     const scalePositions = this.noteService.findPositionsByScaleNotes(simplifiedScaleNotes);
     const outsidePositions = this.noteService.findPositionsByScaleNotes(outsideChordNotes);
     const allPositions = [...scalePositions, ...outsidePositions];

     const chordSelection: MusicSelection = {
       type: 'chord', name: chordName, rootNote: chordRoot, notes: simplifiedScaleNotes,
     };
     const scaleSelection: MusicSelection = {
       type: 'scale', name: scaleName, rootNote: scaleRoot, notes: simplifiedScaleNotes,
     };

     const scaleChordState: ScaleChordState = { scale: scaleSelection, chord: chordSelection };
     const snapshot = this.guitarNeckService.applyHighlightedNotes(allPositions, undefined, scaleChordState);
     this.guitarNeckService.currentSnapshot.set(snapshot);

     this.markerRoleService.computeRoles(
       snapshot.notes as GuitarNote[], // cast — GuitarNote and FretboardNote are structurally compatible
       scaleSelection,
       chordSelection,
     );
   }
   ```

**Return type change:** All `display*()` methods now return `void` instead of `GuitarNote[]`.

---

### Step 5: Refactor `FretboardDisplayService`

**File:** `src/app/services/fretboard-display.service.ts`

Read from `currentSnapshot()` instead of `notes`, `hasActiveResult`, `scaleChordState`.

**Changes:**

1. **`getActiveIntervals()`:**
   ```typescript
   getActiveIntervals(): string[] {
     const snapshot = this.guitarNeckService.currentSnapshot();
     if (!snapshot || !snapshot.hasActiveResult) {
       return [];
     }
     const intervalSet = new Set<string>();
     snapshot.notes.forEach(note => {
       if (note.selected && note.interval) {
         intervalSet.add(note.interval);
       }
     });
     return Array.from(intervalSet);
   }
   ```

2. **`getMarkerCssClass()`:**
   - Change `this.guitarNeckService.scaleChordState()?.chord` → `this.guitarNeckService.currentSnapshot()?.scaleChordState?.chord`

3. **`getRoleCssClass()`:**
   - Change `this.guitarNeckService.scaleChordState()` → `this.guitarNeckService.currentSnapshot()?.scaleChordState`

4. **`hasRelation`:**
   - Change `this.guitarNeckService.scaleChordState() !== null` → `this.guitarNeckService.currentSnapshot()?.scaleChordState !== null`

---

### Step 6: Refactor `FretboardNoteQueryService`

**File:** `src/app/services/fretboard-note-query.service.ts`

Read from `currentSnapshot().notes` instead of `notes`.

**Changes:**

All methods that currently read `this.guitarNeckService.notes` should read `this.guitarNeckService.currentSnapshot()?.notes ?? []` instead.

```typescript
private get snapshotNotes(): readonly FretboardNote[] {
  return this.guitarNeckService.currentSnapshot()?.notes ?? [];
}

isNoteOnFret(stringIndex: number, fret: number): boolean {
  if (stringIndex >= 0 && !this.domainService.currentState().enabledStrings[stringIndex]) {
    return false;
  }
  return this.snapshotNotes.some(note => this.isMatchingNoteOnFret(note, stringIndex, fret));
}

// Same pattern for getNote(), getNoteName(), fretNoteClicked()
```

**Note:** The return type of `getNote()` and `fretNoteClicked()` changes from `GuitarNote` to `FretboardNote`. Since `FretboardNote` has the same shape as `GuitarNote` (both have `string`, `fret`, `note`, `visible`, `selected`, `interval`), this is backward-compatible for readers.

---

### Step 7: Refactor `MarkerRoleService`

**File:** `src/app/services/marker-role.service.ts`

**Changes:**
- Parameter type of `computeRoles()` changes from `GuitarNote[]` to `readonly GuitarNote[]` (or `readonly FretboardNote[]`)
- No logic change needed — the method already only reads from notes

---

### Step 8: Refactor Components

#### 8a. `GuitarNeckComponent`

**File:** `src/app/guitar-neck/guitar-neck.component.ts`

**Changes:**
- Remove `guitarNotes: GuitarNote[]` field
- Remove `this.guitarNeckService.notes = this.guitarNotes` assignment
- Remove `this.guitarNeckService.hideAllNotes()` call
- Call `this.guitarNeckService.initialize(allPositions)` instead
- Pass `allPositions` to template for `[notes]` input (or remove the input entirely)

**New constructor:**
```typescript
constructor() {
  const allPositions = this.noteService.getAllPositions();
  this.guitarNeckService.initialize(allPositions);
}
```

**Template change** (`guitar-neck.component.html`):
- Remove `[notes]="guitarNotes"` from `<app-freatboard>` — the freatboard reads from `currentSnapshot()` now

#### 8b. `FreatboardComponent`

**File:** `src/app/freatboard/freatboard.component.ts`

**Changes:**
- Remove `notes = input.required<GuitarNote[]>()`
- Remove `ngOnInit()` that assigns `this.guitarNeckService.notes = this.notes()`
- Template `@if (notes())` changes to `@if (guitarNeckService.currentSnapshot())`
- All note reads go through `FretboardNoteQueryService` (already the case)

#### 8c. `LegendComponent`

**File:** `src/app/legend/legend.component.ts`

**Changes:**
- `hasActiveResult` getter reads from `currentSnapshot()` instead of separate signal:
  ```typescript
  get hasActiveResult(): boolean {
    return this.guitarNeckService.currentSnapshot()?.hasActiveResult ?? false;
  }
  ```

---

### Step 9: Update All Tests

#### 9a. `fretboard-state.service.spec.ts`

**Changes:**
- Mock notes are now `GuitarNote` objects (immutable interface) — use `createGuitarNote()` or plain objects
- `service.notes` → `service.currentSnapshot()?.notes`
- `service.hasActiveResult()` → `service.currentSnapshot()?.hasActiveResult`
- `service.notes[0].selected = true` → create a new snapshot with selected notes
- `notesMap` tests → remove (notesMap is gone)
- `applyHighlightedNotes()` returns `FretboardSnapshot`, not `GuitarNote[]`
- `hideAllNotes()` returns `FretboardSnapshot`, doesn't mutate
- `showAll()` returns `FretboardSnapshot`, doesn't mutate
- `clearSelection()` → remove tests (method removed)
- `clearFretboard()` → snapshot is null

#### 9b. `fretboard-orchestration.service.spec.ts`

**Changes:**
- Mock `FretboardStateService` needs `currentSnapshot` signal instead of `notes`, `hasActiveResult`, `scaleChordState`, `currentSelection`
- `applyHighlightedNotes()` mock returns `FretboardSnapshot` instead of `GuitarNote[]`
- `display*()` methods return `void` — assert on `currentSnapshot.set()` calls instead of return values
- Remove `guitarNeckService.notes = [...]` assignments
- `scaleChordState.set(null)` → not called directly anymore (handled via snapshot)

#### 9c. `fretboard-display.service.spec.ts`

**Changes:**
- `guitarNeckService.notes = mockNote` → set `currentSnapshot` with notes
- `guitarNeckService.scaleChordState.set(...)` → set `currentSnapshot` with scaleChordState
- `guitarNeckService.hasActiveResult.set(...)` → set `currentSnapshot` with hasActiveResult

#### 9d. `fretboard-note-query.service.spec.ts`

**Changes:**
- `guitarNeckService.notes.find(...)` → `guitarNeckService.currentSnapshot()?.notes.find(...)`
- `note.visible = true/false` → create snapshot with correct visibility
- Tests need to set up `currentSnapshot` before querying

#### 9e. `marker-role.service.spec.ts`

**Changes:**
- `makeNote()` returns plain object (already does) — just ensure it matches `GuitarNote` interface
- Parameter type change is transparent to tests

#### 9f. `guitar-neck.component.spec.ts`

**Changes:**
- Remove `component.guitarNotes = [...]` assignment
- Component no longer has `guitarNotes` field
- Test initialization changes

#### 9g. `freatboard.component.spec.ts`

**Changes:**
- Remove `fixture.componentRef.setInput('notes', [...])`
- Component no longer has `notes` input
- Set up `currentSnapshot` on the service instead

#### 9h. `legend.component.spec.ts`

**Changes:**
- `guitarNeckService.hasActiveResult.set(...)` → set `currentSnapshot` with hasActiveResult

---

## Order of Implementation

The steps must be done in this order to avoid compilation breaks:

1. **Step 1** — Create `FretboardSnapshot` type (new file, no impact)
2. **Step 2** — Refactor `GuitarNote` → immutable interface (breaks writers, readers still work)
3. **Step 3** — Refactor `FretboardStateService` (new snapshot-based API)
4. **Step 4** — Refactor `FretboardOrchestrationService` (produce snapshots)
5. **Step 5** — Refactor `FretboardDisplayService` (read snapshots)
6. **Step 6** — Refactor `FretboardNoteQueryService` (read snapshots)
7. **Step 7** — Refactor `MarkerRoleService` (parameter type change)
8. **Step 8** — Refactor components (remove direct assignments)
9. **Step 9** — Update all tests

**Critical dependency:** Step 2 MUST be done before Step 3, because Step 3 needs the immutable `GuitarNote` interface. Steps 5-8 can be done in parallel after Step 4.

---

## Risk Assessment

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| Breaking template bindings that mutate note properties | Low | Templates only read, never write — readonly interface is compatible |
| Performance regression from creating new snapshots on every action | Low | Snapshot creation is O(n) where n = number of frets × strings (~150). Negligible. |
| `notesMap` O(1) lookup removal causes performance issue | Low | `FretboardNoteQueryService` uses `.find()` which is O(n) on ~150 items. Acceptable. |
| Tests become harder to write | Low | Snapshots are value objects — easier to assert on equality than mocking side effects |
| Scope creep (refactoring too much at once) | Medium | Stick to the snapshot pattern only. Don't refactor `FretboardOrchestrationService` pipeline at the same time. |

---

## Test Strategy

1. **Snapshot equality** — Tests can assert on `FretboardSnapshot` properties rather than checking individual note mutations
2. **Pure function tests** — `applyHighlightedNotes()` becomes a pure-ish function (input → output), easier to test
3. **Consumer tests** — Mock `currentSnapshot()` signal instead of setting `notes` array directly
4. **No behavior change** — All existing tests should pass with updated assertions. The visual output is identical.

---

## Files Changed (Summary)

| File | Change |
|------|--------|
| `src/app/shared/model/fretboard-snapshot.ts` | **NEW** — `FretboardSnapshot` + `FretboardNote` interfaces |
| `src/app/shared/model/guitarNote.ts` | Replace class with immutable interface + factory |
| `src/app/services/fretboard-state.service.ts` | Replace mutable array with snapshot signal |
| `src/app/services/fretboard-orchestration.service.ts` | Produce snapshots instead of mutating |
| `src/app/services/fretboard-display.service.ts` | Read from snapshot |
| `src/app/services/fretboard-note-query.service.ts` | Read from snapshot |
| `src/app/services/marker-role.service.ts` | Parameter type change only |
| `src/app/guitar-neck/guitar-neck.component.ts` | Use `initialize()` instead of direct assignment |
| `src/app/guitar-neck/guitar-neck.component.html` | Remove `[notes]` binding |
| `src/app/freatboard/freatboard.component.ts` | Remove `notes` input, read from snapshot |
| `src/app/freatboard/freatboard.component.html` | Change `@if (notes())` to `@if (currentSnapshot())` |
| `src/app/legend/legend.component.ts` | Read `hasActiveResult` from snapshot |
| `src/app/services/fretboard-state.service.spec.ts` | Rewrite for snapshot API |
| `src/app/services/fretboard-orchestration.service.spec.ts` | Update mocks/assertions |
| `src/app/services/fretboard-display.service.spec.ts` | Update mocks/assertions |
| `src/app/services/fretboard-note-query.service.spec.ts` | Update mocks/assertions |
| `src/app/services/marker-role.service.spec.ts` | Update parameter types |
| `src/app/freatboard/freatboard.component.spec.ts` | Update mocks |
| `src/app/guitar-neck/guitar-neck.component.spec.ts` | Update mocks |
| `src/app/legend/legend.component.spec.ts` | Update mocks |