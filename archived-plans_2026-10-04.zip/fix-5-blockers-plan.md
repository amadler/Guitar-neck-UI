# Plan naprawy 5 blockerów

## Blocker 1 — Asset path + filename mismatch

**Problem:**
- `lessonRegistry.id: 'interwaly'` (ASCII) ≠ `lessons/interwały.md` (unicode 'ą')
- `lessons/` nie w Angular assets → nie trafia do builda
- Brak `if (!response.ok)` → 404 może być potraktowany jako treść lekcji

**Fix:**
1. Przenieść `lessons/interwały.md` → `src/assets/lessons/interwaly.md` (ASCII-safe filename)
2. Usunąć stary `lessons/interwały.md` (lub zostawić jako source of truth, ale assets bierze z `src/assets/`)
3. W `ChatService.startLesson()` zmienić fetch na `fetch('/assets/lessons/${lessonId}.md')`
4. Dodać `if (!response.ok) throw new Error(...)` przed `response.text()`
5. Zaktualizować `LessonRegistryService` — id zostaje `'interwaly'`

**Pliki:**
- MOVE: `lessons/interwały.md` → `src/assets/lessons/interwaly.md`
- MOD: `src/app/chat/services/chat.service.ts` — fetch path + error handling

---

## Blocker 2 — Klikalność pustego gryfu w exercise mode

**Problem:**
- `FretboardNoteQueryService.isNoteOnFret()` sprawdza `note.visible` z snapshotu
- Po pustym snapshotcie (`hideAllNotes()`) wszystkie nuty mają `visible=false`
- Template renderuje marker tylko gdy `isNoteOnFret()` → brak kropek do kliknięcia
- W exercise mode user nie ma czego kliknąć

**Fix:**
W exercise mode, `fretNoteClicked()` w `FreatboardComponent` powinno działać dla każdej fizycznej pozycji, nie tylko widocznych markerów. `FretboardNotePositionService.getNoteAtPosition()` już zwraca nutę dla dowolnej pozycji (string, fret).

1. W `FretboardNoteQueryService` dodać metodę:
   ```typescript
   getNoteAtPhysicalPosition(stringIndex: number, fret: number): GuitarNote | null
   ```
   która zwraca GuitarNote z `FretboardNotePositionService` (wszystkie pozycje, niezależnie od visible).

2. W `FreatboardComponent.fretNoteClicked()`:
   - Jeśli `exerciseMode`, użyj `getNoteAtPhysicalPosition()` zamiast `fretNoteClicked()` z query service
   - To pozwoli klikać dowolną pozycję na gryfie

3. W template: w exercise mode, renderować kropki dla wszystkich pozycji w fretRange (nie tylko visible). Użyć `isNoteInRange()` + sprawdzenie czy pozycja istnieje fizycznie.

**Pliki:**
- MOD: `src/app/services/fretboard-note-query.service.ts` — dodaj `getNoteAtPhysicalPosition()`
- MOD: `src/app/freatboard/freatboard.component.ts` — `fretNoteClicked()` w exercise mode
- MOD: `src/app/freatboard/freatboard.component.html` — renderuj klikalne kropki w exercise mode

---

## Blocker 3 — sendRaw() nie pokazuje odpowiedzi AI

**Problem:**
- `sendRaw()` konsumuje `stream` ale nie zapisuje odpowiedzi assistant do `messages`
- User nie widzi komentarza nauczyciela po "Sprawdź"
- `sendRaw()` używa `for await (const _event of stream)` — inny kontrakt niż `send()`

**Fix:**
Zrefaktorować `sendRaw()` aby używała tego samego pipeline co `send()`, ale z opcją:
- `showUserInput = false` — nie dodawaj wiadomości usera do chat
- `showAssistantOutput = true` — dodawaj odpowiedź assistant do chat

1. Wyodrębnić wspólny pipeline `processStream()`:
   ```typescript
   private async processStream(
     userMessage: string,
     options: { showUserInput: boolean; showAssistantOutput: boolean }
   ): Promise<void>
   ```
   - Jeśli `showUserInput`, dodaj wiadomość usera
   - Jeśli `showAssistantOutput`, dodaj streaming assistant + finalizuj
   - Konsumuj `stream.messages` i `stream.toolCalls`

2. `send()` → woła `processStream(userMessage, { showUserInput: true, showAssistantOutput: true })`
3. `sendRaw()` → woła `processStream(message, { showUserInput: false, showAssistantOutput: true })`
4. `notifyExerciseSubmitted()` → woła `processStream(message, { showUserInput: false, showAssistantOutput: true })`

**Pliki:**
- MOD: `src/app/chat/services/chat.service.ts` — refaktor send/sendRaw/notifyExerciseSubmitted

---

## Blocker 4 — Walidacja kompletności dla "znajdź wszystkie"

**Problem:**
- Dla "znajdź wszystkie kwinty względem A", validator sprawdza tylko kliknięte nuty
- Jeśli user kliknie 1 z 6 kwint, `correctCount=1, incorrectCount=0` — brak info o brakujących
- Ćwiczenia w lekcji wymagają "znajdź wszystkie"

**Fix:**
Dodać `expectedPositions` do `ExerciseTask` — lista wszystkich poprawnych pozycji w aktualnym `fretRange` i `enabledStrings`. Walidator sprawdza zarówno nadmiarowe (incorrect) jak i brakujące (missing).

1. W `ExerciseTask` dodać opcjonalne `expectedPositions?: Array<{ string: number; fret: number }>`
2. W `ExerciseResult` dodać `missingCount: number` i `missingPositions: Array<{ string: number; fret: number }>`
3. W `ExerciseValidatorService.validate()`:
   - Jeśli `expectedPositions` jest podane, oblicz `missingCount` (expected - selected)
   - `correctCount` = selected ∩ expected
   - `incorrectCount` = selected ∉ expected
   - `missingCount` = expected ∉ selected
4. Agent w `start_exercise` tool może podać `expectedPositions` (opcjonalnie)
   - Albo aplikacja sama oblicza expectedPositions z rootNote + expectedIntervals + fretRange + enabledStrings

**Pliki:**
- MOD: `src/app/domain/state.ts` — ExerciseTask.expectedPositions, ExerciseResult.missingCount
- MOD: `src/app/services/exercise-validator.service.ts` — obsługa expectedPositions
- MOD: `src/app/domain/domain.service.ts` — handleStartExercise może obliczyć expectedPositions

---

## Blocker 5 — Testy

**Problem:**
Brak testów dla nowego core flow.

**Fix:**
Dodać testy dla:

1. **`ExerciseValidatorService`**:
   - Wszystkie poprawne
   - Mieszane (część poprawna, część nie)
   - Puste selectedNotes
   - Z expectedPositions (kompletność)
   - Bez expectedPositions

2. **Komendy domenowe** (przez `DomainService`):
   - `start-exercise` → ustawia exerciseMode, exerciseTask
   - `select-note` → dodaje do selectedNotes
   - `deselect-note` → usuwa z selectedNotes
   - `submit-exercise` → waliduje, zapisuje lastExerciseResult
   - `submit-exercise` bez aktywnego ćwiczenia → NO_ACTIVE_EXERCISE

3. **`ChatService.startLesson()`**:
   - Ładuje plik .md
   - 404 → komunikat o błędzie
   - Resetuje agenta

4. **Klikalność w exercise mode**:
   - `fretNoteClicked()` w exercise mode używa physical position
   - `isExerciseSelected()` poprawnie wskazuje zaznaczone

**Pliki:**
- NEW: `src/app/services/exercise-validator.service.spec.ts`
- NEW: `src/app/domain/domain.service.exercise.spec.ts` (lub rozszerzyć istniejący)
- NEW: `src/app/chat/services/chat.service.lesson.spec.ts`
- MOD: `src/app/freatboard/freatboard.component.spec.ts` — test exercise mode

---

## Kolejność implementacji

1. Blocker 1 (asset path) — najprostszy, runtime crash
2. Blocker 2 (klikalność) — core UX, bez tego ćwiczenia nie działają
3. Blocker 4 (kompletność) — walidacja, zależy od Blockera 2
4. Blocker 3 (sendRaw) — UX, odpowiedzi AI
5. Blocker 5 (testy) — na końcu, po stabilizacji kodu