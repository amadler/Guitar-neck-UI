# Refactor: FE integracja — poprawki po review

## Problemy

1. **`AgentApiService`** — nazwa sugeruje "serwis dla agenta", ale zawiera auth, credentials, progress. SRP violation.
2. **Auth w wielu miejscach** — `credentials: 'include'` powtarza się w każdym serwisie. Brak interceptora.
3. **Inline template + style** — login, register, settings mają template i style w `.ts`. Reszta projektu używa osobnych plików.

## Plan

### R1 — Rozbicie `AgentApiService` na dedykowane serwisy

Obecny [`src/app/services/agent-api.service.ts`](src/app/services/agent-api.service.ts) → rozdzielić na:

| Nowy plik | Odpowiedzialność |
|-----------|------------------|
| `src/app/services/chat-api.service.ts` | Tylko `send()` — NDJSON stream do `/api/chat` |
| `src/app/services/auth-api.service.ts` | `register()`, `login()`, `logout()`, `getMe()` |
| `src/app/services/credentials-api.service.ts` | `saveOpenRouterKey()`, `getOpenRouterStatus()`, `deleteOpenRouterKey()` |
| `src/app/services/progress-api.service.ts` | Metody progress (lub rozszerzyć istniejący [`progress.service.ts`](src/app/services/progress.service.ts)) |

**Usunąć**: `agent-api.service.ts`

### R2 — HTTP Interceptor dla `credentials: 'include'`

Nowy plik: `src/app/auth/auth.interceptor.ts`

- Implementuje `HttpInterceptor` z Angular
- Dodaje `withCredentials: true` do każdego requesta przez `HttpClient`
- Rejestracja w [`app.config.ts`](src/app/app.config.ts) przez `withInterceptors()`

**Uwaga**: Chat nadal używa `fetch` (NDJSON stream) — tam `credentials: 'include'` zostaje ręcznie w `chat-api.service.ts`

### R3 — Style i HTML w osobnych plikach

| Komponent | Obecnie | Docelowo |
|-----------|---------|----------|
| [`login/login.component.ts`](src/app/auth/login/login.component.ts) | Inline template + styles | `login.component.html` + `login.component.scss` |
| [`register/register.component.ts`](src/app/auth/register/register.component.ts) | Inline template + styles | `register.component.html` + `register.component.scss` |
| [`settings/settings.component.ts`](src/app/settings/settings.component.ts) | Inline template + styles | `settings.component.html` + `settings.component.scss` |

### R4 — Aktualizacja zależności

| Plik | Stary import | Nowy import |
|------|-------------|-------------|
| [`auth/auth.service.ts`](src/app/auth/auth.service.ts) | `AgentApiService` | `AuthApiService` |
| [`settings/settings.component.ts`](src/app/settings/settings.component.ts) | `AgentApiService` | `CredentialsApiService` |
| [`chat/services/chat.service.ts`](src/app/chat/services/chat.service.ts) | `AgentApiService` | `ChatApiService` |
| [`services/progress.service.ts`](src/app/services/progress.service.ts) | `AgentApiService` | `ProgressApiService` |
| [`chat/services/chat.service.spec.ts`](src/app/chat/services/chat.service.spec.ts) | `AgentApiService` | `ChatApiService` |

## Kolejność implementacji

1. **R2** — interceptor (najpierw infrastruktura, potem serwisy)
2. **R1** — rozbicie `AgentApiService` na 4 serwisy
3. **R4** — aktualizacja importów we wszystkich zależnych plikach
4. **R3** — osobne pliki HTML + SCSS dla login, register, settings
5. **Usunięcie** `agent-api.service.ts`
6. **Build + testy** — weryfikacja

## Diagram zależności po refactorze

```
AuthService ───→ AuthApiService ───→ HttpClient (+ interceptor)
SettingsComponent ───→ CredentialsApiService ───→ HttpClient (+ interceptor)
ProgressService ───→ ProgressApiService ───→ HttpClient (+ interceptor)
ChatService ───→ ChatApiService ───→ fetch (ręczne credentials)
```

Interceptor dodaje `withCredentials` automatycznie do wszystkich requestów przez `HttpClient`.
ChatApiService używa `fetch` (dla NDJSON stream) — tam `credentials: 'include'` pozostaje ręczne.