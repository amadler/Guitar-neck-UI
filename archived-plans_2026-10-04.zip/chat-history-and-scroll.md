# Plan: Chat auto-scroll + klikalna historia gryfu

## Który repo?

**Tylko to repo** — wszystkie zmiany są po stronie frontendu (Angular). Backend API nie wymaga zmian.

---

## 1. Auto-scroll czatu do najnowszej wiadomości

### Problem
`.messages` div ma `overflow-y: auto`, ale nie przewija się automatycznie gdy pojawia się nowa treść.

### Rozwiązanie
Dodać `#scrollAnchor` na końcu listy wiadomości i wywoływać `scrollIntoView()` po każdej zmianie.

### Plik do zmiany

#### [`src/app/chat/chat.component.ts`](src/app/chat/chat.component.ts)
- Dodać w template: `<div #scrollAnchor></div>` na końcu `.messages`
- Dodać `@ViewChild('scrollAnchor', { read: ElementRef }) scrollAnchor!: ElementRef;`
- Dodać prywatną metodę `scrollToBottom()`:
  ```typescript
  private scrollToBottom(): void {
    afterRender({
      callback: () => {
        this.scrollAnchor?.nativeElement.scrollIntoView({ behavior: 'smooth' });
      }
    });
  }
  ```
- Wywoływać `scrollToBottom()` w `effect()`, który nasłuchuje na `chatService.messages()`

---

## 2. Klikalna historia w treści wiadomości

### Problem
Gdy asystent AI wykonuje `domain-command` (np. pokazuje C-dur, potem A-moll), komendy są wykonywane "cicho" — nie ma możliwości kliknięcia i powrotu do poprzedniego widoku.

### Rozwiązanie
Każda wiadomość asystenta przechowuje listę komend, które zostały wykonane w jej ramach. Pod treścią wiadomości wyświetlane są klikalne chipy.

### Zmiany w modelu

#### [`src/app/chat/models/chat-message.ts`](src/app/chat/models/chat-message.ts)
Dodać pole `domainCommands`:
```typescript
import { DomainCommand } from '../../domain/commands';

export interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
  streaming?: boolean;
  reasoning?: string;
  /** Komendy wykonane w ramach tej wiadomości — klikalna historia */
  domainCommands?: Array<{ command: DomainCommand; label: string }>;
}
```

### Zmiany w serwisie

#### [`src/app/chat/services/chat.service.ts`](src/app/chat/services/chat.service.ts)
- W `processStream()`, w case `'domain-command'` (linia 110-112):
  ```typescript
  case 'domain-command':
    this.domainService.execute(event.command);
    // Dodaj do ostatniej wiadomości asystenta jako klikalną historię
    if (options.showAssistantOutput) {
      updateLastAssistant(this.messages, {
        domainCommands: [
          ...(this.messages().at(-1)?.domainCommands ?? []),
          { command: event.command, label: getCommandLabel(event.command) }
        ]
      });
    }
    break;
  ```
- Dodać funkcję `getCommandLabel(command: DomainCommand): string`:
  - `show-pattern` → `"C major (chord)"` / `"A minor (scale)"`
  - `show-intervals` → `"Interwały [1,3,5] od C"`
  - `compare-patterns` → `"C major vs A minor"`
  - `resolve-shape` → `"Kształt: cowboy-C"`
  - `clear-view` → `"Wyczyść"`
  - inne → `""` (puste = nie pokazuj)

### Zmiany w komponencie

#### [`src/app/chat/chat.component.ts`](src/app/chat/chat.component.ts)
- W template, wewnątrz `.msg` div, po `<p>` z treścią, dodać:
  ```html
  @if (msg.domainCommands?.length) {
    <div class="msg-history">
      @for (dc of msg.domainCommands; track $index) {
        <button class="history-chip" (click)="restoreHistory(dc.command)">
          {{ dc.label }}
        </button>
      }
    </div>
  }
  ```
- Dodać metodę `restoreHistory(command: DomainCommand)`:
  ```typescript
  restoreHistory(command: DomainCommand): void {
    this.domainService.execute(command);
  }
  ```
- Dodać style dla `.msg-history` i `.history-chip`

### Przepływ danych

```
AI (backend)
  → stream event: { type: 'domain-command', command: { type: 'show-pattern', ... } }
  → ChatService.processStream()
    → 1. domainService.execute(command)        // zmienia widok gryfu
    → 2. updateLastAssistant(domainCommands: [  // dodaje do wiadomości
         { command, label: 'C-dur' }
       ])
      → messages signal update
        → ChatComponent template re-render
          → chip pojawia się pod treścią wiadomości
    → 3. scrollToBottom()                       // przewija czat
```

```
Użytkownik klika chip w treści wiadomości
  → ChatComponent.restoreHistory(command)
    → domainService.execute(command)            // przywraca widok gryfu
```

### UI/UX

```
┌──────────────────────────────────────┐
│  Wiadomość 1                          │
│  Treść wiadomości...                  │
│  [C-dur] [1 3 5]                      │ ← chipy dla tej wiadomości
├──────────────────────────────────────┤
│  Wiadomość 2                          │
│  Treść wiadomości...                  │
│  [A-moll]                             │ ← chipy dla tej wiadomości
├──────────────────────────────────────┤
│  Wiadomość 3                          │
│  Treść wiadomości...                  │
│  [Interwały 1,b3,5 od A]             │ ← chipy dla tej wiadomości
├──────────────────────────────────────┤
│ [input............................]  │
└──────────────────────────────────────┘
```

Zalety:
- Historia jest **kontekstowa** — widać która wiadomość spowodowała którą zmianę
- Nie zapycha się przy długiej konwersacji (każda wiadomość ma swoje chipy)
- Działa zarówno dla `domain-command` eventów jak i dla action tagów (action tagi już są klikalne, to jest uzupełnienie)

---

## Podsumowanie plików do zmiany

| Plik | Operacja | Opis |
|------|----------|------|
| `src/app/chat/models/chat-message.ts` | **EDYCJA** | Dodanie `domainCommands` do `ChatMessage` |
| `src/app/chat/services/chat.service.ts` | **EDYCJA** | Rejestracja `domain-command` w `domainCommands` wiadomości, dodanie `getCommandLabel()` |
| `src/app/chat/chat.component.ts` | **EDYCJA** | Dodanie auto-scroll, sekcji `msg-history` w template, `restoreHistory()`, stylów |