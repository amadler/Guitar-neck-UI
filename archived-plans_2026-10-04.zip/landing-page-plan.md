# Landing Page — Plan Architektoniczny

## 1. Cel

Dodanie landing page (`/`) przed główną aplikacją (`/app`). Landing page:
- Prezentuje hero section z opisem aplikacji
- Pozwala wybrać adapter AI i wpisać klucz API
- Automatycznie przekierowuje do `/app` jeśli klucz już istnieje w localStorage
- Logo w headerze prowadzi z `/app` z powrotem na landing

## 2. Decyzje Architektoniczne

### 2.1. Routing

| Ścieżka | Komponent | Opis |
|---------|-----------|------|
| `/` | `LandingPageComponent` (nowy) | Landing page z hero + formularzem |
| `/app` | `AppPageComponent` (dawny `HomePageComponent`) | Główna aplikacja z gryfem |

### 2.2. Zmiana nazwy

`HomePageComponent` → `AppPageComponent` (wszystkie pliki: `.ts`, `.html`, `.scss`, `.spec.ts`)

### 2.3. Header na poziomie AppComponent

Header (`app-header`) przenosi się z `HomePageComponent` → `AppComponent` (nad `<router-outlet>`), żeby był widoczny na obu stronach. Logo w headerze staje się linkiem do `/`.

### 2.4. localStorage — klucze

| Klucz | Wartość | Ustawiany przez |
|-------|---------|-----------------|
| `modelApiKey` | string (klucz API) | Landing page formularz |
| `modelName` | string (np. `openrouter/deepseek-v4-flash`) | Landing page formularz |

### 2.5. Adaptery (modele AI)

4 opcje w formularzu:

| Label UI | Wartość localStorage | Provider LangChain |
|----------|---------------------|-------------------|
| OpenRouter — DeepSeek V4 Flash | `openrouter/deepseek-v4-flash` | `ChatOpenRouter` |
| OpenAI — GPT-4o Mini | `openai/gpt-4o-mini` | `ChatOpenAI` |
| Anthropic — Claude Haiku | `anthropic/claude-3-haiku` | `ChatAnthropic` |
| Google — Gemini Flash | `google/gemini-flash` | `ChatGoogleGenerativeAI` |

### 2.6. Redirect

`LandingPageComponent` w `ngOnInit()` sprawdza `localStorage.getItem('modelApiKey')`. Jeśli istnieje → `router.navigate(['/app'])`.

### 2.7. ChatService

Odczytuje `localStorage.getItem('modelName')` i na jego podstawie tworzy odpowiednią instancję modelu LangChain. Na razie prosty switch — później refaktor na strategię.

## 3. Komponent Tree (po zmianach)

```
AppComponent
├── app-header (przeniesiony z HomePageComponent)
│   └── logo → link do /
└── <router-outlet>
    ├── / → LandingPageComponent
    │   ├── HeroSection (inline)
    │   │   ├── headline + subheadline
    │   │   └── hero image (placeholder z New layout/screen.png)
    │   └── SetupForm (inline)
    │       ├── select (adapter/model)
    │       ├── input (API key)
    │       └── button (Zapisz i przejdź)
    └── /app → AppPageComponent (dawny HomePageComponent)
        ├── app-header (już w AppComponent)
        ├── command-bar
        ├── fretboard-section
        ├── bottom-panel
        └── app-footer
```

## 4. Pliki do utworzenia

| Plik | Opis |
|------|------|
| `src/app/landing-page/landing-page.component.ts` | Nowy komponent landing page |
| `src/app/landing-page/landing-page.component.html` | Template: hero + form |
| `src/app/landing-page/landing-page.component.scss` | Style: light, Organic Professional |
| `src/app/landing-page/landing-page.component.spec.ts` | Testy |

## 5. Pliki do modyfikacji

| Plik | Zmiana |
|------|--------|
| `src/app/app.routes.ts` | Dodaj route `/app` → `AppPageComponent`, `/` → `LandingPageComponent` |
| `src/app/app.component.html` | Dodaj `<app-header>` nad `<router-outlet>` |
| `src/app/app.component.ts` | Import HeaderComponent |
| `src/app/header/header.component.html` | Dodaj `routerLink="/"` na logo |
| `src/app/header/header.component.ts` | Import `RouterLink` |
| `src/app/home-page/home-page.component.ts` | **Zmień nazwę** na `AppPageComponent` |
| `src/app/home-page/home-page.component.html` | Usuń `<app-header>` (przeniesiony wyżej) |
| `src/app/home-page/home-page.component.scss` | Usuń `.app-shell` grid (przeniesiony?) |
| `src/app/home-page/home-page.component.spec.ts` | Aktualizacja nazwy |
| `src/app/chat/services/chat.service.ts` | Odczytuj `modelName` z localStorage, switch na providerze |
| `src/styles.scss` | Dodaj globalne style dla landing page (jeśli potrzeba) |

## 6. Pliki do usunięcia / rename

| Stara nazwa | Nowa nazwa |
|-------------|-----------|
| `src/app/home-page/home-page.component.ts` | `src/app/app-page/app-page.component.ts` |
| `src/app/home-page/home-page.component.html` | `src/app/app-page/app-page.component.html` |
| `src/app/home-page/home-page.component.scss` | `src/app/app-page/app-page.component.scss` |
| `src/app/home-page/home-page.component.spec.ts` | `src/app/app-page/app-page.component.spec.ts` |
| `src/app/home-page/` (katalog) | `src/app/app-page/` (katalog) |

## 7. Landing Page — Design

- **Motyw**: Light, "Organic Professional" (zgodny z `New layout/DESIGN.md`)
- **Kolory**: `--md-surface` (#f7faf4) tło, `--md-primary` (#386948) akcenty
- **Typografia**: Literata (headline), Nunito Sans (body)
- **Układ**:
  ```
  ┌─────────────────────────────────────┐
  │           HERO SECTION              │
  │  ┌───────────────────────────────┐  │
  │  │  Headline (Literata, 48px)    │  │
  │  │  Subheadline (Nunito, 18px)   │  │
  │  │                               │  │
  │  │  ┌─────────────────────────┐  │  │
  │  │  │   Hero image (screenshot)│  │  │
  │  │  └─────────────────────────┘  │  │
  │  └───────────────────────────────┘  │
  │                                     │
  │  ┌───────────────────────────────┐  │
  │  │       SETUP FORM             │  │
  │  │  ┌───────────────────────┐   │  │
  │  │  │ Wybierz model: [▼]   │   │  │
  │  │  │ Klucz API: [______]   │   │  │
  │  │  │ [Zapisz i przejdź 🚀] │   │  │
  │  │  └───────────────────────┘   │  │
  │  │  Link: "Masz już klucz?"     │  │
  │  └───────────────────────────────┘  │
  │                                     │
  │            FOOTER                   │
  └─────────────────────────────────────┘
  ```

## 8. Przepływ użytkownika

```
Wejście na /
│
├── localStorage ma modelApiKey?
│   ├── TAK → router.navigate('/app') → AppPageComponent
│   └── NIE → pokaż LandingPageComponent
│
Użytkownik widzi hero + formularz
│
├── Wybiera model z dropdown
├── Wpisuje klucz API
├── Kliknie "Zapisz i przejdź"
│
Zapis do localStorage: modelApiKey, modelName
router.navigate('/app')
│
AppPageComponent ładuje się
Header widoczny (w AppComponent)
Logo w headerze → link do /
ChatService czyta modelName z localStorage
```

## 9. ChatService — zmiany

```typescript
// W getOrCreateAgent():
const apiKey = localStorage.getItem('modelApiKey');
const modelName = localStorage.getItem('modelName') || 'openrouter/deepseek-v4-flash';

switch (modelName) {
  case 'openai/gpt-4o-mini':
    model = new ChatOpenAI({ model: 'gpt-4o-mini', apiKey });
    break;
  case 'anthropic/claude-3-haiku':
    model = new ChatAnthropic({ model: 'claude-3-haiku', apiKey });
    break;
  case 'google/gemini-flash':
    model = new ChatGoogleGenerativeAI({ model: 'gemini-flash', apiKey });
    break;
  default: // openrouter/deepseek-v4-flash
    model = new ChatOpenRouter({ model: 'deepseek/deepseek-v4-flash', apiKey });
    break;
}
```

## 10. Potencjalne problemy

1. **Header na landing page**: Header jest widoczny na landing page (bo w AppComponent). Na landing page nie pokazujemy przycisków AI toggle / help — header musi być warunkowy.
2. **Footer**: Obecnie footer jest w `HomePageComponent`. Po przeniesieniu headera, footer też może być przeniesiony do AppComponent, żeby był widoczny na landing page.
3. **Testy**: `HomePageComponent.spec.ts` i inne testy importujące `HomePageComponent` trzeba zaktualizować.
4. **`.app-shell` grid**: Obecnie zdefiniowany w `styles.scss` jako grid z `var(--header-height)`. Po przeniesieniu headera, grid może wymagać dostosowania.