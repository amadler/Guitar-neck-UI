# Plan: Fix LangGraph Agent Recursion Limit — Lesson Mode HITL

Branch: `lesson-poprawki`

## Problem

W trybie lekcji agent LangGraph wykonuje sekwencję akcji dydaktycznych w jednym nieprzerwanym przebiegu:

```
LLM → show_interval → clear_view → show_interval → clear_view → ...
```

Nie czeka na użytkownika między krokami. Kończy się błędem:

```
GRAPH_RECURSION_LIMIT: Recursion limit of 25 reached without hitting a stop condition
```

## Rozwiązanie: Human-in-the-Loop przez `interrupt()`

Używamy LangGraph [`interrupt()`](https://langchain-ai.github.io/langgraphjs/how-tos/human_in_the_loop/) do pauzowania grafu po każdej akcji dydaktycznej w lesson mode.

## Analiza obecnego kodu

### ChatService (`src/app/chat/services/chat.service.ts`)

- `createAgent()` z `langchain` tworzy agenta z `MemorySaver` checkpointem
- `processStream()` woła `agent.streamEvents()` i przetwarza wszystkie tool calls i messages w jednym przebiegu
- `_lessonMode` — boolean flag, czy lekcja aktywna
- `config.thread_id` — unikalny ID dla każdej lekcji (resetowany w `resetAgent()`)
- `notifyExerciseSubmitted()` — wysyła sztuczny prompt "Użytkownik kliknął Sprawdź..." → do usunięcia

### DomainTools (`src/app/chat/tools/domain-tools.ts`)

- `createDomainTools(domainService)` — tworzy tablicę tooli
- `start_exercise` — wykonuje `domainService.execute({ type: 'start-exercise', ... })` i zwraca wynik
- `submit_exercise` — wykonuje submit i czyta `lastExerciseResult` z state
- `get_exercise_result` — czyta aktualny stan ćwiczenia
- Inne tool: `show_interval`, `show_pattern`, `compare_patterns`, `clear_view`, `set_view`, `set_emphasis`, `resolve_shape`, `set_ai_mode`, `get_current_view`

### DomainService (`src/app/domain/domain.service.ts`)

- `handleStartExercise()` — ustawia `exerciseMode: true`, `exerciseTask`, czyści `selectedNotes` i `lastExerciseResult`
- `handleSubmitExercise()` — waliduje, zapisuje `lastExerciseResult`, resetuje `exerciseMode` i `exerciseTask`

### GuitarNeckComponent (`src/app/guitar-neck/guitar-neck.component.ts`)

- `submitExercise()` — woła `domainService.execute({ type: 'submit-exercise' })` i `chatService.notifyExerciseSubmitted()`

## Kluczowe decyzje architektoniczne

### 1. `interrupt()` tylko w lesson mode

Normalny chat (poza lekcją) ma działać bez zmian — bez interrupt.

### 2. Które tool wymagają interrupt?

**Z interrupt (akcje zmieniające gryf):**
- `show_interval` — pokazuje interwał → user ma czas zobaczyć
- `show_pattern` — pokazuje skalę/akord → user ma czas zobaczyć
- `compare_patterns` — porównanie → user ma czas zobaczyć
- `start_exercise` — ćwiczenie → user klika nuty

**Bez interrupt (pomocnicze):**
- `clear_view` — jeśli jest technicznym przygotowaniem do kolejnej akcji w tym samym kroku, nie pauzuje
- `set_view`, `set_emphasis` — konfiguracja widoku, nie pauzuje
- `resolve_shape` — pokazuje chwyt, ale to też zmiana gryfu → **z interrupt**
- `get_current_view`, `get_exercise_result` — query, bez interrupt
- `set_ai_mode` — przełącznik UI, bez interrupt

**Decyzja o `clear_view`**: Jeśli agent woła `clear_view` jako samodzielną akcję dydaktyczną (np. "teraz wyczyśćmy i pokażę następny"), to powinien pauzować. Ale jeśli to techniczny krok przed `show_interval` w tej samej turze, nie pauzuje. Ponieważ nie możemy kontrolować jak agent używa toola, **nie dodajemy interrupt do `clear_view`** — agent i tak wywoła go przed `show_interval` w ramach przygotowania, a interrupt zrobi `show_interval`.

### 3. Stan lesson mode

`lessonMode` to stan orchestration, nie domain. Przechowujemy go w `ChatService` jako `_lessonMode: boolean`.

Nie wrzucamy do `DomainState`.

### 4. Resume semantics — ochrona przed podwójnym wykonaniem

`interrupt()` w LangGraph JS może wznowić tool/node. Kod przed `interrupt()` może wykonać się ponownie przy resume.

**Zabezpieczenia:**
- `start_exercise` — przed `interrupt()` wykonuje `domainService.execute()`. Przy resume to samo ćwiczenie zostanie uruchomione ponownie, kasując `selectedNotes` i `lastExerciseResult`. **To jest problem.**
- Rozwiązanie: dodać `exerciseId` (np. timestamp + counter) do `ExerciseTask`. Przed wykonaniem `start-exercise` sprawdzić, czy ćwiczenie o tym samym `exerciseId` już istnieje. Jeśli tak — pominąć side effect.

Alternatywnie: rozdzielić przygotowanie stanu od interrupt — przygotować stan przed toolem, a w toolu tylko interrupt i odczyt wyniku. Ale to zmienia architekturę.

**Prostsze rozwiązanie**: W `start_exercise` tool, przed `domainService.execute()`, sprawdzić czy `exerciseMode` jest już true i `exerciseTask` pasuje do inputu. Jeśli tak — nie wykonuj ponownie, tylko idź do `interrupt()`.

### 5. Resume po zwykłej odpowiedzi usera

Gdy graph jest przerwany po `show_interval`, kolejna wiadomość usera (np. "dalej") powinna wznowić graph przez `Command({ resume: userMessage })`.

Gdy graph nie jest przerwany (idle), zwykły `send()` działa normalnie.

### 6. Resume po exercise submit

`GuitarNeckComponent.submitExercise()`:
1. Wykonuje `domainService.execute({ type: 'submit-exercise' })`
2. Pobiera `lastExerciseResult` z `domainService.currentState()`
3. Przekazuje do `ChatService.resumeWithExerciseResult(result)`
4. `ChatService` robi `Command({ resume: exerciseResult })`

Nie wysyła sztucznego HumanMessage.

### 7. Stan grafu

Potrzebujemy wiedzieć w `ChatService`, czy graph jest:
- `idle` — nie ma aktywnego grafu
- `running` — graph aktualnie przetwarza
- `interrupted` — graph przerwany przez `interrupt()`, czeka na resume

Minimalny enum, bez ciężkiego state machine.

## Plan implementacji

### Krok 1: Dodaj `@langchain/langgraph` do zależności

**Plik**: `package.json`

```json
"dependencies": {
  ...
  "@langchain/langgraph": "^1.4.14",
  ...
}
```

`@langchain/langgraph` v1.4.14 jest już w `node_modules` jako transitive dependency. Dodajemy explicite.

---

### Krok 2: Dodaj stan grafu do ChatService

**Plik**: `src/app/chat/services/chat.service.ts`

Dodaj:

```typescript
import { Command, interrupt } from "@langchain/langgraph";

type GraphStatus = 'idle' | 'running' | 'interrupted';

// W klasie:
private _graphStatus: GraphStatus = 'idle';
```

---

### Krok 3: Zmodyfikuj `processStream` dla lesson mode

**Plik**: `src/app/chat/services/chat.service.ts`

Obecnie `processStream` używa `agent.streamEvents()` z `version: "v3"`, który zwraca uproszczony `StreamEvents` z `messages` i `toolCalls`.

Dla lesson mode z `interrupt()` potrzebujemy użyć niższopoziomowego API `streamEvents` z `@langchain/langgraph`, które obsługuje eventy interrupt.

**Problem**: `createAgent()` z `langchain` zwraca `Runnable`, nie LangGraph `StateGraph`. Możemy nie mieć dostępu do natywnych eventów interrupt.

**Rozwiązanie**: Zamiast `createAgent()`, budujemy graph ręcznie używając `StateGraph` z `@langchain/langgraph`. To daje pełną kontrolę nad interruptami.

**Alternatywa**: Sprawdzić czy `createAgent().graph` jest dostępne. Jeśli tak, użyć `agent.graph.streamEvents()` zamiast `agent.streamEvents()`.

**Decyzja**: Budujemy graph ręcznie. To daje:
- Kontrolę nad interruptami
- Możliwość dodania dedykowanego node'a do interrupt po tool call
- Zachowanie istniejącego `MemorySaver`

**Struktura grafu**:

```
[__start__] → [agent] → [tools] → [should_interrupt?] → [__end__]
                  ↑          |            |
                  └──────────┘            ↓
                                     [interrupt]
                                          |
                                     [__end__]
```

Gdzie `should_interrupt?` to conditional edge:
- Jeśli lesson mode i tool był dydaktyczny → idź do `interrupt` node
- W przeciwnym razie → idź do `agent` (normalna pętla)

**Implementacja**:

```typescript
import { StateGraph, Annotation, Command, interrupt } from "@langchain/langgraph";
import { RunnableConfig } from "@langchain/core/runnables";

// Stan grafu
const AgentState = Annotation.Root({
  messages: Annotation<BaseMessage[]>({
    reducer: (a, b) => a.concat(b),
  }),
});

function buildLessonAgent(model: ChatOpenRouter, tools: any[], checkpointer: MemorySaver) {
  const agentNode = async (state: typeof AgentState.State) => {
    const llm = model.bindTools(tools);
    const result = await llm.invoke(state.messages);
    return { messages: [result] };
  };

  const toolsNode = async (state: typeof AgentState.State) => {
    const lastMessage = state.messages[state.messages.length - 1];
    if (!lastMessage?.tool_calls?.length) return state;
    
    const results = [];
    for (const tc of lastMessage.tool_calls) {
      const tool = tools.find(t => t.name === tc.name);
      if (!tool) continue;
      const result = await tool.invoke(tc.args);
      results.push(new ToolMessage({ content: JSON.stringify(result), tool_call_id: tc.id }));
    }
    return { messages: results };
  };

  const shouldInterrupt = (state: typeof AgentState.State) => {
    // Check if lesson mode and last tool was didactic
    // This is determined by the tool itself calling interrupt()
    return "agent";
  };

  const graph = new StateGraph(AgentState)
    .addNode("agent", agentNode)
    .addNode("tools", toolsNode)
    .addEdge("__start__", "agent")
    .addConditionalEdges("agent", shouldInterrupt, {
      agent: "tools",
      end: "__end__",
    })
    .addEdge("tools", "agent")
    .compile({ checkpointer });

  return graph;
}
```

**Jednak to jest DUŻO kodu i zmienia architekturę znacząco.**

**Prostsze podejście**: Użyj `createAgent()` ale zmień `processStream` żeby używać niższopoziomowego API.

Sprawdźmy czy `createAgent()` zwraca coś z polem `graph`:

W LangChain v1.5.x, `createAgent()` z `checkpointer` tworzy `RunnableAgent` który wewnętrznie jest LangGraph `StateGraph`. Możemy dostać się do grafu przez `(agent as any).graph` lub podobne.

**Najprostsze podejście**: Użyj `createAgent()` ale zamiast `streamEvents` z `version: "v3"`, użyj `streamEvents` z `version: "v2"` które zwraca surowe eventy LangGraph, w tym `on_interrupt`.

```typescript
const stream = await agent.streamEvents(
  { messages: [new HumanMessage(userMessage)] },
  { ...this.config, version: "v2" }, // v2 zamiast v3
);

for await (const event of stream) {
  // event.event to np. "on_chat_model_stream", "on_tool_start", "on_interrupt", itd.
}
```

**Jednak** `version: "v2"` zwraca inny format eventów niż obecny kod oczekuje.

**Decyzja ostateczna**: Budujemy graph ręcznie używając `@langchain/langgraph`. To jest najczystsze rozwiązanie, które daje pełną kontrolę. Kod grafu jest prosty — to standardowy tool-calling agent z dodatkowym interrupt node.

---

### Krok 4: Dodaj `interrupt()` w toolach dydaktycznych

**Plik**: `src/app/chat/tools/domain-tools.ts`

Zmodyfikuj `createDomainTools` żeby przyjmował opcjonalny kontekst lesson mode:

```typescript
export function createDomainTools(
  domainService: DomainService,
  context?: { isLessonMode: () => boolean },
) {
```

W toolach dydaktycznych (`show_interval`, `show_pattern`, `compare_patterns`, `start_exercise`):

```typescript
tool(
  async (input: ShowIntervalInput) => {
    const command: DomainCommand = { type: "show-interval", rootNote: input.rootNote, interval: input.interval };
    const result = domainService.execute(command);
    
    // Interrupt only in lesson mode
    if (context?.isLessonMode()) {
      interrupt({ type: 'lesson_step', action: 'show_interval', rootNote: input.rootNote, interval: input.interval });
    }
    
    return { ... };
  },
  ...
)
```

**Ważne**: `interrupt()` w LangGraph JS rzuca specjalny wyjątek, który jest łapany przez graph runtime. Kod PO `interrupt()` wykona się DOPIERO przy resume. Dlatego `return` po `interrupt()` jest bezpieczne — wykona się przy resume.

**Dla `start_exercise`**:

```typescript
tool(
  async (input: StartExerciseInput) => {
    const command: DomainCommand = { type: "start-exercise", ... };
    const result = domainService.execute(command);
    
    if (context?.isLessonMode()) {
      interrupt({ type: 'exercise', question: input.question, rootNote: input.rootNote });
    }
    
    // Przy resume: odczytaj wynik ćwiczenia
    const state = domainService.query<DomainState>({ type: "get-current-view" });
    const exerciseResult = state.success ? state.data.lastExerciseResult : undefined;
    
    return {
      success: result.success,
      action: "start-exercise",
      exerciseResult, // bezpośrednio w tool output
      message: result.success ? `Rozpoczęto ćwiczenie: ${input.question}` : result.message,
    };
  },
  ...
)
```

**Zabezpieczenie przed podwójnym wykonaniem `start-exercise` przy resume**:

```typescript
// Przed domainService.execute() sprawdź czy ćwiczenie już aktywne
const currentState = domainService.query<DomainState>({ type: "get-current-view" });
if (currentState.success && currentState.data.exerciseMode) {
  // Ćwiczenie już aktywne — nie wykonuj ponownie, tylko interrupt
  if (context?.isLessonMode()) {
    interrupt({ type: 'exercise', question: input.question, rootNote: input.rootNote });
  }
  // Odczytaj wynik
  const exerciseResult = currentState.data.lastExerciseResult;
  return { success: true, action: "start-exercise", exerciseResult, message: "Ćwiczenie już aktywne." };
}
```

---

### Krok 5: Zmodyfikuj `ChatService` — resume flow

**Plik**: `src/app/chat/services/chat.service.ts`

#### 5a. `send()` w lesson mode z interrupted graph

```typescript
async send(userMessage: string): Promise<void> {
  if (this._graphStatus === 'interrupted') {
    // Resume the interrupted graph with user message
    await this.resumeGraph(new Command({ resume: userMessage }));
    return;
  }
  await this.processStream(userMessage, { showUserInput: true, showAssistantOutput: true });
}
```

#### 5b. `resumeGraph()` — nowa metoda

```typescript
private async resumeGraph(resumeCommand: Command): Promise<void> {
  if (this.loading()) return;
  this.loading.set(true);
  this._graphStatus = 'running';
  
  try {
    const agent = this.getOrCreateAgent();
    const stream = await agent.streamEvents(
      resumeCommand,
      { ...this.config, version: "v2" },
    );
    
    // Process events — handle messages and tool calls
    for await (const event of stream) {
      if (event.event === 'on_chat_model_stream') {
        // Stream token
      } else if (event.event === 'on_tool_start') {
        // Tool call started
      } else if (event.event === 'on_tool_end') {
        // Tool call completed
      }
    }
  } finally {
    this.loading.set(false);
    this._graphStatus = 'idle';
  }
}
```

**Problem**: `version: "v2"` event stream ma inny format niż obecny kod. Trzeba dostosować logikę streamowania.

**Uproszczenie**: Użyj `agent.invoke()` zamiast `streamEvents()` dla resume. To zwraca końcowy stan, nie streamuje tokenów.

```typescript
private async resumeGraph(resumeCommand: Command): Promise<void> {
  if (this.loading()) return;
  this.loading.set(true);
  this._graphStatus = 'running';
  
  try {
    const agent = this.getOrCreateAgent();
    const result = await agent.invoke(resumeCommand, this.config);
    
    // Extract the last AI message from result
    const lastMessage = result.messages[result.messages.length - 1];
    if (lastMessage?.content) {
      this.messages.update(m => [...m, { role: 'assistant', text: lastMessage.content }]);
    }
  } finally {
    this.loading.set(false);
    this._graphStatus = 'idle';
  }
}
```

**Jednak** to nie streamuje tokenów. Dla lepszego UX możemy użyć `streamEvents` z `version: "v2"` i przetwarzać eventy.

**Kompromis**: Używamy `streamEvents` z `version: "v2"` dla resume, ale uproszczamy logikę — tylko zbieramy tokeny i pokazujemy je.

#### 5c. `resumeWithExerciseResult()` — nowa metoda

```typescript
async resumeWithExerciseResult(result: ExerciseResult): Promise<void> {
  if (this._graphStatus !== 'interrupted') return;
  await this.resumeGraph(new Command({ resume: result }));
}
```

#### 5d. Modyfikacja `processStream` dla lesson mode

W `processStream`, po zakończeniu streamowania, sprawdź czy graph został przerwany:

```typescript
// Po zakończeniu streamEvents
if (this._lessonMode && this._graphStatus === 'interrupted') {
  // Graph został przerwany przez interrupt() — czekamy na user input
  return;
}
```

**Jak wykryć interrupt?** Gdy `interrupt()` jest wywołane w toolu, `streamEvents` rzuca błąd lub zwraca specjalny event. W `version: "v3"` może to być ukryte.

**Bezpieczniejsze podejście**: Nie używaj `version: "v3"` dla lesson mode. Zamiast tego:

```typescript
// W processStream dla lesson mode
try {
  const stream = await agent.streamEvents(
    { messages: [new HumanMessage(userMessage)] },
    { ...this.config, version: "v1" }, // v1 daje surowe eventy
  );
  
  for await (const event of stream) {
    if (event.event === 'on_interrupt') {
      this._graphStatus = 'interrupted';
      break; // Stop processing
    }
    // Handle other events...
  }
} catch (err) {
  // Handle error
}
```

**Problem**: `version: "v1"` i `"v2"` mają różne formaty eventów. Obecny kod używa `"v3"`.

**Decyzja**: Dla lesson mode używamy innego flow niż dla normalnego chatu. Normalny chat nadal używa `version: "v3"` z obecnym kodem. Lesson mode używa ręcznie zbudowanego grafu z `@langchain/langgraph`.

---

### Krok 6: Zbuduj graph ręcznie dla lesson mode

**Plik**: `src/app/chat/services/chat.service.ts` (lub nowy plik `src/app/chat/services/lesson-agent.ts`)

Tworzymy osobny agent dla lesson mode, który:
1. Używa tego samego modelu i tooli
2. Ma wbudowany interrupt po tool call
3. Używa tego samego `MemorySaver`

```typescript
import { StateGraph, Annotation, Command, interrupt } from "@langchain/langgraph";
import { BaseMessage, ToolMessage } from "@langchain/core/messages";

const LessonState = Annotation.Root({
  messages: Annotation<BaseMessage[]>({
    reducer: (a, b) => a.concat(b),
  }),
});

function buildLessonGraph(
  model: ChatOpenRouter,
  tools: ReturnType<typeof createDomainTools>,
  checkpointer: MemorySaver,
) {
  const callModel = async (state: typeof LessonState.State) => {
    const llm = model.bindTools(tools);
    const result = await llm.invoke(state.messages);
    return { messages: [result] };
  };

  const callTools = async (state: typeof LessonState.State) => {
    const lastMessage = state.messages[state.messages.length - 1];
    if (!lastMessage?.tool_calls?.length) return state;
    
    const results: ToolMessage[] = [];
    for (const tc of lastMessage.tool_calls) {
      const tool = tools.find(t => t.name === tc.name);
      if (!tool) continue;
      try {
        const result = await tool.invoke(tc.args);
        results.push(new ToolMessage({ content: JSON.stringify(result), tool_call_id: tc.id }));
      } catch (err) {
        // If interrupt was called, the tool threw — stop processing
        break;
      }
    }
    return { messages: results };
  };

  const shouldContinue = (state: typeof LessonState.State) => {
    const lastMessage = state.messages[state.messages.length - 1];
    if (lastMessage?.tool_calls?.length) {
      return "tools";
    }
    return "__end__";
  };

  const graph = new StateGraph(LessonState)
    .addNode("agent", callModel)
    .addNode("tools", callTools)
    .addEdge("__start__", "agent")
    .addConditionalEdges("agent", shouldContinue, {
      tools: "tools",
      __end__: "__end__",
    })
    .addEdge("tools", "agent")
    .compile({ checkpointer });

  return graph;
}
```

**Problem**: `interrupt()` rzucone wewnątrz toola (który jest wywołany przez `tool.invoke()`) musi być złapane przez LangGraph runtime. To działa tylko jeśli tool jest wywołany wewnątrz node'a grafu, a nie bezpośrednio.

W naszym `callTools` node, wywołujemy `tool.invoke(tc.args)`. Jeśli wewnątrz toola jest `interrupt()`, to rzuci on specjalny wyjątek (`GraphInterrupt`), który musimy przepuścić, żeby LangGraph go złapał.

**Poprawka**:

```typescript
const callTools = async (state: typeof LessonState.State) => {
  const lastMessage = state.messages[state.messages.length - 1];
  if (!lastMessage?.tool_calls?.length) return state;
  
  const results: ToolMessage[] = [];
  for (const tc of lastMessage.tool_calls) {
    const tool = tools.find(t => t.name === tc.name);
    if (!tool) continue;
    const result = await tool.invoke(tc.args);
    results.push(new ToolMessage({ content: JSON.stringify(result), tool_call_id: tc.id }));
  }
  return { messages: results };
};
```

Nie łapiemy wyjątku — pozwalamy, żeby `GraphInterrupt` propagował się do LangGraph runtime.

---

### Krok 7: Zmodyfikuj `ChatService` — użyj lesson grafu

**Plik**: `src/app/chat/services/chat.service.ts`

```typescript
private _lessonGraph: ReturnType<typeof buildLessonGraph> | null = null;

private getOrCreateLessonGraph() {
  if (!this._lessonGraph) {
    const apiKey = localStorage.getItem(API_KEY_STORAGE_KEY);
    const modelName = localStorage.getItem(MODEL_STORAGE_KEY) || DEFAULT_MODEL;
    const model = new ChatOpenRouter({ model: modelName, apiKey });
    const tools = createDomainTools(this.domainService, {
      isLessonMode: () => this._lessonMode,
    });
    this._lessonGraph = buildLessonGraph(model, tools, new MemorySaver());
  }
  return this._lessonGraph;
}
```

**Dla lesson mode `processStream`**:

```typescript
private async processLessonStream(userMessage: string): Promise<void> {
  if (this.loading()) return;
  this.loading.set(true);
  this._graphStatus = 'running';
  
  this.messages.update(m => [...m, { role: 'assistant', text: '', streaming: true }]);
  
  try {
    const graph = this.getOrCreateLessonGraph();
    const stream = await graph.streamEvents(
      { messages: [new HumanMessage(userMessage)] },
      { ...this.config, version: "v2" },
    );
    
    let accumulatedText = '';
    
    for await (const event of stream) {
      if (event.event === 'on_chat_model_stream') {
        const token = event.data?.chunk?.content;
        if (token) {
          accumulatedText += token;
          this.messages.update(m => {
            const msgs = [...m];
            const last = msgs[msgs.length - 1];
            if (last?.streaming) {
              msgs[msgs.length - 1] = { ...last, text: accumulatedText };
            }
            return msgs;
          });
        }
      } else if (event.event === 'on_tool_start') {
        this.messages.update(m => {
          const msgs = [...m];
          const last = msgs[msgs.length - 1];
          if (last?.streaming) {
            msgs[msgs.length - 1] = { ...last, text: `🔧 Używam narzędzia: ${event.name}...` };
          }
          return msgs;
        });
      }
    }
    
    // Finalize
    this.messages.update(m => {
      const msgs = [...m];
      const last = msgs[msgs.length - 1];
      if (last?.streaming) {
        msgs[msgs.length - 1] = { ...last, streaming: false };
      }
      return msgs;
    });
    
    this._graphStatus = 'idle';
  } catch (err) {
    // Check if this is an interrupt
    if (err?.name === 'GraphInterrupt' || String(err).includes('interrupt')) {
      this._graphStatus = 'interrupted';
      // Finalize the message
      this.messages.update(m => {
        const msgs = [...m];
        const last = msgs[msgs.length - 1];
        if (last?.streaming) {
          msgs[msgs.length - 1] = { ...last, streaming: false };
        }
        return msgs;
      });
      return;
    }
    
    // Real error
    const errorMsg = err instanceof Error ? err.message : 'Nieznany błąd';
    this.messages.update(m => [...m, { role: 'assistant', text: `❌ ${errorMsg}` }]);
    this._graphStatus = 'idle';
  } finally {
    this.loading.set(false);
  }
}
```

---

### Krok 8: Resume graph

```typescript
private async resumeGraph(resumeValue: unknown): Promise<void> {
  if (this.loading()) return;
  this.loading.set(true);
  this._graphStatus = 'running';
  
  this.messages.update(m => [...m, { role: 'assistant', text: '', streaming: true }]);
  
  try {
    const graph = this.getOrCreateLessonGraph();
    const stream = await graph.streamEvents(
      new Command({ resume: resumeValue }),
      { ...this.config, version: "v2" },
    );
    
    // Same streaming logic as processLessonStream...
    let accumulatedText = '';
    for await (const event of stream) {
      if (event.event === 'on_chat_model_stream') {
        const token = event.data?.chunk?.content;
        if (token) {
          accumulatedText += token;
          this.messages.update(m => {
            const msgs = [...m];
            const last = msgs[msgs.length - 1];
            if (last?.streaming) {
              msgs[msgs.length - 1] = { ...last, text: accumulatedText };
            }
            return msgs;
          });
        }
      } else if (event.event === 'on_tool_start') {
        this.messages.update(m => {
          const msgs = [...m];
          const last = msgs[msgs.length - 1];
          if (last?.streaming) {
            msgs[msgs.length - 1] = { ...last, text: `🔧 Używam narzędzia: ${event.name}...` };
          }
          return msgs;
        });
      }
    }
    
    this.messages.update(m => {
      const msgs = [...m];
      const last = msgs[msgs.length - 1];
      if (last?.streaming) {
        msgs[msgs.length - 1] = { ...last, streaming: false };
      }
      return msgs;
    });
    
    this._graphStatus = 'idle';
  } catch (err) {
    if (err?.name === 'GraphInterrupt' || String(err).includes('interrupt')) {
      this._graphStatus = 'interrupted';
      this.messages.update(m => {
        const msgs = [...m];
        const last = msgs[msgs.length - 1];
        if (last?.streaming) {
          msgs[msgs.length - 1] = { ...last, streaming: false };
        }
        return msgs;
      });
      return;
    }
    const errorMsg = err instanceof Error ? err.message : 'Nieznany błąd';
    this.messages.update(m => [...m, { role: 'assistant', text: `❌ ${errorMsg}` }]);
    this._graphStatus = 'idle';
  } finally {
    this.loading.set(false);
  }
}
```

---

### Krok 9: Zmodyfikuj `send()` dla lesson mode

```typescript
async send(userMessage: string): Promise<void> {
  if (!this.query.trim()) return;
  
  if (this._lessonMode && this._graphStatus === 'interrupted') {
    // Resume interrupted lesson graph
    await this.resumeGraph(userMessage);
    return;
  }
  
  await this.processStream(userMessage, {
    showUserInput: true,
    showAssistantOutput: true,
  });
}
```

---

### Krok 10: Zmodyfikuj `GuitarNeckComponent.submitExercise()`

**Plik**: `src/app/guitar-neck/guitar-neck.component.ts`

```typescript
submitExercise(): void {
  const result = this.domainService.execute({ type: 'submit-exercise' });
  if (result.success) {
    const state = this.domainService.currentState();
    const exerciseResult = state().lastExerciseResult;
    if (exerciseResult) {
      this.chatService.resumeWithExerciseResult(exerciseResult);
    }
  }
}
```

---

### Krok 11: Usuń `notifyExerciseSubmitted()`

**Plik**: `src/app/chat/services/chat.service.ts`

Usuń metodę `notifyExerciseSubmitted()`.

---

### Krok 12: Zaktualizuj `LESSON_SYSTEM_PROMPT`

```typescript
const LESSON_SYSTEM_PROMPT =
  "Jesteś nauczycielem gitary prowadzącym lekcję krok po kroku. " +
  "Masz przed sobą pełny tekst lekcji. Trzymaj się ściśle jej treści — nie odchodź od tematu. " +
  "Wykonuj JEDNĄ akcję dydaktyczną na raz. " +
  "Po pokazaniu interwału, skali, akordu lub rozpoczęciu ćwiczenia — zatrzymaj się i daj użytkownikowi czas na reakcję. " +
  "Nie wykonuj kilku prezentacji pod rząd. Nie czyść i nie pokazuj następnego przykładu bez odpowiedzi użytkownika. " +
  "Gdy chcesz zadać ćwiczenie, użyj narzędzia start_exercise. " +
  "Podaj question (pytanie do użytkownika), rootNote, expectedIntervals (czego szukać). " +
  "Po otrzymaniu wyniku ćwiczenia, skomentuj odpowiedź użytkownika. " +
  "Jeśli odpowiedź jest dobra — pochwal. Jeśli nie — podpowiedz. " +
  "Gdy użytkownik zada pytanie spoza lekcji, odpowiedz krótko i wróć do lekcji.";
```

---

### Krok 13: Dodaj `resumeWithExerciseResult()` do `ChatService`

```typescript
async resumeWithExerciseResult(result: ExerciseResult): Promise<void> {
  if (this._graphStatus !== 'interrupted') return;
  await this.resumeGraph(result);
}
```

---

### Krok 14: Testy

**Plik**: `src/app/chat/services/chat.service.spec.ts`

Testy:
1. Lesson mode + `show_interval` → tool wykonuje akcję → graph interrupt
2. Normalny chat + `show_interval` → brak interrupt
3. `start_exercise` → ustawia exercise state → graph pause
4. Submit exercise → zwraca `ExerciseResult` → `ChatService` resume przez `Command`
5. Resume nie resetuje ćwiczenia drugi raz
6. Zwykła odpowiedź usera "dalej" → wznawia istniejący interrupted graph
7. Agent nie wykonuje dwóch kolejnych dydaktycznych tooli w jednym nieprzerwanym lesson turn
8. Brak regresji dla normalnego chat flow

**Plik**: `src/app/chat/tools/domain-tools.spec.ts`

Testy:
1. `start_exercise` z `isLessonMode() = true` → woła `interrupt()`
2. `start_exercise` z `isLessonMode() = false` → nie woła `interrupt()`
3. `show_interval` z `isLessonMode() = true` → woła `interrupt()`
4. `show_interval` z `isLessonMode() = false` → nie woła `interrupt()`

---

## Podsumowanie zmian

| Plik | Zmiana |
|------|--------|
| `package.json` | Dodaj `@langchain/langgraph: "^1.4.14"` |
| `src/app/chat/services/chat.service.ts` | Dodaj `GraphStatus`, `_lessonGraph`, `processLessonStream()`, `resumeGraph()`, `resumeWithExerciseResult()`. Zmodyfikuj `send()`. Usuń `notifyExerciseSubmitted()`. |
| `src/app/chat/tools/domain-tools.ts` | Dodaj `context` parametr z `isLessonMode()`. Dodaj `interrupt()` w toolach dydaktycznych. |
| `src/app/guitar-neck/guitar-neck.component.ts` | Zmień `submitExercise()` — zamiast `notifyExerciseSubmitted()`, przekaż `ExerciseResult` przez `resumeWithExerciseResult()`. |
| `src/app/chat/services/chat.service.spec.ts` | Dodaj testy dla lesson mode HITL |
| `src/app/chat/tools/domain-tools.spec.ts` | Dodaj testy dla interrupt w lesson mode |

## Sekwencja zdarzeń — docelowa

### Zwykły krok lekcji (show_interval)

```
1. User: "start lesson"
2. ChatService.startLesson("interwaly")
   → resetAgent(), _lessonMode = true
   → fetch /assets/lessons/interwaly.md
   → processLessonStream("Rozpoczynam lekcję...")
3. Graph: agent node → LLM decides to call show_interval
4. Graph: tools node → show_interval tool:
   a. domainService.execute({ type: 'show-interval', rootNote: 'A', interval: 'b3' })
   b. interrupt({ type: 'lesson_step', action: 'show_interval' })
   c. → GraphInterrupt wyjątek → graph pauzuje
5. ChatService: łapie GraphInterrupt → _graphStatus = 'interrupted'
6. UI: pokazuje interwał na gryfie, czat pokazuje odpowiedź AI
7. User: "dalej"
8. ChatService.send("dalej")
   → _graphStatus === 'interrupted'
   → resumeGraph("dalej")
9. Graph: wznawia od interrupt → show_interval tool kontynuuje
   → return { success: true, action: 'show-interval', ... }
   → ToolMessage wraca do LLM
10. Graph: agent node → LLM decyduje co dalej
    → może odpowiedzieć tekstem lub wywołać kolejny tool
11. Jeśli kolejny tool → znowu interrupt po nim
```

### Ćwiczenie

```
1. AI: "Znajdź wszystkie kwinty względem A"
   → start_exercise tool
   → domainService.execute({ type: 'start-exercise', ... })
   → interrupt({ type: 'exercise', ... })
   → graph pauzuje
2. User klika nuty na gryfie
3. User klika "Sprawdź"
4. GuitarNeckComponent.submitExercise()
   → domainService.execute({ type: 'submit-exercise' })
   → czyta lastExerciseResult z state
   → chatService.resumeWithExerciseResult(exerciseResult)
5. ChatService: resumeGraph(exerciseResult)
   → Command({ resume: exerciseResult })
6. Graph: wznawia → start_exercise tool kontynuuje
   → czyta lastExerciseResult z DomainState
   → return { success: true, action: 'start-exercise', exerciseResult, ... }
7. LLM: komentuje wynik
   → może przejść do kolejnego kroku
   → znowu interrupt po kolejnej akcji
```

## Diagram przepływu

```mermaid
flowchart TD
    Start[User: start lesson] --> ChatService.startLesson
    ChatService.startLesson --> Fetch[fetch lesson.md]
    Fetch --> Process[processLessonStream]
    Process --> Graph[Lesson Graph]
    
    Graph --> Agent[Agent Node: LLM]
    Agent -->|tool call| Tools[Tools Node]
    Tools --> Didactic{Didactic tool?}
    Didactic -->|yes| Interrupt[interrupt]
    Didactic -->|no| Agent
    
    Interrupt --> Paused[Graph PAUSED<br/>_graphStatus=interrupted]
    Paused --> UserInput[User sends message]
    UserInput --> Resume{Resume type}
    
    Resume -->|normal message| ResumeText[resumeGraph text]
    Resume -->|exercise result| ResumeExercise[resumeGraph ExerciseResult]
    
    ResumeText --> Graph
    ResumeExercise --> Graph
    
    Graph --> Agent
```

## Uwagi

1. **`clear_view` bez interrupt** — agent może go użyć jako przygotowania przed `show_interval` w tej samej turze. Interrupt i tak zrobi `show_interval`.
2. **Resume semantics** — `start_exercise` sprawdza czy ćwiczenie już aktywne przed wykonaniem side effect.
3. **`get_exercise_result`** — pozostaje w toolach, ale nie jest używane w lesson flow (wynik idzie bezpośrednio przez `Command({ resume })`).
4. **Normalny chat** — niezmieniony, nadal używa `createAgent()` i `processStream()` z `version: "v3"`.