# Plan: Fix Exercise Mode Display and Interaction Issues

## Problem Summary

When an exercise starts (e.g., "Find all A (root) on the fretboard in frets 0-12"), three issues occur:

1. **Fretboard shows old markers** — The fretboard still displays whatever was shown before (e.g., A major scale) with interval colors. Root notes are highlighted, other scale notes are dimmed.

2. **Can only click on markers** — The user can only click on positions that have markers from the old snapshot, not on all physical positions.

3. **Controls not blocked** — During an exercise, the user can still change the fret range, hide strings, and use the toolbox.

## Desired Behavior (from user interview)

1. **Agent says "zaznacz wszystkie A"** → pusty gryf, user sam musi wiedzieć gdzie są A
2. **User klika** → po kliknięciu pojawia się znacznik wyboru
3. **Agent says "zaznacz wszystkie kwinty"** → A zostaje widoczne, user szuka kwint
4. **Agent może w każdej chwili pokazać podpowiedź** przez emphasis/display

Key requirements:
- **Pusty gryf** — żadnych kropek, żadnych markerów na starcie
- **Pozycje są klikalne ale niewidoczne** — user klika w puste pole
- **Po kliknięciu pojawia się znacznik** (`fretboard__dot--exercise-selected`)
- **Agent steruje widocznością** przez emphasis/display między krokami
- **Ćwiczenie w pełni izolowane** — zakres progów, struny i toolbox zablokowane

## Root Cause

In [`handleStartExercise()`](src/app/domain/domain.service.ts:290), the domain state is updated with `exerciseMode: true`, `selectedNotes: []`, and the exercise task. However, **the fretboard display is NOT updated**. The snapshot from the previous display (e.g., A major scale) remains in `FretboardStateService`.

## Changes Required

### Fix 1: Clear fretboard display when exercise starts

**File:** [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts)

Add `this.orchestration.clearFretboard()` in `handleStartExercise()` after computing expected positions but before emitting state.

```typescript
private handleStartExercise(command: DomainCommand & { type: 'start-exercise' }): DomainResult<DomainState> {
    const { question, rootNote, expectedIntervals, fretRange, enabledStrings } = command;
    
    const err = DomainValidator.validateExerciseTask(rootNote, expectedIntervals)
      ?? DomainValidator.validateFretRange(fretRange);
    if (err) return err;
    
    const range = fretRange ?? this.currentState().fretRange;
    const strings = enabledStrings ?? this.currentState().enabledStrings;
    
    const expectedPositions = this.computeExpectedPositions(rootNote, expectedIntervals, range, strings);
    
    const task: ExerciseTask = {
      question, rootNote, expectedIntervals,
      fretRange: range, enabledStrings: strings,
      expectedPositions,
    };
    
    // ★ CLEAR the fretboard — no old markers
    this.orchestration.clearFretboard();
    
    return this.emitState({
      ...this.currentState(),
      exerciseMode: true,
      exerciseTask: task,
      selectedNotes: [],
      lastExerciseResult: undefined,
      fretRange: range,
      enabledStrings: strings,
    });
  }
```

### Fix 2: Make unselected dots invisible in exercise mode

**File:** [`src/app/freatboard/freatboard.component.scss`](src/app/freatboard/freatboard.component.scss)

Add a CSS class for invisible clickable dots in exercise mode. The dots must be invisible but still clickable.

```scss
/* Exercise mode: unselected dots are invisible but clickable */
.fretboard__dot--exercise-hidden {
  opacity: 0;
  cursor: pointer;
}
```

**File:** [`src/app/freatboard/freatboard.component.html`](src/app/freatboard/freatboard.component.html)

Apply the `fretboard__dot--exercise-hidden` class to unselected dots in exercise mode.

Change line 81 from:
```html
[ngClass]="['fretboard__dot', exerciseMode ? 'fretboard__dot--clickable' : '']"
```
To:
```html
[ngClass]="['fretboard__dot', exerciseMode ? 'fretboard__dot--exercise-hidden' : '']"
```

Also apply to the open string (fret 0) button at line 31:
```html
[ngClass]="['fretboard__dot', 'fretboard__open-note-btn', exerciseMode ? 'fretboard__dot--exercise-hidden' : '']"
```

### Fix 3: Block range toolbar during exercise

**File:** [`src/app/app-page/app-page.component.ts`](src/app/app-page/app-page.component.ts)

Update `rangeDisabled` computed to also check for `exerciseMode`.

```typescript
rangeDisabled = computed(() => 
    this.domainService.currentState().mode === 'positions' || 
    this.domainService.currentState().exerciseMode
);
```

### Fix 4: Block string toggles during exercise

**File:** [`src/app/freatboard/freatboard.component.html`](src/app/freatboard/freatboard.component.html)

Pass `exerciseMode` as the `disabled` input to `StringToggleComponent`.

```html
<app-string-toggle
    [stringName]="string"
    [stringIndex]="i"
    [active]="activeStrings[i]"
    [disabled]="exerciseMode"
    (stringToggled)="onStringToggled($event)"
>
</app-string-toggle>
```

### Fix 5: Block toolbox during exercise

**File:** [`src/app/toolbox/toolbox-builder.component.ts`](src/app/toolbox/toolbox-builder.component.ts)

Add a `disabled` input.

```typescript
readonly disabled = input(false);
```

**File:** [`src/app/toolbox/toolbox-builder.component.html`](src/app/toolbox/toolbox-builder.component.html)

Wrap the toolbox content in a container with disabled styling, and disable the submit button.

```html
<div class="sentence-toolbox" [class.sentence-toolbox--disabled]="disabled()">
  <!-- existing content... -->
  <button class="sentence-toolbox__submit" (click)="submit()" [disabled]="disabled()">Show</button>
</div>
```

**File:** [`src/app/toolbox/toolbox-builder.component.scss`](src/app/toolbox/toolbox-builder.component.scss)

Add CSS for disabled state.

```scss
.sentence-toolbox--disabled {
  pointer-events: none;
  opacity: 0.5;
}
```

**File:** [`src/app/app-page/app-page.component.html`](src/app/app-page/app-page.component.html)

Pass `exerciseMode` to toolbox.

```html
<app-toolbox-builder
    [disabled]="exerciseMode()"
    (toolboxEvent)="onToolboxEvent($event)"
></app-toolbox-builder>
```

**File:** [`src/app/app-page/app-page.component.ts`](src/app/app-page/app-page.component.ts)

Add `exerciseMode` computed.

```typescript
exerciseMode = computed(() => this.domainService.currentState().exerciseMode);
```

## Summary of Changes

| # | File | Change |
|---|------|--------|
| 1 | [`src/app/domain/domain.service.ts:290`](src/app/domain/domain.service.ts:290) | Add `this.orchestration.clearFretboard()` in `handleStartExercise()` |
| 2 | [`src/app/freatboard/freatboard.component.scss`](src/app/freatboard/freatboard.component.scss) | Add `.fretboard__dot--exercise-hidden` CSS class |
| 3 | [`src/app/freatboard/freatboard.component.html:31,81`](src/app/freatboard/freatboard.component.html:31) | Apply `fretboard__dot--exercise-hidden` to unselected dots |
| 4 | [`src/app/freatboard/freatboard.component.html:19-24`](src/app/freatboard/freatboard.component.html:19) | Pass `[disabled]="exerciseMode"` to `StringToggleComponent` |
| 5 | [`src/app/app-page/app-page.component.ts:55`](src/app/app-page/app-page.component.ts:55) | Add `exerciseMode` check to `rangeDisabled` |
| 6 | [`src/app/app-page/app-page.component.ts`](src/app/app-page/app-page.component.ts) | Add `exerciseMode` computed |
| 7 | [`src/app/app-page/app-page.component.html:8-10`](src/app/app-page/app-page.component.html:8) | Pass `[disabled]="exerciseMode()"` to toolbox |
| 8 | [`src/app/toolbox/toolbox-builder.component.ts`](src/app/toolbox/toolbox-builder.component.ts) | Add `readonly disabled = input(false)` |
| 9 | [`src/app/toolbox/toolbox-builder.component.html`](src/app/toolbox/toolbox-builder.component.html) | Add disabled class and disable submit button |
| 10 | [`src/app/toolbox/toolbox-builder.component.scss`](src/app/toolbox/toolbox-builder.component.scss) | Add `.sentence-toolbox--disabled` CSS |

## Testing

1. Start an exercise → fretboard is completely empty (no dots, no markers)
2. Click on any position → selection marker appears (`fretboard__dot--exercise-selected`)
3. Click again → selection is removed
4. Range toolbar is disabled (greyed out)
5. String toggle checkboxes are disabled (greyed out)
6. Toolbox is visually dimmed and not interactive
7. Submit exercise → works as before
8. After exercise ends → controls are re-enabled