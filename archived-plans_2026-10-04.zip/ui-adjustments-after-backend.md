# Plan: UI Adjustments After Backend Integration

## Overview

Three UI issues identified after backend integration:

1. **Issue 3** — No way to navigate back to the home page from login/register pages
2. **Issue 4** — Landing page still shows "Configure AI Assistant" section, but AI config has moved to Settings
3. **Issue 5** — Feature card icons on landing page should be clickable to trigger fretboard actions

---

## Issue 3: Back Navigation from Login/Register

**Problem:** [`LoginComponent`](src/app/auth/login/login.component.html) and [`RegisterComponent`](src/app/auth/register/register.component.html) are standalone routes (not inside [`AppPageComponent`](src/app/app-page/app-page.component.html)). They have no link back to the home page (`/`). The only navigation they offer is between each other (login ↔ register).

**Solution:** Add a "← Powrót do strony głównej" link at the bottom of both auth cards, before the existing link paragraph.

### Files to modify:

| File | Change |
|------|--------|
| [`src/app/auth/login/login.component.html`](src/app/auth/login/login.component.html) | Add `<a routerLink="/">← Powrót do strony głównej</a>` before the existing `<p class="link">` |
| [`src/app/auth/register/register.component.html`](src/app/auth/register/register.component.html) | Same — add back link before the existing `<p class="link">` |

### Acceptance criteria:
- Both login and register pages show a "← Powrót do strony głównej" link
- Clicking it navigates to `/` (the landing page)
- The link is styled consistently with the existing `.link a` styles

---

## Issue 4: Update Landing Page — Configure AI Assistant Section

**Problem:** The [`LandingPageComponent`](src/app/landing-page/landing-page.component.html) still has a "Configure AI Assistant" section (lines 29–43) with a "Skip — use app without AI" button. However, the AI configuration (OpenRouter API key management) has moved to the [`SettingsComponent`](src/app/settings/settings.component.html). This section is now outdated and misleading.

**Solution:** Replace the "Configure AI Assistant" section with a simpler "AI Assistant" call-to-action that redirects to the Settings page for configuration. The "Skip" button should remain but be relabeled.

### Files to modify:

| File | Change |
|------|--------|
| [`src/app/landing-page/landing-page.component.html`](src/app/landing-page/landing-page.component.html) | Replace the `<section class="setup">` block with a simplified version that links to `/settings` for AI configuration |
| [`src/app/landing-page/landing-page.component.scss`](src/app/landing-page/landing-page.component.scss) | Keep existing `.setup` styles — they still work for the simplified card |

### New setup section content:
```html
<!-- AI Assistant -->
<section class="setup">
  <div class="setup__card">
    <h2 class="setup__heading">AI Assistant</h2>
    <p class="setup__desc">
      Configure your AI model in Settings to get interactive help with scales,
      chords, and fretboard patterns.
    </p>
    <div class="setup__actions">
      <a class="btn btn--ghost" routerLink="/settings">Configure in Settings</a>
      <button class="btn btn--primary" type="button" (click)="goToApp()">
        Go to App
      </button>
    </div>
  </div>
</section>
```

### Acceptance criteria:
- The landing page no longer shows the outdated "Configure AI Assistant" with API key fields
- Instead shows a simplified card linking to Settings for AI configuration
- "Go to App" button is the primary CTA for users who want to skip AI setup

---

## Issue 5: Clickable Feature Cards → Fretboard Actions

**Problem:** The landing page has 6 feature cards with icons (🎯, 🎼, 🔗, 🧩, 🤖, ⏱️) that describe what the app can do, but they are static — clicking them does nothing. The user wants them to navigate to the app and trigger the corresponding fretboard action.

**Solution:** Make each feature card clickable. When clicked, it navigates to `/app` with query parameters that the [`AppPageComponent`](src/app/app-page/app-page.component.ts) can interpret to trigger the right action.

### Query parameter design:

| Feature | Icon | Query Params | Expected Action |
|---------|------|-------------|-----------------|
| Show Notes | 🎯 | `?action=show-notes` | Display all notes on fretboard |
| Scales & Chords | 🎼 | `?action=show-pattern&kind=scale` | Open scale/chord selector |
| Intervals | 🔗 | `?action=show-intervals` | Open interval selector |
| Compare Patterns | 🧩 | `?action=compare` | Open compare mode |
| AI Assistant | 🤖 | `?action=ai-mode` | Enable AI chat mode |
| Metronome | ⏱️ | `?action=metronome` | Open app with metronome visible |

### Files to modify:

| File | Change |
|------|--------|
| [`src/app/landing-page/landing-page.component.html`](src/app/landing-page/landing-page.component.html) | Add `(click)="goToAppWithAction('show-notes')"` etc. to each feature card, or wrap them with `<button>` elements |
| [`src/app/landing-page/landing-page.component.ts`](src/app/landing-page/landing-page.component.ts) | Add `goToAppWithAction(action: string)` method that navigates to `/app` with query params |
| [`src/app/landing-page/landing-page.component.scss`](src/app/landing-page/landing-page.component.scss) | Add `.feature-card` cursor pointer and hover state if not already present |
| [`src/app/app-page/app-page.component.ts`](src/app/app-page/app-page.component.ts) | Extend `ngOnInit()` to read `action` query param and dispatch the appropriate [`DomainCommand`](src/app/domain/commands.ts) |

### New method in LandingPageComponent:
```typescript
goToAppWithAction(action: string): void {
  this.router.navigate(['/app'], { queryParams: { action } });
}
```

### New logic in AppPageComponent.ngOnInit():
```typescript
ngOnInit(): void {
  const lessonId = this.route.snapshot.queryParamMap.get('lesson');
  const action = this.route.snapshot.queryParamMap.get('action');

  if (lessonId) {
    // existing lesson logic
    const lesson = this.lessonRegistry.getLesson(lessonId);
    if (lesson) {
      this.domainService.execute({ type: 'set-ai-mode', enabled: true });
      this.chatService.startLesson(lessonId);
    }
  }

  if (action) {
    this.handleLandingAction(action);
  }
}

private handleLandingAction(action: string): void {
  switch (action) {
    case 'show-notes':
      // Show all notes — clear any pattern and show note names
      this.domainService.execute({ type: 'clear-view' });
      this.domainService.execute({ type: 'set-view', markerDisplayMode: 'note-names' });
      break;
    case 'show-pattern':
      // Navigate to scale/chord — the toolbox is already visible
      // User just needs to interact with it
      break;
    case 'show-intervals':
      // Focus on interval selector
      break;
    case 'compare':
      // Set intent to compare mode
      break;
    case 'ai-mode':
      this.domainService.execute({ type: 'set-ai-mode', enabled: true });
      break;
    case 'metronome':
      // Metronome is always visible in the bottom panel
      break;
  }
}
```

### Acceptance criteria:
- Each feature card on the landing page is clickable (cursor: pointer, hover effect)
- Clicking a card navigates to `/app` with the appropriate query parameter
- The app page reads the query param and triggers the corresponding action
- The action is reflected on the fretboard (e.g., AI mode enables chat, Show Notes shows note names)

---

## Implementation Order

1. **Issue 3** (simplest, isolated changes to auth pages)
2. **Issue 4** (moderate, changes to landing page template only)
3. **Issue 5** (most complex, changes to landing page + app page logic)

---

## Files Summary

| File | Issue 3 | Issue 4 | Issue 5 |
|------|---------|---------|---------|
| `src/app/auth/login/login.component.html` | ✅ Add back link | — | — |
| `src/app/auth/register/register.component.html` | ✅ Add back link | — | — |
| `src/app/landing-page/landing-page.component.html` | — | ✅ Replace AI config section | ✅ Add click handlers to feature cards |
| `src/app/landing-page/landing-page.component.ts` | — | — | ✅ Add `goToAppWithAction()` method |
| `src/app/landing-page/landing-page.component.scss` | — | — | ✅ Add cursor/hover for feature cards |
| `src/app/app-page/app-page.component.ts` | — | — | ✅ Handle action query params in `ngOnInit()` |