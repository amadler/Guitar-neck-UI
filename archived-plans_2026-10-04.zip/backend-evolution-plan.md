# Backend Evolution Plan: guitar-neck-agent → Guitar Neck Server

## Overview

Evolve `guitar-neck-agent` from a single-purpose AI chat proxy into a **modular monolith backend** with PostgreSQL, auth, user credentials, lesson progress, and persistent agent checkpoints. The Angular frontend gets a minimal account layer.

## Architecture

```
Angular (Guitar neck UI)
   │  POST /api/chat  │  POST /api/auth/login  │  GET /api/me  │  PUT /api/credentials/openrouter
   ▼                  ▼                        ▼               ▼
guitar-neck-agent / Express
   ├─ /api/auth          ← register, login, logout
   ├─ /api/me            ← current user profile
   ├─ /api/credentials   ← encrypted OpenRouter key
   ├─ /api/progress      ← lesson_progress CRUD
   ├─ /api/chat          ← AI agent (uses user's own key)
   └─ /api/lessons       ← lesson metadata
          │
          ▼
       PostgreSQL (via Drizzle ORM)
```

**Key principle**: The agent tools (`show_pattern`, `start_exercise`, etc.) do NOT touch the database directly. Lesson progress is managed by a separate application service layer, not as a side-effect of agent tool calls.

## Data Model

```mermaid
erDiagram
    users {
        uuid id PK
        string email "unique"
        timestamp created_at
        timestamp updated_at
    }
    user_credentials {
        uuid id PK
        uuid user_id FK
        string provider "e.g. 'openrouter'"
        text encrypted_api_key "AES-GCM"
        timestamp updated_at
    }
    user_profiles {
        uuid user_id PK, FK
        text level "beginner|intermediate|advanced"
        jsonb preferences "{}"
    }
    lesson_progress {
        uuid id PK
        uuid user_id FK
        string lesson_id
        text status "not_started|in_progress|completed"
        int current_step
        timestamp started_at
        timestamp completed_at
        jsonb data "{}"
    }
    exercise_results {
        uuid id PK
        uuid user_id FK
        string lesson_id
        string exercise_id
        jsonb result
        timestamp created_at
    }
    chat_threads {
        uuid id PK
        uuid user_id FK
        string lesson_id "nullable"
        timestamp created_at
    }

    users ||--o{ user_credentials : has
    users ||--o{ user_profiles : has
    users ||--o{ lesson_progress : has
    users ||--o{ exercise_results : has
    users ||--o{ chat_threads : has
```

## Phased Implementation Plan

### P1 — PostgreSQL + Drizzle + Migrations + Docker Compose

**Goal**: Database infrastructure that everything else builds on.

**Files to create/modify in `guitar-neck-agent/`**:

| File | Purpose |
|------|---------|
| `docker-compose.yml` | postgres + caddy (later) |
| `Dockerfile` | backend container |
| `src/db/client.ts` | Drizzle connection pool |
| `src/db/schema/index.ts` | All table definitions |
| `src/db/schema/users.ts` | users table |
| `src/db/schema/user-credentials.ts` | user_credentials table |
| `src/db/schema/user-profiles.ts` | user_profiles table |
| `src/db/schema/lesson-progress.ts` | lesson_progress table |
| `src/db/schema/exercise-results.ts` | exercise_results table |
| `src/db/schema/chat-threads.ts` | chat_threads table |
| `src/db/migrations/` | Drizzle-generated SQL |
| `drizzle.config.ts` | Drizzle config |
| `package.json` | Add drizzle-orm, drizzle-kit, postgres, pg |

**Dependencies to add**:
- `drizzle-orm`, `drizzle-kit`, `postgres` (or `pg`)

**Acceptance criteria**:
- `docker compose up` starts postgres
- `npm run db:generate` creates migrations from schema
- `npm run db:migrate` applies migrations
- Backend can connect and query

---

### P2 — Users + Auth + GET /me

**Goal**: Register, login, logout with HTTP-only secure cookies. No JWT library — use `express-session` with a PostgreSQL session store.

**Files to create/modify**:

| File | Purpose |
|------|---------|
| `src/index.ts` | Mount auth routes, add session middleware |
| `src/auth/router.ts` | POST /register, POST /login, POST /logout |
| `src/auth/middleware.ts` | `requireAuth` middleware (reads session → sets `req.userId`) |
| `src/auth/service.ts` | Password hashing (bcrypt), session management |
| `src/users/router.ts` | GET /api/me |
| `src/users/service.ts` | User CRUD |
| `package.json` | Add `express-session`, `connect-pg-simple`, `bcrypt` |

**Key decisions**:
- Session-based auth (not JWT) — simpler, HTTP-only cookie by default
- Session store in PostgreSQL via `connect-pg-simple`
- Password hashing with bcrypt
- No email verification on MVP

**Acceptance criteria**:
- `POST /api/auth/register` creates user, sets session cookie
- `POST /api/auth/login` validates credentials, sets session cookie
- `POST /api/auth/logout` destroys session
- `GET /api/me` returns `{ id, email, createdAt }` (requires auth)
- Unauthenticated requests to protected routes return 401

---

### P3 — Encrypted User OpenRouter Credentials

**Goal**: Users can store their own OpenRouter API key, encrypted at rest.

**Files to create/modify**:

| File | Purpose |
|------|---------|
| `src/credentials/router.ts` | PUT/GET/DELETE /api/credentials/openrouter |
| `src/credentials/service.ts` | Encrypt/decrypt with AES-GCM |
| `src/credentials/encryption.ts` | AES-GCM helpers using Node crypto |
| `.env.example` | Add `USER_CREDENTIALS_ENCRYPTION_KEY` |

**Key decisions**:
- AES-GCM encryption with a single server-side `USER_CREDENTIALS_ENCRYPTION_KEY`
- `GET /api/credentials/openrouter` returns only `{ configured: true/false }` — never the key
- `PUT /api/credentials/openrouter` accepts `{ apiKey: string }`, encrypts and stores
- `DELETE /api/credentials/openrouter` removes the stored key

**Acceptance criteria**:
- Key is encrypted before storage, decrypted only at usage time
- Status endpoint reveals only whether key exists
- No plaintext key in logs, responses, or session data

---

### P4 — /api/chat Uses the Logged-in User's Key

**Goal**: The chat endpoint reads the user's own OpenRouter key instead of a global env var.

**Files to modify**:

| File | Change |
|------|--------|
| `src/index.ts` | Mount auth middleware on /api/chat, pass `req.userId` |
| `src/routes/chat.ts` | Accept `userId`, fetch credentials, pass to agent |
| `src/agent.ts` | Accept per-user apiKey instead of global config |
| `src/credentials/service.ts` | Add `getDecryptedKey(userId, provider)` method |

**Key changes**:
- `chatRouter` now requires authentication
- `createAgent()` receives the user's decrypted API key
- If user has no key configured, return 402 or clear error message
- `ChatRequestBody` no longer needs `domainState` sent from client — backend can reconstruct from session context (but keep sending it for now to minimize Angular changes)

**Acceptance criteria**:
- Authenticated request with configured key → agent works
- Authenticated request without configured key → clear error
- Unauthenticated request → 401

---

### P5 — Lesson Progress

**Goal**: Track which lessons a user has started, their current step, and completion status.

**Files to create/modify**:

| File | Purpose |
|------|---------|
| `src/progress/router.ts` | GET/POST /api/progress, GET /api/progress/:lessonId |
| `src/progress/service.ts` | CRUD for lesson_progress table |

**Key decisions**:
- Agent does NOT write to progress table directly
- Progress is updated by the application service layer
- Angular calls progress endpoints separately from chat
- `lesson_progress.data` (jsonb) stores lesson-specific state that doesn't need its own column

**Acceptance criteria**:
- `GET /api/progress` returns list of all lesson progress for user
- `GET /api/progress/:lessonId` returns single lesson progress
- `POST /api/progress` creates or updates progress
- Progress is scoped to authenticated user (no userId from client)

---

### P6 — Persistent LangGraph Checkpoint in PostgreSQL

**Goal**: Agent state survives server restarts. Replace `MemorySaver` with PostgreSQL-based checkpointer.

**Files to modify**:

| File | Change |
|------|--------|
| `src/agent.ts` | Replace `MemorySaver` with `PostgresSaver` or custom Drizzle-based checkpointer |
| `src/db/schema/` | Add checkpoint tables if needed by LangGraph |
| `package.json` | Add `@langchain/langgraph-checkpoint-postgres` if available |

**Key decisions**:
- LangGraph checkpoints are separate from `lesson_progress` — they track where the agent is, not what the user learned
- `threadId` links to `chat_threads` table for ownership validation
- On agent start, verify `threadId` belongs to `userId`

**Acceptance criteria**:
- Agent resumes correctly after server restart
- Thread ownership is enforced (user A cannot resume user B's thread)
- Old threads are eventually cleaned up (TBD: TTL/cron)

---

### P7 — Exercise Results / User Level

**Goal**: Store exercise results and compute user skill level.

**Files to create/modify**:

| File | Purpose |
|------|---------|
| `src/progress/exercise-router.ts` | POST /api/progress/exercises |
| `src/progress/level-service.ts` | Compute user level from exercise history |

**Key decisions**:
- `exercise_results.result` (jsonb) stores `{ correctCount, incorrectCount, missingCount, selectedNotes }`
- Level is derived from aggregate data, not stored as a single value (except cached in `user_profiles.level`)
- No complex gamification yet — just track accuracy over time

**Acceptance criteria**:
- Exercise results are persisted
- User profile level can be computed from history

---

### P8 — Angular: Account / Settings / Progress UI

**Goal**: Minimal frontend for auth flows and credential management.

**Files to create in `Guitar neck UI/`**:

| File | Purpose |
|------|---------|
| `src/app/auth/auth.service.ts` | Login, register, logout, session check |
| `src/app/auth/login/login.component.ts` | Login form |
| `src/app/auth/register/register.component.ts` | Register form |
| `src/app/settings/llm-credentials/llm-credentials.component.ts` | API key management UI |
| `src/app/services/progress.service.ts` | Lesson progress API calls |
| `src/environments/environment.ts` | Add `apiUrl` instead of hardcoded localhost |

**Files to modify**:

| File | Change |
|------|--------|
| `src/app/app.routes.ts` | Add login, register, settings routes |
| `src/app/services/agent-api.service.ts` | Use `environment.apiUrl`, include credentials (cookies) |
| `src/app/app-page/app-page.component.ts` | Add user menu (login/logout/settings) |
| `src/app/landing-page/landing-page.component.ts` | Add login/register links |

**Key decisions**:
- `fetch` calls include `credentials: 'include'` for cookie-based auth
- API URL comes from environment config, not hardcoded
- Auth state is tracked via `GET /api/me` on app init
- No route guards on MVP — just show/hide UI elements

**Acceptance criteria**:
- User can register and login from Angular
- User can store/update/delete their OpenRouter key
- User can see their lesson progress
- Chat works with user's own key

---

## Infrastructure (Docker Compose)

```yaml
# docker-compose.yml (added in P1)
services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: guitar_neck
      POSTGRES_USER: guitar_neck
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - pgdata:/var/lib/postgresql/data
    ports:
      - "5432:5432"  # only for dev; remove in prod

  guitar-neck-server:
    build: .
    environment:
      DATABASE_URL: postgres://guitar_neck:${DB_PASSWORD}@postgres:5432/guitar_neck
      USER_CREDENTIALS_ENCRYPTION_KEY: ${USER_CREDENTIALS_ENCRYPTION_KEY}
      SESSION_SECRET: ${SESSION_SECRET}
    ports:
      - "3001:3001"
    depends_on:
      - postgres

  caddy:  # added later for HTTPS
    image: caddy:2-alpine
    ...
```

## Non-Goals (for this phase)

- Email verification / password reset
- OAuth providers (Google, GitHub)
- Admin panel
- Real-time collaboration
- Microservices decomposition
- Repo rename (`guitar-neck-agent` → `guitar-neck-server`) — defer until later refactor

## Architectural Constraints

1. **TonalFacadeService** is the ONLY allowed importer of `@tonaljs/*` in Angular — this backend doesn't need tonal at all
2. **Domain tools never touch the database** — agent tools emit commands, application services persist
3. **LangGraph checkpoints ≠ lesson_progress** — two separate concerns, two separate stores
4. **Session auth, not JWT** — simpler, HTTP-only cookies, no token management on client
5. **No userId from client** — backend derives identity from session cookie