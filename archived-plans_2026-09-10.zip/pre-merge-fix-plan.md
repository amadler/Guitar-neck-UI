# Fix Plan: Pre-merge corrections for commit b68591a

## Overview

Three issues to fix before merging the grooming commit. All are small, targeted changes — no architectural changes needed.

---

## Issue 1: Incorrect shape data (BLOCKER)

### 1a. cowboy-C7 — missing b7

**Problem:** Current shape has G on string 3 (fretOffset 0, label '5'). C7 needs Bb (b7) on string 3.

**Fix in [`src/app/shared/model/guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts:186):**

| String | Current | Correct |
|--------|---------|---------|
| 5      | fretOffset 3, label 'root' | ✓ no change |
| 4      | fretOffset 2, label '3' | ✓ no change |
| **3**  | **fretOffset 0, label '5'** | **fretOffset 3, label 'b7'** |
| 2      | fretOffset 1, label 'root' | ✓ no change |
| 1      | fretOffset 0, label '3' | ✓ no change |

### 1b. barre-E-form — wrong interval labels

**Problem:** Labels don't match E-form major structure (root-5-root-3-5-root).

**Fix in [`src/app/shared/model/guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts:221):**

| String | Current label | Correct label |
|--------|--------------|---------------|
| 6      | 'root' | ✓ 'root' |
| 5      | '5'    | ✓ '5' |
| **4**  | **'3'** | **'root'** |
| **3**  | **'5'** | **'3'** |
| **2**  | **'root'** | **'5'** |
| **1**  | **'3'** | **'root'** |

### 1c. barre-Em-form — wrong interval labels

**Problem:** Labels don't match Em-form minor structure (root-5-root-b3-5-root).

**Fix in [`src/app/shared/model/guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts:236):**

| String | Current label | Correct label |
|--------|--------------|---------------|
| 6      | 'root' | ✓ 'root' |
| 5      | '5'    | ✓ '5' |
| **4**  | **'b3'** | **'root'** |
| **3**  | **'5'** | **'b3'** |
| **2**  | **'root'** | **'5'** |
| **1**  | **'b3'** | **'root'** |

### 1d. barre-A-form — wrong interval labels

**Problem:** Labels don't match A-form major structure (root-5-root-3-5).

**Fix in [`src/app/shared/model/guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts:251):**

| String | Current label | Correct label |
|--------|--------------|---------------|
| 5      | 'root' | ✓ 'root' |
| 4      | '5'    | ✓ '5' |
| **3**  | **'3'** | **'root'** |
| **2**  | **'root'** | **'3'** |
| 1      | '5'    | ✓ '5' |

### 1e. barre-Am-form — wrong labels AND wrong fretOffset

**Problem:** Labels don't match Am-form minor structure (root-5-root-b3-5), AND string 2 has wrong fretOffset (+2 instead of +1).

**Fix in [`src/app/shared/model/guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts:265):**

| String | Current | Correct |
|--------|---------|---------|
| 5      | fretOffset 0, label 'root' | ✓ no change |
| 4      | fretOffset 2, label '5' | ✓ no change |
| **3**  | **fretOffset 2, label 'b3'** | **fretOffset 2, label 'root'** |
| **2**  | **fretOffset 2, label 'root'** | **fretOffset 1, label 'b3'** |
| 1      | fretOffset 0, label '5' | ✓ no change |

### 1f. Extend barre shape validation in tests

**Problem:** [`src/app/shared/model/guitar-shapes.spec.ts`](src/app/shared/model/guitar-shapes.spec.ts:74) only checks `stringSet`, `rootString in stringSet`, and `rootNote undefined` for barre shapes. It does NOT validate that the interval labels are musically correct.

**Fix:** Add a test block that validates barre shape interval labels against the expected chord structure, similar to the existing cowboy test at line 50. Use the same `getNoteAt` + `getIntervalLabel` helpers, but barre shapes need a conceptual root note to calculate intervals against. Since barre shapes are movable, validate against the shape's root string note as the conceptual root (e.g., for barre-E-form, validate as if root=E).

The test should:
1. For each barre shape, determine the conceptual root note from the open string at `rootString`
2. For each position, calculate the actual note at `(string, fretOffset)` 
3. Calculate the expected interval label from the conceptual root to that note
4. Assert `pos.label === expectedLabel`

This catches all the label errors above.

---

## Issue 2: ShapeResolverService allows barre without rootNote

**Problem:** [`ShapeResolverService.resolveShape()`](src/app/services/shape-resolver.service.ts:69) allows calling `resolveShape('barre-E-form')` without `rootNote`. It defaults to `position ?? 0` and returns success with `rootNote: undefined`. This creates state inconsistency in [`DomainService.handleResolveShape()`](src/app/domain/domain.service.ts:245) which falls back to `this.currentState().rootNote`.

**Fix 2a — Add guard in resolver** ([`src/app/services/shape-resolver.service.ts`](src/app/services/shape-resolver.service.ts:69)):
```typescript
if (shape.category === 'barre') {
  if (!rootNote) {
    return {
      success: false,
      positions: [],
      message: `Barre shape "${shape.id}" requires rootNote.`,
    };
  }
  // ... rest of barre handling
}
```

**Fix 2b — Remove `position` from `ResolveShapeCommand`** ([`src/app/domain/commands.ts`](src/app/domain/commands.ts:84)):
Remove the `position?: number` field from `ResolveShapeCommand`. Barre shapes should only be specified via `shapeId + rootNote`. The `position` parameter has no current use case and creates the inconsistency path.

---

## Issue 3: String-based indexOf breaks enharmonic notes

**Problem:** [`ShapeResolverService`](src/app/services/shape-resolver.service.ts:74) uses `this.chromaticNotes.indexOf(rootNote)` which fails for enharmonic spellings like 'Bb' (not in `neckConfig.chromaticNotes` which uses sharps: `['C', 'C#', ...]`).

**Fix:** Replace `indexOf` string comparison with chroma-based lookup using [`noteToChroma()`](src/app/shared/note-utils.ts:20) from the existing `note-utils.ts`.

In [`src/app/services/shape-resolver.service.ts`](src/app/services/shape-resolver.service.ts:73-96):

```typescript
import { noteToChroma } from '../shared/note-utils';

// Replace:
const rootIndex = this.chromaticNotes.indexOf(rootNote);
const openIndex = this.chromaticNotes.indexOf(openStringNote);

// With:
const rootChroma = noteToChroma(rootNote);
const openChroma = noteToChroma(openStringNote);
if (rootChroma === -1) { /* error */ }
if (openChroma === -1) { /* error */ }
baseFret = (rootChroma - openChroma + 12) % 12;
```

This is the same approach already used by `TonalFacadeService` and `note-utils.ts`.

**Update test** in [`src/app/services/shape-resolver.service.spec.ts`](src/app/services/shape-resolver.service.spec.ts:42): The existing test for `barre-A-form` with `'Bb'` should now pass after the chroma fix. Add an additional test that calling `resolveShape('barre-E-form')` without rootNote returns `success: false`.

---

## Files to modify

| File | Changes |
|------|---------|
| `src/app/shared/model/guitar-shapes.ts` | Fix 5 shape definitions (cowboy-C7, barre-E-form, barre-Em-form, barre-A-form, barre-Am-form) |
| `src/app/shared/model/guitar-shapes.spec.ts` | Add barre shape interval validation test |
| `src/app/services/shape-resolver.service.ts` | Add rootNote guard for barre + chroma-based lookup |
| `src/app/services/shape-resolver.service.spec.ts` | Update tests for new guard + chroma fix |
| `src/app/domain/commands.ts` | Remove `position` from `ResolveShapeCommand` |

## Order of execution

1. Fix shape data in `guitar-shapes.ts` (1a-1e)
2. Extend barre tests in `guitar-shapes.spec.ts` (1f)
3. Fix resolver: chroma lookup + rootNote guard (issues 2+3)
4. Update resolver tests
5. Remove `position` from `ResolveShapeCommand`
6. Run full test suite