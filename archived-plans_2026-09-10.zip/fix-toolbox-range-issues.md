# Plan: Fix 3 Toolbox/Range Issues (v2)

## Overview

Three issues reported after adding cowboy/barre shapes:

1. **Barre chords conflict with Range** — resolving a barre shape (e.g., Barre Am-form in F# on frets 9-11) is invisible if the Range toolbar is set to Open (0-4).
2. **Cowboy chords same problem** — cowboy shapes (open chords) are invisible if Range excludes fret 0.
3. **Multi-state intent button overload** — the Show/Compare/Shape chip cycles through 3 states, confusing the user. Restore a proper dropdown.

---

## Issue 1 & 2: Disable Range toolbar in Shape mode + auto-fit fretRange

### Root Cause

In [`domain.service.ts`](src/app/domain/domain.service.ts:226), `handleResolveShape` calls `shapeResolver.resolveShape()` which returns concrete `{string, fret}` positions, but **never updates `fretRange`** in the emitted state. The RangeToolbar remains at whatever the user last set (e.g., Open 0-4), so barre chords on frets 9-11 are outside the visible range.

### Solution (two parts)

**Part A — Auto-fit `fretRange`**: When resolving a shape, compute the min/max fret from the resolved positions and emit the new `fretRange` in state. This ensures the shape is always visible.

**Part B — Disable Range toolbar**: When the toolbox intent is `'shape'`, the Range toolbar buttons should be visually disabled (grayed out, non-clickable) so the user can't accidentally hide the shape.

### Files to change

| File | Change |
|------|--------|
| [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts:226) | In `handleResolveShape`, compute `fretRange` from resolved positions and include it in emitted state. |
| [`src/app/range-toolbar/range-toolbar.component.ts`](src/app/range-toolbar/range-toolbar.component.ts:20) | Add `@Input() disabled: boolean`. When disabled, buttons are non-interactive. |
| [`src/app/range-toolbar/range-toolbar.component.html`](src/app/range-toolbar/range-toolbar.component.html:1) | Add `disabled` attribute / CSS class to buttons when `disabled` input is true. |
| [`src/app/home-page/home-page.component.html`](src/app/home-page/home-page.component.html:12) | Pass `isShapeMode` flag to `app-range-toolbar`. |
| [`src/app/home-page/home-page.component.ts`](src/app/home-page/home-page.component.ts:38) | Add computed `isShapeMode` signal based on toolbox intent. |

### Detailed logic for auto-fit

```typescript
// Helper in domain.service.ts
private computeFretRangeFromPositions(positions: Array<{ string: number; fret: number }>): { min: number; max: number } {
  if (positions.length === 0) return this.currentState().fretRange;
  const frets = positions.map(p => p.fret);
  const min = Math.max(0, Math.min(...frets) - 1);
  const max = Math.min(neckConfig.numberOfFrets, Math.max(...frets) + 1);
  return { min, max };
}
```

Called in `handleResolveShape` after `shapeResolver.resolveShape()` succeeds.

### Edge cases

- **Empty result**: Keep current `fretRange`.
- **Cowboy shapes on fret 0**: `min` will be 0, `max` will be e.g. 4 — fits perfectly.
- **User switches from Shape to Show mode**: Range toolbar re-enables, user can change range again.

---

## Issue 3: Replace multi-state intent button with `<app-dropdown>`

### Root Cause

In [`toolbox-builder.component.html`](src/app/toolbox/toolbox-builder.component.html:6-13), the intent chip cycles:

```
Show → Compare → Shape → Show
```

This is confusing — the user can't see all options at once.

### Solution

Replace the cycling button with the existing `<app-dropdown>` component showing all 3 options: **Show**, **Compare**, **Shape**.

### Files to change

| File | Change |
|------|--------|
| [`src/app/toolbox/toolbox-builder.component.html`](src/app/toolbox/toolbox-builder.component.html:5-13) | Replace cycling button with `<app-dropdown>` for intent selection. |
| [`src/app/toolbox/toolbox-builder.component.ts`](src/app/toolbox/toolbox-builder.component.ts:54) | Add `intentOptions` array and `intentDisplayFn`. |

### Template change

```html
<!-- Before -->
<div class="sentence-toolbox__chip-wrapper">
  <button class="sentence-toolbox__chip sentence-toolbox__chip--select"
    (click)="setIntent(...)">
    {{ intent() === "show" ? "Show" : ... }}
    <span class="sentence-toolbox__arrow">▼</span>
  </button>
</div>

<!-- After -->
<app-dropdown
  [options]="intentOptions"
  [displayFn]="intentDisplayFn"
  [selectedValue]="intent()"
  (valueChange)="setIntent($event)"
></app-dropdown>
```

### Component additions

```typescript
intentOptions: ToolboxIntent[] = ['show', 'compare', 'shape'];
intentDisplayFn = (value: ToolboxIntent) => value.charAt(0).toUpperCase() + value.slice(1);
```

---

## Implementation Order

1. **Issue 3** — simplest, isolated to `toolbox-builder`
2. **Issue 1 & 2 Part A** — auto-fit `fretRange` in `domain.service.ts`
3. **Issue 1 & 2 Part B** — disable Range toolbar when in Shape mode
4. **Tests** — update specs

---

## Test Plan

### Issue 3
- Verify selecting "Show" shows the Show sentence.
- Verify selecting "Compare" shows the Compare sentence.
- Verify selecting "Shape" shows the Shape sentence.

### Issue 1 & 2
- `domain.service.spec.ts`: Add test for `resolve-shape` — verify emitted state includes correct `fretRange`.
- `range-toolbar.component.spec.ts`: Verify `disabled` input disables buttons.
- `home-page.component.spec.ts`: Verify `isShapeMode` is passed correctly.