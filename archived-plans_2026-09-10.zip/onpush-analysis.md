# OnPush Change Detection Strategy — Analysis & Plan

## ⚠️ Known test issue with OnPush

When a component uses `OnPush`, direct property assignment in tests (`component.disabled = true`) does NOT trigger change detection because `@Input()` setters are only called when the **reference changes** — not when you mutate a property directly.

**Fix**: Use `fixture.componentRef.setInput('disabled', true)` instead. This is the Angular 17+ API that properly simulates `@Input()` binding changes and works with `OnPush`.

Affected test: [`string-toggle.component.spec.ts`](src/app/string-toggle/component.spec.ts) line 45 — `component.disabled = true` → `fixture.componentRef.setInput('disabled', true)`

## Context

After migration, all components use `ChangeDetectionStrategy.Eager` (default). This means Angular checks **every component in the tree** on every browser event, timer, XHR, etc. — even if nothing relevant changed.

The goal: identify which components can safely use `OnPush`, and what refactoring is needed to enable it.

## Critical Architectural Constraint

The app uses a **mutable state pattern**:

- [`FretboardStateService`](src/app/services/fretboard-state.service.ts) mutates `GuitarNote` objects in-place (`note.visible = true`, `note.selected = true`, `note.interval = 'root'`)
- [`FretboardDisplayService`](src/app/services/fretboard-display.service.ts) reads mutable state via getters
- [`PatternBuilderService`](src/app/services/pattern-builder.service.ts) exposes mutable `currentPattern` / `relatedChord` as plain properties
- [`DomainService`](src/app/domain/domain.service.ts) uses `signal<DomainState>` internally, but exposes it as a plain getter [`currentState`](src/app/domain/domain.service.ts:35) — not as a signal

**OnPush only triggers** when:
1. An `@Input()` reference changes (`===`)
2. An event originates from the component or its children
3. An `async` pipe emits
4. `markForCheck()` / `detectChanges()` is called manually

With mutable state and no `@Input()` bindings for most components, OnPush would mean the UI **stops updating** when services mutate data.

## Component Tree

```
AppComponent (Eager)
└─ RouterOutlet
   └─ HomePageComponent (Eager)
      ├─ HeaderComponent (Eager)
      ├─ ToolboxBuilderComponent (OnPush ✓ already)
      ├─ RangeToolbarComponent (Eager)
      ├─ GuitarNeckComponent (Eager)
      │  └─ FreatboardComponent (Eager)
      │     └─ StringToggleComponent (Eager)
      ├─ LegendComponent (Eager)
      ├─ RelationshipStripComponent (Eager)
      ├─ PatternDisplayComponent (Eager)
      ├─ MetronomeComponent (Eager)
      └─ FooterComponent (Eager)
```

## Component-by-Component Analysis

### Tier 1: Can go OnPush IMMEDIATELY (zero refactoring)

These components have no `@Input()` bindings to mutable objects and no getters reading mutable service state. All state changes are event-driven from within the component.

| Component | File | Reason |
|-----------|------|--------|
| **FooterComponent** | [`footer.component.ts`](src/app/footer/footer.component.ts) | Pure static template, no state, no inputs |
| **HeaderComponent** | [`header.component.ts`](src/app/header/header.component.ts) | `helpModalOpen` changes only on click events from within |
| **MetronomeComponent** | [`metronome.component.ts`](src/app/metronome/metronome.component.ts) | All state (`bpm`, `isRunning`, `currentBeat`, `extendedOpen` signal) changes via user clicks. Self-contained. |
| **RangeToolbarComponent** | [`range-toolbar.component.ts`](src/app/range-toolbar/range-toolbar.component.ts) | All state changes via user clicks. Emits events upward. |
| **StringToggleComponent** | [`string-toggle.component.ts`](src/app/string-toggle/string-toggle.component.ts) | Pure `@Input()`s (primitives), emits events upward. **But**: parent `FreatboardComponent` must propagate changes. |
| **DropdownComponent** | [`toolbox/dropdown.component.ts`](src/app/toolbox/dropdown.component.ts) | Uses `signal()` for internal state (`isOpen`, `filterText`). Inputs from parent. |
| **AppComponent** | [`app.component.ts`](src/app/app.component.ts) | No state, just `<router-outlet>`. |

### Tier 2: Already OnPush — no action needed

| Component | File | Note |
|-----------|------|------|
| **ToolboxBuilderComponent** | [`toolbox/toolbox-builder.component.ts`](src/app/toolbox/toolbox-builder.component.ts) | Already `OnPush` at line 31. Uses signals for all state. |

### Tier 3: Needs refactoring to enable OnPush

These components read mutable service state via getters in their templates. To use OnPush, the data flow must change.

#### HomePageComponent

[`home-page.component.ts`](src/app/home-page/home-page.component.ts)

- Uses `signal<DisplayMode>` for `displayMode` — works with OnPush
- `chatEnabled` is set once — fine
- `onToolboxEvent()` and `onRangeChange()` are event handlers — trigger CD
- **Verdict**: Can go OnPush **after** child components are addressed. HomePage itself doesn't read mutable service state directly.

#### GuitarNeckComponent

[`guitar-neck.component.ts`](src/app/guitar-neck/guitar-neck.component.ts)

- `guitarNotes: GuitarNote[]` is set once in constructor and **never changes reference**
- Passes `[notes]="guitarNotes"` to `FreatboardComponent`
- The array is mutated in-place by `FretboardStateService.applyHighlightedNotes()`
- **Problem**: With OnPush, `FreatboardComponent` won't detect that `guitarNotes[0].selected` changed
- **Solution**: Convert to immutable pattern — create a new array reference when notes change, or use signals

#### FreatboardComponent

[`freatboard.component.ts`](src/app/freatboard/freatboard.component.ts)

- `@Input() notes: GuitarNote[]` — reference never changes
- Multiple getters reading mutable service state:
  - `fretRange` → `domainService.currentState.fretRange`
  - `activeStrings` → `domainService.currentState.enabledStrings`
  - `showNoteLabels` → `displayService.showNoteLabels`
  - `getMarkerCssClass()` → reads `scaleChordState`, `markerDisplayMode`
  - `getRoleCssClass()` → reads `markerRoleService.lastRoles`
  - `isNoteInRange()` → reads `fretRange`
  - `isNoteOnFret()` → reads `noteQueryService`
  - `isNoteSelected()` → reads `note.selected` (mutable!)
  - `getNoteInterval()` → reads `note.interval` (mutable!)
- **Verdict**: Heaviest coupling to mutable state. Requires the most refactoring.

#### LegendComponent

[`legend.component.ts`](src/app/legend/legend.component.ts)

- Getters: `markerDisplayMode`, `hasActiveResult`, `hasRelation`, `activeIntervals`, `isActive()`
- All read mutable service state
- **Solution**: Convert these to signals or observables from the services

#### PatternDisplayComponent

[`pattern-display.component.ts`](src/app/pattern-display/pattern-display.component.ts)

- Getters: `currentPattern`, `relatedChord`, `isScaleChordMode`
- Read mutable `PatternBuilderService` properties
- **Solution**: Convert `PatternBuilderService` to expose signals

#### RelationshipStripComponent

[`relationship-strip.component.ts`](src/app/relationship-strip/relationship-strip.component.ts)

- Getters: `hasRelation`, `scaleName`, `scaleRoot`, `chordName`, `chordRoot`, `chordTonesInScale`, `chordTonesOutsideScale`
- Read mutable `FretboardStateService.scaleChordState`
- **Solution**: Convert to signals or observables

## Recommended Approach

### Phase 1: Low-hanging fruit (no refactoring)

Switch these to `OnPush` immediately — they're safe even as children of Eager parents:

1. [`AppComponent`](src/app/app.component.ts)
2. [`FooterComponent`](src/app/footer/footer.component.ts)
3. [`HeaderComponent`](src/app/header/header.component.ts)
4. [`MetronomeComponent`](src/app/metronome/metronome.component.ts)
5. [`RangeToolbarComponent`](src/app/range-toolbar/range-toolbar.component.ts)
6. [`DropdownComponent`](src/app/toolbox/dropdown.component.ts)
7. [`StringToggleComponent`](src/app/string-toggle/string-toggle.component.ts)

### Phase 2: Service refactoring (enable OnPush for data-driven components)

The core problem: services mutate state in-place. To enable OnPush for the remaining components, services need to expose state reactively.

**Key changes needed:**

#### A. [`FretboardStateService`](src/app/services/fretboard-state.service.ts)

Convert mutable properties to signals:

```typescript
// Before
notes: GuitarNote[];
hasActiveResult = false;
currentSelection: MusicSelection | null = null;
scaleChordState: ScaleChordState | null = null;

// After
readonly notes: GuitarNote[];  // keep as-is, but...
readonly notesSignal = signal<GuitarNote[]>([]);  // new signal for change detection
readonly hasActiveResult = signal(false);
readonly currentSelection = signal<MusicSelection | null>(null);
readonly scaleChordState = signal<ScaleChordState | null>(null);
```

Methods like `applyHighlightedNotes()` would update the signal after mutation:

```typescript
applyHighlightedNotes(notes: GuitarNote[]): GuitarNote[] {
  // ... existing mutation logic ...
  this.notesSignal.set([...this.notes]);  // new reference triggers OnPush
  return result;
}
```

#### B. [`PatternBuilderService`](src/app/services/pattern-builder.service.ts)

```typescript
// Before
currentPattern: PatternInfo | null = null;
relatedChord: PatternInfo | null = null;

// After
readonly currentPattern = signal<PatternInfo | null>(null);
readonly relatedChord = signal<PatternInfo | null>(null);
```

#### C. [`FretboardDisplayService`](src/app/services/fretboard-display.service.ts)

Methods like `getActiveIntervals()` and `getMarkerCssClass()` are pure functions of service state — they don't need signals themselves, but they're called from templates that need to re-evaluate when state changes.

#### D. [`DomainService`](src/app/domain/domain.service.ts)

Already has `stateSignal` — expose it as a `readonly` signal instead of a getter:

```typescript
// Before
get currentState(): DomainState { return this.stateSignal(); }

// After
readonly currentState = this.stateSignal.asReadonly();
```

This allows components to do `domainService.currentState()` in templates, which works with OnPush.

### Phase 3: Switch remaining components to OnPush

After service refactoring:

| Component | How it detects changes |
|-----------|----------------------|
| **HomePageComponent** | `displayMode()` signal + child events |
| **GuitarNeckComponent** | Would need to read `fretboardState.notesSignal()` or similar |
| **FreatboardComponent** | Would read signals instead of getter properties |
| **LegendComponent** | Would read `domainService.currentState()` as signal + `fretboardState.hasActiveResult()` |
| **PatternDisplayComponent** | Would read `patternBuilder.currentPattern()` as signal |
| **RelationshipStripComponent** | Would read `fretboardState.scaleChordState()` as signal |

### Phase 4: Make HomePageComponent OnPush (biggest win)

Once all children are OnPush-safe, switching `HomePageComponent` to OnPush means the **entire subtree** is only checked when:
- A user interacts with the app (click, input)
- A signal changes
- An async pipe emits

This eliminates all the "background noise" checks from timers, XHR, etc.

## Summary Table

| Component | Current | Recommended | Refactoring Needed | Priority |
|-----------|---------|-------------|-------------------|----------|
| AppComponent | Eager | **OnPush** | None | High |
| FooterComponent | Eager | **OnPush** | None | High |
| HeaderComponent | Eager | **OnPush** | None | High |
| MetronomeComponent | Eager | **OnPush** | None | High |
| RangeToolbarComponent | Eager | **OnPush** | None | High |
| DropdownComponent | Eager | **OnPush** | None | High |
| StringToggleComponent | Eager | **OnPush** | None | High |
| ToolboxBuilderComponent | OnPush | OnPush (keep) | None | — |
| HomePageComponent | Eager | **OnPush** | After children are ready | Medium |
| GuitarNeckComponent | Eager | **OnPush** | Service signals | Medium |
| FreatboardComponent | Eager | **OnPush** | Service signals + template refactor | High (most impact) |
| LegendComponent | Eager | **OnPush** | Service signals | Medium |
| PatternDisplayComponent | Eager | **OnPush** | Service signals | Low |
| RelationshipStripComponent | Eager | **OnPush** | Service signals | Low |

## Recommendation

1. **Start with Phase 1** — 7 components can go OnPush today with zero risk
2. **Then refactor services** (Phase 2) — convert key properties to signals
3. **Then switch the remaining components** (Phase 3-4)
4. **The crown jewel**: `HomePageComponent` OnPush stops unnecessary checks for the entire subtree