# Code Review: `chat.service.ts`

## Overview

Dobrze wydzielony serwis, ale warstwa streamingu zawiera sporo ręcznie napisanego kodu który LangChain już ma wbudowany. Poniżej konkretne problemy.

---

### 1. Unused import: `ChatOllama`

**File:** [`src/app/chat/services/chat.service.ts`](src/app/chat/services/chat.service.ts:2)

```typescript
import { ChatOllama } from "@langchain/ollama";
```

`ChatOllama` nie jest używany w pliku. Model to `ChatOpenRouter` (linia 21). Do usunięcia.

---

### 2. API key hardcoded w serwisie

**File:** [`src/app/chat/services/chat.service.ts`](src/app/chat/services/chat.service.ts:21)

```typescript
apiKey: "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"
```

Klucz API jest wpisany na sztywno. Powinien być w [`environment.ts`](src/environments/environment.ts) i `environment.prod.ts`, tak jak istniejące `geminiApiKey`.

---

### 3. `agent.stream()` — legacy stream mode, brak typowania

**File:** [`src/app/chat/services/chat.service.ts`](src/app/chat/services/chat.service.ts:43-87)

```typescript
const stream = await this.agent.stream(
  { messages: [new HumanMessage(userMessage)] },
  { configurable: { thread_id: this.threadId } }
);
```

`agent.stream()` domyślnie używa legacy LangGraph `updates` mode. Zwraca surowe snapshoty stanu z nazwami nodów jako kluczami, co zmusza do:

- `Object.keys(ev)` żeby zgadnąć który node odpisał (l. 52)
- `as Record<string, unknown>` — utrata typowania (l. 56)
- ręcznego przechodzenia po `nodeOutput['messages']` (l. 59)
- sprawdzania `msg['content']` i `msg['additional_kwargs']` jako nagich string keys (l. 65-67)

Zainstalowany LangChain (`langchain@^1.5.10`) oferuje [`agent.streamEvents({ version: "v3" })`](node_modules/langchain/dist/agents/ReactAgent.d.ts:243-246), który zwraca [`AgentRunStream`](node_modules/langchain/dist/agents/transformers/types.d.ts:80-92) z typowanymi projekcjami:

```typescript
const run = await this.agent.streamEvents(
  { messages: [new HumanMessage(userMessage)] },
  { configurable: { thread_id: this.threadId }, version: "v3" }
);

// Typowany AsyncIterable z wbudowanymi sub-streamami tekstu i reasoning
for await (const msgEvent of run.messages) {
  for await (const token of msgEvent.text) { ... }
  for await (const reasoningToken of msgEvent.reasoning) { ... }
}

// Final state zawsze dostępny — nie trzeba fallbacku
const finalState = await run.output;
```

Eliminuje to ~60 linii ręcznego parsowania.

---

### 4. `getState` fallback z `any` castem

**File:** [`src/app/chat/services/chat.service.ts`](src/app/chat/services/chat.service.ts:90-119)

```typescript
const state = await (this.agent as any).getState(...);
const messages = (state as any)?.values?.messages;
const lastAi = [...messages].reverse().find((m: any) => m.type === 'ai' || m._type === 'ai');
```

Fallback istnieje bo `stream()` czasem nie daje tokenów w pierwszym evencie (linia 89: "no tokens streamed"). Przy `streamEvents(v3)` jest niepotrzebny — `run.output` zawsze zwraca finalny stan.

Dodatkowo ręczne wykrywanie typu wiadomości (`m.type === 'ai'`) powinno być zastąpione [`AIMessage.isInstance()`](node_modules/@langchain/core/dist/messages/ai.d.ts:26-32), które jest dostępne w `@langchain/core/messages`.

---

### 5. Streamowanie podmienia cały text przy każdym chunku

**File:** [`src/app/chat/services/chat.service.ts`](src/app/chat/services/chat.service.ts:71-83)

```typescript
this.messages.update((m) => {
  const msgs = [...m];
  const last = msgs[msgs.length - 1];
  if (last?.streaming) {
    msgs[msgs.length - 1] = { ...last, text: content, ... };
  }
  return msgs;
});
```

Przy każdym evencie podmieniany jest cały obiekt ostatniej wiadomości. W v3 API `msgEvent.text` to [`TextContentStream`](node_modules/@langchain/core/dist/language_models/stream.d.ts:88-104) który daje każdy token z osobna i jest zaprojektowany do append-only.

---

### 6. Testy mockują `invoke`, serwis woła `stream`

**File:** [`src/app/chat/services/chat.service.spec.ts`](src/app/chat/services/chat.service.spec.ts:16-17, 46-47)

```typescript
mockAgent = { invoke: vi.fn() };
```

Mock ma tylko `invoke`, ale `send()` woła `agent.stream()` (linia 43). Działa bo testy override'ują `(service as any).agent` i nie testują faktycznej metody `send()` z prawdziwym streamem.

Po migracji na `streamEvents(v3)` mock powinien zwracać:

```typescript
mockAgent = {
  streamEvents: vi.fn().mockResolvedValue({
    messages: mockAsyncIterableOf(msgEvents),
    output: Promise.resolve(aiMessage),
  }),
};
```

---

## Podsumowanie

| Problem | Linie | Waga |
|---------|-------|------|
| Nieużywany import `ChatOllama` | 2 | Niska |
| API key hardcoded | 21 | Wysoka |
| `agent.stream()` — ręczne parsowanie eventów | 43-87 | Średnia |
| `getState` fallback z `any` | 90-119 | Średnia |
| Podmiana całego textu zamiast append | 71-83 | Niska |
| Mocki nie testują faktycznej ścieżki | spec: 16-17 | Średnia |

Łącznie do wycięcia ~50 linii boilerplate'u i 6+ `any` castów.