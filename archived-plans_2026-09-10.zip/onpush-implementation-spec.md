# Phase 2-4 Implementation Spec — OnPush for All Components

## Overview

Convert the remaining 6 components to `OnPush` by refactoring services to expose state via Angular `signal()` instead of mutable properties.

---

## Phase 2: Service Refactoring

### 2A. FretboardStateService

**File**: [`src/app/services/fretboard-state.service.ts`](src/app/services/fretboard-state.service.ts)

**Changes**:

```typescript
// Add import
import { Injectable, inject, signal } from '@angular/core';

// Convert these properties to signals:
// Before:
hasActiveResult = false;
currentSelection: MusicSelection | null = null;
scaleChordState: ScaleChordState | null = null;

// After:
readonly hasActiveResult = signal(false);
readonly currentSelection = signal<MusicSelection | null>(null);
readonly scaleChordState = signal<ScaleChordState | null>(null);
```

**Update methods** — at the end of each method that modifies these, call `.set()`:

```typescript
applyHighlightedNotes(notes: GuitarNote[]): GuitarNote[] {
  // ... existing mutation logic ...
  this.hasActiveResult.set(notes.length > 0);
  return this.notes.filter(note => note.selected);
}

clearFretboard() {
  this.hideAllNotes();
  this.clearSelection();
  this.hasActiveResult.set(false);
  this.currentSelection.set(null);
  this.scaleChordState.set(null);
}
```

In `displayScaleWithChord()` in [`fretboard-orchestration.service.ts`](src/app/services/fretboard-orchestration.service.ts), after setting `scaleChordState`:

```typescript
this.guitarNeckService.scaleChordState.set({ scale: ..., chord: ... });
```

### 2B. PatternBuilderService

**File**: [`src/app/services/pattern-builder.service.ts`](src/app/services/pattern-builder.service.ts)

```typescript
import { Injectable, inject, signal } from '@angular/core';

// Before:
currentPattern: PatternInfo | null = null;
relatedChord: PatternInfo | null = null;

// After:
readonly currentPattern = signal<PatternInfo | null>(null);
readonly relatedChord = signal<PatternInfo | null>(null);
```

Update `setCurrentPattern()`, `setRelatedChord()`, `clearCurrentPattern()` to use `.set()`.

### 2C. DomainService

**File**: [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts)

Already has `stateSignal`. Just expose it as readonly:

```typescript
// Before:
get currentState(): DomainState {
  return this.stateSignal();
}

// After:
readonly currentState = this.stateSignal.asReadonly();
```

This is a **breaking change** — all code that reads `domainService.currentState.fretRange` must change to `domainService.currentState().fretRange` (function call).

### 2D. FretboardDisplayService

**File**: [`src/app/services/fretboard-display.service.ts`](src/app/services/fretboard-display.service.ts)

No signal changes needed here — its methods are pure functions of other services' state. But the `showNoteLabels` getter reads `domainService.currentState` which becomes a signal call:

```typescript
// Before:
get showNoteLabels(): boolean {
  return this.domainService.currentState.markerDisplayMode !== 'neutral-dots';
}

// After:
get showNoteLabels(): boolean {
  return this.domainService.currentState().markerDisplayMode !== 'neutral-dots';
}
```

---

## Phase 3: Switch Remaining Components to OnPush

### 3A. FreatboardComponent

**File**: [`src/app/freatboard/freatboard.component.ts`](src/app/freatboard/freatboard.component.ts)

**Change detection**: `Eager` → `OnPush`

**Template getters** — all getters that read `domainService.currentState.X` must become function calls:

```typescript
// Before:
get fretRange() {
  return this.domainService.currentState.fretRange;
}

get activeStrings(): boolean[] {
  return this.domainService.currentState.enabledStrings;
}

// After:
get fretRange() {
  return this.domainService.currentState().fretRange;
}

get activeStrings(): boolean[] {
  return this.domainService.currentState().enabledStrings;
}
```

**`showNoteLabels`** — already delegated to `FretboardDisplayService`, which reads `domainService.currentState()` — no change needed in template.

**`getMarkerCssClass()`** — reads `domainService.currentState.markerDisplayMode` → change to `domainService.currentState().markerDisplayMode`.

**`getRoleCssClass()`** — reads `markerRoleService.lastRoles` (a plain Map). This is the tricky one — `lastRoles` is a mutable property set by `computeRoles()`. Two options:

1. **Quick fix**: Make `lastRoles` a `signal<Map<string, MarkerRole>>` in `MarkerRoleService`
2. **Alternative**: Call `markForCheck()` manually after roles are computed

**Recommendation**: Option 1 — convert `lastRoles` to signal:

```typescript
// In marker-role.service.ts:
readonly lastRoles = signal<Map<string, MarkerRole>>(new Map());

// In computeRoles(), at the end:
this.lastRoles.set(roles);
```

### 3B. LegendComponent

**File**: [`src/app/legend/legend.component.ts`](src/app/legend/legend.component.ts)

**Change detection**: `Eager` → `OnPush`

**Getter changes**:

```typescript
// Before:
get markerDisplayMode(): string {
  return this.domainService.currentState.markerDisplayMode;
}

get hasActiveResult(): boolean {
  return this.guitarNeckService.hasActiveResult;
}

get hasRelation(): boolean {
  return this.displayService.hasRelation;
}

get activeIntervals(): string[] {
  return this.displayService.getActiveIntervals();
}

// After:
get markerDisplayMode(): string {
  return this.domainService.currentState().markerDisplayMode;
}

get hasActiveResult(): boolean {
  return this.guitarNeckService.hasActiveResult();
}

get hasRelation(): boolean {
  return this.displayService.hasRelation;
}

get activeIntervals(): string[] {
  return this.displayService.getActiveIntervals();
}
```

Note: `hasRelation` in `FretboardDisplayService` reads `guitarNeckService.scaleChordState` — after Phase 2A, this becomes `guitarNeckService.scaleChordState()`.

### 3C. PatternDisplayComponent

**File**: [`src/app/pattern-display/pattern-display.component.ts`](src/app/pattern-display/pattern-display.component.ts)

**Change detection**: `Eager` → `OnPush`

**Getter changes**:

```typescript
// Before:
get currentPattern() {
  return this.patternBuilder.currentPattern;
}

get relatedChord() {
  return this.patternBuilder.relatedChord;
}

get isScaleChordMode(): boolean {
  return this.domainService.currentState.mode === 'scale-chord';
}

// After:
get currentPattern() {
  return this.patternBuilder.currentPattern();
}

get relatedChord() {
  return this.patternBuilder.relatedChord();
}

get isScaleChordMode(): boolean {
  return this.domainService.currentState().mode === 'scale-chord';
}
```

### 3D. RelationshipStripComponent

**File**: [`src/app/relationship-strip/relationship-strip.component.ts`](src/app/relationship-strip/relationship-strip.component.ts)

**Change detection**: `Eager` → `OnPush`

**Getter changes**:

```typescript
// Before:
get hasRelation(): boolean {
  return this.fretboardState.scaleChordState?.chord != null;
}

get scaleName(): string {
  return this.fretboardState.scaleChordState?.scale.name ?? '';
}

// After:
get hasRelation(): boolean {
  return this.fretboardState.scaleChordState()?.chord != null;
}

get scaleName(): string {
  return this.fretboardState.scaleChordState()?.scale.name ?? '';
}
```

Same pattern for `scaleRoot`, `chordName`, `chordRoot`.

### 3E. GuitarNeckComponent

**File**: [`src/app/guitar-neck/guitar-neck.component.ts`](src/app/guitar-neck/guitar-neck.component.ts)

**Change detection**: `Eager` → `OnPush`

No getter changes needed — it only passes `guitarNotes` (set once) to `FreatboardComponent`. The notes are mutated in-place, but `FreatboardComponent` will now read signals from services directly, so it will detect changes.

### 3F. HomePageComponent

**File**: [`src/app/home-page/home-page.component.ts`](src/app/home-page/home-page.component.ts)

**Change detection**: `Eager` → `OnPush`

Already uses `signal<DisplayMode>` for `displayMode` — works with OnPush. No other changes needed.

---

## Phase 4: Verify

### Test updates needed

Any test that directly assigns to `@Input()` properties must use `fixture.componentRef.setInput()` instead. Check these spec files:

- [`freatboard.component.spec.ts`](src/app/freatboard/freatboard.component.spec.ts)
- [`legend.component.spec.ts`](src/app/legend/legend.component.spec.ts)
- [`pattern-display.component.spec.ts`](src/app/pattern-display/pattern-display.component.spec.ts)
- [`relationship-strip.component.spec.ts`](src/app/relationship-strip/relationship-strip.component.spec.ts)
- [`guitar-neck.component.spec.ts`](src/app/guitar-neck/guitar-neck.component.spec.ts)
- [`home-page.component.spec.ts`](src/app/home-page/home-page.component.spec.ts)

### Run tests

```bash
npm test
```

### Build check

```bash
npm run build
```

---

## Execution Order (recommended)

1. **Phase 2A** — `FretboardStateService` signals
2. **Phase 2B** — `PatternBuilderService` signals
3. **Phase 2C** — `DomainService` expose `asReadonly()`
4. **Phase 2D** — `FretboardDisplayService` update `showNoteLabels` getter
5. **Phase 2A addendum** — `MarkerRoleService.lastRoles` → signal
6. **Phase 3A** — `FreatboardComponent` OnPush + getter updates
7. **Phase 3B** — `LegendComponent` OnPush + getter updates
8. **Phase 3C** — `PatternDisplayComponent` OnPush + getter updates
9. **Phase 3D** — `RelationshipStripComponent` OnPush + getter updates
10. **Phase 3E** — `GuitarNeckComponent` OnPush
11. **Phase 3F** — `HomePageComponent` OnPush
12. **Phase 4** — Fix tests, run `npm test`, run `npm run build`

---

## Risk Assessment

| Change | Risk | Mitigation |
|--------|------|------------|
| `DomainService.currentState` getter → signal call | **Medium** — every consumer must use `()` | Search all `currentState.` usages across codebase |
| `FretboardStateService` properties → signals | **Medium** — many consumers | Search all `guitarNeckService.hasActiveResult`, `scaleChordState`, `currentSelection` |
| `PatternBuilderService` properties → signals | **Low** — only 2 consumers | PatternDisplayComponent + DomainService |
| `MarkerRoleService.lastRoles` → signal | **Low** — only FreatboardComponent reads it | Single consumer |
| Component OnPush switch | **Low** — if signals are correct, CD works | Run full test suite |

### Search patterns to find all consumers before refactoring:

```
domainService\.currentState\.   → must become domainService.currentState().
guitarNeckService\.hasActiveResult → must become guitarNeckService.hasActiveResult()
guitarNeckService\.scaleChordState → must become guitarNeckService.scaleChordState()
guitarNeckService\.currentSelection → must become guitarNeckService.currentSelection()
patternBuilder\.currentPattern → must become patternBuilder.currentPattern()
patternBuilder\.relatedChord → must become patternBuilder.relatedChord()