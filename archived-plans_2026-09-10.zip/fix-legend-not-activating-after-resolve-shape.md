# Plan: Fix Legend Not Activating After `__ds.execute({ type: 'resolve-shape' })`

## Bug Analysis

### Symptom
Calling `window.__ds.execute({ type: 'resolve-shape', shapeId: 'cowboy-C' })` from the browser console displays notes on the fretboard but the **Intervals Legend panel does not appear**.

### Root Cause

There is **one primary cause** and **one potential secondary issue**:

#### Primary: `displayMode` signal is never set to `'legend'`

The flow has two paths:

**Path A — Toolbox (works correctly):**
1. User clicks in Toolbox → `toolboxEvent` output fires
2. [`HomePageComponent.onToolboxEvent()`](src/app/home-page/home-page.component.ts:65) is called
3. It calls [`domainService.execute(command)`](src/app/home-page/home-page.component.ts:81)
4. **Then** it explicitly sets [`this.displayMode.set('legend')`](src/app/home-page/home-page.component.ts:82)
5. The template [`@if (displayMode() === 'legend')`](src/app/home-page/home-page.component.html:27) renders `<app-legend>`

**Path B — Console `__ds.execute()` (broken):**
1. [`window.__ds`](src/app/home-page/home-page.component.ts:53) exposes the raw `DomainService` instance
2. `__ds.execute()` calls [`DomainService.execute()`](src/app/domain/domain.service.ts:85) directly
3. `DomainService` handles domain logic (resolves shape, displays positions, updates state signal)
4. **But `displayMode` is never set** — `HomePageComponent.onToolboxEvent()` is completely bypassed
5. The template's `@if` condition is `false`, so `<app-legend>` is never rendered

#### Secondary: Interval labels from shape positions vs calculated intervals

The shape positions have `label` fields (`'root'`, `'3'`, `'5'`), but the legend's [`isActive()`](src/app/legend/legend.component.ts:62) checks against CSS class names like `'root'`, `'major-3rd'`, `'perfect-5th'`. However, [`displayPositions()`](src/app/services/fretboard-orchestration.service.ts:65) calls [`markIntervals()`](src/app/services/fretboard-orchestration.service.ts:130) which calculates intervals from **note pitch classes** (not from shape labels), so the intervals **should be correct** for standard cowboy chords. This is likely **not a bug** for `cowboy-C`.

## Solution Design

### Approach: Reactive `displayMode` via Angular `effect()`

Instead of relying on `onToolboxEvent()` to manually set `displayMode` after each command, make `HomePageComponent` **reactively observe** the domain state and automatically derive `displayMode`.

This fixes ALL callers (Toolbox, console `__ds`, future AI integration) with a single change.

#### How it works

```mermaid
flowchart TD
    A[Any caller: Toolbox / __ds / AI] --> B[DomainService.execute]
    B --> C[DomainService updates currentState signal]
    B --> D[FretboardStateService.hasActiveResult signal]
    C --> E[HomePageComponent effect fires]
    D --> E
    E --> F{hasActiveResult?}
    F -->|false| G[displayMode = null]
    F -->|true| H{state.mode}
    H -->|scale/chord/custom/positions| I[displayMode = legend]
    H -->|scale-chord| J[displayMode = relationship]
```

#### Why `hasActiveResult` is needed

Both [`handleClearView()`](src/app/domain/domain.service.ts:216) and the initial page load produce `mode: 'scale'` (from `DEFAULT_DOMAIN_STATE`). Without `hasActiveResult`, we couldn't distinguish "no pattern shown" from "scale pattern shown". The `hasActiveResult` signal from [`FretboardStateService`](src/app/services/fretboard-state.service.ts:18) provides this distinction — it's `false` on clear/initial and `true` after any pattern is displayed.

## Implementation Steps

### Step 1: Add `effect()` to `HomePageComponent`

**File:** [`src/app/home-page/home-page.component.ts`](src/app/home-page/home-page.component.ts)

1. Inject `FretboardStateService` (or use the existing `FretboardStateService` via a new injection)
2. Add an `effect()` in the constructor that watches `domainService.currentState()` and `guitarNeckService.hasActiveResult()`
3. Derive `displayMode` from the observed values

```typescript
// New imports needed:
import { effect } from '@angular/core';
import { FretboardStateService } from '../services/fretboard-state.service';

// New injection:
private guitarNeckService = inject(FretboardStateService);

// In constructor:
effect(() => {
  const state = this.domainService.currentState();
  const hasResult = this.guitarNeckService.hasActiveResult();
  
  if (!hasResult) {
    this.displayMode.set(null);
    return;
  }
  
  switch (state.mode) {
    case 'scale':
    case 'chord':
    case 'custom':
    case 'positions':
      this.displayMode.set('legend');
      break;
    case 'scale-chord':
      this.displayMode.set('relationship');
      break;
  }
});
```

### Step 2: Simplify `onToolboxEvent()` (optional cleanup)

The `displayMode` assignments in `onToolboxEvent()` become redundant since the effect handles them. They can be removed for cleanliness, but keeping them doesn't cause harm (the effect would just confirm the same value). **Recommendation: remove the redundant `displayMode.set()` calls** to avoid confusion.

### Step 3: Verify the fix

1. Call `window.__ds.execute({ type: 'resolve-shape', shapeId: 'cowboy-C' })` from console
2. Confirm the Legend panel appears
3. Confirm intervals are correctly highlighted in the legend (Root, 3, 5 should be active)
4. Test existing Toolbox paths still work (show scale, show chord, compare, clear)
5. Run `npm test` to ensure no regressions

## Files to Modify

| File | Change |
|------|--------|
| [`src/app/home-page/home-page.component.ts`](src/app/home-page/home-page.component.ts) | Add `effect()` to reactively set `displayMode` based on domain state + `hasActiveResult` |
| [`src/app/home-page/home-page.component.ts`](src/app/home-page/home-page.component.ts) | (Optional) Remove redundant `displayMode.set()` calls from `onToolboxEvent()` |

## Files NOT to Modify

| File | Reason |
|------|--------|
| [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts) | Domain logic is correct; the issue is purely UI orchestration |
| [`src/app/domain/commands.ts`](src/app/domain/commands.ts) | Command definitions are correct |
| [`src/app/legend/legend.component.ts`](src/app/legend/legend.component.ts) | Legend component logic is correct; it just isn't rendered |
| [`src/app/services/fretboard-orchestration.service.ts`](src/app/services/fretboard-orchestration.service.ts) | Orchestration logic is correct |
| [`src/app/services/shape-resolver.service.ts`](src/app/services/shape-resolver.service.ts) | Shape resolution is correct |