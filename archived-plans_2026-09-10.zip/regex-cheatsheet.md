# VS Code Search & Replace — konkretne regexy

Kopiuj i wklej do VS Code Ctrl+Shift+F → `.*` → Alt+Enter → potem regex replace.

---

## Krok 1: DomainService — zmień getter na sygnał

W [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts:35-37):

```typescript
// ZAMIEŃ:
get currentState(): DomainState {
    return this.stateSignal();
}

// NA:
readonly currentState = this.stateSignal.asReadonly();
```

---

## Krok 2: Wszystkie odczyty `currentState.` → `currentState().`

| Search (regex) | Replace | Uwaga |
|----------------|---------|-------|
| `currentState\.` | `currentState().` | Działa tylko gdy po kropce jest coś — nie złapie `currentState` na końcu |

**Wyjątki**: w `domain.service.ts` zostaw `this.currentState` bez kropki (linia 62, 207-209).

---

## Krok 3: Odczyty `FretboardStateService` — dodaj `()`

| Search (regex) | Replace | Gdzie |
|----------------|---------|-------|
| `(?<!\.set\()hasActiveResult\b(?!\()(?!\s*=)` | `hasActiveResult()` | WSZYSTKIE pliki |
| `(?<!\.set\()scaleChordState\b(?!\()(?!\s*=)` | `scaleChordState()` | WSZYSTKIE pliki |
| `(?<!\.set\()currentSelection\b(?!\()(?!\s*=)` | `currentSelection()` | WSZYSTKIE pliki |

**Wyjaśnienie regex**: `(?<!\.set\()` = nie poprzedzone `.set(`, `(?!\()` = nie ma już `()`, `(?!\s*=)` = nie ma `=` (przypisanie).

---

## Krok 4: Zapisy w testach — `= value` → `.set(value)`

| Search (regex) | Replace | Gdzie |
|----------------|---------|-------|
| `hasActiveResult\s*=\s*` | `hasActiveResult.set(` | Tylko `*.spec.ts` |
| `scaleChordState\s*=\s*` | `scaleChordState.set(` | Tylko `*.spec.ts` |
| `currentSelection\s*=\s*` | `currentSelection.set(` | Tylko `*.spec.ts` |

Po tym replace zostaną wiszące `)` — np. `hasActiveResult.set(false` → trzeba dodać `)` na końcu. VS Code nie ogarnia tego w jednym replace, więc:

**Druga runda dla testów**: Szukaj `\.set\(([^)]+)$` → Zamień na `.set($1)` — to doda zamykający nawias tam gdzie brak.

---

## Krok 5: `PatternBuilderService` — dopiero zrobisz

W [`src/app/services/pattern-builder.service.ts`](src/app/services/pattern-builder.service.ts):

```typescript
// ZAMIEŃ:
currentPattern: PatternInfo | null = null;
relatedChord: PatternInfo | null = null;

// NA:
readonly currentPattern = signal<PatternInfo | null>(null);
readonly relatedChord = signal<PatternInfo | null>(null);
```

Dodaj `import { Injectable, inject, signal } from '@angular/core';` (już jest `inject`).

Potem w metodach: `this.currentPattern = null` → `this.currentPattern.set(null)`, `this.currentPattern = {...}` → `this.currentPattern.set({...})`.

**Odczyty** (w `pattern-display.component.ts`, `domain.service.ts`): `currentPattern` → `currentPattern()`.

---

## Krok 6: `MarkerRoleService.lastRoles` → sygnał

W [`src/app/services/marker-role.service.ts`](src/app/services/marker-role.service.ts:48):

```typescript
// ZAMIEŃ:
lastRoles: Map<string, MarkerRole> = new Map();

// NA:
readonly lastRoles = signal<Map<string, MarkerRole>>(new Map());
```

W `computeRoles()` na końcu: `this.lastRoles = roles;` → `this.lastRoles.set(roles);`

W `fretboard-display.service.ts` odczyt: `this.markerRoleService.lastRoles?.get(key)` → `this.markerRoleService.lastRoles()?.get(key)`

---

## Krok 7: Testy spec — poprawki `@Input()` dla OnPush

W każdym `*.spec.ts` gdzie test bezpośrednio przypisuje do `@Input()`:

| Search | Replace |
|--------|---------|
| `component\.(\w+)\s*=\s*` | `fixture.componentRef.setInput('$1', ` |

Potem druga runda: dodaj `)` na końcu linii gdzie brakuje.

---

## Podsumowanie — kolejność

1. **DomainService** — zmień getter
2. **Regex**: `currentState.` → `currentState().` (wszystkie pliki)
3. **Regex**: `hasActiveResult` → `hasActiveResult()` (z exclude)
4. **Regex**: `scaleChordState` → `scaleChordState()` (z exclude)
5. **Regex**: `currentSelection` → `currentSelection()` (z exclude)
6. **PatternBuilderService** — zmień na sygnały
7. **Regex**: `currentPattern` → `currentPattern()` (z exclude)
8. **Regex**: `relatedChord` → `relatedChord()` (z exclude)
9. **MarkerRoleService** — `lastRoles` → sygnał
10. **Testy**: regex dla `.set(`
11. **Testy**: regex dla `@Input()` → `setInput()`
12. Uruchom `npm test`