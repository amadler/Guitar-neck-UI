# Plan: AI Mode — stabilizacja layoutu chata

## Problem

Gdy rozmowa z AI się rozwija, kontener chata w [`bottom-panel`](src/app/home-page/home-page.component.html:39) rozszerza się, wypychając [`pattern-display`](src/app/pattern-display/pattern-display.component.ts) (pattern card) do wąskiego paska.

**Przyczyny**:
1. Chat nie ma zdefiniowanych flex właściwości w [`bottom-panel`](src/app/home-page/home-page.component.scss:57) → domyślnie `flex: 0 0 auto`
2. Wiadomości w [`ChatComponent`](src/app/chat/chat.ts:30) mają `max-width: 80%` (80% kontenera chata)
3. Brak mechanizmu "trybu AI" który by usztywnił layout

## Rozwiązanie

Dodać stan `aiMode` do [`DomainState`](src/app/domain/state.ts), komendę `set-ai-mode` do [`DomainCommand`](src/app/domain/commands.ts), toggle button w [`header`](src/app/header/header.component.html), i poprawić flex layout w `bottom-panel`.

### Diagram przepływu stanu

```mermaid
flowchart TD
    User[User clicks AI toggle in header] --> HeaderComp[HeaderComponent]
    HeaderComp -->|execute set-ai-mode| DomainSvc[DomainService]
    DomainSvc -->|updates state signal| DomainState[DomainState.aiMode = true]
    DomainState -->|reactively hides| Metronome[Metronome component]
    DomainState -->|reactively adds CSS class| Chat[Chat container]
    DomainState -->|pattern-display gets full space| PatternCard[Pattern card]
```

### Zmiany w kodzie

#### 1. [`DomainState`](src/app/domain/state.ts) — dodać pole `aiMode`

```typescript
export interface DomainState {
  // ... existing fields ...
  
  /** AI chat mode — when active, metronome hides and chat gets fixed width. */
  aiMode: boolean;
}
```

Dodać `aiMode: false` do [`DEFAULT_DOMAIN_STATE`](src/app/domain/state.ts:62).

#### 2. [`commands.ts`](src/app/domain/commands.ts) — dodać komendę

```typescript
export interface SetAiModeCommand {
  type: 'set-ai-mode';
  enabled: boolean;
}
```

Dodać do unii [`DomainCommand`](src/app/domain/commands.ts:94):
```typescript
export type DomainCommand =
  | ShowPatternCommand
  | ComparePatternsCommand
  | ShowIntervalCommand
  | SetViewCommand
  | SetEmphasisCommand
  | ClearViewCommand
  | ResolveShapeCommand
  | SetAiModeCommand;
```

#### 3. [`DomainService`](src/app/domain/domain.service.ts) — zarejestrować handler

W [`registerCommandHandlers`](src/app/domain/domain.service.ts:56) dodać:
```typescript
this.commandHandlers.set('set-ai-mode', (c) => this.handleSetAiMode(c));
```

Dodać handler:
```typescript
private handleSetAiMode(command: DomainCommand & { type: 'set-ai-mode' }): DomainResult<DomainState> {
  return this.emitState({
    ...this.currentState(),
    aiMode: command.enabled,
  });
}
```

#### 4. [`HeaderComponent`](src/app/header/header.component.ts) — dodać toggle button

Wstrzyknąć `DomainService`:
```typescript
private domainService = inject(DomainService);
```

Dodać metodę:
```typescript
toggleAiMode(): void {
  const current = this.domainService.currentState().aiMode;
  this.domainService.execute({ type: 'set-ai-mode', enabled: !current });
}
```

W [`header.component.html`](src/app/header/header.component.html:7) dodać przycisk w `.app-header__actions`:
```html
<button class="icon-btn ai-toggle" type="button" 
  [class.active]="domainService.currentState().aiMode"
  (click)="toggleAiMode()" aria-label="AI Chat">
  <!-- SVG chat bubble icon -->
  <svg width="22" height="22" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" 
      stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
  </svg>
</button>
```

Styl `.ai-toggle.active` w [`header.component.scss`](src/app/header/header.component.scss):
```scss
.ai-toggle.active {
  color: var(--md-primary);
  background: var(--md-primary-container);
}
```

#### 5. [`HomePageComponent`](src/app/home-page/home-page.component.ts) — odczytać aiMode

Dodać signal:
```typescript
import { computed } from '@angular/core';

aiMode = computed(() => this.domainService.currentState().aiMode);
```

#### 6. [`home-page.component.html`](src/app/home-page/home-page.component.html:39) — warunkowe ukrycie metronomu i klasa dla chata

```html
<section class="bottom-panel" [class.bottom-panel--ai-mode]="aiMode()">
  <div class="bottom-panel__scale-info">
    <app-pattern-display></app-pattern-display>
  </div>
  <div class="bottom-panel__divider"></div>
  @if (!aiMode()) {
    <div class="bottom-panel__metronome">
      <app-metronome></app-metronome>
    </div>
  }
  @if (chatEnabled) {
    <div class="bottom-panel__chat" [class.bottom-panel__chat--active]="aiMode()">
      <app-chat></app-chat>
    </div>
  }
</section>
```

#### 7. [`home-page.component.scss`](src/app/home-page/home-page.component.scss:57) — flex layout

Dodać style dla chata:
```scss
.bottom-panel__chat {
  flex: 0 0 auto;
  min-width: 0;
}

.bottom-panel__chat--active {
  width: 360px;
  flex-shrink: 0;
}
```

Gdy `aiMode` — pattern-display zajmuje resztę:
```scss
.bottom-panel--ai-mode {
  .bottom-panel__scale-info {
    flex: 1;
    min-width: 0;
  }
}
```

#### 8. Responsywność

W media query dla `<=900px`:
```scss
@media (max-width: 900px) {
  .bottom-panel {
    flex-direction: column;
    gap: 16px;
  }

  .bottom-panel__chat--active {
    width: 100%;
  }
}
```

### Kolejność implementacji

| # | Zadanie | Pliki |
|---|---------|-------|
| 1 | Dodać `aiMode` do `DomainState` + `DEFAULT_DOMAIN_STATE` | `src/app/domain/state.ts` |
| 2 | Dodać `SetAiModeCommand` do `commands.ts` | `src/app/domain/commands.ts` |
| 3 | Dodać handler w `DomainService` | `src/app/domain/domain.service.ts` |
| 4 | Dodać toggle button w `HeaderComponent` | `src/app/header/header.component.ts`, `.html`, `.scss` |
| 5 | Dodać `aiMode` signal w `HomePageComponent` | `src/app/home-page/home-page.component.ts` |
| 6 | Zmienić template — warunkowy metronom, klasa dla chata | `src/app/home-page/home-page.component.html` |
| 7 | Dodać style CSS — fixed width chata, flex poprawki | `src/app/home-page/home-page.component.scss` |
| 8 | Walidacja — `npm run build` i `npm test` | — |