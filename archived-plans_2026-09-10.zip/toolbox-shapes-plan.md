# Plan: Add shape picker to toolbox (separate branch)

## Goal

Make all cowboy and barre shapes selectable from the toolbox UI so the user can visually verify them on the fretboard.

## Branch

Create from `api-extension`: `feat/toolbox-shapes`

## Changes

### 1. Fix shape category cycling — remove dead `triad-inversion`

**File:** [`src/app/toolbox/toolbox-builder.component.ts`](src/app/toolbox/toolbox-builder.component.ts:43)

Remove `triadShapes` — the `triad-inversion` category was removed from the registry during grooming.

```typescript
// Remove this line (line 44):
triadShapes = getShapesByCategory('triad-inversion');
```

**File:** [`src/app/toolbox/toolbox-builder.component.ts`](src/app/toolbox/toolbox-builder.component.ts:88)

Update `currentShapes` getter — remove the `triad-inversion` case:

```typescript
get currentShapes(): Array<{ id: string; name: string; category: string }> {
  switch (this.shapeCategory()) {
    case 'cowboy': return this.cowboyShapes;
    case 'barre': return this.barreShapes;
    default: return [];
  }
}
```

**File:** [`src/app/toolbox/toolbox-builder.component.html`](src/app/toolbox/toolbox-builder.component.html:132)

Update category chip cycling — remove `triad-inversion`:

```html
(click)="setShapeCategory(shapeCategory() === 'cowboy' ? 'barre' : 'cowboy')"
```

And update the label:

```html
{{ shapeCategory() === 'cowboy' ? 'Cowboy' : 'Barre' }}
```

### 2. Auto-select first shape when category changes

**File:** [`src/app/toolbox/toolbox-builder.component.ts`](src/app/toolbox/toolbox-builder.component.ts:82)

When category changes, select the first available shape automatically:

```typescript
setShapeCategory(category: ShapeCategory): void {
  this.shapeCategory.set(category);
  const shapes = this.currentShapes;
  this.selectedShape.set(shapes.length > 0 ? shapes[0] : null);
}
```

### 3. Remove `ShapeCategory` type dependency on `triad-inversion`

**File:** [`src/app/toolbox/model.ts`](src/app/toolbox/model.ts)

Check if `ShapeCategory` includes `'triad-inversion'`. If so, remove it:

```typescript
export type ShapeCategory = 'cowboy' | 'barre';
```

### 4. (Optional) Add `cowboy-C7` as default selected shape on init

**File:** [`src/app/toolbox/toolbox-builder.component.ts`](src/app/toolbox/toolbox-builder.component.ts:70)

```typescript
selectedShape = signal<{ id: string; name: string } | null>(this.cowboyShapes[0] ?? null);
```

This way when user opens the toolbox in Shape mode, C major (first cowboy) is already selected.

## Files to modify

| File | Changes |
|------|---------|
| `src/app/toolbox/toolbox-builder.component.ts` | Remove triadShapes, update currentShapes, auto-select on category change, default shape |
| `src/app/toolbox/toolbox-builder.component.html` | Remove triad-inversion from chip cycling and label |
| `src/app/toolbox/model.ts` | Remove 'triad-inversion' from ShapeCategory type |

## Test

After changes:
1. `npm start` → toolbox should show "Shape" intent after 2 clicks
2. Select "Barre" → "Barre E-form (major)" → root key "F" → "Show"
3. Fretboard should display F barre chord with correct positions
4. Select "Cowboy" → "C7 (open)" → "Show"
5. Fretboard should display C7 with Bb on string 3