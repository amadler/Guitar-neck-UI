# PR #9 Fix Plan — API Extension Scope Reduction

Based on the 12 decisions agreed upon, this plan details the exact changes needed for PR `origin/api-extension`.

## Execution Order

```
Faza 1: WYCINAMY zbędny scope
  ├── 1. Usuń show-voicing, show-arpeggio, show-lick (commands + handlers)
  ├── 2. Usuń triad-inversion entries z shape registry (24 wpisy)
  ├── 3. Usuń martwe typy: INVALID_VOICING, validateVoicing()
  └── 4. Usuń filterNotesBySet, isSubsetOf, isSupersetOf z TonalFacade

Faza 2: AUDYT + NAPRAWA tego co zostaje
  ├── 5. Zweryfikuj wszystkie dane w guitar-shapes.ts (cowboy + barre)
  │     - sprawdź każdą pozycję względem stroju EADGBE
  │     - popraw błędne labelki
  │     - dodaj testy walidacji danych
  └── 6. Napraw model fixed vs movable
        - cowboy: własne rootNote/chordType
        - movable: rootNote jako parametr
        - zablokuj cowboy-C + rootNote=F (niespójny stan)

Faza 3: POPRAWA API
  ├── 7. KeyAnalysis DTO — zamiast Record<string, unknown>
  │     - własny interfejs KeyAnalysis
  │     - mapowanie Tonal → DomainContract
  └── 8. Type-safety cleanup w DomainService
        - CommandHandler/QueryHandler: any → konkretne typy
        - bez nowych frameworków/abstrakcji

Faza 4: TESTY
  └── 9. Testy dla foundation (pokrycie logiki domenowej)
        - ShapeResolverService
        - walidacja pozycji (DomainValidator)
        - getNoteAtPosition / findPositionsByExactCoordinates
        - semantic queries (detect-chord, detect-scale, get-key-analysis)
        - resolve-shape command

Faza 5: DOKUMENTACJA
  ├── 10. BACKLOG.md — zaktualizuj P6, dodaj osobne wpisy dla show-voicing/arpeggio/lick
  └── 11. docs/api/domain-contract-api.md — odzwierciedl zredukowany scope
```

---

## Task 1: Remove `show-voicing`, `show-arpeggio`, `show-lick`

### 1a. [`src/app/domain/commands.ts`](src/app/domain/commands.ts)

- Delete interfaces: `ShowVoicingCommand`, `ShowArpeggioCommand`, `ShowLickCommand`
- Remove them from `DomainCommand` union type
- Keep `ResolveShapeCommand`

### 1b. [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts)

- Remove registrations: `'show-voicing'`, `'show-arpeggio'`, `'show-lick'` from `registerCommandHandlers()`
- Delete handler methods: `handleShowVoicing()`, `handleShowArpeggio()`, `handleShowLick()`

### 1c. [`src/app/domain/state.ts`](src/app/domain/state.ts)

- Remove `INVALID_VOICING` from `DomainError` enum

### 1d. [`src/app/domain/domain-validator.ts`](src/app/domain/domain-validator.ts)

- Remove `validateVoicing()` method

---

## Task 2: Remove hardcoded triad inversions from shape registry

### 2a. [`src/app/shared/model/guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts)

- Delete all entries with `category: 'triad-inversion'` (lines 254-554, 24 entries)
- Keep only `cowboy` and `barre` entries
- Remove `'triad-inversion'` from `GuitarShape['category']` type union

---

## Task 3: Remove dead types

### 3a. [`src/app/domain/state.ts`](src/app/domain/state.ts)

- Remove `INVALID_VOICING` from `DomainError` enum (if not already done in 1c)

### 3b. [`src/app/domain/domain-validator.ts`](src/app/domain/domain-validator.ts)

- Remove `validateVoicing()` method (if not already done in 1d)

---

## Task 4: Remove unused Tonal API methods

### 4a. [`src/app/services/tonal-facade.service.ts`](src/app/services/tonal-facade.service.ts)

- Remove methods: `filterNotesBySet()`, `isSubsetOf()`, `isSupersetOf()`
- Remove imports: `isSubsetOf`, `isSupersetOf`, `filter as pcsetFilter` from `@tonaljs/pcset`
- Keep: `detectChord()`, `detectScale()`, `getMajorKey()`, `getMinorKey()`

---

## Task 5: Verify musical data in guitar-shapes.ts

### 5a. Audit cowboy shapes

Check each position's label against the actual note at `(string, fretOffset + fixedFret)`.

Standard tuning: E2(6), A2(5), D3(4), G3(3), B3(2), E4(1).

**Known error in `cowboy-A`** ([`guitar-shapes.ts:62-68`](src/app/shared/model/guitar-shapes.ts:62-68)):
- String 3, fretOffset 2 → note = A (G+2), label says `'3'` → should be `'root'`
- String 2, fretOffset 2 → note = C# (B+2), label says `'root'` → should be `'3'`

Labels on strings 3 and 2 are **swapped**. Full audit needed for all shapes.

### 5b. Add data validation tests

Create [`src/app/shared/model/guitar-shapes.spec.ts`](src/app/shared/model/guitar-shapes.spec.ts):
- For each shape position, verify label matches actual note using chromatic scale
- Verify cowboy shapes have consistent `rootNote`/`chordType`
- Verify barre shapes have valid `stringSet` and `rootString`

---

## Task 6: Fix fixed vs movable shapes

### 6a. [`src/app/shared/model/guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts)

Add optional fields to `GuitarShape`:
```typescript
rootNote?: string;    // fixed root for cowboy chords (e.g., 'C')
chordType?: string;   // fixed chord type (e.g., 'major', 'minor')
```

Populate for each cowboy shape:
| Shape | rootNote | chordType |
|-------|----------|-----------|
| cowboy-C | C | major |
| cowboy-A | A | major |
| cowboy-G | G | major |
| cowboy-E | E | major |
| cowboy-D | D | major |
| cowboy-Am | A | minor |
| cowboy-Em | E | minor |
| cowboy-Dm | D | minor |
| cowboy-C7 | C | dominant |
| cowboy-G7 | G | dominant |

### 6b. [`src/app/services/shape-resolver.service.ts`](src/app/services/shape-resolver.service.ts)

- Cowboy shapes: ignore `rootNote` parameter if shape has its own `rootNote`
- Return the shape's own `rootNote` in result
- Add validation: if cowboy has `rootNote` and caller passes different one → return error

---

## Task 7: Define proper `KeyAnalysis` DTO

### 7a. [`src/app/domain/queries.ts`](src/app/domain/queries.ts)

Replace `GetKeyAnalysisResult = Record<string, unknown>` with:

```typescript
export interface KeyAnalysis {
  tonic: string;
  mode: 'major' | 'minor';
  scale: string[];
  triads: string[];
  chords: string[];
  secondaryDominants?: string[];
}
```

Update `GetKeyAnalysisResult` type.

### 7b. [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts)

Update `handleGetKeyAnalysis()` to map Tonal.js result to `KeyAnalysis` DTO.

---

## Task 8: Type-safety cleanup in DomainService

### 8a. [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts)

Replace:
```typescript
type CommandHandler = (command: any) => DomainResult<DomainState>;
type QueryHandler = (query: any) => DomainResult<any>;
```

With properly typed handlers using discriminated unions:
```typescript
type CommandHandler = (command: DomainCommand) => DomainResult<DomainState>;
type QueryHandler = (query: DomainQuery) => DomainResult<unknown>;
```

Update handler signatures to use concrete command/query types instead of `& { type: ... }` intersections.

---

## Task 9: Add tests for foundation

### 9a. [`src/app/services/shape-resolver.service.spec.ts`](src/app/services/shape-resolver.service.spec.ts) — NEW

- `resolveShape('cowboy-C')` → correct positions
- `resolveShape('barre-E-form', 'F')` → F barre positions
- `resolveShape('nonexistent')` → `success: false`
- Cowboy with wrong rootNote → error

### 9b. [`src/app/services/note.service.spec.ts`](src/app/services/note.service.spec.ts) — UPDATE

- `getNoteAtPosition(5, 3)` → `'C'`
- `getNoteAtPosition(0, 3)` → `null`
- `getNoteAtPosition(1, 25)` → `null`
- `findPositionsByExactCoordinates([{string:5, fret:3}])` → correct GuitarNote[]

### 9c. [`src/app/domain/domain-validator.spec.ts`](src/app/domain/domain-validator.spec.ts) — NEW

- `validatePosition(5, 3)` → `null`
- `validatePosition(7, 3)` → error
- `validateNoteAtPosition(5, 3, 'C', ...)` → `null`
- `validateNoteAtPosition(5, 3, 'F', ...)` → error

### 9d. [`src/app/domain/domain.service.spec.ts`](src/app/domain/domain.service.spec.ts) — NEW

- `execute({ type: 'resolve-shape', shapeId: 'cowboy-C' })` → success
- `query({ type: 'detect-chord', notes: ['C', 'E', 'G'] })` → `{ chords: ['C major'] }`
- `query({ type: 'detect-scale', notes: ['C', 'D', 'E', 'F', 'G', 'A', 'B'] })` → includes 'major'
- `query({ type: 'get-key-analysis', tonic: 'C', mode: 'major' })` → `KeyAnalysis`
- `query({ type: 'get-available-shapes' })` → shapes list

### 9e. [`src/app/shared/model/guitar-shapes.spec.ts`](src/app/shared/model/guitar-shapes.spec.ts) — NEW

- Each shape position label matches actual note
- Cowboy shapes have consistent rootNote/chordType
- Barre shapes have valid stringSet

---

## Task 10: Update BACKLOG.md

### 10a. Update existing P6 entry

- Reduce scope to match PR: `resolve-shape`, `detect-chord`, `detect-scale`, `get-key-analysis`, `get-available-shapes`
- Remove references to `show-voicing`, `show-arpeggio`, `show-lick`, triad inversions
- Update MVP and Done-when criteria

### 10b. Add new backlog items

- **P7: `show-voicing`** — Chord voicing with inversion/spread on specific strings
- **P8: `show-arpeggio`** — Interval sequence on specific strings
- **P9: `show-lick`** — Specific validated positions

---

## Task 11: Update documentation

### 11a. [`docs/api/domain-contract-api.md`](docs/api/domain-contract-api.md)

- Remove docs for `show-voicing`, `show-arpeggio`, `show-lick`
- Add docs for `resolve-shape`, `detect-chord`, `detect-scale`, `get-key-analysis`, `get-available-shapes`
- Update `DomainState` — add `mode: 'positions'` and `shapeInfo`
- Update `DomainError` enum
- Update `DomainResult` examples