# Plan: Fix remaining test failures after TS migration

## Current state
- ✅ TS2322 errors fixed via `Partial<MockedObject<T>>` (6 files)
- ❌ 7 test failures remain in 2 categories

---

## Category 1: HeaderComponent — `localStorage` not available in test environment

**Error:** `TypeError: localStorage.getItem is not a function`

**Root cause:** The Angular Vitest runner (`@angular/build:unit-test` with `"runner": "vitest"`) doesn't provide a full jsdom environment with `localStorage` by default. The component's [`ngOnInit`](src/app/header/header.component.ts:18-22) calls `localStorage.getItem()` which throws.

**Fix:** Add a `beforeEach` in [`header.component.spec.ts`](src/app/header/header.component.spec.ts) that mocks `Storage.prototype` methods:

```typescript
beforeEach(() => {
    const store: Record<string, string> = {};
    vi.spyOn(Storage.prototype, 'getItem').mockImplementation(
        (key: string) => store[key] ?? null
    );
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(
        (key: string, value: string) => { store[key] = value; }
    );
});
```

This provides a working in-memory `localStorage` for all tests in the file.

---

## Category 2: MetronomeComponent — `Date.now()` spy conflicts with Zone.js

**Error:** Both tapTempo tests expect BPM to change from 120, but it stays at 120.

**Root cause:** `vi.spyOn(Date, 'now')` replaces `Date.now` globally. Angular's Zone.js also calls `Date.now()` internally (during change detection, async operations, etc.), consuming the mock values before the test code can use them. This causes the `tapTimestamps` array to get wrong values, and the BPM computation never triggers.

**Fix:** Replace `vi.spyOn(Date, 'now')` with `vi.useFakeTimers()` + `vi.advanceTimersByTime()` in the `tapTempo` describe block in [`metronome.component.spec.ts`](src/app/metronome/metronome.component.spec.ts):

```typescript
describe('tapTempo', () => {
    beforeEach(() => {
        vi.useFakeTimers();
    });

    afterEach(() => {
        vi.useRealTimers();
    });

    it('should compute ~120 BPM from 6 taps at 500ms intervals', () => {
        for (let i = 0; i < 6; i++) {
            component.tapTempo();
            vi.advanceTimersByTime(500);
        }
        expect(component.bpm).toBe(120);
    });

    it('should reset tap array if gap exceeds 2000ms', () => {
        component.tapTempo();                          // time 0
        vi.advanceTimersByTime(500);
        component.tapTempo();                          // time 500, BPM=120
        expect(component.bpm).toBe(120);

        vi.advanceTimersByTime(3500);                  // advance to 4000
        component.tapTempo();                          // gap 3500>2000, reset
        expect(component.bpm).toBe(120);

        vi.advanceTimersByTime(1000);                  // advance to 5000
        component.tapTempo();                          // interval 1000ms, BPM=60
        expect(component.bpm).toBe(60);
    });

    it('should ignore intervals less than 200ms', () => {
        component.tapTempo();                          // time 0
        vi.advanceTimersByTime(150);
        component.tapTempo();                          // time 150, interval ignored
        expect(component.bpm).toBe(120);

        vi.advanceTimersByTime(1050);                  // advance to 1200
        component.tapTempo();                          // interval 1050ms, BPM=57
        expect(component.bpm).toBe(57);
    });
});
```

This approach:
- Uses Vitest's built-in fake timer system which properly isolates time
- Avoids Zone.js interference since `vi.useFakeTimers()` replaces the timer system at the Vitest level
- Is cleaner and more readable than manual `Date.now()` spying
- Automatically restores real timers via `afterEach`

---

## Files to modify

| File | Change |
|------|--------|
| [`src/app/header/header.component.spec.ts`](src/app/header/header.component.spec.ts) | Add `beforeEach` with `Storage.prototype` mock |
| [`src/app/metronome/metronome.component.spec.ts`](src/app/metronome/metronome.component.spec.ts) | Replace `vi.spyOn(Date, 'now')` with `vi.useFakeTimers()` in `tapTempo` describe block |

## Verification

Run `ng test` and confirm:
- HeaderComponent: all 5 tests pass
- MetronomeComponent: all tapTempo tests pass (3 tests)
- No regressions in other tests