# Plan: Wdrożenie brakujących narzędzi Domain Tools dla AI

## Analiza obecnego stanu

**Co już działa:**
- [`DomainService`](src/app/domain/domain.service.ts) — rejestruje 8 command handlerów i 8 query handlerów
- [`domain-tools.ts`](src/app/chat/tools/domain-tools.ts) — implementuje tylko **4** narzędzia Langchain:
  - `show_pattern` → `show-pattern`
  - `show_interval` → `show-interval`
  - `clear_view` → `clear-view`
  - `get_current_view` → `get-current-view`

**Brakuje 12 narzędzi** — wszystkie poniższe są zarejestrowane w `DomainService` ale nie mają odpowiedników Langchain:

| Lp. | Nazwa narzędzia (Langchain) | Komenda/Kwerenda | Typ |
|-----|---------------------------|-------------------|-----|
| 1 | `compare_patterns` | `compare-patterns` | command |
| 2 | `set_view` | `set-view` | command |
| 3 | `set_emphasis` | `set-emphasis` | command |
| 4 | `resolve_shape` | `resolve-shape` | command |
| 5 | `set_ai_mode` | `set-ai-mode` | command |
| 6 | `get_available_patterns` | `get-available-patterns` | query |
| 7 | `get_pattern_details` | `get-pattern-details` | query |
| 8 | `detect_chord` | `detect-chord` | query |
| 9 | `detect_scale` | `detect-scale` | query |
| 10 | `get_key_analysis` | `get-key-analysis` | query |
| 11 | `get_available_shapes` | `get-available-shapes` | query |
| 12 | `resolve_shape_query` | `resolve-shape-query` | query |

## Krok 1: Rozszerzenie `domain-tools.ts`

Dodać 12 nowych narzędzi Langchain do funkcji `createDomainTools()`.

### 1.1 `compare_patterns` (command)

```typescript
const comparePatternsSchema = z.object({
  primary: z.object({
    patternType: z.enum(["scale", "chord"]),
    patternName: z.string(),
    rootNote: z.string(),
  }),
  secondary: z.object({
    patternType: z.enum(["scale", "chord"]),
    patternName: z.string(),
    rootNote: z.string(),
  }),
});
```

- Wywołuje: `domainService.execute({ type: 'compare-patterns', primary, secondary })`
- Zwraca: `{ success, action: 'compare-patterns', primary, secondary, message }`

### 1.2 `set_view` (command)

```typescript
const setViewSchema = z.object({
  fretRange: z.object({ min: z.number(), max: z.number() }).optional(),
  enabledStrings: z.array(z.boolean()).length(6).optional(),
  markerDisplayMode: z.enum(["interval-colors", "note-names", "neutral-dots"]).optional(),
});
```

- Wywołuje: `domainService.execute({ type: 'set-view', ... })`
- Zwraca: `{ success, action: 'set-view', message }`

### 1.3 `set_emphasis` (command)

```typescript
const setEmphasisSchema = z.object({
  emphasis: z.object({
    intervals: z.array(z.string()).optional(),
    roles: z.array(z.string()).optional(),
  }),
});
```

- Wywołuje: `domainService.execute({ type: 'set-emphasis', emphasis })`
- Zwraca: `{ success, action: 'set-emphasis', emphasis, message }`

### 1.4 `resolve_shape` (command)

```typescript
const resolveShapeSchema = z.object({
  shapeId: z.string().describe("ID kształtu, np. 'cowboy-C', 'barre-E-form'"),
  rootNote: z.string().optional().describe("Root note dla movable shapes (barre)"),
});
```

- Wywołuje: `domainService.execute({ type: 'resolve-shape', shapeId, rootNote })`
- Zwraca: `{ success, action: 'resolve-shape', shapeId, rootNote, message }`

### 1.5 `set_ai_mode` (command)

```typescript
const setAiModeSchema = z.object({
  enabled: z.boolean(),
});
```

- Wywołuje: `domainService.execute({ type: 'set-ai-mode', enabled })`
- Zwraca: `{ success, action: 'set-ai-mode', enabled, message }`

### 1.6 `get_available_patterns` (query)

```typescript
// Brak parametrów — schema: z.object({})
```

- Wywołuje: `domainService.query({ type: 'get-available-patterns' })`
- Zwraca: `{ success, action: 'get-available-patterns', scales: string[], chords: string[], message }`

### 1.7 `get_pattern_details` (query)

```typescript
const getPatternDetailsSchema = z.object({
  patternType: z.enum(["scale", "chord"]),
  patternName: z.string(),
  rootNote: z.string(),
});
```

- Wywołuje: `domainService.query({ type: 'get-pattern-details', patternType, patternName, rootNote })`
- Zwraca: `{ success, action: 'get-pattern-details', patternType, patternName, rootNote, details, message }`

### 1.8 `detect_chord` (query)

```typescript
const detectChordSchema = z.object({
  notes: z.array(z.string()),
});
```

- Wywołuje: `domainService.query({ type: 'detect-chord', notes })`
- Zwraca: `{ success, action: 'detect-chord', notes, chords: string[], message }`

### 1.9 `detect_scale` (query)

```typescript
const detectScaleSchema = z.object({
  notes: z.array(z.string()),
  tonic: z.string().optional(),
  match: z.enum(["exact", "fit"]).optional(),
});
```

- Wywołuje: `domainService.query({ type: 'detect-scale', notes, tonic, match })`
- Zwraca: `{ success, action: 'detect-scale', notes, scales: string[], message }`

### 1.10 `get_key_analysis` (query)

```typescript
const getKeyAnalysisSchema = z.object({
  tonic: z.string(),
  mode: z.enum(["major", "minor"]),
});
```

- Wywołuje: `domainService.query({ type: 'get-key-analysis', tonic, mode })`
- Zwraca: `{ success, action: 'get-key-analysis', tonic, mode, analysis: KeyAnalysis, message }`

### 1.11 `get_available_shapes` (query)

```typescript
const getAvailableShapesSchema = z.object({
  category: z.enum(["cowboy", "barre", "caged", "custom"]).optional(),
});
```

- Wywołuje: `domainService.query({ type: 'get-available-shapes', category })`
- Zwraca: `{ success, action: 'get-available-shapes', shapes: [...], message }`

### 1.12 `resolve_shape_query` (query)

```typescript
const resolveShapeQuerySchema = z.object({
  shapeId: z.string(),
  rootNote: z.string().optional(),
});
```

- Wywołuje: `domainService.query({ type: 'resolve-shape-query', shapeId, rootNote })`
- Zwraca: `{ success, action: 'resolve-shape-query', shapeId, positions: [...], message }`

## Krok 2: Aktualizacja `domain-tools.spec.ts`

Dodać testy dla każdego z 12 nowych narzędzi, wzorując się na istniejących testach:

- Dla **command tools**: sprawdzić czy `domainService.execute()` został wywołany z odpowiednim `DomainCommand`
- Dla **query tools**: sprawdzić czy `domainService.query()` został wywołany z odpowiednim `DomainQuery`
- Dla **failure cases**: sprawdzić czy narzędzie poprawnie obsługuje `success: false` z `DomainService`

## Krok 3: Aktualizacja `chat.service.ts` — system prompt

Dodać do `systemPrompt` w [`chat.service.ts`](src/app/chat/services/chat.service.ts:34-39) opisy nowych narzędzi, np.:

```
"Gdy użytkownik poprosi o porównanie dwóch patternów, użyj compare_patterns. "
"Gdy zapyta o dostępne skale lub akordy, użyj get_available_patterns. "
"Gdy zapyta o analizę tonacji, użyj get_key_analysis. "
"Gdy zapyta o kształty (cowboy chords, barre), użyj get_available_shapes lub resolve_shape. "
"Gdy zapyta o detekcję akordu z nut, użyj detect_chord. "
"Gdy zapyta o detekcję skali z nut, użyj detect_scale. "
```

## Krok 4: Weryfikacja

- `npm test` — wszystkie testy (istniejące + nowe) przechodzą
- `npm run build` — kompilacja TypeScript bez błędów

## Diagram przepływu

```mermaid
flowchart LR
    A[Użytkownik] -->|wiadomość| B[Chat Service]
    B -->|wywołanie narzędzia| C[domain-tools.ts]
    C -->|DomainCommand| D[DomainService.execute]
    C -->|DomainQuery| E[DomainService.query]
    D --> F[Handler registry]
    E --> G[Query registry]
    F --> H[Serwisy aplikacji]
    G --> H
    H --> I[Fretboard / Stan]
```

## Uwagi

- Wszystkie narzędzia używają tego samego wzorca co istniejące 4 — nie ma potrzeby zmiany architektury
- `set_ai_mode` jest specyficzne — zmienia tylko `mode: 'ai'` w stanie, nie wpływa na gryf. AI powinno wiedzieć kiedy go użyć
- `resolve_shape` i `resolve_shape_query` różnią się: pierwszy wyświetla na gryfie, drugi tylko zwraca pozycje
- Opisy narzędzi (description) powinny być po polsku, zgodnie z istniejącą konwencją