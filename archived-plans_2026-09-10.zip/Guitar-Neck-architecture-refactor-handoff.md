# Guitar Neck UI — notatka architektoniczna / handoff do dalszej pracy

**Data:** 2026-09-07  
**Repo:** `amadler/Guitar-neck-UI`  
**Stan odniesienia:** `master` po pracach nad Domain API + otwarty PR #10 (`feat/caged-minor-shapes`)  
**Cel dokumentu:** zebrać niedomknięte tematy architektoniczne, ustalenia, problemy i proponowaną kolejność dalszej pracy tak, aby można było wrócić do tematu z innym agentem bez odtwarzania całej historii.

---

## 1. Kontekst produktu

Guitar Neck UI to edukacyjny wizualizator gryfu. Gryf jest centrum produktu.

Najważniejsze scenariusze:

- pokazanie skali na gryfie,
- pokazanie akordu,
- pokazanie relacji skala–akord,
- pokazanie konkretnych pozycji / shape’ów,
- docelowo praca z CAGED i innymi sposobami organizacji gryfu,
- AI ma korzystać z tego samego kontraktu domenowego co aplikacja, ale nie ma samodzielnie liczyć teorii muzyki.

Aktualny kierunek produktu jest prosty: nie budujemy rozbudowanej platformy edukacyjnej ani ciężkiej architektury. Najważniejsze są czytelność gryfu, teoria muzyki i łatwe rozwijanie kolejnych sposobów prezentacji.

---

## 2. Obecny istotny przepływ

W dużym uproszczeniu:

```text
Toolbox / przyszły AI
        ↓
DomainService
        ↓
FretboardOrchestrationService
        ↓
TonalFacadeService / NotePositionService / MarkerRoleService
        ↓
FretboardStateService
        ↓
Fretboard UI
```

Dodatkowo obecnie istnieje `PatternBuilderService`, który równolegle buduje i przechowuje dane o aktualnym patternie.

To właśnie tutaj pojawia się pierwszy ważny problem architektoniczny.

---

## 3. Canonical state — co nim jest

W `src/app/domain/state.ts` istnieje `DomainState`.

Jest świadomie opisany jako:

> minimal, immutable source of truth

Obecnie zawiera m.in.:

```ts
mode
rootNote
patternName
compareTarget
fretRange
enabledStrings
emphasis
markerDisplayMode
selectedNotes
shapeInfo
```

`patternType` nie jest osobnym polem — jest wyprowadzany z `mode`.

Przykład:

```ts
{
  mode: 'scale',
  rootNote: 'C',
  patternName: 'major'
}
```

To oznacza: użytkownik aktualnie ogląda skalę C major.

To jest **canonical state**.

Canonical state powinien przechowywać decyzje / intencję użytkownika i minimalny stan potrzebny do odtworzenia widoku.

---

## 4. Derived state — co nim powinno być

Derived state to dane, które można jednoznacznie ponownie obliczyć z canonical state.

Przykład: z

```ts
{
  mode: 'scale',
  rootNote: 'C',
  patternName: 'major'
}
```

można wyliczyć:

```ts
PatternInfo {
  name: 'major',
  rootNote: 'C',
  type: 'scale',
  notes: ['C', 'D', 'E', 'F', 'G', 'A', 'B'],
  intervals: [...],
  semitones: [...],
  steps: [...]
}
```

`PatternInfo` nie opisuje nowej decyzji użytkownika. Jest wynikiem:

```text
rootNote + patternName + patternType
```

Dlatego powinien być **derived**, a nie drugim niezależnie zapisywanym stanem.

To samo dotyczy `relatedChord`.

Jeżeli `DomainState.compareTarget` mówi:

```ts
{
  rootNote: 'G',
  patternName: 'major',
  patternType: 'chord'
}
```

to `relatedChord: PatternInfo` można z tego ponownie wyliczyć.

---

# 5. Problem nr 1 — PatternBuilderService

## Jak działa obecnie

`PatternBuilderService`:

- trzyma `currentPattern` jako Angular `signal`,
- trzyma `relatedChord` jako Angular `signal`,
- buduje `PatternInfo`,
- mutuje `FretboardStateService.currentSelection`,
- jest ręcznie synchronizowany przez `DomainService`.

Czyli obecnie przy zmianie patternu dzieje się w praktyce coś w rodzaju:

```text
DomainService
  ├─ aktualizuje DomainState
  ├─ wywołuje PatternBuilder.setCurrentPattern()
  └─ czasem PatternBuilder.setRelatedChord()
```

Problemem **nie jest brak reaktywności**. `PatternBuilderService` jest reaktywny, bo korzysta z `signal()`.

Problemem jest to, że mamy **drugi reaktywny store z informacją, którą już posiada canonical DomainState**.

Potencjalny stan niespójny:

```text
DomainState:
  C major

PatternBuilder.currentPattern:
  A minor
```

Nawet jeśli obecny kod stara się pilnować synchronizacji, architektura wymaga pamiętania o aktualizacji kilku miejsc.

## Wniosek

`PatternBuilderService` nie powinien być właścicielem niezależnego stanu.

Docelowo:

```text
DomainState
   ↓
computed / derived
   ├─ currentPattern
   └─ relatedChord
```

Zmiana canonical state automatycznie powoduje przeliczenie derived state.

## Co konkretnie zrobić

### Krok 1 — znaleźć wszystkich konsumentów

Przed zmianą zmapować użycie:

- `PatternBuilderService`,
- `currentPattern`,
- `relatedChord`,
- `setCurrentPattern`,
- `setRelatedChord`,
- `clearCurrentPattern`,
- `FretboardStateService.currentSelection`.

Wiadomo już, że `PatternDisplayComponent` korzysta równocześnie z:

```text
DomainService.currentState
PatternBuilder.currentPattern
PatternBuilder.relatedChord
```

To jest jeden z głównych symptomów obecnego problemu.

### Krok 2 — oddzielić budowanie PatternInfo od przechowywania stanu

Logika budowania `PatternInfo` powinna zostać stateless.

Najprostszy wariant:

```ts
buildPatternInfo(patternName, rootNote, type): PatternInfo
```

Może to być czysta funkcja, jeśli nie potrzebuje DI.

Jeżeli po refaktorze okaże się, że sensownie korzysta z zależności typu `TonalFacadeService`, można zostawić cienki stateless service.

Najważniejsza decyzja:

> nie chodzi ideologicznie o „function vs service”; chodzi o usunięcie drugiego mutable state.

### Krok 3 — currentPattern jako derived signal

Kierunek:

```ts
currentPattern = computed(() => {
  const state = domainState();

  if (state.mode !== 'scale' && state.mode !== 'chord') {
    return null;
  }

  return buildPatternInfo(
    state.patternName,
    state.rootNote,
    state.mode
  );
});
```

Szczegóły zależą od tego, gdzie finalnie żyje view model.

### Krok 4 — relatedChord jako derived signal

Źródłem powinno być `DomainState.compareTarget`, a nie osobny `.set()`.

### Krok 5 — usunąć ręczną synchronizację z DomainService

Docelowo znikają wywołania typu:

```ts
patternBuilder.setCurrentPattern(...)
patternBuilder.setRelatedChord(...)
patternBuilder.clearCurrentPattern()
```

---

# 6. Problem nr 2 — duplikacja w FretboardStateService

`FretboardStateService` obecnie zawiera m.in.:

```ts
notes: GuitarNote[]
hasActiveResult
currentSelection
scaleChordState
```

oraz mutuje fizyczny render state nut:

```ts
visible
selected
interval
```

## Co jest tutaj prawidłowe

`FretboardStateService` ma sens jako stan renderowania gryfu.

Czyli:

> co faktycznie jest widoczne / zaznaczone na gryfie.

To jest inna odpowiedzialność niż `DomainState`.

Rozdzielenie:

```text
DomainState
= co użytkownik chce oglądać

FretboardState
= jak aktualnie wygląda wyrenderowany gryf
```

jest sensowne.

## Co wymaga sprawdzenia

Podejrzane są:

```ts
currentSelection
scaleChordState
```

bo przechowują informacje semantyczne bardzo podobne do:

```ts
DomainState.mode
DomainState.rootNote
DomainState.patternName
DomainState.compareTarget
```

Na razie **nie usuwać ich automatycznie**.

Najpierw znaleźć wszystkich konsumentów.

Prawdopodobny rezultat:

- fizyczne `notes`, `visible`, `selected`, `hasActiveResult` zostają w `FretboardStateService`,
- semantyczne `currentSelection` może okazać się zbędnym duplikatem,
- `scaleChordState` może być zastąpione derived selection z DomainState albo uproszczone do danych potrzebnych wyłącznie rendererowi / `MarkerRoleService`.

To powinien być osobny mały krok po PatternBuilderze.

---

# 7. FretboardOrchestrationService — zostawić

Początkowo był podejrzany jako dodatkowa warstwa, ale analiza kodu pokazała, że ma realną odpowiedzialność.

Aktualnie koordynuje pipeline:

```text
Tonal / teoria muzyki
        ↓
pozycje na gryfie
        ↓
highlight
        ↓
interwały / role
        ↓
FretboardState
```

Przykładowe operacje:

```ts
displayScale()
displayChord()
displayCustomPattern()
displayPositions()
displayScaleWithChord()
clearFretboard()
```

Szczególnie `displayScaleWithChord()` wykonuje realną logikę aplikacyjną:

- resolve skali,
- resolve akordu,
- obliczenie chord tones spoza skali,
- znalezienie pozycji,
- highlight,
- przygotowanie danych do marker roles.

## Wniosek

Na tym etapie **nie usuwać `FretboardOrchestrationService`**.

Przeniesienie tego wszystkiego do `DomainService` stworzyłoby god-service.

Docelowo sensowny układ:

```text
DomainService
       ↓
FretboardOrchestrationService
       ↓
FretboardStateService
```

---

# 8. DomainService i walidacja — otwarty temat

Obecny `DomainService` waliduje komendy przez `DomainValidator`.

W trakcie analizy pojawiło się ważne rozróżnienie.

## Toolbox

Toolbox:

- korzysta z kontrolowanych selectów,
- buduje typed `DomainCommand`,
- nie jest niezaufanym wejściem tekstowym.

Czyli wiele walidacji jest tam redundantnych.

## AI

AI:

- generuje dane z języka naturalnego,
- jest wejściem niezaufanym,
- może wygenerować nieistniejący pattern, zły root, błędny zakres itd.

Tutaj walidacja jest konieczna.

## Docelowy kierunek

Logicznie:

```text
Toolbox
   ↓
typed trusted DomainCommand
   ↓
DomainService

AI
   ↓
AI adapter / parser / validator
   ↓
validated DomainCommand
   ↓
DomainService
```

`DomainService` może nadal bronić kluczowych invariantów, ale nie musi być ciężką warstwą parsing + validation dla każdego źródła.

**Nie robić tego jednocześnie z PatternBuilder refactorem.** To osobny cleanup po uporządkowaniu state.

---

# 9. Problem nr 3 — struktura katalogów

Obecnie jeden feature jest rozrzucony pomiędzy:

```text
domain/
services/
shared/
toolbox/
pattern-display/
...
```

Przy pracy nad konkretnym zachowaniem trzeba skakać przez znaczną część repo.

Dla małego/średniego projektu komplikuje to orientację.

## Proponowany kierunek

Feature-first, ale płytki:

```text
src/app/
  domain/
  fretboard/
  music-theory/
  shapes/
  toolbox/
  pattern-display/
```

Przykładowo:

```text
fretboard/
  fretboard.component.*
  fretboard-state.service.ts
  note-position.service.ts
  marker-role.service.ts

music-theory/
  tonal-facade.service.ts
  tonal-adapter.ts
  pattern-resolver.ts

shapes/
  guitar-shapes.ts
  shape-resolver.service.ts
```

Nie tworzyć wielopoziomowej Clean Architecture.

## Kolejność

Najpierw:

1. PatternBuilder refactor,
2. analiza duplicated state,

potem:

3. przenoszenie plików.

Inaczej najpierw przeniesiemy bałagan, a za chwilę będziemy ponownie zmieniać te same pliki.

---

# 10. Problem nr 4 — pattern vs sposób przedstawienia na gryfie

To najważniejszy nowy wniosek wynikający z pracy nad CAGED.

## Obecnie

Skala i akord korzystają ze wspólnego źródła teorii:

```text
TonalFacade.resolvePattern(...)
        ↓
notes / intervals
        ↓
NotePositionService.findPositionsByScaleNotes(...)
```

Czyli np.:

```text
D minor
→ D F A
→ wszystkie pozycje D/F/A na gryfie
```

Natomiast shape’y działają osobnym torem:

```text
GUITAR_SHAPES
        ↓
ShapeResolverService
        ↓
konkretne string/fret
        ↓
displayPositions()
```

Cowboy, barre i obecny CAGED są więc traktowane jak osobna treść muzyczna.

To jest niepotrzebne rozdzielenie.

---

# 11. Właściwszy model: pattern + projection / layout

Akord lub skala powinny najpierw zostać rozwiązane jako **pattern muzyczny**.

Przykład:

```text
root = D
patternType = chord
patternName = minor

→ notes = D F A
→ intervals = 1 b3 5
```

Dopiero potem wybieramy sposób przedstawienia:

```text
Pattern: D minor
      ↓
projection/layout
      ├─ full fretboard
      ├─ cowboy
      ├─ barre
      └─ CAGED
```

To samo dla skali:

```text
Pattern: D dorian
      ↓
projection/layout
      ├─ full fretboard
      └─ CAGED
```

Czyli:

> cowboy / barre / CAGED nie są inną teorią muzyki. Są innymi sposobami przedstawienia tego samego patternu na gryfie.

## Ważne doprecyzowanie

Nie oznacza to, że wszystkie projekcje mają identyczną geometrię.

### Full fretboard

Pokazuje wszystkie wystąpienia nut należących do patternu.

### Cowboy

To konkretny fixed voicing — potrzebuje fizycznych współrzędnych.

### Barre

To movable voicing — potrzebuje geometrii shape’u i transpozycji.

### CAGED

Powinien organizować ten sam pattern w pięciu kolejnych pozycjach/formach C–A–G–E–D.

Dla akordów może to być shape/voicing.

Dla skal jest to raczej pozycja / region powiązany z formą CAGED.

Wspólne powinno być więc:

```text
resolve musical pattern
```

a różne:

```text
project pattern to fretboard
```

---

# 12. Potencjalna wspólna warstwa projekcji

Nie jest jeszcze decyzją implementacyjną, ale naturalnym kierunkiem jest coś w rodzaju:

```ts
projectPattern(pattern, projection)
```

np.:

```ts
projectPattern(pattern, {
  layout: 'full-fretboard'
})
```

```ts
projectPattern(pattern, {
  layout: 'caged'
})
```

```ts
projectPattern(pattern, {
  layout: 'caged',
  form: 'E'
})
```

```ts
projectPattern(pattern, {
  layout: 'barre',
  form: 'E'
})
```

Możliwa nazwa odpowiedzialności:

```text
PatternPositionService
PatternProjectionService
FretboardProjectionService
```

Nazwa nie jest jeszcze ustalona.

**Ważne:** nie dodawać nowego serwisu tylko dla „ładnej architektury”. Najpierw określić minimalne API i zobaczyć, czy logika rzeczywiście tworzy osobną odpowiedzialność.

---

# 13. CAGED — czego oczekujemy produktowo

## CAGED nie powinien oznaczać

```text
wybierz:
CAGED Dm-form
```

i pokaż jeden hardkodowany shape.

To jest obecny kierunek PR #10 i nie spełnia celu produktu.

## Oczekiwany scenariusz

Użytkownik wybiera muzyczny pattern, np.:

```text
D minor
```

a aplikacja potrafi zwrócić / pokazać:

```text
C-form position
A-form position
G-form position
E-form position
D-form position
```

czyli pięć kolejnych reprezentacji tego samego Dm wzdłuż gryfu.

Jeszcze ważniejsze: CAGED nie powinien być ograniczony do:

```text
major | minor
```

API powinno działać dla patternów, które aplikacja już potrafi rozwiązać.

Przykładowo:

```text
D maj7
D sus4
D minor pentatonic
D dorian
...
```

Oczywiście sposób projekcji akordu i skali może być inny, ale ich źródłem ma być ten sam resolved pattern.

---

# 14. CAGED — Toolbox vs API

## Toolbox

Nie chcemy przeciążać głównego Toolboxa wyborem:

```text
C / A / G / E / D form
```

Na tym etapie to za dużo sterowania.

Toolbox powinien pozwolić powiedzieć w uproszczeniu:

```text
pokaż D minor w CAGED
```

## API / service

Serwis powinien jednak udostępniać obie możliwości.

### Wszystkie pozycje

```ts
resolveCagedPattern(pattern)
```

→ zwraca 5 pozycji.

### Konkretna pozycja

```ts
resolveCagedPosition(pattern, form)
```

→ zwraca np. tylko E-form.

To będzie przydatne dla:

- AI,
- przyszłego Practice Mode,
- nawigacji Next/Previous,
- kliknięcia konkretnego shape’u,
- bardziej zaawansowanego UI.

## Otwarta decyzja UI

Nie jest jeszcze ustalone, czy fretboard ma:

1. pokazywać wszystkie 5 pozycji jednocześnie,
2. pokazywać jedną aktywną pozycję i nawigację `Previous / Next`,
3. pokazywać wszystkie, ale wyróżniać jedną aktywną.

Ważna decyzja już zapadła:

> przełącznika pozycji C/A/G/E/D nie wkładamy na razie do głównego Toolboxa.

---

# 15. PR #10 — aktualna ocena

PR:

`https://github.com/amadler/Guitar-neck-UI/pull/10`

Branch:

```text
feat/caged-minor-shapes
```

PR implementuje obecnie:

- 5 hardkodowanych minor CAGED shapes:
  - `caged-Cm-form`
  - `caged-Am-form`
  - `caged-Gm-form`
  - `caged-Em-form`
  - `caged-Dm-form`
- kategorię `caged`,
- dodatkowe `baseFret`,
- obsługę transpozycji w `ShapeResolverService`,
- UI traktujące CAGED jako trzecią kategorię obok cowboy/barre.

W trakcie review poprawiono:

- błędną możliwość generowania ujemnych progów dla C/G-form,
- testy octave wrap,
- dane / komentarze dla Gm.

Technicznie kod był blisko merge.

## Jednak produktowo / architektonicznie model okazał się zły

Aktualne API jest ustawione:

```text
form → root → shape
```

a powinno raczej być:

```text
pattern → CAGED projection → 5 forms
```

Dlatego:

> PR #10 nie powinien być mergowany tylko dlatego, że przechodzą testy.

Najpierw trzeba zdecydować, czy:

- przerobić go na nowy model,
- czy zamknąć i zrobić replacement PR.

## Co można z PR #10 wykorzystać

Potencjalnie przydatne są:

- przetestowana logika transpozycji geometrycznych shape’ów,
- `baseFret` jako koncepcja dla form, w których root nie jest na najniższym progu,
- testy zgodności interwałów z fizycznymi pozycjami,
- część danych o formach C/A/G/E/D.

Nie należy jednak traktować pięciu minor chord shapes jako fundamentu publicznego CAGED API.

---

# 16. Proponowana kolejność dalszej pracy

## Etap A — uporządkowanie state

### A1. Refactor PatternBuilderService

Cel:

```text
jeden canonical state
+ derived PatternInfo
```

Bez drugiego mutable store.

### A2. Audit FretboardStateService

Sprawdzić:

```ts
currentSelection
scaleChordState
```

i zdecydować, czy są:

- potrzebnym render state,
- derived state,
- czy niepotrzebną kopią DomainState.

## Etap B — uporządkowanie kodu

### B1. Feature-first folders

Po zakończeniu refaktoru state przenieść pliki do logicznych obszarów:

```text
domain/
fretboard/
music-theory/
shapes/
toolbox/
pattern-display/
```

Bez zmiany zachowania.

## Etap C — ujednolicenie pattern projection

Zaprojektować minimalny wspólny pipeline:

```text
resolve pattern
      ↓
projection
      ↓
fretboard positions
      ↓
render
```

Nie przepisywać wszystkiego jednocześnie.

Najpierw doprowadzić do tego, żeby obecne:

```text
full fretboard
cowboy
barre
```

mogły być opisane jako warianty tego samego flow.

## Etap D — poprawny CAGED

Dopiero na nowej podstawie:

```text
pattern + CAGED projection
```

zbudować:

- 5 pozycji,
- API wszystkich pozycji,
- API jednej pozycji,
- minimalny Toolbox,
- później ewentualną nawigację po pozycjach.

## Etap E — wejście AI

Po uporządkowaniu kontraktu:

```text
AI text
  ↓
AI adapter / validation
  ↓
DomainCommand / DomainQuery
```

Nie mieszać walidacji AI z logiką Toolboxa.

---

# 17. Czego świadomie teraz NIE robić

Nie dodawać:

- NgRx,
- CQRS,
- repository layer,
- kolejnych fasad bez konkretnej odpowiedzialności,
- nowych store’ów,
- event sourcing,
- rozbudowanej Clean Architecture.

Nie usuwać na siłę:

- `TonalFacadeService`,
- `FretboardOrchestrationService`.

Oba mają obecnie wyraźną odpowiedzialność.

Nie wkładać derived presentation data do canonical `DomainState` tylko po to, żeby usunąć inny serwis.

---

# 18. Docelowy mental model

```text
                     ┌─────────────────────┐
                     │   Canonical State   │
                     │     DomainState     │
                     └─────────┬───────────┘
                               │
                      derived / computed
                               │
              ┌────────────────┴──────────────┐
              │                               │
        PatternInfo                    related pattern
              │
              └──────────────┬────────────────┘
                             │
                     resolved pattern
                   notes / intervals
                             │
                             ▼
                   projection / layout
              ┌────────┬───────┬────────┐
              │        │       │        │
             full    cowboy   barre   CAGED
              │        │       │        │
              └────────┴───────┴────────┘
                             │
                       fret positions
                             │
                             ▼
              FretboardOrchestrationService
                             │
                             ▼
                    FretboardStateService
                             │
                             ▼
                          Fretboard
```

---

# 19. Najważniejsze decyzje do zapamiętania

1. **`DomainState` pozostaje minimalnym, niemutowalnym canonical state.**
2. **`PatternInfo` i `relatedChord` są derived, nie canonical.**
3. **Problem `PatternBuilderService` to drugi stan, nie brak reaktywności.**
4. **`FretboardOrchestrationService` na razie zostaje.**
5. **Trzeba sprawdzić `currentSelection` i `scaleChordState` pod kątem duplikacji.**
6. **Toolbox jest trusted/typed; AI wymaga silniejszej walidacji na swojej granicy.**
7. **Po refaktorze state przechodzimy na płytką strukturę feature-first.**
8. **Akord/skala to muzyczny pattern; cowboy/barre/CAGED to sposoby projekcji na gryf.**
9. **CAGED nie może być API ograniczonym do `major | minor`.**
10. **Publiczne CAGED API powinno działać na patternie i zwracać 5 pozycji; dodatkowo powinno pozwalać pobrać jedną pozycję.**
11. **Toolbox nie powinien teraz dostać przełącznika C/A/G/E/D.**
12. **PR #10 nie powinien być mergowany w obecnym modelu bez ponownej decyzji architektonicznej.**

---

# 20. Pierwszy prompt dla kolejnego agenta

Jeśli praca ma być kontynuowana od razu, zacząć od:

> Przeanalizuj aktualny `PatternBuilderService`, `DomainState`, `PatternDisplayComponent` i `FretboardStateService`. Celem jest usunięcie `PatternBuilderService` jako niezależnego state holdera bez rozbudowywania canonical `DomainState`. `PatternInfo` i `relatedChord` mają być derived/computed z canonical state. Najpierw zmapuj wszystkich konsumentów `currentPattern`, `relatedChord`, `currentSelection` i `scaleChordState`. Nie zmieniaj jeszcze `FretboardOrchestrationService`, struktury katalogów ani CAGED. Przed implementacją pokaż obecny i docelowy przepływ stanu oraz wskaż, które pola są canonical, derived i render-only.

Dopiero po zakończeniu tego refaktoru przejść do kolejnych etapów opisanych wyżej.
