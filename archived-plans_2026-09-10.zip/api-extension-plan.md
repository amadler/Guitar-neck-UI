# Pełny plan implementacji — Rozszerzenie API

## Decyzje architektoniczne (podsumowanie dyskusji)

1. **Semantyczne API dla AI** — AI opisuje intencję muzyczną, aplikacja oblicza pozycje
2. **RAW API (`show-positions`) istnieje wewnętrznie** — jako metoda serwisowa + do prototypowania z konsoli, NIE wystawiona dla AI
3. **Walidacja każdej pozycji** — string (1-6), fret (0-24), zgodność nuty z pozycją
4. **Detekcja przez Tonal.js** — chord-detect, scale-detect, pcset, key — wystawione przez TonalFacadeService
5. **Shape registry = DANE, nie kod** — cowboy, barre, triady jako wpisy w tablicy
6. **Cowboy/barre = pierwsi konsumenci** nowego API

---

## Krok 1: Wzmocnienie TonalFacadeService — nowe funkcje Tonal.js

**Cel:** Wystawić przez [`TonalFacadeService`](src/app/services/tonal-facade.service.ts) wszystkie funkcje Tonal.js które będą potrzebne.

### Co dodać

```typescript
// W TonalFacadeService

/** Detekcja akordu z listy nut. Woła @tonaljs/chord-detect.detect() */
detectChord(notes: string[]): string[];

/** Detekcja skali z listy nut. Woła @tonaljs/scale.detect() */
detectScale(notes: string[], tonic?: string, match?: 'exact' | 'fit'): string[];

/** Analiza tonacji major. Woła @tonaljs/key.majorKey() */
getMajorKey(tonic: string): MajorKey;

/** Analiza tonacji minor. Woła @tonaljs/key.minorKey() */
getMinorKey(tonic: string): MinorKey;

/** Filtruj nuty — zostaw tylko te należące do setu. Woła @tonaljs/pcset.filter() */
filterNotesBySet(notes: string[], set: string[]): string[];

/** Sprawdź czy set1 jest podzbiorem set2. Woła @tonaljs/pcset.isSubsetOf() */
isSubsetOf(set: string[]): (notes: string[]) => boolean;

/** Sprawdź czy set1 jest nadzbiorem set2. Woła @tonaljs/pcset.isSupersetOf() */
isSupersetOf(set: string[]): (notes: string[]) => boolean;
```

### Pliki do zmiany

| Plik | Zmiana |
|------|--------|
| [`src/app/services/tonal-facade.service.ts`](src/app/services/tonal-facade.service.ts) | Dodać 6 nowych metod |
| [`src/app/services/tonal-facade.service.spec.ts`](src/app/services/tonal-facade.service.spec.ts) | Testy dla każdej nowej metody |

### Testy

- `detectChord(['C', 'E', 'G'])` → `['C major']`
- `detectScale(['C', 'D', 'E', 'F', 'G', 'A', 'B'])` → `['major', 'ionian']`
- `getMajorKey('C')` → zawiera `scale`, `triads`, `chords`
- `filterNotesBySet(['C', 'C#', 'D'], ['C', 'D', 'E'])` → `['C', 'D']`
- `isSubsetOf(['C', 'E'])(['C', 'E', 'G'])` → `true`

---

## Krok 2: Walidacja pozycji — nowe metody w serwisach

**Cel:** Dodać możliwość walidacji i znajdowania konkretnych pozycji `(string, fret)`.

### Co dodać

```typescript
// W FretboardNotePositionService

/** Zwraca nutę na danej pozycji (string, fret) lub null jeśli poza zakresem */
getNoteAtPosition(string: number, fret: number): string | null;

/** Znajduje konkretne pozycje po współrzędnych — nie po chromie */
findPositionsByExactCoordinates(positions: Array<{ string: number; fret: number }>): GuitarNote[];
```

```typescript
// W DomainValidator — nowe walidacje

static validateStringIndex(string: number): DomainResult<never> | null;
static validateFret(fret: number): DomainResult<never> | null;
static validatePosition(string: number, fret: number): DomainResult<never> | null;
static validateNoteAtPosition(string: number, fret: number, expectedNote: string): DomainResult<never> | null;
```

```typescript
// W DomainState — nowe error types

DomainError.INVALID_POSITION     // string/fret poza zakresem
DomainError.POSITION_NOTE_MISMATCH  // nuta nie brzmi na (string, fret)
```

### Pliki do zmiany

| Plik | Zmiana |
|------|--------|
| [`src/app/services/note.service.ts`](src/app/services/note.service.ts) | `getNoteAtPosition()`, `findPositionsByExactCoordinates()` |
| [`src/app/services/note.service.spec.ts`](src/app/services/note.service.spec.ts) | Testy dla nowych metod |
| [`src/app/domain/domain-validator.ts`](src/app/domain/domain-validator.ts) | 4 nowe metody statyczne |
| [`src/app/domain/state.ts`](src/app/domain/state.ts) | 2 nowe `DomainError` wartości |

### Testy

- `getNoteAtPosition(5, 3)` → `'C'` (A-string, 3. próg)
- `getNoteAtPosition(0, 3)` → `null` (string poza zakresem)
- `getNoteAtPosition(1, 25)` → `null` (fret poza zakresem)
- `findPositionsByExactCoordinates([{string:5, fret:3}])` → `[GuitarNote(C, 5, 3)]`
- `validatePosition(5, 3)` → `null` (OK)
- `validatePosition(7, 3)` → `DomainError.INVALID_POSITION`
- `validateNoteAtPosition(5, 3, 'C')` → `null` (OK — C brzmi na A3)
- `validateNoteAtPosition(5, 3, 'F')` → `DomainError.POSITION_NOTE_MISMATCH`

---

## Krok 3: Nowe komendy semantyczne w DomainContract

**Cel:** Dodać 3 nowe komendy dla AI + 3 nowe kwerendy.

### ShowVoicingCommand

```typescript
interface ShowVoicingCommand {
  type: 'show-voicing';
  chordType: string;           // 'maj7', 'min', 'dim' — istniejące nazwy
  rootNote: string;            // 'C', 'F#'
  voicing: {
    stringSet: number[];       // które struny (np. [5,4,3])
    inversion?: number;        // 0=root, 1=1st, 2=2nd
    spread?: boolean;          // rozproszony bas?
    omit?: string[];           // które nuty pominąć (np. ['5'])
  };
  fretRange?: { min: number; max: number };
}
```

**Logika:**
1. Rozwiąż nuty akordu przez [`TonalFacadeService.resolvePattern()`](src/app/services/tonal-facade.service.ts:42)
2. Oblicz przewrót (przesuń nuty cyklicznie o `inversion`)
3. Dla każdej struny w `stringSet`, znajdź najbliższą pozycję zadanej nuty w zadanym `fretRange`
4. Zastosuj `spread` (przesuń niektóre nuty o oktawę)
5. Zastosuj `omit` (usuń wskazane interwały)
6. Wywołaj wewnętrzne `displayPositions()`

### ShowArpeggioCommand

```typescript
interface ShowArpeggioCommand {
  type: 'show-arpeggio';
  chordType: string;           // 'Am', 'Cmajor7'
  rootNote: string;
  pattern: string[];           // sekwencja interwałowa: ['root', '3', '5', '3', 'root']
  strings: number[];           // na których strunach grać
  fretRange?: { min: number; max: number };
}
```

**Logika:**
1. Rozwiąż nuty akordu
2. Mapuj `pattern` (np. `['root', '3', '5']`) na konkretne nuty
3. Dla każdej nuty w patternie, znajdź pozycję na odpowiedniej strunie
4. Wywołaj wewnętrzne `displayPositions()`

### ShowLickCommand

```typescript
interface ShowLickCommand {
  type: 'show-lick';
  notes: Array<{
    note: string;              // nazwa nuty: 'C', 'E', 'G'
    string: number;            // struna 1-6
    fret?: number;             // opcjonalnie: konkretny próg
  }>;
  rootNote?: string;           // dla oznaczeń interwałowych
  label?: string;              // 'Am spread arpeggio'
}
```

**Logika:**
1. Dla każdej pozycji: waliduj `string` (1-6), `fret` (0-24 jeśli podany)
2. Jeśli `fret` nie podany, znajdź najbliższy próg dla `note` na danej strunie w aktualnym `fretRange`
3. Jeśli `fret` podany, sprawdź czy `note` faktycznie brzmi na `(string, fret)` — jeśli nie, zwróć błąd
4. Wywołaj wewnętrzne `displayPositions()`

### Nowe kwerendy

```typescript
interface DetectChordQuery {
  type: 'detect-chord';
  notes: string[];             // nuty do analizy
}
// Zwraca: { chords: string[] }

interface DetectScaleQuery {
  type: 'detect-scale';
  notes: string[];
  tonic?: string;
  match?: 'exact' | 'fit';
}
// Zwraca: { scales: string[] }

interface GetKeyAnalysisQuery {
  type: 'get-key-analysis';
  tonic: string;
  mode: 'major' | 'minor';
}
// Zwraca: MajorKey | MinorKey (z Tonal.js)
```

### Pliki do zmiany

| Plik | Zmiana |
|------|--------|
| [`src/app/domain/commands.ts`](src/app/domain/commands.ts) | 3 nowe interfejsy + rozszerzenie `DomainCommand` |
| [`src/app/domain/queries.ts`](src/app/domain/queries.ts) | 3 nowe interfejsy + rozszerzenie `DomainQuery` |
| [`src/app/domain/state.ts`](src/app/domain/state.ts) | Nowy mode `'positions'`, nowe pole `shapeInfo` |
| [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts) | 3 nowe handlery + rejestracja |
| [`src/app/domain/domain.service.spec.ts`](src/app/domain/domain.service.spec.ts) | Testy dla nowych handlerów |

---

## Krok 4: Wewnętrzne RAW API — displayPositions()

**Cel:** Dodać wewnętrzną metodę do wyświetlania dowolnych pozycji. NIE wystawiona jako komenda dla AI.

```typescript
// W FretboardOrchestrationService
displayPositions(positions: GuitarNote[]): GuitarNote[];

// W FretboardNotePositionService
findPositionsByExactCoordinates(positions: Array<{ string: number; fret: number }>): GuitarNote[];
```

### Pliki do zmiany

| Plik | Zmiana |
|------|--------|
| [`src/app/services/fretboard-orchestration.service.ts`](src/app/services/fretboard-orchestration.service.ts) | `displayPositions()` |
| [`src/app/services/fretboard-orchestration.service.spec.ts`](src/app/services/fretboard-orchestration.service.spec.ts) | Testy |
| [`src/app/services/note.service.ts`](src/app/services/note.service.ts) | `findPositionsByExactCoordinates()` (już w kroku 2) |

---

## Krok 5: Shape registry — dane

**Cel:** Zdefiniować system kształtów i dane dla cowboy/barre/triad.

### Nowy plik: [`src/app/shared/model/guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts)

```typescript
export interface GuitarShape {
  id: string;
  name: string;
  category: 'cowboy' | 'barre' | 'triad-inversion' | 'caged' | 'custom';
  positions: Array<{
    string: number;
    fretOffset: number;  // 0 = root fret position
    label?: string;      // interval label
  }>;
  rootString: number;
  fixedFret?: number;    // dla cowboy chords — stała pozycja
  mutedStrings?: number[];
  stringSet?: number[];  // dla movable shapes
}

// Rejestr
export const GUITAR_SHAPES: GuitarShape[] = [
  // Cowboy chords
  { id: 'cowboy-C', name: 'C major', category: 'cowboy', ... },
  { id: 'cowboy-A', name: 'A major', category: 'cowboy', ... },
  { id: 'cowboy-G', name: 'G major', category: 'cowboy', ... },
  { id: 'cowboy-E', name: 'E major', category: 'cowboy', ... },
  { id: 'cowboy-D', name: 'D major', category: 'cowboy', ... },
  { id: 'cowboy-Am', name: 'A minor', category: 'cowboy', ... },
  { id: 'cowboy-Em', name: 'E minor', category: 'cowboy', ... },
  { id: 'cowboy-Dm', name: 'D minor', category: 'cowboy', ... },
  
  // Barre chords
  { id: 'barre-E-form', name: 'Barre E-form', category: 'barre', ... },
  { id: 'barre-A-form', name: 'Barre A-form', category: 'barre', ... },
  { id: 'barre-Em-form', name: 'Barre Em-form', category: 'barre', ... },
  { id: 'barre-Am-form', name: 'Barre Am-form', category: 'barre', ... },
  
  // Triad inversions (major + minor × 3 string sets × 3 inversions)
  // ...
];
```

### Nowy serwis: [`src/app/services/shape-resolver.service.ts`](src/app/services/shape-resolver.service.ts)

```typescript
@Injectable({ providedIn: 'root' })
export class ShapeResolverService {
  /** Rozwijanie kształtu na konkretne pozycje */
  resolveShape(shapeId: string, rootNote?: string, position?: number): ShapeResolutionResult;
  
  /** Lista dostępnych kształtów */
  getAvailableShapes(category?: string): GuitarShape[];
  
  /** Pobierz kształt po ID */
  getShapeById(shapeId: string): GuitarShape | undefined;
}
```

### Nowa komenda: ResolveShapeCommand

```typescript
interface ResolveShapeCommand {
  type: 'resolve-shape';
  shapeId: string;              // np. 'cowboy-C', 'barre-E-form'
  rootNote?: string;            // dla movable shapes
  position?: number;            // fret position (0 = open)
}
```

`ResolveShapeCommand` rozwija kształt → `ShowLickCommand` i wykonuje go.

### Pliki do zmiany

| Plik | Zmiana |
|------|--------|
| [`src/app/shared/model/guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts) | **NOWY** — typy + dane |
| [`src/app/services/shape-resolver.service.ts`](src/app/services/shape-resolver.service.ts) | **NOWY** — serwis |
| [`src/app/services/shape-resolver.service.spec.ts`](src/app/services/shape-resolver.service.spec.ts) | **NOWY** — testy |
| [`src/app/domain/commands.ts`](src/app/domain/commands.ts) | `ResolveShapeCommand` |
| [`src/app/domain/queries.ts`](src/app/domain/queries.ts) | `GetAvailableShapesQuery`, `ResolveShapeQuery` |
| [`src/app/domain/domain.service.ts`](src/app/domain/domain.service.ts) | Nowe handlery |

---

## Krok 6: Integracja z Toolbox

**Cel:** Dodać nowe opcje w Toolboxie dla cowboy/barre/triad.

### Pliki do zmiany

| Plik | Zmiana |
|------|--------|
| [`src/app/toolbox/toolbox-builder.component.ts`](src/app/toolbox/toolbox-builder.component.ts) | Nowe sekcje UI dla kształtów |
| [`src/app/toolbox/toolbox-builder.component.html`](src/app/toolbox/toolbox-builder.component.html) | Nowe dropdowny + przyciski |
| [`src/app/toolbox/model.ts`](src/app/toolbox/model.ts) | Nowe typy komend dla kształtów |

---

## Mermaid: pełny przepływ

```mermaid
flowchart TD
    subgraph "AI"
        A1[show-voicing]
        A2[show-arpeggio]
        A3[show-lick]
        A4[resolve-shape]
        A5[detect-chord]
        A6[detect-scale]
    end

    subgraph "Toolbox"
        T1[Cowboy chords]
        T2[Barre chords]
        T3[Triad inversions]
    end

    subgraph "DomainService"
        DS[DomainService]
        DV[DomainValidator]
    end

    subgraph "Music Theory"
        TF[TonalFacadeService]
        TF -->|resolvePattern| TONAL1[Tonal.js scale/chord]
        TF -->|detectChord| TONAL2[chord-detect]
        TF -->|detectScale| TONAL3[scale-detect]
        TF -->|getMajorKey| TONAL4[key]
        TF -->|filterNotesBySet| TONAL5[pcset]
    end

    subgraph "Position Resolution"
        SR[ShapeResolverService]
        NS[FretboardNotePositionService]
        NS -->|getNoteAtPosition| NS
        NS -->|findPositionsByExactCoordinates| NS
    end

    subgraph "Display"
        ORCH[FretboardOrchestrationService]
        ORCH -->|displayPositions| SS[FretboardStateService]
        SS -->|applyHighlightedNotes| FRET[Fretboard]
    end

    A1 --> DS
    A2 --> DS
    A3 --> DS
    A4 --> DS
    A5 --> DS
    A6 --> DS
    T1 --> DS
    T2 --> DS
    T3 --> DS

    DS --> DV
    DV -->|pass| TF
    DV -->|pass| NS

    DS -->|resolve-shape| SR
    SR -->|lookup| REG[Shape Registry<br/>guitar-shapes.ts]
    SR -->|resolve positions| NS

    DS -->|show-voicing/arpeggio/lick| ORCH
    ORCH --> NS
    NS --> ORCH
    ORCH --> SS
```

---

## Kolejność implementacji (todo)

### Faza 1: Foundation (krok 1-2)
- [ ] **1a.** Dodać `getNoteAtPosition()` i `findPositionsByExactCoordinates()` w [`note.service.ts`](src/app/services/note.service.ts)
- [ ] **1b.** Dodać walidacje pozycji w [`domain-validator.ts`](src/app/domain/domain-validator.ts)
- [ ] **1c.** Dodać nowe `DomainError` wartości w [`state.ts`](src/app/domain/state.ts)
- [ ] **1d.** Dodać wrapper Tonal.js w [`tonal-facade.service.ts`](src/app/services/tonal-facade.service.ts): `detectChord()`, `detectScale()`, `getMajorKey()`, `getMinorKey()`, `filterNotesBySet()`, `isSubsetOf()`, `isSupersetOf()`
- [ ] **1e.** Dodać `displayPositions()` w [`fretboard-orchestration.service.ts`](src/app/services/fretboard-orchestration.service.ts)

### Faza 2: DomainContract (krok 3)
- [ ] **2a.** Dodać `ShowVoicingCommand`, `ShowArpeggioCommand`, `ShowLickCommand` w [`commands.ts`](src/app/domain/commands.ts)
- [ ] **2b.** Dodać `DetectChordQuery`, `DetectScaleQuery`, `GetKeyAnalysisQuery` w [`queries.ts`](src/app/domain/queries.ts)
- [ ] **2c.** Rozszerzyć `DomainState` o `mode: 'positions'` i `shapeInfo`
- [ ] **2d.** Dodać handlery w [`domain.service.ts`](src/app/domain/domain.service.ts)

### Faza 3: Shape registry (krok 5)
- [ ] **3a.** Stworzyć [`guitar-shapes.ts`](src/app/shared/model/guitar-shapes.ts) z typami
- [ ] **3b.** Stworzyć [`shape-resolver.service.ts`](src/app/services/shape-resolver.service.ts)
- [ ] **3c.** Dodać `ResolveShapeCommand` + kwerendy
- [ ] **3d.** Dodać dane cowboy chords (C, A, G, E, D, Am, Em, Dm)
- [ ] **3e.** Dodać dane barre chords (E-form, A-form, Em-form, Am-form)
- [ ] **3f.** Dodać dane triad inversions (major + minor × 3 string sets × 3 inversions)

### Faza 4: Toolbox UI (krok 6)
- [ ] **4a.** Dodać sekcję cowboy chords w Toolboxie
- [ ] **4b.** Dodać sekcję barre chords w Toolboxie
- [ ] **4c.** Dodać sekcję triad inversions w Toolboxie

### Faza 5: Testy i dokumentacja
- [ ] **5a.** Testy dla wszystkich nowych metod w serwisach
- [ ] **5b.** Testy dla nowych komend w DomainService
- [ ] **5c.** Testy dla shape resolvera
- [ ] **5d.** Aktualizacja [`API_DOCUMENTATION.md`](API_DOCUMENTATION.md)
- [ ] **5e.** Aktualizacja [`docs/api/domain-contract-api.md`](docs/api/domain-contract-api.md)
- [ ] **5f.** Aktualizacja [`BACKLOG.md`](BACKLOG.md) — dodać wpis o rozszerzeniu API

---

## Podsumowanie: co daje AI

| AI mówi | Aplikacja robi | Wynik |
|---------|---------------|-------|
| "pokaż C-dur w I przewrocie na strunach 4-3-2" | `show-voicing` → oblicza pozycje | Wyświetla triadę |
| "pokaż arpeggio Am: root-3-5-3-root" | `show-arpeggio` → mapuje na nuty | Wyświetla sekwencję |
| "pokaż zagrywkę C na 5/3, E na 4/2, G na 3/0" | `show-lick` → waliduje każdą pozycję | Wyświetla zagrywkę |
| "pokaż akord C-dur otwarty" | `resolve-shape` → cowboy-C | Wyświetla C-dur open |
| "pokaż F-dur barre" | `resolve-shape` → barre-E-form, rootNote=F, position=1 | Wyświetla F-dur barre |
| "mam nuty C, E, G — co to za akord?" | `detect-chord` → Tonal.js | "C major" |
| "jakie akordy są w C-dur?" | `get-key-analysis` → Tonal.js | Lista akordów |