# Chat + Agent POC — plan implementacji (Ollama + checkpointer)

## Stack
- `createAgent` z `langchain` (v1.5.10)
- `ChatOllama` z `@langchain/ollama` → lokalny Ollama (`http://localhost:11434`)
- Model: `qwen3:8b`
- Narzędzia: `tool()` + `zod` z `langchain/tools`
- Pamięć agenta: `MemorySaver` + `thread_id` (LangGraph checkpointer)
- UI historia: osobny `ChatMessage[]` w signal
- Bez API key, bez OpenRouter, bez backendu

## Podział odpowiedzialności

```
ChatService (Angular)
├── LangChain agent (createAgent + checkpointer)
├── thread_id (UUID) — klucz do pamięci agenta
├── loading signal
└── ChatMessage[] — wyłącznie do renderowania UI

LangChain
├── MemorySaver + thread_id = pamięć rozmowy
├── agent.invoke({ messages: [nowa wiadomość] }, { configurable: { thread_id } })
├── HumanMessage / AIMessage / ToolMessage
└── agent loop (tool calls)

Domain tools
├── tool() + zod
├── DomainService.execute()
└── zwracają obiekt { success, action, ... }

UI (ChatComponent)
├── renderuje: user messages + final assistant responses
└── nie zna ToolMessage, tool calls, checkpointów
```

## Przepływ

```
User input
   ↓
ChatService.send()
   ├── dopisz ChatMessage { role: "user", text } do UI
   ↓
agent.invoke(
  { messages: [new HumanMessage(userMessage)] },
  { configurable: { thread_id } }
)
   ↓
LangChain memory (MemorySaver + thread_id)
   ↓
final AIMessage
   ↓
dopisz ChatMessage { role: "assistant", text } do UI
```

## Modele

### `src/app/chat/models/chat-message.ts`

```typescript
export interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
}
```

Tylko `user` i `assistant`. Tool execution jest szczegółem LangChain.

## Co się dzieje

### Instalujemy
- `@langchain/ollama`

### Usuwamy (custom agent infrastructure)
- `src/app/chat/models/agent-tool.ts`, `agent-tool-call.ts`, `agent-message.ts`
- `src/app/chat/services/agent-client.interface.ts`
- `src/app/chat/services/gemini-client.service.ts`
- `src/app/chat/services/provider-types.ts`
- `src/app/chat/tools/tool-registry.ts`
- `src/app/chat/tools/domain-tool-executor.ts`

### Przepisujemy
- `src/app/chat/tools/domain-tools.ts`
- `src/app/chat/services/chat.service.ts`
- `src/app/chat/chat.ts`

### Zostawiamy
- `projects/guitar-chat/` — tylko odpinamy import
- `src/app/chat/guide/`
- `src/app/domain/` — bez zmian
- `src/app/services/` — bez zmian

## Krok 1: Zainstalować `@langchain/ollama`

```bash
npm install @langchain/ollama
```

## Krok 2: Narzędzia domenowe — `src/app/chat/tools/domain-tools.ts`

```typescript
import { tool } from "langchain/tools";
import { z } from "zod";
import { DomainService } from "../../domain/domain.service";
import { DomainCommand } from "../../domain/commands";

export function createDomainTools(domainService: DomainService) {
  return [
    tool(
      async ({ patternType, patternName, rootNote, fretRange }) => {
        const command: DomainCommand = {
          type: "show-pattern",
          patternType,
          patternName,
          rootNote,
          fretRange,
        };
        const result = domainService.execute(command);
        return {
          success: result.success,
          action: "show-pattern",
          patternType,
          patternName,
          rootNote,
          message: result.success
            ? `Pokazano ${patternType} ${patternName} (${rootNote})`
            : result.message,
        };
      },
      {
        name: "show_pattern",
        description: "Wyświetla skalę lub akord na gryfie gitary...",
        schema: z.object({
          patternType: z.enum(["scale", "chord"]),
          patternName: z.string().describe("Nazwa patternu"),
          rootNote: z.string().describe("Nuta podstawowa"),
          fretRange: z.object({
            min: z.number().min(0).max(24),
            max: z.number().min(0).max(24),
          }).optional(),
        }),
      }
    ),
    tool(
      async ({ rootNote, interval }) => {
        const command: DomainCommand = { type: "show-interval", rootNote, interval };
        const result = domainService.execute(command);
        return {
          success: result.success,
          action: "show-interval",
          rootNote,
          interval,
          message: result.success
            ? `Pokazano interwał ${interval} od ${rootNote}`
            : result.message,
        };
      },
      {
        name: "show_interval",
        description: "Wyświetla pojedynczy interwał od root note na gryfie",
        schema: z.object({
          rootNote: z.string().describe("Nuta podstawowa"),
          interval: z.string().describe("Nazwa interwału, np. b3, 3, 5, b7"),
        }),
      }
    ),
    tool(
      async () => {
        const result = domainService.execute({ type: "clear-view" });
        return {
          success: result.success,
          action: "clear-view",
          message: result.success ? "Widok wyczyszczony" : result.message,
        };
      },
      {
        name: "clear_view",
        description: "Czyści gryf i resetuje widok do domyślnego stanu",
        schema: z.object({}),
      }
    ),
  ];
}
```

## Krok 3: ChatService — `src/app/chat/services/chat.service.ts`

```typescript
import { Injectable, inject, signal } from "@angular/core";
import { ChatOllama } from "@langchain/ollama";
import { createAgent } from "langchain";
import { MemorySaver } from "@langchain/langgraph-checkpoint";
import { AIMessage, HumanMessage } from "@langchain/core/messages";
import { createDomainTools } from "../tools/domain-tools";
import { DomainService } from "../../domain/domain.service";
import { ChatMessage } from "../models";

@Injectable({ providedIn: "root" })
export class ChatService {
  private domainService = inject(DomainService);

  readonly messages = signal<ChatMessage[]>([]);
  readonly loading = signal(false);

  private threadId = crypto.randomUUID();

  private agent = createAgent({
    model: new ChatOllama({
      model: "qwen3:8b",
      temperature: 0.7,
    }),
    tools: createDomainTools(this.domainService),
    checkpointer: new MemorySaver(),
    systemPrompt:
      "Jesteś pomocnym asystentem gitarzysty. Mów po polsku, krótko i rzeczowo. " +
      "Gdy użytkownik poprosi o pokazanie skali lub akordu na gryfie, użyj narzędzia show_pattern. " +
      "Gdy zapyta o interwał, użyj show_interval. " +
      "Gdy poprosi o wyczyszczenie widoku, użyj clear_view. " +
      "Po wykonaniu narzędzia powiedz użytkownikowi co zostało pokazane.",
  });

  async send(userMessage: string): Promise<void> {
    if (this.loading()) return;
    this.loading.set(true);

    this.messages.update((m) => [...m, { role: "user", text: userMessage }]);

    try {
      const result = await this.agent.invoke(
        { messages: [new HumanMessage(userMessage)] },
        { configurable: { thread_id: this.threadId } }
      );

      const lastAssistantMessage = [...result.messages]
        .reverse()
        .find((m) => m instanceof AIMessage && m.content);
      if (lastAssistantMessage) {
        this.messages.update((m) => [
          ...m,
          { role: "assistant", text: lastAssistantMessage.content as string },
        ]);
      }
    } catch (err) {
      this.messages.update((m) => [
        ...m,
        { role: "assistant", text: "Przepraszam, wystąpił błąd. Spróbuj ponownie." },
      ]);
      console.error("ChatService error:", err);
    } finally {
      this.loading.set(false);
    }
  }

  reset(): void {
    this.threadId = crypto.randomUUID();
    this.messages.set([]);
  }
}
```

## Krok 4: ChatComponent — `src/app/chat/chat.ts`

```typescript
import { Component, inject } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ChatService } from "./services/chat.service";

@Component({
  selector: "app-chat",
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="chat">
      <div class="messages">
        @for (msg of chatService.messages(); track msg) {
          <div class="msg" [class.user]="msg.role === 'user'">
            <p>{{ msg.text }}</p>
          </div>
        }
        @if (chatService.loading()) {
          <div class="msg typing">...</div>
        }
      </div>
      <form #f="ngForm" (ngSubmit)="send()">
        <input name="q" ngModel [(ngModel)]="query" placeholder="Np. pokaż C-dur" />
        <button type="submit" [disabled]="chatService.loading()">Wyślij</button>
      </form>
    </div>
  `,
  styles: [`
    .chat { height: 400px; display: flex; flex-direction: column; border: 1px solid #ccc; border-radius: 8px; }
    .messages { flex: 1; overflow-y: auto; padding: 12px; }
    .msg { margin: 8px 0; padding: 8px 12px; border-radius: 8px; max-width: 80%; }
    .user { background: #1976d2; color: #fff; margin-left: auto; }
    .assistant { background: #e0e0e0; color: #333; margin-right: auto; }
    .typing { color: #999; font-style: italic; }
    form { display: flex; gap: 8px; padding: 10px; border-top: 1px solid #ddd; }
    input { flex: 1; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
    button { padding: 8px 16px; background: #1976d2; color: #fff; border: none; border-radius: 4px; }
  `],
})
export class ChatComponent {
  chatService = inject(ChatService);
  query = "";

  async send() {
    if (!this.query.trim()) return;
    const q = this.query;
    this.query = "";
    await this.chatService.send(q);
  }
}
```

## Krok 5: Odpiąć `projects/guitar-chat/`

W `home-page.component.ts` zmienić import:
```typescript
import { ChatComponent } from '../chat/chat';
```

## Krok 6: Usunąć custom agent pliki

## Krok 7: `npm run build`

## Podsumowanie zmian

| Co | Było | Jest |
|---|---|---|
| Model | `ChatOpenAI` → OpenRouter | `ChatOllama` → lokalny `qwen3:8b` |
| API key | `process.env["OPENROUTER_API_KEY"]` | Brak |
| Pamięć agenta | Ręczna `BaseMessage[]` w serwisie | `MemorySaver` + `thread_id` |
| UI historia | Mieszana z agent memory | Osobny `ChatMessage[]` signal |
| Tool return | String z "OK:"/"ERROR:" | Obiekt `{ success, action, message }` |
| ToolMessage w UI | Renderowany jako assistant | Nie renderowany |
| `ChatMessage` | `{ role, text, commandSummary, commandSuccess }` | `{ role, text }` — czysty UI |
| Reset | Czyścił ręczną historię | Nowy `thread_id` + czysty `messages` |