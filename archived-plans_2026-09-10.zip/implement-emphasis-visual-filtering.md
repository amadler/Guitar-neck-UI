# Plan: Implement Emphasis Visual Filtering

## Problem

The `emphasis` field in [`DomainState`](src/app/domain/state.ts:55) is correctly stored via [`SetEmphasisCommand`](src/app/domain/commands.ts:56-59) and [`handleSetEmphasis()`](src/app/domain/domain.service.ts:213-218), but **no code reads it** to affect the visual display. When a user says "podświetl kwinty" (highlight fifths), the AI calls `set_emphasis({ intervals: ['5'] })`, the state updates, but the fretboard rendering remains unchanged.

## Root Cause

The rendering pipeline has no emphasis-aware filtering:

| Layer | File | What it does | Emphasis-aware? |
|-------|------|-------------|-----------------|
| Orchestration | [`FretboardOrchestrationService`](src/app/services/fretboard-orchestration.service.ts) | Highlights ALL notes in a pattern | ❌ |
| Display CSS | [`FretboardDisplayService.getMarkerCssClass()`](src/app/services/fretboard-display.service.ts:26-40) | Returns CSS class based on `markerDisplayMode` and interval | ❌ |
| Template | [`freatboard.component.html`](src/app/freatboard/freatboard.component.html) | Renders all selected notes uniformly | ❌ |

## Solution

Add emphasis-aware dimming in the display layer. Notes whose interval is **not** in the emphasis list get a "dimmed" CSS class. Notes whose interval **is** in the emphasis list keep their normal interval color.

### Changes Required

#### 1. [`FretboardDisplayService`](src/app/services/fretboard-display.service.ts)

Add a method to check if a note interval is emphasized:

```typescript
/** Returns true if the given interval should be visually emphasized based on current emphasis spec. */
isEmphasized(interval: string): boolean {
  const emphasis = this.domainService.currentState().emphasis;
  if (!emphasis || !emphasis.intervals || emphasis.intervals.length === 0) {
    return true; // no emphasis = show everything
  }
  // 'root' is the tonic — treat it as '1' for matching
  const normalizedInterval = interval === 'root' ? '1' : interval;
  return emphasis.intervals.includes(normalizedInterval);
}
```

Modify `getMarkerCssClass()` to return a dimmed class when emphasis is active and the note is not emphasized:

```typescript
getMarkerCssClass(interval: string | undefined): string {
  // When a chord relation is active, use role-based coloring instead
  if (this.guitarNeckService.scaleChordState()?.chord) {
    return '';
  }

  const mode = this.domainService.currentState().markerDisplayMode;
  
  if (mode === 'interval-colors' && interval) {
    // Check emphasis — if emphasis is active and this interval is NOT emphasized, dim it
    if (!this.isEmphasized(interval)) {
      return 'fretboard__dot--dimmed';
    }
    return 'fretboard__dot--' + interval;
  }
  
  if (mode === 'note-names') {
    // Even in note-names mode, dim non-emphasized notes
    if (interval && !this.isEmphasized(interval)) {
      return 'fretboard__dot--dimmed';
    }
    return 'fretboard__dot--neutral';
  }
  
  return 'fretboard__dot--neutral-dot';
}
```

#### 2. CSS — Add dimmed style

In [`freatboard.component.scss`](src/app/freatboard/freatboard.component.scss), add:

```scss
/* ---- Emphasis dimming ---- */
.fretboard__dot--dimmed {
  opacity: 0.25;
  background-color: var(--guitar-neck-marker-bg-color);
  color: var(--guitar-neck-marker--color);
}
```

#### 3. AI Tool — Pass emphasis in `show_pattern`

In [`domain-tools.ts`](src/app/chat/tools/domain-tools.ts), the `show_pattern` tool should also accept and pass `emphasis` so the AI can set emphasis in a single command:

```typescript
const showPatternSchema = z.object({
  patternType: z.enum(["scale", "chord"]),
  patternName: z.string(),
  rootNote: z.string(),
  fretRange: z.object({ min: z.number(), max: z.number() }).optional(),
  emphasis: z.object({
    intervals: z.array(z.string()).optional(),
    roles: z.array(z.string()).optional(),
  }).optional(),
});
```

And pass it through in the tool handler:

```typescript
const command: DomainCommand = {
  type: "show-pattern",
  patternType: input.patternType,
  patternName: input.patternName,
  rootNote: input.rootNote,
  fretRange: input.fretRange,
  emphasis: input.emphasis,
};
```

### How It Works

1. User says "podświetl kwinty" → AI calls `set_emphasis({ intervals: ['5'] })`
2. `DomainState.emphasis` is set to `{ intervals: ['5'] }`
3. When the fretboard re-renders, `getMarkerCssClass()` is called for each note
4. For notes with interval `'5'` (perfect-5th): normal interval color is applied
5. For notes with other intervals (root, 2, 3, 4, 6, 7): `fretboard__dot--dimmed` class is applied → they appear faded
6. The user sees only the fifths highlighted, other notes dimmed

### Edge Cases

- **No emphasis set**: All notes display normally (no dimming)
- **Empty emphasis.intervals**: All notes display normally
- **`markerDisplayMode: 'neutral-dots'`**: Dimming still applies — dimmed notes get the dimmed class, emphasized notes get neutral-dot class
- **`markerDisplayMode: 'note-names'`**: Dimming applies — non-emphasized notes get dimmed, emphasized notes get neutral
- **Scale-chord (compare) mode**: `getMarkerCssClass()` returns `''` (role-based coloring), so emphasis is not applied during compare mode — this is correct since compare mode has its own visual system
- **Interval `'root'`**: Normalized to `'1'` for emphasis matching, so `emphasis: { intervals: ['1'] }` will highlight the root/tonic

### Files to Modify

1. [`src/app/services/fretboard-display.service.ts`](src/app/services/fretboard-display.service.ts) — add `isEmphasized()` and modify `getMarkerCssClass()`
2. [`src/app/freatboard/freatboard.component.scss`](src/app/freatboard/freatboard.component.scss) — add `.fretboard__dot--dimmed` CSS class
3. [`src/app/chat/tools/domain-tools.ts`](src/app/chat/tools/domain-tools.ts) — add `emphasis` to `show_pattern` schema and handler