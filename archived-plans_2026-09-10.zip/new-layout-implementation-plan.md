# Plan: Nowy layout z Google Slides

## Decyzje architektoniczne (podjęte)

| Decyzja | Wybór | Uzasadnienie |
|---------|-------|-------------|
| BEM vs Tailwind | **BEM** | Spójność z istniejącym kodem, samodokumentujący się HTML |
| Izolacja fretboardu | **Tylko refactor CSS** | Bez zmiany architektury komponentu |
| System kolorów | **CSS Custom Properties** | Jedno źródło prawdy dla markerów i legendy |
| Command Bar | **Na górze, dock znika** | Zwalnia dolny panel, kluczowa zmiana layoutu |
| Bottom Panel | **Scale Info \| Chord Info \| Metronome** | Zastępuje dock + pattern-display |
| Relationship strip | **Wewnątrz sekcji fretboardu, pod gryfem** | Zamiast osobnego komponentu pod spodem |
| Wygląd fretboardu | **Zostaje obecny** | Tylko BEM-izacja nazw klas |
| Footer | **Zostaje** | |
| Legenda interval colors | **Zostaje jak dotąd** — osobno, zależnie od trybu | |
| Metronome | **Pełna funkcjonalność** — tap tempo, time signature zachowane | |
| String toggles | **Zostają w freatboard** — fretboard się nie zmienia | |
| Pattern display | **Nowy wygląd, ta sama funkcjonalność** — notes + intervals + semitones + steps + prompts | |

**Zasada nadrzędna: NIE TRACIMY NIC Z FUNKCJONALNOŚCI**

---

## Fazy implementacji

### Phase 1: CSS Foundation — Marker Palette

**Cel:** CSS Custom Properties jako jedyne źródło prawdy dla kolorów i rozmiarów markerów.

**Pliki do zmiany:**
- `src/styles.scss` — dodać sekcję `--marker-*` properties, usunąć stare `--interval-*` (lub zmapować)
- `src/app/freatboard/freatboard.component.scss` — zmienić `.guitar-neck__root { background: var(--interval-root) }` → `background: var(--marker-root)`
- `src/app/legend/legend.component.scss` — zmienić `.legend-roles__swatch--scale-root { background: var(--interval-root) }` → `background: var(--marker-root)`
- `src/app/relationship-strip/relationship-strip.component.scss` — zmienić hardcoded `#888`, `#2196f3`, `#ffc107` itd. na `var(--marker-*)`

**Nowe zmienne w `:root`:**
```css
:root {
  /* Marker colors — interval layer */
  --marker-root: rgb(168, 18, 35);
  --marker-minor-2nd: rgb(180, 110, 60);
  --marker-major-2nd: rgb(185, 140, 55);
  /* ... wszystkie 12 interwałów ... */

  /* Marker colors — role layer */
  --marker-scale-tone: #888;
  --marker-scale-tone-border: #666;
  --marker-scale-root-glow: #ffc107;
  --marker-chord-tone: #2196f3;
  --marker-chord-tone-border: #1565c0;
  --marker-chord-root-glow: #ffc107;
  --marker-outside-border: #ff9800;

  /* Marker sizes */
  --marker-size: 24px;
  --marker-font-size: 11px;
  --marker-border-radius: 50%;

  /* Neutral markers */
  --marker-neutral-bg: rgba(255, 255, 255, 0.92);
  --marker-neutral-color: rgb(255, 255, 255);
}
```

**Zachować stare `--interval-*` jako aliasy** (lub usunąć i zaktualizować wszystkie referencje).

**Test:** Po zmianie kolory markerów na gryfie i w legendzie są identyczne.

---

### Phase 2: Layout Restructure — home-page.component

**Cel:** Nowa struktura strony: Header → Command Bar → Fretboard Section → Legend/Relationship → Bottom Panel → Footer.

**Pliki do zmiany:**
- `src/app/home-page/home-page.component.html` — całkowita przebudowa
- `src/app/home-page/home-page.component.scss` — nowe style BEM

**Nowa struktura HTML:**
```html
<main class="app-shell">
  <app-header></app-header>

  <section class="command-bar">
    <div class="command-bar__mode">
      <!-- toolbox builder: Show / Compare / Build -->
      <app-toolbox-builder (toolboxEvent)="onToolboxEvent($event)"></app-toolbox-builder>
    </div>
    <div class="command-bar__range">
      <!-- range preset buttons -->
      <app-range-toolbar></app-range-toolbar>
    </div>
  </section>

  <section class="fretboard-section">
    <div class="fretboard-section__neck">
      <app-guitar-neck></app-guitar-neck>
    </div>
    <!-- Legend — shown only for Show commands -->
    <app-legend *ngIf="displayMode() === 'legend'" class="fretboard-section__legend"></app-legend>
    <!-- Relationship strip — shown only for Compare -->
    <app-relationship-strip *ngIf="displayMode() === 'relationship'" class="fretboard-section__relationship"></app-relationship-strip>
  </section>

  <section class="bottom-panel">
    <div class="bottom-panel__scale-info">
      <app-pattern-display></app-pattern-display>
    </div>
    <div class="bottom-panel__divider"></div>
    <div class="bottom-panel__chord-info">
      <!-- shared with pattern-display -->
    </div>
    <div class="bottom-panel__divider"></div>
    <div class="bottom-panel__metronome">
      <app-metronome></app-metronome>
    </div>
  </section>

  <app-footer></app-footer>
</main>
```

**Uwagi:**
- `app-legend` i `app-relationship-strip` zostają w `fretboard-section`, pod gryfem — tak jak dotąd, tylko w nowym layoutu
- `app-pattern-display` — nowy wygląd (karty z notes + intervals), ale zachowuje semitones, steps, prompts
- `app-footer` — zostaje

---

### Phase 3: Command Bar Component

**Cel:** Nowy komponent (lub sekcja w home-page) z selects + Apply + Range.

**Nowy komponent:** `src/app/command-bar/` (lub rozbudowa `home-page`)

**Zawartość:**
- Mode label (Show/Compare/Build)
- Key select (12 nut)
- Pattern select (skala/akord w zależności od trybu)
- Drugi rząd selects dla Compare (chord key + chord type)
- Apply button (zielony `#467d53`)
- Range preset buttons: [0–4] [5–9] [9–13] [12–16] [Full] [Custom]

**Styl BEM:**
```scss
.command-bar { }
.command-bar__mode { }
.command-bar__select { }
.command-bar__select--active { }
.command-bar__apply-btn { }
.command-bar__range-group { }
.command-bar__range-btn { }
.command-bar__range-btn--active { }
```

**Uwaga:** `app-range-toolbar` obecnie ma card-style z ikonami. Nowy layout ma proste buttony `[0–4]`. Trzeba przerobić `range-toolbar.component.html`.

---

### Phase 4: Bottom Panel

**Cel:** Trzy kolumny: Scale Info, Chord Info, Metronome.

**Pliki do zmiany:**
- `src/app/pattern-display/pattern-display.component.html` — nowy wygląd (karty), zachowana funkcjonalność
- `src/app/pattern-display/pattern-display.component.scss` — nowy styl BEM
- `src/app/metronome/metronome.component.html` — nowy wygląd (BEM), zachowana funkcjonalność
- `src/app/metronome/metronome.component.scss` — nowy styl

**Styl BEM dla pattern-display:**
```scss
.pattern-card { }
.pattern-card--scale { }
.pattern-card--chord { }
.pattern-card__header { }
.pattern-card__title { }
.pattern-card__notes { }
.pattern-card__intervals { }
```

**Metronome w bottom-panel:**
- Zachowuje: BPM display, +/- buttons, Start/Stop, tap tempo, time signature
- Nowy wygląd: BEM, dopasowany do layoutu

---

### Phase 5: Relationship Strip — nowy wygląd

**Cel:** Relationship strip w nowym wyglądzie (inline legend z kropkami + ikony crown/star).

**Pliki do zmiany:**
- `src/app/relationship-strip/relationship-strip.component.html` — nowy wygląd
- `src/app/relationship-strip/relationship-strip.component.scss` — nowy styl BEM, kolory z `var(--marker-*)`

**Nowy wygląd (z code.html):**
```
Relationship: C Lydian + G Maj7
● Scale Note  👑 Scale Root  ● Chord Tone in Scale  ★ Chord Root  ◯ Chord Outside Scale
Chord tones in scale: G, B, D | Outside: F#
```

**Ikony:**
- 👑 (crown) dla scale-root
- ★ (star) dla chord-root
- Żółty glow (`#fbbf24`) dla obu

---

### Phase 6: Fretboard CSS Refactor (BEM-izacja)

**Cel:** Przeniesienie stylów markerów do osobnych klas, separacja od rysowania gryfu.

**Pliki do zmiany:**
- `src/app/freatboard/freatboard.component.scss` — refactor nazw klas na BEM
- `src/app/freatboard/freatboard.component.html` — aktualizacja nazw klas
- `src/app/services/fretboard-display.service.ts` — aktualizacja zwracanych stringów CSS

**Nowe nazwy BEM:**
```scss
/* Fretboard structure */
.fretboard { }
.fretboard__fret-indices { }
.fretboard__string { }
.fretboard__string--disabled { }
.fretboard__fret { }
.fretboard__nut-label { }
.fretboard__marker { }         /* inlay dots */
.fretboard__marker--double { } /* 12th fret */

/* Note markers */
.fretboard__dot { }
.fretboard__dot--root { background: var(--marker-root); }
.fretboard__dot--minor-2nd { background: var(--marker-minor-2nd); }
/* ... wszystkie interwały ... */

/* Role markers */
.fretboard__dot--role-scale-tone { background: var(--marker-scale-tone); }
.fretboard__dot--role-chord-tone { background: var(--marker-chord-tone); }
/* ... */

/* Neutral markers */
.fretboard__dot--neutral { }
.fretboard__dot--neutral-dot { }
```

**Uwaga:** `fretboard-display.service.ts` ma metody `getMarkerCssClass()` i `getRoleCssClass()` które zwracają stringi jak `'guitar-neck__root'`. Trzeba zaktualizować do `'fretboard__dot--root'`.

---

### Phase 7: Design Tokens z DESIGN.md

**Cel:** Zastosowanie palety kolorów i typografii z `DESIGN.md`.

**Zmiany w `styles.scss`:**
```css
:root {
  /* Design tokens — Organic Professional */
  --md-surface: #f7faf4;
  --md-surface-container: #e9f0e8;
  --md-on-surface: #2c342e;
  --md-primary: #386948;
  --md-on-primary: #e8ffe9;
  --md-secondary: #665e53;
  --md-tertiary: #745c27;

  /* Typography */
  --font-headline: 'Literata', serif;
  --font-body: 'Nunito Sans', sans-serif;
}
```

**Fonty:** Dodać `@import` dla Literata i Nunito Sans w `index.html` lub `styles.scss`.

---

## Kolejność wykonania (tickets)

| # | Task | Pliki | Zależności |
|---|------|-------|-----------|
| 1 | **CSS Custom Properties** — dodać `--marker-*` do `:root`, zaktualizować `freatboard.component.scss`, `legend.component.scss`, `relationship-strip.component.scss` | `styles.scss`, `freatboard.component.scss`, `legend.component.scss`, `relationship-strip.component.scss` | — |
| 2 | **Design tokens** — dodać kolory i fonty z DESIGN.md | `styles.scss`, `index.html` | — |
| 3 | **Command Bar** — stworzyć `command-bar` komponent lub sekcję z selects + Apply + Range | `home-page.component.html`, `home-page.component.scss`, nowy `command-bar/` | 1, 2 |
| 4 | **Range toolbar refactor** — przerobić z card-style na inline buttons | `range-toolbar.component.html`, `range-toolbar.component.scss` | 3 |
| 5 | **Bottom Panel** — stworzyć sekcję z Scale Info, Chord Info, Metronome | `home-page.component.html`, `home-page.component.scss` | 1, 2 |
| 6 | **Pattern display refactor** — nowy wygląd (karty), zachowana funkcjonalność | `pattern-display.component.html`, `pattern-display.component.scss` | 5 |
| 7 | **Metronome refactor** — nowy wygląd, zachowana funkcjonalność | `metronome.component.html`, `metronome.component.scss` | 5 |
| 8 | **Relationship strip** — nowy wygląd (inline legend + ikony) | `relationship-strip.component.html`, `relationship-strip.component.scss` | 1 |
| 9 | **Fretboard BEM refactor** — zmienić nazwy klas, zaktualizować `fretboard-display.service.ts` | `freatboard.component.scss`, `freatboard.component.html`, `fretboard-display.service.ts` | 1 |
| 10 | **Header update** — nowy wygląd BEM | `header.component.html`, `header.component.scss` | 2 |
| 11 | **Cleanup** — usunąć stary dock, nieużywane style, sprawdzić spójność | `home-page.component.html`, `styles.scss` | 3-10 |
| 12 | **Test** — uruchomić `npm test`, sprawdzić wizualnie | — | 11 |

---

## Diagram struktury komponentów

```mermaid
flowchart TD
    AppShell["app-shell (home-page)"]
    
    AppShell --> Header["app-header"]
    AppShell --> CommandBar["command-bar"]
    AppShell --> FretboardSection["fretboard-section"]
    AppShell --> BottomPanel["bottom-panel"]
    AppShell --> Footer["app-footer"]
    
    CommandBar --> Toolbox["app-toolbox-builder<br/>(Show/Compare/Build)"]
    CommandBar --> Range["app-range-toolbar<br/>(preset buttons)"]
    
    FretboardSection --> GuitarNeck["app-guitar-neck"]
    GuitarNeck --> Freatboard["app-freatboard<br/>(string toggles inside)"]
    FretboardSection --> Legend["app-legend<br/>(Show mode)"]
    FretboardSection --> RelationshipStrip["app-relationship-strip<br/>(Compare mode)"]
    
    BottomPanel --> ScaleInfo["pattern-card--scale<br/>(notes + intervals)"]
    BottomPanel --> ChordInfo["pattern-card--chord<br/>(notes + intervals)"]
    BottomPanel --> Metronome["app-metronome<br/>(full: BPM + tap + time sig)"]
```

---

## Podsumowanie — co się zmienia, a co zostaje

### Zmienia się:
1. **Command Bar** na górę zamiast docka na dole
2. **Bottom Panel** z Scale Info, Chord Info, Metronome
3. **Wygląd** — nowa paleta kolorów (Organic Professional), fonty Literata/Nunito Sans
4. **Nazwy klas CSS** — BEM-izacja (guitar-neck__* → fretboard__*)
5. **CSS Custom Properties** — jedno źródło prawdy dla kolorów
6. **Relationship strip** — nowy wygląd (inline legend + ikony)

### Zostaje bez zmian:
1. **Fretboard** — wygląd, string toggles wewnątrz, logika
2. **Legenda interval colors** — osobno, zależnie od trybu
3. **Metronome** — pełna funkcjonalność (tap tempo, time signature)
4. **Pattern display** — wszystkie dane (notes, intervals, semitones, steps, prompts)
5. **Footer**
6. **Wszystkie serwisy** — FretboardOrchestrationService, FretboardStateService, itd.
7. **Toolbox** — tylko zmiana pozycji (z docka do command-bar)